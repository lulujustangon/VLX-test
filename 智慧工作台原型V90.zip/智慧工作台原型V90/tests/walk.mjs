/* 按《演示全流程1019.docx》（2026-10-20 修订版，晚间按参考版改动、夜间按看板改版更新断言）16 步走一遍：每步核对要点的按钮可见、未被遮挡，屏幕上出现该步的关键文字，记录生成耗时，截图。
   用法：node tests/walk.mjs <截图目录> [浏览器路径] [宽x高] */
import { chromium } from "playwright";
import path from "node:path";
import fs from "node:fs/promises";

const out = process.argv[2] || "shots";
const exe = process.argv[3];
const [W, H] = (process.argv[4] || "1920x1080").split("x").map(Number);
await fs.mkdir(out, { recursive: true });
const b = await chromium.launch(exe ? { executablePath: exe, args: ["--no-sandbox"] } : {});
const p = await b.newPage({ viewport: { width: W, height: H }, acceptDownloads: true });
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
p.on("console", (m) => { if (m.type() === "error") errs.push(`console: ${m.text()}`); });
await p.goto(`file://${path.resolve("dist/智慧工作台_V90_汇报演示版.html")}`);
await p.waitForTimeout(1500);
const wait = (ms) => p.waitForTimeout(ms);
const log = (...a) => console.log(...a);
const fail = (m) => { throw new Error(m); };
const shot = async (name) => { await wait(900); await p.screenshot({ path: path.join(out, `${name}.png`) }); };
const body = () => p.evaluate(() => document.body.innerText);

async function click(loc, label) {
  await loc.first().scrollIntoViewIfNeeded();
  const box = await loc.first().boundingBox();
  if (!box) fail(`不可见：${label}`);
  const covered = await loc.first().evaluate((el, pt) => {
    const top = document.elementFromPoint(pt.x, pt.y);
    return top && !el.contains(top) && !top.contains(el) ? `${top.id || ""}.${top.className || ""}` : "";
  }, { x: box.x + box.width / 2, y: box.y + box.height / 2 });
  if (covered) fail(`${label} 被遮挡：${covered}`);
  await loc.first().click();
  await wait(350);
}
/* 屏幕上要出现的关键文字（演示全流程「屏幕内容」列） */
async function expect(step, words) {
  const t = await body();
  const miss = words.filter((w) => !t.includes(w));
  if (miss.length) fail(`${step} 缺少：${miss.join("、")}`);
  const jargon = ["演示", "构造", "模拟", "画面时间", "二级物资", "二次寻源", "实施方案", "＊＊"].filter((w) => t.includes(w));
  if (jargon.length) fail(`${step} 界面出现不该有的词：${jargon.join("、")}`);
  log(`${step} 通过`);
}
async function idle(label, max = 60000) {
  const t0 = Date.now();
  await wait(600);
  await p.waitForFunction(() => !document.querySelector("#emThread .em-chain-live, #emThread .em-caret, #emThread .em-dots, #emThread li.run"), null, { timeout: max }).catch(() => fail(`等不到：${label}`));
  return Date.now() - t0;
}
/* 应急：到达指定阶段，且没有调用中的能力、没有正在输出的回复 */
async function emgIdle(label, phase, max = 60000) {
  const t0 = Date.now();
  await wait(600);
  await p.waitForFunction((ph) => { const E = window.__V92E, r = document.querySelector(".v92-emg"); return E && r && E.phase >= ph && !E.busy && !r.querySelector("li.run") && !r.querySelector(".em-caret,.em-dots"); }, phase, { timeout: max }).catch(() => fail(`等不到：${label}`));
  return Date.now() - t0;
}
const key = async (k) => { await p.mouse.click(Math.round(W * 0.5), 30); await p.keyboard.press(k); };
const clockHM = () => p.evaluate(() => window.DEMO_CLOCK.hm());

/* ===== 第一段 ===== */
await expect("1-1", ["今日简报", "重点事项 7 条", "超期交货督办 2 条", "「供货单状态」督办 2 条", "协议库存匹配待确认 3 条", "新增任务", "一般事项", "我的关注", "夜间巡查（今天 00:30）"]);
await shot("1-1_首页");
await expect("菜单", ["今日简报", "智能办理", "任务跟踪", "动态看板", "智能问数", "我的常用", "也可以直接问"]);
await click(p.locator(".homebrief-root-card.focus"), "重点事项");
await expect("1-2a", ["重点事项 · 7项", "超期交货督办", "订单 4500951207 超期交货"]);
await click(p.locator('[data-homebrief-category="超期交货督办"]'), "超期交货督办");
await expect("1-2b", ["超期交货督办 · 2项", "订单 4500951207 超期交货"]);
await click(p.locator('[data-homebrief-task="S1"]'), "订单 4500951207 超期交货");
await expect("1-2", ["7 月 15 日", "ECP 供应计划确定交货期", "10 月 15 日", "货到忠县驼丘仓库", "ERP 收货单据未同步电子签章平台", "e物资签章", "已超 11 天", "不是供应商违约", "西安西电高压开关有限责任公司"]);
await shot("1-2_工单详情");
await click(p.locator('[data-v93-open="S1"]'), "查看分析过程");
{ const t0 = Date.now(); await p.locator('[data-em-act="s-s1-go"]').first().waitFor({ timeout: 15000 }).catch(() => fail("分析过程没展开完")); log("1-3 展开(ms)", Date.now() - t0); }
await expect("1-3", ["核对工单", "分清情形", "07:32", "08:50", "10 月 16 日已送达忠县驼丘仓库", "查收货卡在哪一步", "研判紧急程度和影响", "较急", "出库领用、到货款结算", "沿实物流调用 4 条思维链", "待决策", "库管员、项目部物资员"]);
await shot("1-3_分析过程");
await click(p.locator('[data-em-act="s-s1-go"]'), "确认，去办理");
await expect("1-4", ["办理收货第 2 步", "ERP 收货单据 → 电子签章平台", "驼丘仓库库管员、项目部物资员", "内部人员推工单；供应商经 e物资提醒", "同步告知", "以您的账号办理，操作留痕", "原来 8 个节点都要人做", "原来人工怎么做"]);
await shot("1-4_确认办理");
await click(p.locator('[data-em-act="s-s1-ok"]'), "确认办理");
log("1-5 办理(ms)", await idle("办理", 40000));
await expect("1-5", ["办理结果核对", "已到达，待签章", "第 3 步", "已推送签章人员和供应商", "已告知项目经理、结算专责"]);
await shot("1-5_办理结果");
await click(p.locator('[data-em-act="s-s1-check"]'), "核对无误，确认");
await idle("确认", 10000);
await expect("1-5b", ["签章完成、ERP 收货后，这张工单自动办结", "8 个步骤中智能体完成 6 个", "任务跟踪", "待签章 · 签章完成后自动办结"]);
await click(p.locator('#emThread [data-em-tab="2"]'), "操作记录");
await expect("1-5c", ["操作记录", "谁做的、依据什么、结果如何", "确认办理", "同步 ERP 收货单据至电子签章平台", "核对办理结果"]);
await shot("1-5_操作记录");
await click(p.locator('#emThread [data-em-tab="0"]'), "工单与分析");
if (await p.locator("#emergencyNotifyCard").isVisible()) fail("没按 E 提醒卡就出来了");

/* ===== 第二段 ===== */
await key("e");
await p.locator("#emergencyNotifyCard").waitFor({ state: "visible", timeout: 5000 }).catch(() => fail("按 E 后提醒卡没弹出"));
if ((await clockHM()) !== "10:15") fail(`提醒时画面时间不是 10:15：${await clockHM()}`);
await expect("2-1", ["应急任务提醒", "10:15", "忠县 110kV 石拔南线 22 号塔滑坡", "运检部提报 23 种抢修物资", "市内 2 小时、省内 4 小时、跨省 8 小时出库"]);
await shot("2-1_应急提醒");
await click(p.locator("[data-approvedui-notice-enter]"), "立即处理");
log("2-2 思考与查找(ms)", await emgIdle("思考与查找", 2, 90000));
await expect("2-2", ["应急物资保障", "保障方案初稿已起草", "本单位资源查找", "23 种有 12 种，缺 11 种", "全域同时查找", "物资公司运营中心", "46 条可用性确认已发出", "应急采购需求 2 种已起草"]);
await shot("2-2_思考与编排");
await key("r");
log("2-3/2-4 归集与方案(ms)", await emgIdle("保障方案", 4, 60000));
await p.locator('[data-emergency-canvas-tab="responses"]').first().click(); await wait(400);
await expect("2-3", ["已发确认", "46", "29", "8/9", "万州在建工程", "11:39", "第 3 批", "看全部"]);
await shot("2-3_寻源与工单跟踪");
await click(p.locator("[data-v95-feed]"), "看全部回复");
await expect("2-3b", ["OPGW 光缆排产要 7 天", "只看最新 5 条"]);
if (!(await p.evaluate(() => /第 1 批[\s\S]*第 2 批/.test(document.querySelector(".v92-emg").textContent)))) fail("2-3 前两批回复的归集记录不在执行步骤里");
await click(p.locator("[data-v95-feed]"), "只看最新 5 条");
await p.locator('[data-emergency-canvas-tab="plans"]').first().click(); await wait(400);
await expect("2-4", ["方案一 送达最快（推荐）", "方案二 协调单位最少", "方案三 运输里程最短", "导出 Word", "导出 Excel", "后续步骤建议", "还有 17 条确认没回复"]);
await shot("2-4_保障方案");
await click(p.locator("[data-v93-submit]"), "报物资部选定");
await emgIdle("报选定", 5, 20000);
await key("r");
log("2-5 选定(ms)", await emgIdle("物资部选定", 6, 30000));
if ((await clockHM()) !== "13:20") fail(`选定后画面时间不是 13:20：${await clockHM()}`);
await expect("2-5a", ["市公司物资部", "选定方案一", "跨单位调拨 2 项", "协议库存紧急发货 3 项", "在建工程借用 1 项", "待建管单位同意", "应急采购 2 种", "确认后发起审批"]);
await click(p.locator('[data-v93-go="db"]'), "确认发起 · 调拨");
await emgIdle("调拨", 6, 30000);
await expect("2-5b", ["未成功", "正被武隆公司库管员处理", "不会重复建单", "调拨单 4900218734 已创建"]);
await click(p.locator('[data-v93-go="xy"]'), "确认发起 · 紧急发货");
await emgIdle("紧急发货", 6, 20000);
await click(p.locator('[data-v93-go="cg"]'), "确认发起 · 应急采购");
await emgIdle("应急采购", 7, 20000);
await expect("2-5", ["后续事项已发起", "ERP 调拨单 2 张已发起", "待对方接收", "应急采购 2 种已提交审批", "到货跟踪和签收由需求单位负责", "又收到 8 条", "按方案一发起的事项", "发起 → 接收 → 办理 → 回执"]);
await shot("2-5_后续事项");

/* ===== 第三段 ===== */
await click(p.locator("#emUserBtn"), "切换");
await click(p.locator('[data-em-who="A"]'), "物资部数字化管理专责");
await wait(1200);
await expect("3-1a", ["今日简报", "要您处理的有 2 件", "电商逾期支付 8 月超期 2,118 张", "8 月工单运营月报", "进入工单运营看板 ›"]);
await shot("3-1_管理岗今日简报");
await click(p.locator("[data-v95-board]"), "进入工单运营看板");
await idle("看板开场", 15000);
await expect("3-1", ["工单运营看板", "8 月在用工单 113 类", "统计期 8 月（自然月）", "118,427", "比 7 月 ↑23%", "4.8%", "37 家单位中 21 家高于平均"]);
if ((await p.locator(".m0-kpis .m0k").count()) !== 2 || (await p.locator(".m0-kpis").innerText()).includes("113")) fail("3-1 指标卡应只有触发量、应办结未办结率两张");
if (!(await p.locator(".m0-kpis .m0-spark svg").count()) || !(await p.locator(".m0-donut svg").count())) fail("3-1 缺迷你走势或构成环形");
const t31 = await body();
if (/4,094|累计/.test(t31.split("智能助手")[0] || "")) log("提示：看板上出现 4,094 或累计字样，请核对");
await shot("3-1_看板首页");
await expect("3-2a", ["按专业", "合同", "7.99%", "61%"]);
await expect("3-2b", ["按单位", "21 家高于平均", "超高压", "35.54%"]);
await p.locator(".v94-pn", { hasText: "按人" }).first().scrollIntoViewIfNeeded();
await expect("3-2c", ["包鑫", "物资公司", "11,533", "协议库存匹配", "胡若涵", "5,660", "靳川", "市南", "3,290", "郭强", "2,925", "供货单状态督办", "向洪伟", "2,320", "采购计划上报（退回）"]);
await shot("3-2_按人");
await click(p.locator('[data-em-act="s-m0-tpl"]'), "组件模板");
await expect("3-2t", ["组件模板 9 种", "指标卡", "迷你走势", "趋势折线", "构成环形", "排名条形", "堆叠柱形", "热力图", "明细表", "异常卡片", "看板上：按专业"]);
await shot("3-2_组件模板");
await click(p.locator('[data-em-act="s-m0-tpl"]'), "收起组件模板");
await p.click("#chatInput"); await p.keyboard.press("Tab");
await p.waitForFunction(() => document.querySelector("#chatInput").value === "8 月未办结率高于平均的单位，按专业拆开", null, { timeout: 8000 }).catch(() => fail("Tab 填入不对"));
await p.keyboard.press("Enter");
log("3-2 对话生成新图(ms)", await idle("新图", 30000));
await expect("3-2d", ["对话生成 · 堆叠柱形", "超期未办结按专业拆分", "看板模板库", "换成热力图"]);
await shot("3-2_对话生成新图");
await p.click("#chatInput"); await p.keyboard.press("Tab");
await p.waitForFunction(() => document.querySelector("#chatInput").value === "换成热力图", null, { timeout: 8000 }).catch(() => fail("Tab 填入不对（热力图）"));
await p.keyboard.press("Enter");
log("3-2 换热力图(ms)", await idle("换热力图", 20000));
await expect("3-2e", ["对话生成 · 热力图", "颜色最深的三格", "云阳仓储 332 条"]);
if (!(await p.locator(".v94-gen .m0-heat").count())) fail("3-2e 没换成热力图");
await shot("3-2_换热力图");
/* 拖右下角调整「按单位」大小、拖标题把「按专业」挪到「各类工单」前面（可选操作） */
const uw = p.locator('.m0w[data-m0w="unit"]');
await uw.scrollIntoViewIfNeeded(); await uw.hover();
const rb = await uw.locator("[data-m0-rs]").boundingBox();
await p.mouse.move(rb.x + 7, rb.y + 7); await p.mouse.down(); await p.mouse.move(rb.x + 140, rb.y + 50, { steps: 8 }); await p.mouse.up(); await wait(400);
const ucol = await p.locator('.m0w[data-m0w="unit"]').evaluate((el) => el.style.gridColumn);
if (ucol === "span 5") fail("3-2f 拖右下角没有改变宽度");
await p.locator('.m0w[data-m0w="rate"]').scrollIntoViewIfNeeded();
const mh = await p.locator('.m0w[data-m0w="major"] .m0w-hd h4').boundingBox(), rt = await p.locator('.m0w[data-m0w="rate"]').boundingBox();
await p.mouse.move(mh.x + 10, mh.y + 5); await p.mouse.down(); await p.mouse.move(rt.x + 30, rt.y + 40, { steps: 10 }); await p.mouse.up(); await wait(400);
const ord = await p.$$eval(".m0w", (a) => a.map((x) => x.dataset.m0w).join(","));
if (ord !== "gen,abn,major,rate,unit,people") fail(`3-2f 拖标题换位置不对：${ord}`);
log("3-2f 拖动与调整大小：通过", ucol, ord);
await p.locator(".v94-pn", { hasText: "异常关注" }).first().scrollIntoViewIfNeeded();
await expect("3-3", ["长时未触发", "剩余异常 10 类", "应办结未办结率高", "电商逾期支付", "49.13%", "环节长时滞留", "9 天"]);
if ((await body()).includes("借用物资")) fail("异常关注里不应出现借用物资");
await shot("3-3_异常关注");
await click(p.locator('[data-em-act="s-m0-ecom"]'), "电商逾期支付");
log("3-4 分析(ms)", await idle("电商逾期支付分析", 40000));
await expect("3-4", ["预警之日起 5 天", "合同约定的支付到期日", "2,109 张", "9 张", "垫江 6 张、綦江 3 张", "工单时限偏紧", "业务风险"]);
if ((await body()).includes("45 天")) fail("不应出现 45 天");
await shot("3-4_电商逾期支付");
await click(p.locator('[data-em-act="s-m0-clue"]'), "形成监督检查线索");
await click(p.locator('[data-em-act="s-m0-clue-ok"]'), "确认");
await idle("线索", 20000);
await click(p.locator('[data-em-act="s-m0-assign"]'), "分配给对应专责");
await idle("分配", 20000);
await key("r");
await idle("专责回复", 20000);
await expect("3-5", ["物资公司供应链监督检查专责", "物资部督查专责", "保留原工单办理时限不变", "同类情况以后不再询问", "操作日志", "15:40"]);
await shot("3-5_线索与专责回复");
await p.click("#chatInput"); await p.keyboard.press("Tab");
await p.waitForFunction(() => document.querySelector("#chatInput").value === "生成 8 月工单运营月报", null, { timeout: 8000 }).catch(() => fail("Tab 填入不对（月报）"));
await p.keyboard.press("Enter");
log("3-6 月报(ms)", await idle("月报", 40000));
await expect("3-6a", ["一、本月概况", "二、历史异常工单分析与处置", "三、异常监控", "4,096", "4,094", "下载 Word"]);
const dl = p.waitForEvent("download", { timeout: 5000 });
await click(p.locator('[data-em-act="s-m0-word"]'), "下载 Word");
log("下载文件：", (await dl).suggestedFilename());
await click(p.locator('[data-em-act="s-m0-save"]'), "保存到我的常用");
await expect("3-6", ["已保存到「我的常用」", "每月最后一天"]);
await shot("3-6_月报");
await click(p.locator('[data-v94-group="track"]'), "任务跟踪");
await expect("3-6b", ["任务跟踪", "电商逾期支付 · 工单时限确认", "专责已回复 · 保留原时限"]);

/* 左侧菜单：管理岗只有工单运营看板；我的常用里出现刚保存的月报（演示路径外，核对能打开） */
if (await p.locator('[data-v94-item="K1A"]').count()) fail("管理岗不应再有我的看板");
await click(p.locator("[data-v95-sched]"), "我的常用");
await expect("我的常用", ["工单运营月报", "每月最后一天 07:00"]);

/* F5 复位 */
await p.reload(); await wait(1500);
if (!(await body()).includes("重点事项 7 条")) fail("F5 后没有回到初始首页");
log("F5 复位：通过");
log("页面错误：", errs.length ? errs.join(" | ") : "无");
await b.close();
if (errs.length) process.exit(1);
