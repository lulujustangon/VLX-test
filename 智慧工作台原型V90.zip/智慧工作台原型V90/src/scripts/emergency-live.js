/* V90 第二段（2026-10-20 按演示全流程 10.20 修订版和李奇霖《应急寻源》确认单改）：忠县应急在汇报现场当下弹出（画面时间 10:15），同一账号处理。
   10 月 20 日晚按董老师意见再改：应急采购需求同步起草，物资部选定方案后由人确认才发起审批（1019-22、1019-23）；以大代小按业务规则提出，经项目部门评判同意后才算备货（李奇霖第 9 题）；
   回复只来自查到有货的单位（李奇霖第 2 步批注）。仍以需求方（忠县公司）视角、点开后开始编排（1019-18、1017-24）。
   左侧：思考与编排 → 查本单位 → 缺口全域同时查找并发可用性确认 → 全省无货的同步起草应急采购需求（都不等人点）→ 对话；
   右侧画布：编排、物资清单、寻源与工单跟踪、保障方案（10:15 起是方案初稿，随进展补全；11:42 出三版）。左侧每一行能力调用都能点开，详情显示在画布最上面。
   演示控件（界面上不显示）键盘 R：第一次，回复分三批到达（10:46、11:12、11:40），归集后约 4 秒 11:42 自动出保障方案；点「报物资部选定」后第二次，跳到 13:20 物资部已选定方案一。
   不按时分别在 35 秒、25 秒后自动跳。后续事项按办理方式分四张卡逐项确认（调拨、紧急发货、在建借用、应急采购）。应急事件、各单位和供应商回复、方案时间与费用为演示设定，见客户交付说明。
   1019 版（需求预估、保障方案后人工发起二次寻源、实施方案两版、生成 5 张工单）源码在 历史版本/智慧工作台_V90_汇报演示版_1019重做版源码/。 */
(() => {
  const EM = window.EM;
  if (!EM) return;
  const h = EM.h;
  const S8 = () => (typeof state !== "undefined" ? state : {});
  const K = 1; /* 整体节奏系数，脚本里的等待时间按 K=1 实测 */
  const CK = () => window.DEMO_CLOCK;

  /* ---------- 数据 ---------- */
  /* 忠县本单位有的 12 种：物资、数量、本单位来源、说明 */
  const LOCAL = [
    ["钢芯铝绞线 JL/G1A-300/40", "2.6 千米", "县公司仓库", "以大代小，代 240/30，项目部门评判后同意"], ["接续管 JY-300/40", "6 只", "县公司仓库", "以大代小，代 240/30 配套，项目部门评判后同意"],
    ["盘形悬式瓷绝缘子 U70BP", "96 片", "应急储备", "同规格"], ["复合绝缘子 FXBW-110/100", "9 支", "应急储备", "同规格"], ["均压环", "12 个", "县公司仓库", "同规格"], ["U 型挂环 U-10", "36 个", "县公司仓库", "同规格"],
    ["直角挂板 Z-10", "24 个", "县公司仓库", "同规格"], ["球头挂环 QP-10", "18 个", "县公司仓库", "同规格"], ["碗头挂板 W-10", "18 个", "县公司仓库", "同规格"], ["联板 L-1040", "6 块", "应急储备", "同规格"],
    ["接地装置（圆钢 φ12）", "1 套", "专业仓和班组库", "同规格"], ["地脚螺栓 M36", "16 根", "本单位在建工程现场", "同规格"],
  ];
  /* 缺的 11 种：物资、数量、11:40 时的来源、渠道、状态（ok 确认可用 / wait 待建管单位同意 / buy 应急采购） */
  const SHORT = [
    ["铁塔", "35.82 吨", "云阳公司", "其他单位库存", "ok"], ["铝包钢绞线", "2.02 吨", "云阳公司", "其他单位库存", "ok"],
    ["110kV 导线跳线（07H(P)Z）", "8 套", "武隆公司", "其他单位库存", "ok"], ["110kV 导线跳线（07H(P)RS）", "4 套", "武隆公司", "其他单位库存", "ok"], ["防振锤 FRYJ-2/G", "20 个", "武隆公司", "其他单位库存", "ok"],
    ["光缆耐张串", "10 套", "金具协议供应商", "协议库存", "ok"], ["光缆悬垂串", "3 套", "金具协议供应商", "协议库存", "ok"], ["光缆余缆架", "2 个", "金具协议供应商", "协议库存", "ok"],
    ["OPGW 光缆", "2.16 千米", "万州在建工程（可借 2.2 千米）", "在建工程借用", "wait"],
    ["铁塔防坠落导轨装置", "134 米", "全省无货", "应急采购", "buy"], ["光缆接头盒", "1 只", "全省无货", "应急采购", "buy"],
  ];
  /* 10:16 发出确认后陆续收到的回复，分三批归集（10:46 前 12 条、11:12 前 10 条、11:40 前 7 条，共 29 条）；这里列出其中 12 条。
     可用性确认只发给全域查找查到有货的单位和供应商，所以「不能供」都是库存已占用或预留、排产赶不上，不出现「没有库存」（李奇霖第 2 步批注） */
  const REPLIES = [
    ["10:21", "云阳公司", "铁塔 35.82 吨可调出，今天 16:00 前装车；铝包钢绞线 2.02 吨可调；跳线两种也有，明天 10:00 后出库", "ok"],
    ["10:24", "武隆公司", "110kV 导线跳线 07H(P)Z 8 套、07H(P)RS 4 套，防振锤 FRYJ-2/G 20 个可调，已备货", "ok"],
    ["10:28", "忠县公司运检部（项目部门）", "同意以大代小 2 种：钢芯铝绞线 JL/G1A-300/40 代 240/30，接续管配套", "ok"],
    ["10:31", "开州公司", "铁塔库存已预留给本单位在建工程，不能调出", "no"],
    ["10:37", "丰都公司", "跳线库存已用于本单位抢修，不能调出", "no"],
    ["10:46", "金具协议供应商（经 ESC）", "光缆耐张串 10 套、悬垂串 3 套、余缆架 2 个，今天 21:00 前送到忠县驼丘仓库", "ok"],
    ["10:52", "江津公司", "防振锤只有 6 个，不够 20 个", "part"],
    ["11:05", "光缆协议供应商（经 ESC）", "OPGW 光缆排产要 7 天，赶不上", "no"],
    ["11:12", "万州公司", "铝包钢绞线库存已用于本单位线路检修，不能调出", "no"],
    ["11:18", "万州在建工程项目部", "OPGW 光缆 2.2 千米满足现场需求，借用需建管单位同意", "wait"],
    ["11:26", "北碚公司", "防振锤只剩 4 个，已预留本单位，不能调出", "no"],
    ["11:33", "涪陵在建工程项目部", "光缆 11 月 1 日就要架设，不能借", "no"],
    ["11:39", "物资公司应急储备库", "110kV 导线跳线 07H(P)Z 有 4 套，可作备用", "part"],
  ];
  const BATCH = [
    { at: [10, 46], upto: "10:46", n: 12, t: "10:21—10:46 收到 12 条：云阳、武隆可调铁塔、钢绞线、跳线和防振锤，金具协议供应商 3 种今天 21:00 前送到，8 种确认可用；开州、丰都库存已占用，不能调出。项目部门同意以大代小 2 种。" },
    { at: [11, 12], upto: "11:12", n: 10, t: "10:47—11:12 又收到 10 条：OPGW 光缆的协议供应商排产要 7 天，赶不上；江津防振锤不够；万州公司库存已用于本单位。" },
    { at: [11, 40], upto: "11:40", n: 7, t: "11:13—11:40 又收到 7 条：万州在建工程项目部可借 OPGW 光缆 2.2 千米，满足现场需求，待建管单位同意；涪陵 11 月 1 日要架设，不能借。" },
  ];
  const PLAN = {
    head: ["比较项", "方案一 送达最快（推荐）", "方案二 协调单位最少", "方案三 运输里程最短"],
    rows: [
      ["铁塔、铝包钢绞线", "云阳调拨 · 今天 18:00", "云阳调拨 · 今天 18:00", "云阳调拨 · 今天 18:00"],
      ["跳线 2 种", "武隆调拨 · 今天 17:30", "云阳调拨 · 明天 12:00", "云阳调拨 · 明天 12:00"],
      ["防振锤", "武隆调拨 · 今天 17:30", "金具协议供应商 · 今天 21:00", "武隆调拨 · 今天 17:30"],
      ["金具 3 种", "金具协议供应商 · 今天 21:00", "金具协议供应商 · 今天 21:00", "金具协议供应商 · 今天 21:00"],
      ["OPGW 光缆", "借万州在建工程 · 今天 22:00", "应急采购 · 后天 14:00", "借万州在建工程 · 今天 22:00"],
      ["接头盒、防坠落导轨", "应急采购 · 选定后确认发起", "应急采购 · 选定后确认发起", "应急采购 · 选定后确认发起"],
      ["全部到齐（不含应急采购 2 种）", "今天 22:00", "后天 14:00", "明天 12:00"],
      ["协调方", "5 方：云阳、武隆、金具协议供应商、万州建管单位、应急采购供应商", "3 方：云阳、金具协议供应商、应急采购供应商", "5 方：云阳、武隆、金具协议供应商、万州建管单位、应急采购供应商"],
      ["运输里程（千米）", "620", "1,900", "510"],
      ["费用（万元，运输＋采购）", "约 43", "约 47", "约 41"],
      ["需注意", "万州借用需建管单位同意", "OPGW 光缆后天才到", "跳线明天 12:00 才到"],
    ],
  };
  /* 物资部选定方案一后的后续事项，按办理方式分四张卡，每张由人确认后发起；应急采购在这里才发起审批（董老师 1019-22、1019-23） */
  const FOLLOW = {
    db: { title: "跨单位调拨 2 项", how: "ERP 调拨单", rows: ["云阳公司 → 忠县驼丘仓库：铁塔 35.82 吨、铝包钢绞线 2.02 吨", "武隆公司 → 忠县驼丘仓库：110kV 导线跳线 8 套、4 套，防振锤 20 个"],
      calls: [["办理", "ERP · 创建调拨单 · 云阳 → 忠县", "调拨单 4900218733 已创建，已推送云阳公司，待接收。", 3400],
        ["办理", "ERP · 创建调拨单 · 武隆 → 忠县", "提交未成功：ERP 返回「物料 110kV 导线跳线 07H(P)Z 正被武隆公司库管员处理，已锁定」。先查重，再重新提交。", 2900, "fail"],
        ["查询", "ERP · 调拨单查重", "按本次提交的参考号查，上一次没有生成调拨单，重新提交不会重复建单。", 1100],
        ["办理", "ERP · 创建调拨单 · 武隆 → 忠县（第 2 次）", "调拨单 4900218734 已创建，已推送武隆公司，待接收。", 3100]],
      done: "ERP 调拨单 2 张已发起：4900218733（云阳）、4900218734（武隆，首次提交遇 ERP 锁定，查重后重提），待对方接收" },
    xy: { title: "协议库存紧急发货 3 项", how: "e物资通知供应商", rows: ["金具协议供应商：光缆耐张串 10 套、光缆悬垂串 3 套、光缆余缆架 2 个，送忠县驼丘仓库"],
      calls: [["协同提醒", "e物资 · 紧急发货通知", "紧急发货通知已发给金具协议供应商，对方已读，待确认。", 1600]], done: "e物资紧急发货通知已发出，供应商已读，待确认" },
    jy: { title: "在建工程借用 1 项", how: "建管单位同意后发起", rows: ["万州在建工程：OPGW 光缆 2.2 千米，满足现场需求"] },
    cg: { title: "应急采购 2 种", how: "确认后发起审批", rows: ["光缆接头盒 1 只、铁塔防坠落导轨装置 134 米：全省无货，前期寻源不能满足现场需求", "询价内容已写好，由您转发应急采购供应商微信群"],
      calls: [["办理", "应急采购需求 · 提交审批", "应急采购需求 2 种已提交，进入应急物资采购审批流程。", 2700]], done: "应急采购 2 种已提交审批；询价内容待您转发应急采购供应商微信群" },
  };
  /* 编排画布的节点：专业组合能力和它调用的原子能力 */
  const NODES = {
    n1: { name: "本单位资源查找", org: "忠县公司", caps: [["查询", "县公司仓库与应急储备"], ["查询", "专业仓和班组库"], ["查询", "本单位在建工程现场"]] },
    n2: { name: "全域同时查找", org: "物资公司运营中心", caps: [["审核", "应急物资管理规范"], ["查询", "其他单位库存与物资公司应急储备库"], ["查询", "协议库存"], ["查询", "在建工程物资"], ["协同提醒", "可用性确认"]] },
    n3: { name: "应急采购需求起草", org: "忠县公司", caps: [["审核", "全域查找结果"], ["写作", "应急采购需求"]] },
    n4: { name: "回复归集", org: "物资公司运营中心", caps: [["查询", "各单位与供应商回复"]] },
    n5: { name: "保障方案生成", org: "物资公司运营中心", caps: [["查询", "确认可用的来源"], ["审核", "送达效率优先"], ["写作", "保障方案"]] },
    n6: { name: "后续事项发起", org: "忠县公司", caps: [["写作", "后续事项清单"], ["办理", "ERP 调拨单"], ["协同提醒", "e物资紧急发货"], ["办理", "应急采购审批"]] },
  };

  /* ---------- 状态（刷新页面即复位） ----------
     phase：0 未开始，1 思考与查找中，2 确认已发出等回复，3 回复已归集（11:40），4 保障方案已出（11:42），5 已报物资部，6 物资部已选定（13:20），7 后续事项已发起 */
  const E = { t0: 0, phase: 0, think: [], ev: [], items: [], node: {}, out: {}, log: [], feed: [], planStep: 0, edit: {}, go: {}, busy: 0, order: ["n1", "n2", "n3", "n4", "n5", "n6"] };
  window.__V92E = E;
  const now = () => Date.now();
  const clock = (ms) => { if (!ms) return ""; const d = new Date(ms); return [d.getHours(), d.getMinutes(), d.getSeconds()].map((n) => String(n).padStart(2, "0")).join(":"); };
  const timers = [];
  const at = (ms, fn) => timers.push(setTimeout(fn, ms * K));
  const logIt = (t, tm) => E.log.push([tm || clock(now()), t]);

  /* 一组原子能力调用：rows 逐个「调用中 → 返回」，全部返回后 done() */
  function runCalls(list, rows, done, start = 0) {
    let t = start;
    rows.forEach((r) => {
      const c = Object.assign({ st: "run" }, r);
      at(t, () => { list.push(c); c.at = now(); paint(); });
      t += r.ms || 1500;
      at(t, () => { c.st = "done"; logIt(`${r.cap} · ${r.call}：${r.t}`); paint(); });
      t += 450;
    });
    at(t, () => { if (done) done(); paint(); });
    return t;
  }
  /* 一项专业组合能力：先出一行「打算」，再逐个调用原子能力 */
  function runNode(key, intent, rows, sum, done, opt = {}) {
    E.node[key] = "run";
    E.busy += 1;
    const ev = { key, name: NODES[key].name, intent, calls: [], st: "run", at: now(), sum: "" };
    if (opt.inStream) E.items.push({ k: "node", ev }); else E.ev.push(ev);
    paint();
    runCalls(ev.calls, rows, () => {
      ev.st = opt.wait ? "wait" : "done"; ev.sum = sum; E.out[key] = sum;
      E.node[key] = opt.wait ? "wait" : "done";
      E.busy -= 1;
      if (done) done();
    }, 800);
  }
  /* 智能体回复：先三个点，再逐字出现 */
  function aiSay(html, after) {
    const m = { k: "ai", html, n: 0, pre: true };
    E.busy += 1;
    E.items.push(m);
    paint();
    const total = EM.textLen(html);
    const step = Math.max(2, Math.ceil(total / 70));
    setTimeout(function tick() {
      m.pre = false;
      m.n += step;
      if (m.n >= total) { m.n = Infinity; E.busy -= 1; paint(); if (after) after(); return; }
      paintStream();
      setTimeout(tick, 30);
    }, 550);
  }
  const typing = () => E.items.some((m) => m.k === "ai" && m.n !== Infinity);
  let fallback = null;
  const armFallback = (fn, ms) => { clearTimeout(fallback); fallback = setTimeout(fn, ms); };

  /* ---------- 2-2 点开后从第一步思考，查本单位、全域同时查找、起草应急采购需求，都不等人点；采购要等方案选定后由人确认 ---------- */
  function start() {
    if (E.t0 || !window.__v90NoticeReleased) return;
    E.t0 = now(); E.phase = 1;
    const th = (cap, call, t, ms) => ({ cap, call, t, ms });
    runCalls(E.think, [
      th("查询", "应急需求工单", "忠县公司运检部提报：110kV 石拔南线 22 号塔受滑坡影响，需移塔改造，抢修物资 23 种。保障要求：市内 2 小时、省内 4 小时、跨省 8 小时出库。", 1400),
      th("查询", "思维链库", "调出「应急物资保障」思维链：先查本单位，缺口在全省同时查找，查到的发可用性确认，不等人点；全省都没有的同步起草应急采购需求，方案选定后由您确认再发起。", 900),
      th("写作", "应急物资保障方案 · 初稿", "按思维链先列出方案框架，后面每一步的结果自动补进去，见右侧「保障方案」。", 3100),
    ], () => {
      E.plan0 = true;
      logIt("按「应急物资保障」思维链编排 6 项专业组合能力");
      openCanvas("flow");
      at(1600, stepLocal);
    }, 700);
  }
  function stepLocal() {
    runNode("n1", "先查忠县自己的：县公司仓库、应急储备、专业仓和班组库，还有本单位管的在建工程现场。", [
      { cap: "查询", call: "ERP · 县公司仓库与应急储备", t: "同规格有货 8 种；另有 2 种可以大代小（钢芯铝绞线、接续管）。", from: "ERP 库存（忠县）", ms: 2800 },
      { cap: "查询", call: "实物资源一体化 · 专业仓和班组库", t: "再有 1 种：接地装置 1 套。", from: "实物资源一体化", ms: 2600 },
      { cap: "查询", call: "本单位在建工程现场物资", t: "再有 1 种：地脚螺栓 M36，16 根。", from: "本单位在建工程台账", ms: 1100 },
      { cap: "协同提醒", call: "项目部门 · 以大代小评判", t: "以大代小 2 种已请项目部门评判，同意后备货。", from: "以大代小规则：项目部门评判后同意", ms: 700 },
    ], "23 种有 12 种，缺 11 种", () => { openCanvas("materials"); at(500, stepAll); });
  }
  function stepAll() {
    runNode("n2", "缺的 11 种在全省同时查：其他单位库存和物资公司应急储备库、协议库存、在建工程一起查，查到的马上发可用性确认。", [
      { cap: "审核", call: "应急物资管理规范", t: "来源先后：其他单位库存和物资公司应急储备库 → 协议库存 → 在建工程借用 → 应急采购。三类渠道同时查，按这个先后选用。", from: "应急物资管理规范", ms: 500 },
      { cap: "查询", call: "ERP · 全省库存与物资公司应急储备库", t: "14 个单位有其中 5 种。", from: "ERP 库存（各单位）", ms: 2300 },
      { cap: "查询", call: "协议库存", t: "9 家协议供应商有其中 4 种（含 OPGW 光缆）。", from: "协议库存", ms: 1200 },
      { cap: "查询", call: "在建工程物资", t: "万州、涪陵 2 个在建工程有 OPGW 光缆。", from: "在建工程物资台账", ms: 1000 },
      { cap: "协同提醒", call: "调拨征询 · 经物资公司运营中心", t: "向 14 个单位发出跨单位调拨征询 31 条。", from: "物资公司运营中心", ms: 1100 },
      { cap: "协同提醒", call: "ESC · 协议库存征询", t: "向 9 家执行供应商发出征询 13 条，回复时间设在 11:30 前。", from: "ESC", ms: 1600 },
      { cap: "协同提醒", call: "在建工程 · 借用征询", t: "向万州、涪陵在建工程项目部发出 2 条。", from: "消息平台", ms: 1100 },
    ], "9 种查到来源，46 条可用性确认已发出", () => { openCanvas("responses"); at(400, stepBuy); });
  }
  function stepBuy() {
    runNode("n3", "光缆接头盒、铁塔防坠落导轨装置全省都没有，不等确认结果，同步把应急采购需求写好；物资部选定方案后，由您确认再发起审批。", [
      { cap: "审核", call: "全域查找结果", t: "光缆接头盒 1 只、铁塔防坠落导轨装置 134 米：其他单位、协议库存、在建工程都没有。", from: "全域查找结果", ms: 1100 },
      { cap: "写作", call: "应急采购需求", t: "应急采购需求 2 种已起草，附规格、数量和全域查找结果；询价内容一并写好，发起时转发应急采购供应商微信群。", from: "应急采购需求单", ms: 3400 },
    ], "应急采购需求 2 种已起草，待确认", () => {
      E.phase = 2; E.sent = now();
      E.node.n4 = "wait";
      E.ev.push({ key: "n4", name: NODES.n4.name, intent: "回复进来后逐条归集，算出哪些物资确认可用。", calls: [], st: "wait", at: now(), sum: "等回复" });
      sideRefresh();
      aiSay("本单位有 12 种，其中以大代小 2 种已请项目部门评判。缺的 11 种里 9 种查到来源，46 条可用性确认已发出，回复陆续进来我归集；全省都没有的 2 种，应急采购需求已写好，物资部选定方案后请您确认发起。");
      armFallback(arrive, 35000); /* 2-2 讲稿比画面生成长约 20 秒，讲完再跳 */
    });
  }

  /* ---------- 2-3 回复归集（R 或 35 秒兜底）：回复分三批到达，画面时间依次到 10:46、11:12、11:40 ---------- */
  function arrive() {
    if (E.phase !== 2 || E.busy) return;
    clearTimeout(fallback);
    E.busy += 1;
    const ev = E.ev.find((x) => x.key === "n4");
    ev.st = "run"; E.node.n4 = "run";
    openCanvas("responses");
    BATCH.forEach((b, i) => at(i * 2600, () => {
      if (CK()) CK().set(b.at[0], b.at[1], 0);
      E.batch = i + 1; E.got = (E.got || 0) + b.n;
      E.feed = REPLIES.filter((r) => r[0] <= b.upto);
      ev.calls.push({ cap: "查询", call: `各单位与供应商回复 · 第 ${i + 1} 批`, t: b.t, from: "调拨征询回复；ESC 征询回复；借用征询回复", st: "done", at: now(), ms: 0, batch: i });
      ev.sum = `已回复 ${E.got} 条`;
      paint(); sideRefresh();
    }));
    at(BATCH.length * 2600 - 1800, () => {
      E.busy -= 1;
      E.phase = 3;
      ev.st = "done"; ev.sum = "已回复 29 条，9 种中 8 种确认可用"; E.node.n4 = "done"; E.out.n4 = ev.sum;
      aiSay("回复分三批归集好了，到 11:40 共 29 条：9 种里 8 种确认能用，项目部门也同意了以大代小 2 种。OPGW 光缆的协议供应商要 7 天，赶不上；万州在建工程可以借 2.2 千米，满足现场需求，等建管单位同意。全省没货的 2 种，应急采购需求已写好，等方案选定后确认发起。", () => at(3500, plan));
      sideRefresh();
    });
  }

  /* ---------- 2-4 保障方案自动生成（11:42），送达效率优先，三版并排，可改可导出 ---------- */
  function plan() {
    if (E.phase !== 3) return;
    if (CK()) CK().set(11, 42, 0);
    runNode("n5", "回复齐了，按物资送达效率优先排保障方案：送达最快的一版推荐，另排协调单位最少、运输里程最短两版。", [
      { cap: "查询", call: "确认可用的来源", t: "8 种确认可用，OPGW 光缆可借万州在建工程或走应急采购，2 种应急采购。", from: "回复归集", ms: 700 },
      { cap: "审核", call: "思维链 · 送达效率优先", t: "先比各物资送达时间，再比协调方数、运输里程和费用。", from: "思维链 · 应急物资保障", ms: 600 },
      { cap: "写作", call: "保障方案 · 三版", t: "三版方案已写好，见右侧「保障方案」。", ms: 2900 },
    ], "三版保障方案，推荐方案一 送达最快", () => {
      E.phase = 4;
      openCanvas("plans");
      E.busy += 1;
      revealPlan(() => {
        E.busy -= 1;
        aiSay("三版保障方案在右侧，按送达效率排：<b>推荐方案一 送达最快</b>，除应急采购的 2 种外今天 22:00 全部到齐；方案二只协调 3 方，但 OPGW 光缆改走应急采购，后天 14:00 才齐；方案三运输里程最短，明天 12:00 到齐。表里每一格都能改，也能导出。方案由市公司物资部选定。<br>还有 17 条确认没回复，我继续催；有新回复，方案自动更新。");
      });
    }, { inStream: true });
  }
  function revealPlan(done) {
    E.planStep = 0;
    const end = PLAN.rows.length + 1;
    const go = () => {
      E.planStep += 1;
      paintCanvas();
      if (E.planStep < end) return setTimeout(go, E.planStep < 2 ? 500 : 200);
      done();
    };
    go();
  }
  function submit() {
    if (E.phase !== 4 || E.busy) return;
    E.phase = 5; E.subAt = now();
    logIt("保障方案已报市公司物资部选定");
    E.items.push({ k: "me", text: "报物资部选定" });
    aiSay("三版保障方案已报市公司物资部，选定后我列出后续事项。");
    paint(); sideRefresh();
    armFallback(select, 25000);
  }

  /* ---------- 2-5 物资部选定（R 或 20 秒兜底）：画面时间跳到 13:20，后续事项逐项确认 ---------- */
  function select() {
    if (E.phase !== 5 || E.busy) return;
    clearTimeout(fallback);
    if (CK()) CK().set(13, 20, 0);
    E.phase = 6; E.pick = "一";
    logIt("市公司物资部选定方案一 送达最快");
    E.items.push({ k: "in", who: "市公司物资部", at: clock(now()).slice(0, 5), text: "选定方案一 送达最快。" });
    openCanvas("plans");
    E.got = 37;
    runNode("n6", "物资部选定了方案一。先把方案出来后新到的回复归进来，再把接下来要发起的事按办理方式分开，每项您确认后再发起。", [
      { cap: "查询", call: "各单位与供应商回复 · 继续归集", t: "11:42—13:20 又收到 8 条，均为库存已占用、不能调出，方案一不用调整；还有 9 条没回复，继续催。", from: "调拨征询回复；ESC 征询回复", ms: 1500 },
      { cap: "写作", call: "后续事项清单", t: "跨单位调拨 2 项、协议库存紧急发货 3 项、在建工程借用 1 项、应急采购 2 种，逐项确认后发起。", from: "方案一", ms: 2300 },
    ], "待确认发起", () => {
      E.items.push({ k: "follow" });
      aiSay("应急采购的 2 种按方案一确认后才发起审批。收货地点按需求提报（忠县驼丘仓库），到货跟踪和签收由需求单位负责。");
      sideRefresh();
    }, { inStream: true });
  }
  function goFollow(k) {
    if (E.phase !== 6 || E.go[k] || E.busy || !FOLLOW[k].calls) return;
    E.go[k] = "run";
    const c = FOLLOW[k];
    const list = [];
    E.goCalls = E.goCalls || {};
    E.goCalls[k] = list;
    E.busy += 1;
    runCalls(list, c.calls.map(([cap, call, t, ms, st]) => ({ cap, call, t, ms: ms || 1400, fail: st === "fail" })), () => {
      E.go[k] = "done";
      E.busy -= 1;
      logIt(c.done);
      /* 对方接收要时间：云阳十几秒后接收调拨单，武隆到这一段结束仍待接收；供应商二十多秒后在 e物资回复确认 */
      E.recv = E.recv || {};
      if (k === "db") at(16000, () => { E.recv.yy = now(); logIt("云阳公司已接收调拨单 4900218733"); paint(); });
      if (k === "xy") at(23000, () => { E.recv.sup = now(); E.items.push({ k: "in", who: "金具协议供应商 · e物资回复", at: clock(now()), text: "收到。光缆耐张串 10 套、光缆悬垂串 3 套、光缆余缆架 2 个今天 21:00 前送到忠县驼丘仓库，车辆信息发货时补传。" }); logIt("金具协议供应商确认紧急发货"); paint(); });
      openCanvas("responses");
      if (E.go.db === "done" && E.go.xy === "done" && E.go.cg === "done") finishAll();
      sideRefresh();
    });
    paint();
  }
  function finishAll() {
    E.phase = 7;
    Object.assign(S8(), { v90EmgDone: true, v90Plan: "一" });
    document.body.classList.add("v90-emg-done"); document.body.classList.remove("v90-notice-live");
    E.items.push({ k: "result", title: "后续事项已发起", lines: [FOLLOW.db.done, FOLLOW.xy.done, "万州 OPGW 光缆借用：建管单位同意后发起", FOLLOW.cg.done, "到货跟踪和签收由需求单位负责，有变化进入次日今日简报"] });
    EM.refreshHome();
    EM.toast("后续事项已发起");
  }
  window.v92Tickets = () => [];

  function reply(v) {
    E.items.push({ k: "me", text: v });
    paint();
    E.busy += 1;
    const go = (fn) => setTimeout(() => { E.busy -= 1; fn(); }, 400);
    if (/报物资部|选定/.test(v) && E.phase === 4) return go(() => { E.items.pop(); submit(); });
    if (/进展|回复|怎么样|到哪/.test(v)) return go(() => { openCanvas("responses"); aiSay(E.phase >= 3 ? `已发确认 46 条，已回复 29 条：9 种中 8 种确认可用，OPGW 光缆等万州建管单位同意；应急采购 2 种${E.go.cg === "done" ? "在审批" : "需求已写好，方案选定后请您确认发起"}。` : E.sent ? "46 条可用性确认已发出，回复陆续进来，我归集好告诉您。" : "正在查本单位和全省的来源。"); });
    return go(() => aiSay("这件应急正在处理，进展在右侧「寻源与工单跟踪」。保障方案出来后，由市公司物资部选定。"));
  }

  /* ---------- 渲染：左侧执行过程与对话 ---------- */
  const capChip = (c) => `<em class="em-cap">${h(c)}</em>`;
  /* 每一行能力调用都可以点开，详情显示在画布最上面 */
  const REG = {};
  let seq = 0;
  function callLi(c, n) {
    if (c.st === "run") return `<li class="run"><i></i><div><p>${capChip(c.cap)}<span class="em-call">正在调用 ${h(c.call)}…</span></p></div></li>`;
    if (!c.id) { c.id = ++seq; REG[c.id] = c; }
    return `<li class="v94-call${E.detail === c.id ? " on" : ""}${c.fail && c.st === "done" ? " v96-fail" : ""}" data-v94-call="${c.id}" title="点开看详情"><i>${n}</i><div><p>${capChip(c.cap)}<span class="em-call">${h(c.call)}</span>${c.fail && c.st === "done" ? '<b class="v96-fail-tag">未成功</b>' : ""}${h(c.t)}</p>${c.from || c.ms ? `<small>${c.from ? `依据：${h(c.from)}` : ""}${c.ms ? `<em>用时 ${(c.ms / 1000).toFixed(1)} 秒</em>` : ""}<em>${clock(c.at)}</em></small>` : ""}</div></li>`;
  }
  const callsHtml = (list) => `<div class="em-chain v92-chain"><ol>${list.map((c, i) => callLi(c, i + 1)).join("")}</ol></div>`;
  const stLabel = { run: "调用中", wait: "等回复", done: "已完成" };
  /* 只展开正在执行的和最新的一步，其余收起只露结论；用户点开、收起的保持（10 月 20 日晚减少画面信息量） */
  const latestEv = () => [...E.ev, ...E.items.filter((m) => m.k === "node").map((m) => m.ev)].reduce((a, b) => (!a || b.at >= a.at ? b : a), null);
  function nodeEvent(ev) {
    const live = ev.st === "run" || ev.st === "wait";
    const user = (E.userOpen || {})[ev.key];
    const open = user != null ? user : live || ev === latestEv();
    return `<details class="approvedui-replay-event ${ev.st === "done" ? "done" : "current"} v92-ev" data-v95-ev="${ev.key}" ${open ? "open" : ""}><summary><span class="approvedui-replay-node">${ev.st === "done" ? "✓" : "●"}</span><span class="approvedui-replay-copy"><strong><i class="approvedui-cap-chip v92-grp-chip">专业组合能力</i>${h(ev.name)}${NODES[ev.key] ? `<em class="v96-org">${h(NODES[ev.key].org)}</em>` : ""}${ev.st === "run" ? '<span class="approvedui-replay-spinner" aria-label="执行中"></span>' : ""}</strong><small>${h(ev.sum || ev.intent)}</small></span><time>${clock(ev.at)} · ${stLabel[ev.st]}</time><span class="approvedui-replay-chevron">⌄</span></summary><div class="approvedui-replay-detail"><p class="v92-intent">${h(ev.intent)}</p>${ev.calls.length ? callsHtml(ev.calls) : '<p class="v90-sub">等待回复…</p>'}</div></details>`;
  }
  function stageInfo() {
    if (E.phase >= 6) return [3, "发起后续事项", "按选定的方案一逐项发起。", E.phase === 7 ? "调拨单 2 张、紧急发货通知已发起，应急采购已提交审批。" : "物资部已选定方案一。", "万州借用需建管单位同意。", "到货跟踪和签收由需求单位负责。"];
    if (E.phase >= 4) return [2, "保障方案", "出保障方案，报物资部选定。", E.phase === 5 ? "已报市公司物资部，等待选定。" : "三版方案，推荐方案一 送达最快。", "万州借用需建管单位同意。", E.phase === 5 ? "物资部选定后列出后续事项。" : "报市公司物资部选定。"];
    if (E.phase >= 2) return [1, "全域查找", "缺的 11 种找到来源。", E.phase === 3 ? "29 条回复已归集，9 种中 8 种确认可用。" : "46 条可用性确认已发出，应急采购需求 2 种已起草。", "OPGW 光缆协议库存赶不上。", E.phase === 3 ? "生成保障方案。" : "归集回复。"];
    if (E.node.n1 === "done") return [1, "全域查找", "缺的 11 种找到来源。", "本单位 12 种，缺 11 种。", "全省都没有的要走应急采购。", "查到的直接发可用性确认，不等人点。"];
    return [0, "查本单位", "看忠县自己能解决多少。", E.plan0 ? "已按思维链编排 6 项专业组合能力。" : "正在读需求、调思维链。", "现场勘察后物资清单可能调整。", "缺的在全省同时查找。"];
  }
  function execCard() {
    const [si, name, goal, out, risk, next] = stageInfo();
    const names = ["查本单位", "全域查找", "保障方案", "后续事项"];
    const busy = E.think.some((c) => c.st === "run") || E.ev.some((e) => e.st === "run");
    const live = E.phase === 7 ? "已发起" : busy ? "执行中" : E.phase === 2 ? "等待回复" : E.phase === 5 ? "等待物资部选定" : "执行中";
    /* 阶段卡只留进度条、阶段产出和下一步（目标、风险两格收进画布，10 月 20 日晚减少画面信息量） */
    void goal; void risk;
    const stage = `<section class="approvedui-replay-stage approvedui-replay-stage-current"><div class="approvedui-replay-stage-head"><div><span>阶段信息</span><b>当前阶段：${name}</b></div><div class="approvedui-replay-stage-live"><i class="approvedui-replay-spinner"></i><span>${live}</span><em>${si + 1} / 4</em></div></div><div class="approvedui-replay-stage-track">${names.map((n, i) => `<span class="${i < si ? "done" : i === si ? "current" : ""}"><i>${i < si ? "✓" : i + 1}</i>${n}</span>`).join("")}</div><div class="approvedui-replay-stage-grid v95-grid2"><div><span>阶段产出</span><b>${out}</b></div><div><span>下一步</span><b>${next}</b></div></div></section>`;
    const plan = E.plan0 ? `<div class="v92-plan-line"><b>编排</b>按「应急物资保障」思维链调用 6 项专业组合能力：本单位资源查找 → 全域同时查找 → 应急采购需求起草 → 回复归集 → 保障方案生成 → 后续事项发起。前 3 项马上执行，后面的等回复进来再调；发起调拨、紧急发货和应急采购都要您确认；编排图在右侧「编排」。</div>` : "";
    /* 思考与编排做完后收起，只露一句：按思维链编排了几项能力 */
    const thinkOpen = E.thinkOpen != null ? E.thinkOpen : !E.plan0;
    const think = `<details class="v92-think v95-think" ${thinkOpen ? "open" : ""}><summary><h5>思考与编排${!E.plan0 ? '<span class="em-chain-live">进行中</span>' : '<small>已按「应急物资保障」思维链编排 6 项专业组合能力，保障方案初稿已起草 ›</small>'}</h5></summary>${callsHtml(E.think)}${plan}</details>`;
    const evs = E.ev.map((ev) => nodeEvent(ev)).join("");
    return `<article class="approvedui-exec-card approvedui-replay-card v92-exec">${stage}<div class="approvedui-exec-intro"><div class="approvedui-exec-intro-copy"><b>任务执行过程</b><span>智能体的思考、编排和能力调用，逐步更新</span></div></div><div class="approvedui-exec-content"><div class="approvedui-replay-stream">${think}${evs}</div></div></article>`;
  }
  function followCard(k) {
    const c = FOLLOW[k], st = E.go[k];
    const btn = !c.calls ? '<span class="sc-chip warn">待建管单位同意</span>' : st === "done" ? '<span class="sc-chip ok">已发起</span>' : st === "run" ? '<span class="sc-chip">发起中</span>' : `<button class="em-btn em-btn-w" data-v93-go="${k}" ${E.busy ? "disabled" : ""}>确认发起</button>`;
    const calls = E.goCalls && E.goCalls[k] && E.goCalls[k].length ? callsHtml(E.goCalls[k]) : "";
    return `<div class="em-m em-m-card em-confirm-card ${st === "done" || !c.calls ? "ok" : "wait"} v93-fc"><h5>${!c.calls ? "" : st === "done" ? "" : "需要你确认："}${h(c.title)} · ${h(c.how)}</h5><ul>${c.rows.map((r) => `<li>${h(r)}</li>`).join("")}</ul>${calls}<div class="em-m-btns">${btn}</div></div>`;
  }
  function itemHtml(m) {
    if (m.k === "me") return `<div class="emergency-message user"><div class="emergency-bubble">${h(m.text)}</div></div>`;
    if (m.k === "ai") {
      const body = m.pre ? '<span class="em-dots"><i></i><i></i><i></i></span>' : m.n === Infinity ? m.html : `${EM.cut(m.html, m.n)}<span class="em-caret"></span>`;
      return `<div class="emergency-message"><div class="emergency-avatar">智</div><div class="emergency-bubble">${body}</div></div>`;
    }
    if (m.k === "in") return `<div class="em-m v93-in"><header><b>${h(m.who)}</b><time>${h(m.at)}</time></header><p>${h(m.text)}</p></div>`;
    if (m.k === "node") return `<div class="v92-node-card">${nodeEvent(m.ev)}</div>`;
    if (m.k === "follow") return `<div class="v93-follow">${["db", "xy", "jy", "cg"].map(followCard).join("")}</div>`;
    if (m.k === "result") return `<div class="em-m em-m-card em-result-card v92-result"><h5>${h(m.title)}</h5>${m.lines.map((l) => `<p>${h(l)}</p>`).join("")}</div>`;
    return "";
  }
  function streamInner() {
    const out = [execCard()];
    for (const m of E.items) { out.push(itemHtml(m)); if (m.k === "ai" && m.n !== Infinity) break; }
    return out.join("");
  }
  window.v92EmgStream = () => `<div class="v92-emg">${streamInner()}</div>`;

  /* ---------- 渲染：右侧画布 ---------- */
  const TABS = [["flow", "编排"], ["materials", "物资清单"], ["responses", "寻源与工单跟踪"], ["plans", "保障方案"]];
  const nodeSt = { run: "调用中", wait: "等回复", done: "已完成" };
  function flowPage() {
    /* 每步写明由哪家单位办理：查全省、发征询、出方案归物资公司运营中心（李奇霖第 4、5 题），仍从忠县公司账号看（用户 10 月 20 日定） */
    const steps = [["查本单位", "忠县公司"], ["缺口全域同时查找", "物资公司运营中心"], ["全省无货同步起草采购需求", "忠县公司"], ["出保障方案", "物资公司运营中心"], ["选定方案", "市公司物资部"], ["逐项确认发起", "忠县公司"]];
    const nodes = E.order.map((k, i) => {
      const n = NODES[k], st = E.node[k] || "todo";
      return `<li class="v92-n ${st}"><div class="v92-n-h"><i>${st === "done" ? "✓" : i + 1}</i><span>专业组合能力</span><strong>${h(n.name)}</strong><em class="v96-org">${h(n.org)}</em><b class="v92-n-st">${st === "run" ? '<i class="v90-spin"></i>' : ""}${nodeSt[st] || "待调用"}</b></div><div class="v92-n-caps">${n.caps.map(([c, x]) => `<span><em class="em-cap">${h(c)}</em>${h(x)}</span>`).join("")}</div>${E.out[k] ? `<p class="v92-n-out">产出：${h(E.out[k])}</p>` : ""}</li>`;
    }).join("");
    return `<section class="v90-sec v92-flow"><div class="v90-sec-h"><h4>能力编排 · 忠县 22 号塔滑坡应急</h4><span>按「应急物资保障」思维链编排</span></div><div class="v92-steps">${steps.map(([s, o]) => `<span>${h(s)}<small>${h(o)}</small></span>`).join("<i>→</i>")}</div><p class="v90-sub">依据：应急物资保障思维链；应急物资管理规范（来源先后：其他单位库存和物资公司应急储备库 → 协议库存 → 在建工程借用 → 应急采购）。原子能力按查询、写作、办理、审核、协同提醒五类。</p><ol class="v92-nodes">${nodes}</ol></section>`;
  }
  /* 某种缺口物资此刻的状态：确认可用的在第 1 批回复后出现，万州借用在第 3 批后出现 */
  const stNow = (r) => (r[4] === "buy" ? (E.node.n3 === "done" ? "buy" : "") : r[4] === "ok" ? ((E.batch || 0) >= 1 ? "ok" : "") : (E.batch || 0) >= 3 ? "wait" : "");
  const buyChip = () => (E.go.cg === "done" ? '<span class="sc-chip warn">应急采购 · 审批中</span>' : '<span class="sc-chip warn">应急采购 · 需求已起草</span>');
  const chipOf = (st) => (st === "ok" ? '<span class="sc-chip ok">确认可用</span>' : st === "wait" ? '<span class="sc-chip warn">待建管单位同意</span>' : st === "buy" ? buyChip() : '<span class="sc-chip">确认中</span>');
  function materialsPage() {
    const n1 = E.node.n1 === "done";
    const dai = (r) => /以大代小/.test(r[3]);
    const rows = n1 ? LOCAL.map((r) => [h(r[0]), h(r[1]), "本单位", h(`${r[2]} · ${r[3]}`), dai(r) && !(E.batch >= 1) ? '<span class="sc-chip warn">待项目部门评判</span>' : '<span class="sc-chip ok">已备货</span>'])
      .concat(SHORT.map((r) => { const st = stNow(r); return [h(r[0]), h(r[1]), "缺口", E.node.n2 === "done" || E.node.n2 === "wait" ? h(r[4] === "buy" ? "全省无货 · 应急采购" : st ? `${r[3]} · ${r[2]}` : r[3]) : "—", st ? chipOf(st) : E.node.n2 === "done" ? '<span class="sc-chip">确认中</span>' : '<span class="sc-chip">查找中</span>']; })) : [];
    return `<section class="v90-sec"><div class="v90-sec-h"><h4>物资清单 · 23 种</h4><span>${n1 ? "本单位 12 种，缺 11 种" : "运检部提报 23 种，正在查本单位"}</span></div>${n1 ? `<div class="sc-tw"><table class="sc-t sc-t-dense"><thead><tr><th>物资</th><th>数量</th><th>类别</th><th>来源</th><th>状态</th></tr></thead><tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table></div>` : '<p class="v90-sub">本单位查完后显示。</p>'}</section>`;
  }
  function responsesPage() {
    const tag = { ok: '<span class="sc-chip ok">可用</span>', no: '<span class="sc-chip warn">不能供</span>', part: '<span class="sc-chip">部分</span>', wait: '<span class="sc-chip warn">待同意</span>' };
    /* 最新回复默认只列最近 5 条，点开看全部（10 月 20 日晚减少画面信息量） */
    const rev = E.feed.slice().reverse();
    const shown = E.feedAll ? rev : rev.slice(0, 5);
    const more = rev.length > 5 ? `<button class="v94-more-btn" data-v95-feed>${E.feedAll ? "只看最新 5 条" : `看全部 ${rev.length} 条`}</button>` : "";
    const feed = E.feed.length ? shown.map(([t, w, x, k], i) => `<div class="${i === 0 ? "new" : ""}"><time>${t}</time><b>${h(w)}</b><span>${tag[k]}${h(x)}</span></div>`).join("") + `<p class="v90-sub">已回复 ${E.got || 0} 条，需要说明的 ${E.feed.length} 条在这里，其余为库存已占用或预留、不能调出的答复。${more}</p>` : `<p class="v90-sub">${E.sent ? "可用性确认只发给查到有货的单位和供应商，回复陆续进来。" : "全域查找开始后显示。"}</p>`;
    /* 选定方案后：按物资看来源、办理方式和单据进度（发起 → 对方接收 → 办理 → 回执） */
    const dots = (n) => `<span class="v94-dots">${[0, 1, 2, 3].map((i) => `<i class="${i < n ? "on" : ""}"></i>`).join("")}</span>`;
    const rv = E.recv || {};
    const TR = [
      ["本单位 12 种", "忠县仓库、应急储备等", "—", 4, '<span class="sc-chip ok">已备货</span>'],
      ["铁塔、铝包钢绞线", "云阳公司", "ERP 调拨单", E.go.db === "done" ? (rv.yy ? 2 : 1) : 0, E.go.db === "done" ? (rv.yy ? '<span class="sc-chip ok">已接收</span>' : '<span class="sc-chip">已发起 · 待接收</span>') : '<span class="sc-chip">待确认发起</span>'],
      ["跳线 2 种、防振锤", "武隆公司", "ERP 调拨单", E.go.db === "done" ? 1 : 0, E.go.db === "done" ? '<span class="sc-chip">已发起 · 待接收</span>' : '<span class="sc-chip">待确认发起</span>'],
      ["光缆耐张串等 3 种", "金具协议供应商", "e物资紧急发货", E.go.xy === "done" ? (rv.sup ? 2 : 1) : 0, E.go.xy === "done" ? (rv.sup ? '<span class="sc-chip ok">供应商已确认</span>' : '<span class="sc-chip">已读 · 待确认</span>') : '<span class="sc-chip">待确认发起</span>'],
      ["OPGW 光缆 2.2 千米", "万州在建工程", "借用", 0, '<span class="sc-chip warn">待建管单位同意</span>'],
      ["接头盒、防坠落导轨", "应急采购", "应急采购审批", E.go.cg === "done" ? 1 : 0, E.go.cg === "done" ? '<span class="sc-chip warn">审批中</span>' : '<span class="sc-chip">待确认发起</span>'],
    ];
    const track = E.phase >= 6 ? `<h5>按方案一发起的事项</h5><div class="sc-tw"><table class="sc-t"><thead><tr><th>物资</th><th>来源</th><th>办理方式</th><th>发起 → 接收 → 办理 → 回执</th><th>状态</th></tr></thead><tbody>${TR.map((r) => `<tr><td>${h(r[0])}</td><td>${h(r[1])}</td><td>${h(r[2])}</td><td>${dots(r[3])}</td><td>${r[4]}</td></tr>`).join("")}</tbody></table></div><p class="v90-sub">收货地点按需求提报（忠县驼丘仓库）；到货跟踪和签收由需求单位负责。</p>` : "";
    const sent = E.sent ? 46 : 0, got = E.got || 0;
    return `<section class="v90-sec v90-progress"><div class="v90-sec-h"><h4>忠县缺的 11 种 · 寻源与工单跟踪</h4><span>${E.phase >= 6 ? "13:20 更新" : E.batch ? `第 ${E.batch} 批回复已归集` : "全域同时查找"}</span></div>
      <div class="v90-counters"><div><span>已发确认</span><b>${sent}</b></div><div><span>已回复</span><b>${got}</b></div><div><span>确认可用</span><b>${(E.batch || 0) >= 1 ? "8/9" : "0/9"}</b></div><div><span>应急采购</span><b>${E.node.n3 === "done" ? (E.go.cg === "done" ? "2 种审批中" : "2 种待确认") : "—"}</b></div></div>${track}
      <h5>最新回复</h5><div class="v90-feed">${feed}</div>
      <h5>11 种物资的来源</h5><div class="sc-tw"><table class="sc-t"><thead><tr><th>物资</th><th>数量</th><th>渠道</th><th>来源</th><th>状态</th></tr></thead><tbody>${SHORT.map((r) => { const st = stNow(r); return `<tr><td>${h(r[0])}</td><td>${h(r[1])}</td><td>${E.node.n2 === "done" ? h(r[3]) : "—"}</td><td>${st ? h(r[2]) : E.node.n2 === "done" ? "确认中" : "—"}</td><td>${st ? chipOf(st) : "—"}</td></tr>`; }).join("")}</tbody></table></div></section>`;
  }
  const cell = (r, c, v) => (E.edit[`${r}-${c}`] != null ? E.edit[`${r}-${c}`] : v);
  /* 方案初稿：10:15 列出框架，每一步的结果自动补进去 */
  function draft() {
    const n1 = E.node.n1 === "done", n2 = E.node.n2 === "done", n3 = E.node.n3 === "done";
    const part = (t, body, ok) => `<h5>${t}</h5><p class="${ok ? "" : "v90-sub"}">${ok ? body : "待补充"}</p>`;
    return `<section class="v90-sec v94-draft"><div class="v90-sec-h"><h4>应急物资保障方案 · 初稿</h4><span>随处理进展自动补全</span></div>
      ${part("一、事件概况", "忠县 110kV 石拔南线 22 号塔受滑坡影响，需移塔改造。忠县公司运检部提报抢修物资 23 种；保障要求：市内 2 小时、省内 4 小时、跨省 8 小时出库。", E.think.length >= 1 && E.think[0].st === "done")}
      ${part("二、本单位保障", `县公司仓库、应急储备、专业仓和班组库、本单位在建工程现场共有 12 种；其中以大代小 2 种（钢芯铝绞线、接续管）${E.batch >= 1 ? "项目部门已评判同意" : "已请项目部门评判，同意后备货"}。`, n1)}
      ${part("三、缺口全域查找", "缺 11 种。其他单位库存和物资公司应急储备库、协议库存、在建工程同时查，9 种查到来源，已发可用性确认 46 条；跨单位调拨征询经物资公司运营中心，协议库存经 ESC 征询执行供应商。", n2)}
      ${part("四、应急采购", "光缆接头盒 1 只、铁塔防坠落导轨装置 134 米全省无货，应急采购需求已同步起草；物资部选定方案后，由需求单位确认发起审批，询价内容转发应急采购供应商微信群。", n3)}
      ${part("五、待定事项", "回复归集后出保障方案，报市公司物资部选定；现场勘察定损后核对物资清单。", E.plan0)}</section>`;
  }
  /* 后续步骤建议：出方案后按物资送达时间排（李奇霖第 18 题看重物资送达效率） */
  const NEXT = [
    ["报市公司物资部选定方案", "三版方案报物资部，选定后列出要发起的事项", "现在"],
    ["跨单位调拨、协议库存紧急发货", "按选定方案逐项确认后发起：ERP 调拨单、e物资紧急发货通知", "选定后"],
    ["万州 OPGW 光缆借用", "请建管单位同意，同意后发起借用", "选定后"],
    ["应急采购 2 种", "需求已写好，选定方案后由您确认发起审批", "选定后"],
    ["按勘察结果核对清单", "现场勘察定损后核对 23 种物资的规格和数量，有变化重新查找", "勘察完成后"],
  ];
  function plansPage() {
    if (E.phase < 4 && E.node.n5 !== "run") return `<div class="collaboration-app-page v90-page">${E.plan0 || E.think.length >= 3 ? draft() : `<section class="v90-sec"><div class="v90-sec-h"><h4>保障方案</h4></div><p class="v90-sub">正在编写初稿。</p></section>`}</div>`;
    const n = Math.min(E.planStep - 1, PLAN.rows.length);
    const table = n > 0 ? `<div class="sc-tw"><table class="sc-t v90-cmp v93-plan"><thead><tr>${PLAN.head.map((x, i) => `<th class="${i === 1 ? "rec" : ""}${E.pick && i === 1 ? " pick" : ""}">${h(x)}</th>`).join("")}</tr></thead><tbody>${PLAN.rows.slice(0, n).map((r, ri) => `<tr>${r.map((x, i) => (i === 0 ? `<td>${h(x)}</td>` : `<td class="${i === 1 ? "rec" : ""}" contenteditable="${E.phase >= 6 ? "false" : "true"}" data-v93-cell="${ri}-${i}">${h(cell(ri, i, x))}</td>`)).join("")}</tr>`).join("")}</tbody></table></div>` : "";
    let tail = "";
    if (E.phase >= 4 && n >= PLAN.rows.length) {
      const state = E.phase >= 6 ? `<span class="sc-chip ok">市公司物资部已选定方案一 · 13:20</span>` : E.phase === 5 ? `<span class="sc-chip warn">已报市公司物资部 · 等待选定</span>` : "";
      tail = `<div class="v93-plan-foot"><span class="v90-sub">表格每一格都可以直接修改</span><div class="v90-btns">${state}<button data-v93-export="doc">导出 Word</button><button data-v93-export="xls">导出 Excel</button>${E.phase === 4 ? '<button class="primary" data-v93-submit>报物资部选定</button>' : ""}</div></div>`;
    }
    const next = E.phase >= 4 && E.phase < 6 && n >= PLAN.rows.length ? `<section class="v90-sec"><div class="v90-sec-h"><h4>后续步骤建议</h4><span>按物资送达时间排</span></div><ol class="v94-next">${NEXT.map(([a, b, c], i) => `<li><i>${i + 1}</i><div><b>${a}</b><p>${b}</p></div><em>${c}</em></li>`).join("")}</ol></section>` : "";
    return `<div class="collaboration-app-page v90-page"><section class="v90-sec"><div class="v90-sec-h"><h4>保障方案 · 三版对比</h4><span>${E.phase >= 4 ? "按物资送达效率优先 · 11:42 生成" : "生成中"}</span></div>${table}${tail}</section>${next}</div>`;
  }
  function exportPlan(kind) {
    const rows = [PLAN.head].concat(PLAN.rows.map((r, ri) => r.map((x, i) => (i ? cell(ri, i, x) : x))));
    const html = `<html><head><meta charset="utf-8"></head><body><h3>忠县 110kV 石拔南线 22 号塔滑坡 · 保障方案</h3><table border="1">${rows.map((r, i) => `<tr>${r.map((x) => (i ? `<td>${h(x)}</td>` : `<th>${h(x)}</th>`)).join("")}</tr>`).join("")}</table></body></html>`;
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob(["﻿", html], { type: kind === "doc" ? "application/msword" : "application/vnd.ms-excel" }));
    a.download = `忠县滑坡保障方案.${kind}`;
    document.body.appendChild(a); a.click(); a.remove();
    EM.toast(`已导出 忠县滑坡保障方案.${kind}`);
  }
  function detailCard() {
    const c = REG[E.detail];
    if (!c) return "";
    const rows = [["能力", h(c.cap)], ["返回结果", h(c.t)]];
    if (c.from) rows.push(["依据", h(c.from)]);
    rows.push(["时间", clock(c.at) || "—"]);
    if (c.ms) rows.push(["用时", `${(c.ms / 1000).toFixed(1)} 秒`]);
    let extra = "";
    if (/应急需求工单/.test(c.call)) extra = `<h5>原始工单</h5><table class="sc-t"><tbody>${[["工单", "应急物资主动保障_办理工单 · 10:15 推送"], ["提报单位", "忠县公司运检部"], ["地点", "忠县 110kV 石拔南线 22 号塔"], ["现场情况", "滑坡，需移塔改造"], ["物资", "23 种：铁塔、导地线、金具、光缆、绝缘子等"], ["保障要求", "市内 2 小时、省内 4 小时、跨省 8 小时出库"], ["收货地点", "忠县驼丘仓库（提报时明确）"]].map(([a, b]) => `<tr><td>${a}</td><td>${b}</td></tr>`).join("")}</tbody></table>`;
    else if (c.batch != null) { const lo = c.batch ? BATCH[c.batch - 1].upto : "00:00", hi = BATCH[c.batch].upto; extra = `<h5>这一批里需要说明的回复</h5><table class="sc-t"><thead><tr><th>时间</th><th>回复方</th><th>内容</th></tr></thead><tbody>${REPLIES.filter((r) => r[0] > lo && r[0] <= hi).map((r) => `<tr><td>${r[0]}</td><td>${h(r[1])}</td><td>${h(r[2])}</td></tr>`).join("")}</tbody></table>`; }
    else if (/县公司仓库与应急储备|专业仓|在建工程现场/.test(c.call)) extra = `<h5>本单位有货的物资</h5><table class="sc-t"><thead><tr><th>物资</th><th>数量</th><th>来源</th><th>说明</th></tr></thead><tbody>${LOCAL.map((r) => `<tr>${r.map((x) => `<td>${h(x)}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
    else if (/管理规范/.test(c.call)) extra = `<h5>来源先后</h5><p>其他单位库存和物资公司应急储备库 → 协议库存 → 在建工程借用 → 应急采购。三类渠道同时查，按这个先后选用。</p>`;
    return `<section class="v90-sec v94-detail"><div class="v90-sec-h"><h4>${h(c.call)}</h4><button class="v94-x" data-v94-x aria-label="关闭详情">×</button></div><table class="sc-t"><tbody>${rows.map(([a, b]) => `<tr><td>${a}</td><td>${b}</td></tr>`).join("")}</tbody></table>${extra}</section>`;
  }
  function canvasInner() {
    const tab = S8().emergencyCanvasTab;
    const det = detailCard();
    if (det) return `<div class="collaboration-app-page v90-page">${det}</div>`;
    const body = tab === "materials" ? materialsPage() : tab === "responses" ? responsesPage() : tab === "plans" ? plansPage() : flowPage();
    return body.startsWith('<div class="collaboration-app-page') ? body : `<div class="collaboration-app-page v90-page">${body}</div>`;
  }
  const isMine = () => { const s = S8(); return s.view === "emergency" && s.emergencyThread === "E001"; };
  const baseTabs = window.emergencyCanvasTabs;
  window.emergencyCanvasTabs = function () {
    if (S8().emergencyThread !== "E001") return baseTabs.apply(this, arguments);
    const cur = TABS.some((t) => t[0] === S8().emergencyCanvasTab) ? S8().emergencyCanvasTab : "flow";
    return `<nav class="emergency-canvas-tabs">${TABS.map(([k, n]) => `<button class="${cur === k ? "on" : ""}" data-emergency-canvas-tab="${k}">${n}</button>`).join("")}</nav>`;
  };
  const baseCanvas = window.emergencyCanvasContent;
  window.emergencyCanvasContent = function () {
    if (S8().emergencyThread !== "E001") return baseCanvas.apply(this, arguments);
    if (!TABS.some((t) => t[0] === S8().emergencyCanvasTab)) S8().emergencyCanvasTab = "flow";
    return canvasInner();
  };

  /* ---------- 局部重绘：执行过程和对话只换左侧内容，画布只换正文，输入框不动 ---------- */
  let stick = true;
  let quiet = 0; /* 整体重绘后 V89 会把对话滚回顶部，这段时间的滚动不算用户操作 */
  function paintStream() {
    if (!isMine()) return;
    const root = document.querySelector("#emergencyEmergencyWorkspace .v92-emg");
    if (!root) return;
    /* 用户手动展开、收起过的执行步骤记在 E.userOpen（toggle 事件），重画时按它来 */
    root.innerHTML = streamInner();
    const b = document.querySelector("#emergencyEmergencyWorkspace .emergency-thread-body");
    if (b && stick) b.scrollTop = b.scrollHeight;
  }
  function paintCanvas() {
    if (!isMine() || !S8().emergencyCanvasOpen) return;
    const body = document.querySelector("#emergencyEmergencyWorkspace .emergency-canvas-body");
    if (!body) return;
    /* 正在改方案表时不重绘，免得光标丢失 */
    if (document.activeElement && document.activeElement.closest && document.activeElement.closest("[data-v93-cell]") && body.contains(document.activeElement)) return;
    const html = canvasInner();
    if (body.dataset.v92 === html) return;
    const top = body.scrollTop;
    body.innerHTML = html;
    body.dataset.v92 = html;
    body.scrollTop = top;
  }
  function paintHead() {
    const sub = document.querySelector("#emergencyEmergencyWorkspace .emergency-thread-title span");
    if (sub) sub.textContent = subtitle();
  }
  function paint() { paintStream(); paintCanvas(); paintHead(); }
  /* 整体重绘（换画布页签、打开画布）时保留输入框里已打的字 */
  function rerender() {
    const inp = document.getElementById("emergencyPrompt");
    const keep = inp ? { v: inp.value, f: document.activeElement === inp, s: inp.selectionStart } : null;
    try { emergencyRender(); } catch (_) { /* 未在应急视图时不重绘 */ }
    const n = document.getElementById("emergencyPrompt");
    if (n && keep) { n.value = keep.v; if (keep.f) { n.focus(); n.setSelectionRange(keep.s, keep.s); } }
  }
  function openCanvas(tab) {
    E.detail = 0;
    const s = S8();
    s.emergencyCanvasTab = tab; s.collaborationTab = tab; s.emergencyCanvasOpen = true;
    if (isMine()) rerender();
  }

  /* ---------- 侧栏「应急任务中心」：忠县这件放出前不显示，状态随进度更新 ---------- */
  function subtitle() {
    if (E.phase === 7) return "23 种物资 · 后续事项已发起";
    if (E.phase >= 3) return `23 种物资 · 本单位 12 种 · 缺口确认可用 8/9 · 应急采购 2 种${E.go.cg === "done" ? "审批中" : "待确认"}`;
    return `23 种物资 · 本单位 ${E.node.n1 === "done" ? 12 : 0} 种 · 缺口 11 种`;
  }
  function syncMeta() {
    try {
      const m = emergencyTaskMeta.E001;
      m.title = "忠县 110kV 石拔南线 22 号塔滑坡";
      m.status = E.phase === 7 ? "已发起" : E.phase === 6 ? "待确认发起" : E.phase === 5 ? "待物资部选定" : E.phase === 4 ? "保障方案" : E.phase >= 2 ? "寻源中" : "处理中";
      m.detail = E.phase === 7 ? "调拨单、紧急发货已发起" : E.phase >= 3 ? "确认可用 8/9" : E.sent ? "46 条确认已发出" : "刚刚";
      m.subtitle = subtitle();
      window.__v91Sub = m.subtitle;
    } catch (_) { /* 应急模块未加载时不处理 */ }
  }
  function sideRefresh() { try { timelineEnsureSidebarTasks(); } catch (_) { /* 侧栏未加载时不处理 */ } }
  window.v92SideRefresh = sideRefresh;
  if (typeof timelineEnsureSidebarTasks === "function") {
    const baseSide = timelineEnsureSidebarTasks;
    timelineEnsureSidebarTasks = function () {
      syncMeta();
      const r = baseSide.apply(this, arguments);
      const a = document.getElementById("emergencyBadge");
      if (a) a.textContent = window.__v90NoticeReleased ? "3" : "2";
      return r;
    };
  }

  /* 忠县任务对话只保留一条执行过程卡，V89 的示例对话不再补回 */
  try {
    const st = S8();
    st.emergencyThreads = st.emergencyThreads || {};
    st.emergencyThreads.E001 = [{ role: "assistant", kind: "timelineoverview", example: true, text: "" }];
  } catch (_) { /* 应急模块未加载时不处理 */ }

  if (typeof emergencyRender === "function") {
    const baseEmgRender = emergencyRender;
    emergencyRender = function () {
      quiet = Date.now() + 200;
      baseEmgRender.apply(this, arguments);
      const mine = isMine();
      document.body.classList.toggle("v92-emg-on", mine);
      if (!mine) return;
      if (!E.t0 && window.__v90NoticeReleased) start();
      syncMeta();
      paintHead();
      document.querySelector("#emergencyEmergencyWorkspace .emergency-suggestions")?.remove();
      const b = document.querySelector("#emergencyEmergencyWorkspace .emergency-thread-body");
      if (b && !b.dataset.v92) { b.dataset.v92 = "1"; b.addEventListener("scroll", () => { if (Date.now() < quiet) return; stick = b.scrollHeight - b.scrollTop - b.clientHeight < 80; }, { passive: true }); }
      [20, 120].forEach((ms) => setTimeout(() => { const b1 = document.querySelector("#emergencyEmergencyWorkspace .emergency-thread-body"); if (b1 && stick) b1.scrollTop = b1.scrollHeight; }, ms));
    };
  }
  /* 执行过程卡：approvedui.js 的 execCard 在忠县任务里改由这里画 */
  window.v92ExecCardFor = (thread) => (thread === "E001" ? window.v92EmgStream() : "");

  /* 应急对话：忠县任务里的输入由这里处理 */
  const baseSend = window.emergencySendPrompt;
  if (typeof baseSend === "function")
    window.emergencySendPrompt = function (t) {
      if (S8().emergencyThread !== "E001") return baseSend.apply(this, arguments);
      const el = document.getElementById("emergencyPrompt");
      const v = String(t ?? (el && el.value) ?? "").trim();
      if (!v) return;
      if (el) el.value = "";
      stick = true;
      reply(v);
    };

  document.addEventListener("click", (e) => {
    /* 用户点开、收起执行步骤：记下来，重画时保持 */
    const sm = e.target.closest("details[data-v95-ev] > summary, details.v95-think > summary");
    if (sm && isMine()) {
      const d = sm.parentElement;
      if (d.dataset.v95Ev) { E.userOpen = E.userOpen || {}; E.userOpen[d.dataset.v95Ev] = !d.open; } else E.thinkOpen = !d.open;
    }
    if (e.target.closest("[data-v95-feed]") && isMine()) { e.preventDefault(); e.stopImmediatePropagation(); E.feedAll = !E.feedAll; paint(); return; }
    const cl = e.target.closest("[data-v94-call]");
    if (cl && isMine()) {
      e.preventDefault(); e.stopImmediatePropagation();
      const c = REG[+cl.dataset.v94Call];
      if (c && /初稿|保障方案 · 三版/.test(c.call)) { E.detail = 0; openCanvas("plans"); return; }
      E.detail = E.detail === +cl.dataset.v94Call ? 0 : +cl.dataset.v94Call;
      if (S8().emergencyCanvasOpen) { paint(); } else openCanvas(S8().emergencyCanvasTab || "flow");
      return;
    }
    if (e.target.closest("[data-v94-x]")) { e.preventDefault(); e.stopImmediatePropagation(); E.detail = 0; paint(); return; }
    if (e.target.closest("[data-emergency-canvas-tab]")) E.detail = 0;
    const g = e.target.closest("[data-v93-go]");
    if (g) { e.preventDefault(); e.stopImmediatePropagation(); goFollow(g.dataset.v93Go); return; }
    if (e.target.closest("[data-v93-submit]")) { e.preventDefault(); e.stopImmediatePropagation(); submit(); return; }
    const x = e.target.closest("[data-v93-export]");
    if (x) { e.preventDefault(); e.stopImmediatePropagation(); exportPlan(x.dataset.v93Export); }
  }, true);
  document.addEventListener("input", (e) => {
    const c = e.target.closest && e.target.closest("[data-v93-cell]");
    if (c) E.edit[c.dataset.v93Cell] = c.textContent;
  });
  /* 点提醒卡「立即处理」：approvedui.js 打开应急任务，这里开始 */
  window.addEventListener("click", (ev) => {
    if (!ev.target.closest || !ev.target.closest("[data-approvedui-notice-enter]")) return;
    document.body.classList.add("v90-emg-done"); document.body.classList.remove("v90-notice-live");
    stick = true;
    setTimeout(start, 60);
  }, true);
  /* 今日简报里点忠县应急 */
  window.v92OpenEmergency = function () {
    try {
      const s = S8();
      s.emergencyThread = "E001"; s.collaborationTask = "E001";
      if (!E.t0) s.emergencyCanvasOpen = false;
      setView("emergency");
      setTimeout(() => { try { emergencyRender(); } catch (_) {} }, 30);
    } catch (_) { /* 应急工作台未加载时不处理 */ }
  };

  /* ---------- 演示控件（界面上不显示） ----------
     R：回复归集到 11:40；报物资部选定后，物资部选定方案一（13:20）。
     Tab：把这一步要说的话以打字效果填进输入框（应急段由按钮推进，这里只给任务线程用） */
  window.v92EmgLine = () => "";
  let auto = null;
  function autoType(el, text) {
    clearInterval(auto);
    el.focus();
    el.value = "";
    let i = 0;
    auto = setInterval(() => {
      i += 1;
      el.value = text.slice(0, i);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      if (i >= text.length) clearInterval(auto);
    }, 70);
  }
  document.addEventListener("keydown", (e) => {
    const t = e.target, k = (e.key || "").toLowerCase();
    if (k === "tab") {
      const emg = isMine(), threadOpen = !!EM.S.open;
      const line = emg ? window.v92EmgLine() : threadOpen && window.v92ThreadLine ? window.v92ThreadLine() : "";
      if (!line) return;
      const el = document.getElementById(emg ? "emergencyPrompt" : "chatInput");
      if (!el || (t === el && el.value.trim())) return;
      e.preventDefault();
      autoType(el, line);
      return;
    }
    if (t && (/INPUT|TEXTAREA|SELECT/.test(t.tagName) || t.isContentEditable)) return;
    if (k === "r" && isMine()) { if (E.phase === 2) arrive(); else if (E.phase === 5) select(); }
  }, true);
})();
