/* 左侧菜单（2026-10-20 按设计稿改）：新建对话 / 今日简报 / 智能办理 / 任务跟踪 / 动态看板 / 智能问数 / 我的常用 / 最近对话。
   智能办理下挂正在办的事项；办完转「任务跟踪」，应急放出后也挂在「任务跟踪」下；动态看板下挂工单运营看板（管理岗）和我的看板。
   原「查询对话」「应急任务中心」入口撤下，应急工作区改从「任务跟踪」进入。 */
(() => {
  const EM = window.EM;
  if (!EM) return;
  const h = EM.h;
  const S8 = () => (typeof state !== "undefined" ? state : {});
  const who = () => (window.execWho ? window.execWho() : "H");
  const T = (id) => (EM.S.threads || {})[id];
  const open = () => EM.S.open || "";
  const fold = {}; /* 用户手动展开、收起的分组 */

  /* ---------- 各账号挂在菜单下的事项 ---------- */
  function doing() {
    if (who() === "A") {
      const m0 = T("M0") || {};
      const list = [];
      if (!(m0.clue && m0.reply)) list.push({ id: "M0", sub: "ecom", t: "电商逾期支付 8 月超期 2,118 张", s: m0.cls ? "处置中" : "待处置" });
      if (!m0.saved) list.push({ id: "M0", sub: "report", t: "8 月工单运营月报", s: (m0.repN || 0) >= 3 ? "已生成" : "待生成" });
      return list;
    }
    if (who() !== "H") return [];
    const s1 = T("S1");
    const list = [];
    if (!(s1 && s1.closed)) list.push({ id: "S1", t: "订单 4500951207 超期交货", s: s1 && s1.handled ? "已办理 · 待您核对" : s1 && s1.go ? "办理中" : `待决策 · 已超 ${window.__v96Days ? window.__v96Days.od() : ""} 天` });
    list.push({ id: "S2", t: "订单 4500949833 超期交货", s: `已超 ${window.__v96Days ? window.__v96Days.s2() : ""} 天` });
    list.push({ id: "G1", t: "「供货单状态」督办 2 张", s: "已超工单时限 1 天" });
    list.push({ id: "P1", t: "协议库存匹配待确认 3 条", s: "明天 17:00" });
    return list;
  }
  function emgMeta() {
    try { return emergencyTaskMeta.E001; } catch (_) { return null; }
  }
  function tracking() {
    const list = [];
    if (who() === "H") {
      if (window.__v90NoticeReleased) {
        const m = emgMeta();
        list.push({ id: "E001", t: "忠县 110kV 石拔南线 22 号塔滑坡", s: m ? `${m.status} · ${m.detail}` : "处理中", emg: true });
      }
      const s1 = T("S1");
      if (s1 && s1.closed) list.push({ id: "S1", t: "订单 4500951207 超期交货", s: "待签章 · 签章完成后自动办结" });
      list.push({ id: "HF2", t: "忠县 110kV 新立输变电工程物资到货", s: "关键物资 9 项，已到 7 项" });
      list.push({ id: "HF3", t: "华力通线缆股份有限公司发货", s: "10 月 27 日发货" });
    } else {
      const m0 = T("M0");
      if (m0 && m0.clue) list.push({ id: "M0", sub: "ecom", t: "监督检查线索 · 垫江、綦江", s: "已推送 2 条" });
      if (m0 && m0.assign) list.push({ id: "M0", sub: "ecom", t: "电商逾期支付 · 工单时限确认", s: m0.reply ? "专责已回复 · 保留原时限" : "已分配 · 等专责回复" });
    }
    return list;
  }
  /* 管理岗只有工单运营看板；个人看板按需定制（邱主任 10.15 C-7「不是所有的人都会有这个看板」），不再给一份和工单运营看板重复的 */
  function boards() {
    return who() === "A"
      ? [{ id: "M0", sub: "board", t: "工单运营看板", s: "全公司 · 37 家单位" }]
      : [{ id: "K1H", t: "我的看板", s: "忠县 · 业务指标、我的工单运营指标" }];
  }

  /* 当前所在：任务线程 id、应急、首页 */
  function here() {
    const s = S8();
    if (s.view === "emergency" && s.emergencyThread === "E001") return { id: "E001" };
    if (open()) { const t = T(open()); return { id: open(), sub: t && t.sub }; }
    if (s.view === "scheduled") return { view: "scheduled" };
    if (s.view === "chat") return { view: "home" };
    return {};
  }
  const isOn = (it, cur) => it.id === cur.id && (!it.sub ? true : it.sub === "board" ? !cur.sub || cur.sub === "board" : cur.sub === it.sub);

  const ICON = { brief: "i-list", do: "i-nav-do", track: "i-nav-track", board: "i-nav-board", ask: "i-search", star: "i-nav-star" };
  const ico = (k) => `<svg class="icon"><use href="#${ICON[k]}" /></svg>`;
  function group(key, name, list, cur, empty) {
    const has = list.some((it) => isOn(it, cur));
    const show = fold[key] != null ? fold[key] : has;
    const badge = list.length && key !== "board" ? `<span class="nav-badge${key === "track" && list.some((x) => x.emg) ? " alert" : ""}">${list.length}</span>` : "";
    const items = list.length
      ? list.map((it) => `<button class="v94-sub${isOn(it, cur) ? " on" : ""}" data-v94-item="${it.id}"${it.sub ? ` data-v94-sub="${it.sub}"` : ""}><span>${h(it.t)}</span><small>${h(it.s)}</small></button>`).join("")
      : `<p class="v94-none">${empty}</p>`;
    return `<button class="nav-btn v94-nav${has ? " active" : ""}" data-v94-group="${key}" aria-expanded="${show}">${ico(key)}<span class="side-text">${name}</span>${badge}<i class="v94-caret${show ? " open" : ""}"></i></button><div class="v94-subnav${show ? "" : " fold"}">${items}</div>`;
  }
  function render() {
    const box = document.querySelector("#sidebar .sidebar-scroll .nav-group");
    if (!box) return;
    const cur = here();
    const nSched = (S8().scheduled || []).length;
    const html = `<button class="nav-btn v94-nav${cur.view === "home" ? " active" : ""}" data-v94-home>${ico("brief")}<span class="side-text">今日简报</span></button>` +
      group("do", "智能办理", doing(), cur, "暂无待办理的事项") +
      group("track", "任务跟踪", tracking(), cur, "暂无跟踪中的事项") +
      group("board", "动态看板", boards(), cur, "") +
      `<button class="nav-btn v94-nav${cur.view === "home" && S8().v95Ask ? " active" : ""}" data-v94-ask>${ico("ask")}<span class="side-text">智能问数</span></button>` +
      `<button class="nav-btn v94-nav${cur.view === "scheduled" ? " active" : ""}" data-view="scheduled" data-v95-sched>${ico("star")}<span class="side-text">我的常用</span>${nSched ? `<span class="nav-badge" id="scheduleCountBadge">${nSched}</span>` : ""}</button>`;
    if (box.dataset.v94 === html) return;
    box.dataset.v94 = html;
    box.innerHTML = html;
  }
  window.v94SideRender = render;

  /* 原「应急任务中心」下的任务列表不再显示；最近对话里的任务线程不再单独成组 */
  function trimRecent() {
    document.getElementById("timelineSidebarEmergencyThreads")?.remove();
  }
  /* 顶栏右侧显示当天日期 */
  function dateTag() {
    const hd = document.getElementById("approveduiSystemHeader");
    if (!hd || hd.querySelector(".v94-date")) return;
    const d = new Date();
    hd.insertAdjacentHTML("beforeend", `<span class="v94-date">${d.getMonth() + 1} 月 ${d.getDate()} 日 周${"日一二三四五六"[d.getDay()]}</span>`);
  }
  /* 首页输入框上方「也可以直接问」：两个账号各给自己的问题（v90.js window.V95_QS）；问数首页里已经列出，不再重复 */
  function quickAsk() {
    const wrap = document.querySelector("#view-chat .composer-wrap");
    const cur = document.getElementById("v94qk");
    const qs = (window.V95_QS || {})[who()] || [];
    const show = wrap && !open() && !S8().v95Ask && qs.length;
    if (!show) { cur?.remove(); return; }
    if (cur && cur.dataset.who === who()) return;
    cur?.remove();
    wrap.insertAdjacentHTML("afterbegin", `<div id="v94qk" class="v94-qk" data-who="${who()}"><span>也可以直接问：</span>${qs.map(([id, q]) => `<button data-v94-q="${id}">${h(q)}</button>`).join("")}</div>`);
  }
  /* 问数首页借用简报卡片，标题跟着改 */
  function askTitle() {
    const el = document.querySelector("#normalBriefCard .normal-brief-title strong");
    const want = S8().v95Ask ? "智能问数" : "今日简报";
    if (el && el.textContent !== want) el.textContent = want;
  }
  const tick = () => { try { whoSync(); render(); trimRecent(); hist(); dateTag(); quickAsk(); askTitle(); } catch (_) { /* 侧栏未加载时不处理 */ } };
  document.addEventListener("click", (e) => {
    const q = e.target.closest && e.target.closest("[data-v94-q]");
    if (!q) return;
    e.preventDefault(); e.stopImmediatePropagation();
    EM.openThread(q.dataset.v94Q);
    setTimeout(tick, 60);
  }, true);

  function openItem(id, sub) {
    if (id === "E001") { window.v92OpenEmergency && window.v92OpenEmergency(); return; }
    /* 工单运营看板：从菜单直接到对应的一步（看板、电商逾期支付分析、月报），做过的只切过去看 */
    if (id === "M0" && window.v95Open) { window.v95Open("M0", sub === "ecom" ? "s-m0-ecom" : sub === "report" ? "s-m0-report" : "s-sub-board"); return; }
    EM.openThread(id);
  }

  /* ---------- 我的常用：按账号分开，存放到时间自动执行的和从对话存下来的常用（10 月 20 日晚补）----------
     原先菜单按钮重画后没接上点击，点了不跳转；列表是 V89 的 4 条通用系统任务，两个账号一样。 */
  const SCHED = {
    H: [
      { id: 101, name: "超期交货督办夜间巡查", desc: "每天凌晨查本人名下的超期交货督办：卡在收货第 1 步（供应商没在 ECP 确认发货通知）的，经 e物资提醒供应商；卡在第 2、3 步要您确认的，留到早上。结果写进今日简报。", schedule: "每天 00:30", next: "明天 00:30", status: "已启用", context: "结果推送今日简报", last: "今天 00:30 · 提醒供应商 2 家", runsToday: 1, successRate: 100, triggerKey: "plan" },
      { id: 102, name: "本周到期未收货订单", desc: "每周一列出本周 ECP 确定交货期已到、ERP 还没收货的订单，附供应商最新回复。", schedule: "每周一 08:00", next: "下周一 08:00", status: "已启用", context: "从对话「本周还有哪些订单到期未收货」存下", last: "本周一 08:00 · 3 张", runsToday: 0, successRate: 100, triggerKey: "plan" },
    ],
    A: [],
  };
  let schedWho = "";
  function schedSync() {
    const s = S8();
    if (!s || schedWho === who()) return;
    schedWho = who();
    s.scheduled = SCHED[schedWho] || [];
    s.selectedSchedule = (s.scheduled[0] || {}).id;
    if (s.view === "scheduled" && typeof renderSchedules === "function") renderSchedules();
  }
  /* 页头的小字原是 V89 写死的（含 1 个系统常驻任务、待处理异常 1），按当前列表改 */
  function schedHead() {
    const list = S8().scheduled || [];
    const set = (id, v, small) => { const el = document.getElementById(id); if (!el) return; el.textContent = v; const sm = el.nextElementSibling; if (sm) sm.textContent = small; };
    set("scheduleKpiTotal", String(list.length), "到时间自动执行，或从对话存下");
    set("scheduleKpiEnabled", String(list.filter((x) => ["运行中", "已启用"].includes(x.status)).length), "按时执行");
    set("scheduleKpiRuns", String(list.reduce((a, x) => a + (x.runsToday || 0), 0)), "结果推送今日简报");
    set("scheduleKpiFailed", String(list.filter((x) => x.status === "异常").length), "—");
    const empty = document.querySelector("#scheduleList .schedule-empty");
    if (empty && !list.length) empty.textContent = who() === "A" ? "还没有常用。生成月报后点「保存到我的常用」，或在对话里说要定期做的事。" : "还没有常用。";
  }
  if (typeof renderSchedules === "function") {
    const baseRS = renderSchedules;
    renderSchedules = function () { const r = baseRS.apply(this, arguments); try { schedHead(); } catch (_) { /* 页面未加载时不处理 */ } return r; };
  }
  function openSched() {
    schedSync();
    if (open()) document.querySelector('#emThread [data-em-act="close"]')?.click();
    try { window.setView("scheduled"); } catch (_) { /* 视图未加载时不处理 */ }
    if (typeof renderSchedules === "function") renderSchedules();
  }

  /* ---------- 最近对话：按账号各自的历史（10 月 20 日晚补）。原先两个账号同样 4 条 V89 对话，管理岗点开会进旧版应急任务中心 ---------- */
  const HIST = {
    H: [["Q2", "华力通线缆股份有限公司在途订单的交货情况", "昨天 · 智能问数"], ["Q3", "忠县驼丘仓库 OPGW 光缆还有多少", "周一 · 智能问数"]],
    A: [["QA1", "8 月各单位应办结未办结率前五", "昨天 · 智能问数"], ["QA2", "合同专业超期未办结最多的 5 家单位", "周一 · 智能问数"], ["QA3", "8 月触发次数最多的 5 个人", "上周五 · 智能问数"]],
  };
  function hist() {
    const box = document.getElementById("recentList");
    if (!box) return;
    box.querySelectorAll("[data-recent]").forEach((b) => b.remove());
    const list = HIST[who()] || [];
    const html = `<div id="v95hist"><button class="recent-item" data-v94-home>今日简报<span class="recent-meta"><span class="mini-dot live"></span>08:55 · 智能管家</span></button>${list.map(([id, t, m]) => `<button class="recent-item${open() === id ? " active" : ""}" data-v95-hist="${id}">${h(t)}<span class="recent-meta"><span class="mini-dot"></span>${h(m)}</span></button>`).join("")}</div>`;
    const cur = document.getElementById("v95hist");
    if (cur && cur.dataset.k === html) { if (cur !== box.lastElementChild) box.appendChild(cur); return; }
    cur?.remove();
    box.insertAdjacentHTML("beforeend", html);
    box.lastElementChild.dataset.k = html;
  }
  if (typeof window.renderRecent === "function") {
    const baseRR = window.renderRecent;
    window.renderRecent = function () { const r = baseRR.apply(this, arguments); try { hist(); } catch (_) { /* 侧栏未加载时不处理 */ } return r; };
  }

  /* ---------- 智能问数：单独的问数首页，按账号给示例问题；输入框里的问题按授权范围答（v90.js window.v95Ask） ---------- */
  function setAsk(on) {
    const s = S8();
    if (!s || !!s.v95Ask === on) return;
    s.v95Ask = on;
    document.body.classList.toggle("v95-ask-on", on);
    const inp = document.getElementById("chatInput");
    if (inp) inp.placeholder = on ? (who() === "A" ? "问数据，例如：合同专业超期未办结最多的 5 家单位" : "问数据，例如：本周还有哪些订单到期未收货") : "向智慧工作台发送消息…";
    EM.refreshHome();
  }
  function askSend() {
    const inp = document.getElementById("chatInput");
    const q = inp && inp.value.trim();
    if (!q || !window.v95Ask) return false;
    inp.value = "";
    window.v95Ask(q);
    setTimeout(tick, 60);
    return true;
  }
  const asking = () => !!S8().v95Ask && !open() && S8().view === "chat";
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Enter" || e.shiftKey || e.target.id !== "chatInput" || !asking()) return;
    if (askSend()) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);
  document.addEventListener("click", (e) => {
    if (!e.target.closest || !e.target.closest("#chatSend") || !asking()) return;
    if (askSend()) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);
  /* 换账号：问数、我的常用、最近对话跟着换 */
  let lastWho = "";
  function whoSync() {
    if (lastWho === who()) return;
    lastWho = who();
    if (S8().v95Ask) setAsk(false);
    schedSync();
    hist();
  }

  /* 捕获阶段处理：分组展开收起不能触发「点菜单就关闭任务线程」 */
  window.addEventListener("click", (e) => {
    const t = e.target;
    if (!t.closest || !t.closest("#sidebar")) return;
    let el;
    if ((el = t.closest("[data-v94-group]"))) {
      e.preventDefault(); e.stopImmediatePropagation();
      const k = el.dataset.v94Group;
      const sub = el.nextElementSibling;
      fold[k] = sub ? sub.classList.contains("fold") : true;
      render();
      return;
    }
    if ((el = t.closest("[data-v94-item]"))) {
      e.preventDefault(); e.stopImmediatePropagation();
      openItem(el.dataset.v94Item, el.dataset.v94Sub);
      setTimeout(tick, 60);
      return;
    }
    const home = (ask) => {
      if (open()) document.querySelector('#emThread [data-em-act="close"]')?.click();
      try { window.setView("chat"); } catch (_) {}
      /* 回到今日简报（或问数首页）：展开到摘要层 */
      try { const s = S8(); if (s.briefnavHome) { s.briefnavHome.level = "summary"; } if (s.homebriefBrief) s.homebriefBrief.root = "summary"; } catch (_) {}
      setAsk(ask);
      EM.refreshHome();
      setTimeout(tick, 60);
    };
    if (t.closest("[data-v94-home]")) {
      e.preventDefault(); e.stopImmediatePropagation();
      home(false);
      return;
    }
    if (t.closest("[data-v94-ask]")) {
      e.preventDefault(); e.stopImmediatePropagation();
      /* 不自动聚焦输入框：原型里输入框获得焦点会把简报区收起 */
      home(true);
      return;
    }
    if (t.closest("[data-v95-sched]")) {
      e.preventDefault(); e.stopImmediatePropagation();
      setAsk(false);
      openSched();
      setTimeout(tick, 60);
      return;
    }
    if ((el = t.closest("[data-v95-hist]"))) {
      e.preventDefault(); e.stopImmediatePropagation();
      setAsk(false);
      EM.openThread(el.dataset.v95Hist);
      setTimeout(tick, 60);
    }
  }, true);
  /* 任务线程、应急、账号切换都会改菜单，统一在这些动作后重画 */
  ["click", "keydown"].forEach((ev) => document.addEventListener(ev, () => setTimeout(tick, 80), true));
  setInterval(tick, 1000);
  tick();
})();
