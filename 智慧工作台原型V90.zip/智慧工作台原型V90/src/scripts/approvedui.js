/* Source runtime block 33 id="approveduiRuntime" */
(function(){
  const q=(s,r=document)=>r.querySelector(s), qa=(s,r=document)=>Array.from(r.querySelectorAll(s));
  const esc=s=>String(s??'').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]));
  let noticeDismissed=false,noticeReady=false;

  function ensureSystemHeader(){
    qa('body > .agentsurface-system-header,body > .systemheaderlegacy-system-header,body > .approvedui-system-header').forEach(x=>x.remove());
    const h=document.createElement('header');h.id='approveduiSystemHeader';h.className='approvedui-system-header';h.innerHTML='<div class="approvedui-system-title">供应链智慧工作台</div>';document.body.insertBefore(h,document.body.firstChild);
  }
  function noticeMarkup(){const card=document.createElement('aside');card.id='emergencyNotifyCard';card.className='approvedui-notice';card.dataset.approveduiNotice='compact';card.innerHTML='<div class="approvedui-notice-head"><span class="approvedui-notice-dot"></span><strong>应急任务提醒</strong><span class="approvedui-notice-time">'+(window.DEMO_CLOCK?window.DEMO_CLOCK.hm():"刚刚")+'</span><button type="button" class="approvedui-notice-close" data-approvedui-notice-close aria-label="关闭应急任务提醒">×</button></div><div class="approvedui-notice-body"><div class="approvedui-notice-label">应急物资主动保障工单 · 工单中心推送</div><div class="approvedui-notice-title">忠县 110kV 石拔南线 22 号塔滑坡</div><div class="approvedui-notice-copy">运检部提报 23 种抢修物资。</div><div class="approvedui-notice-state"><i></i><div><b>保障要求</b>市内 2 小时、省内 4 小时、跨省 8 小时出库</div></div></div><div class="approvedui-notice-actions"><button type="button" class="primary" data-approvedui-notice-enter>立即处理</button><button type="button" data-approvedui-notice-close>稍后处理</button></div>';return card}
  function syncNotice(){let card=q('#emergencyNotifyCard');const compact=card?.classList.contains('approvedui-notice')&&card?.dataset.approveduiNotice==='compact'&&!!q('[data-approvedui-notice-close]',card);if(card&&!compact){card.remove();card=null}if(!card&&!noticeDismissed){card=noticeMarkup();document.body.appendChild(card)}if(card)card.classList.toggle('show',noticeReady&&!noticeDismissed&&state?.view==='chat')}

  function recapModalMarkup(){return '<div class="processreview-recap-top"><span>17:00 · 今日复盘</span><h2>今日复盘</h2><p>按项目和物资汇总今日处理结果、未闭环风险及明日动作。</p></div><div class="processreview-recap-body"><div class="processreview-recap-metrics"><div class="processreview-recap-metric"><b>12</b><span>今日完成事项</span></div><div class="processreview-recap-metric"><b>5</b><span>AI自动完成</span></div><div class="processreview-recap-metric"><b>2</b><span>明日继续关注</span></div></div><div class="processreview-recap-list"><div class="processreview-recap-item"><i>✓</i><div><strong>迎峰度夏重点工程</strong><p>采购批次2026-08流标后的加急采购方式已确认，预计较常规重新采购缩短4天；采购负责人和项目发起人已同步。</p></div></div><div class="processreview-recap-item"><i>!</i><div><strong>重庆北部500千伏输变电工程</strong><p>主变压器订单CQ-2026-0187仍未取得供应商发货确认；10千伏开关柜和电力电缆交期需继续核验，可能影响8月22日安装窗口。</p></div></div><div class="processreview-recap-item"><i>→</i><div><strong>明日优先动作</strong><p>09:30前确认主变压器实际发货时间；10:00前复核开关柜和电力电缆到货承诺，仍未反馈则升级督办并同步项目负责人。</p></div></div></div><div class="processreview-recap-cheer">忠县石拔南线#22滑坡应急已推进到3项方案差异确认，其余一般事项由智能体继续跟踪。</div><div class="approvedui-recap-actions"><button data-approvedui-recap-chat>进入复盘对话</button></div></div>'}
  function patchRecap(){try{processreviewEnsureRecapUI?.()}catch(_){}const anchor=q('#processreviewRecapAnchor .processreview-recap-anchor-card');if(anchor){anchor.classList.add('approvedui-recap-clickable');anchor.setAttribute('data-processreview-open-recap','');anchor.innerHTML='<div class="processreview-recap-anchor-icon">✓</div><div class="processreview-recap-anchor-copy"><strong>今日复盘</strong><span>迎峰度夏采购方式已确认；主变压器发货和两类关键物资交期明日继续跟踪。</span></div><span class="approvedui-recap-hint">展开 ›</span>'}const overlay=q('#processreviewRecapOverlay');if(overlay){const modal=q('.processreview-recap-modal',overlay);if(modal)modal.innerHTML=recapModalMarkup()}}
  function recapConversationHtml(){return '<div class="message"><div class="avatar">智</div><div class="bubble assistant-copy"><div class="thinking"><span class="live-dot"></span>今日17:00工作复盘</div>今天共完成12项事项，其中5项由智能体自动完成。迎峰度夏重点工程采购批次2026-08已确认加急采购方式；忠县石拔南线#22滑坡应急已推进到3项方案差异确认。<div class="tool-call"><b>未闭环：</b>主变压器订单CQ-2026-0187仍待供应商确认发货；10千伏开关柜和电力电缆交期需要继续核验。</div></div></div><div class="message user"><div class="avatar">我</div><div class="bubble">今天还有什么没闭环？</div></div><div class="message"><div class="avatar">智</div><div class="bubble assistant-copy">重庆北部500千伏输变电工程还有两类问题：主变压器尚未确认发货，可能压缩到货验收时间；10千伏开关柜和电力电缆的承诺交期尚未最终核实，可能影响8月22日安装窗口。</div></div><div class="message user"><div class="avatar">我</div><div class="bubble">明天先做什么？</div></div><div class="message"><div class="avatar">智</div><div class="bubble assistant-copy">明日09:30前确认主变压器实际发货时间；10:00前复核开关柜和电力电缆到货承诺。届时仍无反馈，直接升级督办并同步重庆北部工程项目负责人。</div></div>'}
  function openRecapConversation(){let idx=state.conversations.findIndex(x=>x.approveduiRecap);if(idx<0){const item={title:'今日复盘 · 8月12日',type:'智能体对话',time:'刚刚',messages:5,live:false,approveduiRecap:true};const briefIdx=state.conversations.findIndex(x=>x.assistantbriefButler);state.conversations.splice(briefIdx>=0?briefIdx+1:0,0,item);idx=state.conversations.indexOf(item)}try{renderRecent?.();renderChatTable?.()}catch(_){}setView?.('chat');setTimeout(()=>{const thread=q('#chatThread');if(!thread)return;thread.innerHTML=recapConversationHtml();thread.scrollTop=0;qa('#recentList .recent-item').forEach(x=>x.classList.remove('active'));const btn=q(`#recentList [data-recent="${idx}"]`);btn?.classList.add('active')},60)}

  const threadRailSpecs=[
    {key:'main',host:'#view-chat',scroll:'#chatThread',item:'.message.user'},
    {key:'emergency',host:'#emergencyEmergencyWorkspace .emergency-chat-column',scroll:'#emergencyEmergencyWorkspace .emergency-thread-body',item:'.emergency-message.user'},
    {key:'agent',host:'#view-agentchat .agent-chat-main',scroll:'#view-agentchat #agentChatStream',item:'.agent-chat-message.user'},
    {key:'compose',host:'#view-agents .composer-chat',scroll:'#view-agents .composer-chat-scroll',item:'.composer-msg.user'}
  ];
  function railNodeText(node){const bubble=node.querySelector('.bubble,.emergency-bubble,.agent-chat-bubble,.composer-bubble')||node;return (bubble.textContent||'').replace(/\s+/g,' ').trim()}
  function railTop(node,scroll){const nr=node.getBoundingClientRect(),sr=scroll.getBoundingClientRect();return scroll.scrollTop+(nr.top-sr.top)}
  function updateThreadRail(spec){const host=q(spec.host),scroll=q(spec.scroll);if(!host||!scroll)return;const rail=host.querySelector(`:scope > .approvedui-thread-rail[data-approvedui-rail="${spec.key}"]`);if(!rail)return;const items=qa(spec.item,scroll),buttons=qa('.approvedui-thread-rail-mark',rail);if(!items.length)return;const sr=scroll.getBoundingClientRect(),target=scroll.scrollTop+Math.min(150,sr.height*.28);let active=0,dist=Infinity;items.forEach((node,i)=>{const d=Math.abs(railTop(node,scroll)-target);if(d<dist){dist=d;active=i}});buttons.forEach((b,i)=>b.classList.toggle('active',i===active))}
  function syncOneThreadRail(spec){const host=q(spec.host),scroll=q(spec.scroll);if(!host||!scroll)return;host.classList.add('approvedui-thread-host');let rail=host.querySelector(`:scope > .approvedui-thread-rail[data-approvedui-rail="${spec.key}"]`);if(!rail){rail=document.createElement('aside');rail.className='approvedui-thread-rail';rail.dataset.approveduiRail=spec.key;rail.setAttribute('aria-label','用户问题定位');rail.innerHTML='<div class="approvedui-thread-rail-track"></div>';host.appendChild(rail)}const items=qa(spec.item,scroll);const entries=items.map((node,i)=>{node.id=`approvedui-${spec.key}-question-${i+1}`;const label=`第${i+1}次提问`,full=railNodeText(node)||label,short=full.length>34?full.slice(0,34)+'…':full;return {id:node.id,label,full,short}});const track=q('.approvedui-thread-rail-track',rail),signature=entries.map(x=>`${x.id}\u0000${x.full}`).join('\u0001');if(track.dataset.approveduiSignature!==signature){track.dataset.approveduiSignature=signature;track.innerHTML=entries.map(x=>`<button class="approvedui-thread-rail-mark" data-approvedui-thread-jump="${x.id}" data-approvedui-thread-scroll="${spec.key}" aria-label="${esc(x.label)}：${esc(x.full)}" title="${esc(x.full)}"><span class="approvedui-thread-rail-text">${esc(x.short)}</span></button>`).join('')}rail.classList.toggle('has-items',items.length>0);if(!scroll.dataset.approveduiRailBound){scroll.dataset.approveduiRailBound='1';scroll.addEventListener('scroll',()=>{const s=threadRailSpecs.find(x=>q(x.scroll)===scroll);if(s)updateThreadRail(s)},{passive:true})}updateThreadRail(spec)}
  function syncThreadRails(){const old=q('#assistantbriefQuestionRail');if(old)old.hidden=true;threadRailSpecs.forEach(syncOneThreadRail)}
  function scheduleThreadRailSync(){requestAnimationFrame(()=>requestAnimationFrame(syncThreadRails));[0,60,180,360].forEach(delay=>setTimeout(syncThreadRails,delay))}

  /* V91（按 10.17 过稿意见）：应急在汇报现场当下弹出，点开后从第一步逐条执行。缺口不等人确认直接全省找货；回复分三批进来（v90.js 管快捷键 R）。
     每行：能力、标题、摘要、说明、依据、产出。状态和时间按 state.v91* 现算：v91EmgAt 点开时刻，v91Rev 已出的前 5 步，v91Batch 已到回复批次，v91BatchAt 各批时刻。 */
  const eTasksBase=[
    ['推送提醒','收到忠县应急需求工单','110kV 石拔南线 22 号塔受滑坡影响，需移塔改造。','工单原文：110kV 石拔南线 22 号铁塔受滑坡影响，需采取杆塔移位进行改造。','应急需求工单','事件进入运营中心待办。'],
    ['分析','按历史案例预估物资','2025 年 8 月同一区段两次滑坡都是移塔改造，预估要 23 种物资。','石拔北线 26 号塔、石拔南线 22 号塔两次滑坡的物资清单，作为本次预估；现场勘察回来后再核对。','历史应急事件记录','预估 23 种物资。'],
    ['查询','查忠县本单位库存','同规格有货 10 种，以大代小可代 2 种，本地解决 12 种，缺 11 种。','钢芯铝绞线 240/30 和配套接续管没有同规格，按以大代小用本地 300/40 代用；已通知忠县物资专责先备好 12 种。','忠县各仓库库存；以大代小标准表','本地 12 种已备货。'],
    ['查询','缺的 11 种直接全省找货','不等人确认：其他单位库存、协议库存、在建在途工程物资、应急采购四个渠道同时查。','按应急物资管理办法规定的先后顺序：其他单位库存、协议库存、在建在途借用，最后应急采购。','应急物资管理办法；ERP 库存；协议库存；在建在途订单','形成四类候选来源。'],
    ['办理','发出询问并持续催回复','向 14 个单位、9 家供应商、6 个在建项目同时发出 46 条询问。','每 5 分钟收一次回复，没回复的再催一次。','询问清单与发送时间','回复陆续进来，见「找货进展」。'],
    ['分析','借调前推演对方工期','借万州在建光缆，补还后离它架设还有 20 天，不影响投运；借涪陵只剩 1 天，不建议。','江苏中天 48 小时内能发 2.2 千米，10 月 26 日前补还万州。','万州、涪陵项目里程碑；江苏中天回复','选定借万州 2.2 千米，需万州项目部同意。'],
    ['分析','11 种全部找到来源','其他单位库存 6 种、协议库存 3 种、在建借用 1 种、应急采购 1 种。','北碚防振锤调出后会低于本单位应急储备，改由武隆多出 13 个。','各单位回复；应急储备','可以排供应方案。'],
    ['分析','排三个供应方案并比较','时间最快、质量最优、成本最低，等您选定。','逐项比较到货、送电、库存新旧、借调、费用和风险，推荐时间最快。','施工计划；抽检记录；费用测算','三个方案待选。'],
    ['办理','生成工单驱动执行','选定方案后生成调拨、借用、采购审批等工单。','对方在原系统按工单办理，结果以工单中心回执为准。','工单中心','工单已下发。'],
    ['推送提醒','跟踪到货与回执','未接收超过 30 分钟自动提醒，进度同步给忠县物资专责。','到货、回执逐张跟踪。','工单中心回执','跟踪中。']
  ];
  const v90Done=()=>!!(typeof state!=='undefined'&&state.v90EmgDone);
  const clock=ms=>{if(!ms)return '';const d=new Date(ms);return [d.getHours(),d.getMinutes(),d.getSeconds()].map(n=>String(n).padStart(2,'0')).join(':')};
  const OFFS=[0,2,4,8,10];
  let eTasks=[];
  /* 返回 [能力,标题,摘要,说明,依据,产出,状态,时间,原序号]，只含已经出现的步骤 */
  function v90Tasks(){
    const s=(typeof state!=='undefined'&&state)||{},rev=s.v91Rev||0,b=s.v91Batch||0,at=s.v91BatchAt||[],plan=!!s.v90PlanShown,fin=v90Done(),t0=s.v91EmgAt||0;
    const out=[];const push=(i,st,ms)=>{const y=eTasksBase[i].slice();if(fin&&i===7)y[2]='已选定方案'+(s.v90Plan||'一')+'。';if(fin&&i===8)y[2]='已生成 '+(s.v90Tickets||8)+' 张工单，对方在原系统按工单办理。';out.push(y.concat([st,typeof ms==='string'?ms:clock(ms),i]))};
    const ra=s.v91RevAt||[];for(let i=0;i<Math.min(rev,5);i++)push(i,i===4?(b>=3?'done':'current'):(i===rev-1?'current':'done'),ra[i]||t0+OFFS[i]*1000);
    if(b>=2)push(5,'done',at[1]);
    if(b>=3)push(6,'done',at[2]);
    if(plan||fin)push(7,fin?'done':'current',s.v91PlanAt);
    if(fin){push(8,'done',s.v90DoneAt||'');push(9,'current','')}
    eTasks=out;return eTasks
  }
  let renderedExecutionThread='';
  function executionCardCollapsed(){const key=state?.emergencyThread||'unknown';return !!state?.approveduiExecutionCollapsed?.[key]}
  function setExecutionCardCollapsed(key,value){if(!state.approveduiExecutionCollapsed)state.approveduiExecutionCollapsed={};state.approveduiExecutionCollapsed[key]=value}
  const replayPhaseNames=['研判需求','本单位解决','全省找货','方案与执行'];
  const replayPhaseIndex=[0,0,1,2,2,2,2,3,3,3];
  const replayStatusLabel={done:'已完成',current:'进行中',future:'待执行'};
  function replayPhaseFor(index){return replayPhaseIndex[index]??3}
  function replayCanvasTab(index){return index<3?'materials':index<7?'responses':'plans'}
  function replayEvent(x,pos){const status=x[6],index=x[8],phase=replayPhaseFor(index),open=status==='current'||state?.approveduiReplayOpen===index;const wait=index===4?'正在等待回复':index===7?'等待您选定方案':'正在执行';return `<details class="approvedui-replay-event ${status}" data-approvedui-replay-event="${index}" ${open?'open':''}><summary data-approvedui-replay-canvas="${replayCanvasTab(index)}" data-approvedui-replay-index="${index}"><span class="approvedui-replay-node">${status==='done'?'✓':status==='current'?'●':'○'}</span><span class="approvedui-replay-copy"><strong><i class="approvedui-cap-chip">${esc(x[0])}</i>${esc(x[1])}${status==='current'?'<span class="approvedui-replay-spinner" aria-label="执行中"></span>':''}</strong><small>${esc(x[2])}</small></span><time>${x[7]?esc(x[7])+' · ':''}${replayStatusLabel[status]}</time><span class="approvedui-replay-chevron">⌄</span></summary><div class="approvedui-replay-detail"><div class="approvedui-replay-detail-head"><span>执行记录 · 阶段 ${phase+1}</span><b>${status==='current'?wait:'执行结果'}</b></div><p>${esc(x[3])}</p><div class="approvedui-replay-facts"><div><span>依据</span><b>${esc(x[4])}</b></div><div><span>本次产出</span><b>${esc(x[5])}</b></div></div>${status==='current'&&index===7?'<div class="approvedui-replay-action"><span>三个供应方案待您选定</span><button data-emergency-open-canvas="plans">查看方案对比</button></div>':''}</div></details>`}
  function execCard(){
    const thread=state?.emergencyThread||'unknown';
    /* 忠县任务（E001）的执行过程和对话由 emergency-live.js 画 */
    if(window.v92ExecCardFor){const own=window.v92ExecCardFor(thread);if(own)return own}
    if(renderedExecutionThread!==thread){renderedExecutionThread=thread;state.approveduiReplayOpen=null;setExecutionCardCollapsed(thread,false)}
    v90Tasks();const fin=v90Done(),s=state||{},rev=s.v91Rev||0,b=s.v91Batch||0,plan=!!s.v90PlanShown;
    const collapsed=executionCardCollapsed(),done=eTasks.filter(x=>x[6]==='done').length,current=eTasks.find(x=>x[6]==='current'),events=eTasks.map(replayEvent).join(''),stageNames=replayPhaseNames;
    const last=eTasks.length?eTasks[eTasks.length-1][8]:0,stageCurrent=replayPhaseFor(current?current[8]:last);
    const stageNow=fin?'跟踪执行':plan?'选定供应方案':b>=3?'可以排供应方案':rev>=4?'全省找货':rev>=3?'本单位解决':'研判需求';
    const goal=fin?'跟踪工单到货与回执，未接收的自动提醒。':plan?'从三个供应方案中选定一个。':rev>=4?'缺的 11 种全省找到来源。':'弄清要哪些物资，本单位能解决多少。';
    const got=b>=3?11:b>=2?9:b>=1?4:0,replied=b>=3?38:b>=2?27:b>=1?12:0;
    const output=b>=3?'忠县本地解决 12 种；提报的 11 种已全部找到来源。':rev>=5?`46 条询问已发出，已回复 ${replied} 条，已有来源 ${got}/11。`:rev>=3?'预估 23 种；忠县本地解决 12 种，缺 11 种。':'正在按历史案例预估物资。';
    const risk=b>=2?'借用万州在建光缆需万州项目部同意。':'全省都没有的物资要走应急采购。';
    const next=fin?'到货后核对回执，闭环后进入事件复盘。':plan?'选定方案后生成工单，对方在原系统按工单办理。':b>=3?'您可以让我按已收到的回复出供应方案。':rev>=5?'继续归集回复，没回复的 5 分钟后再催。':'继续执行下一步。';
    const live=current?(current[8]===4?'等待回复':current[8]===7?'等待选定方案':fin?'跟踪执行中':'执行中'):'执行完成';
    const stage=`<section class="approvedui-replay-stage approvedui-replay-stage-current"><div class="approvedui-replay-stage-head"><div><span>阶段信息</span><b>当前阶段：${stageNow}</b></div><div class="approvedui-replay-stage-live"><i class="approvedui-replay-spinner"></i><span>${live}</span><em>${stageCurrent+1} / ${stageNames.length}</em></div></div><div class="approvedui-replay-stage-track">${stageNames.map((name,i)=>`<span class="${i<stageCurrent?'done':i===stageCurrent?'current':''}"><i>${i<stageCurrent?'✓':i+1}</i>${name}</span>`).join('')}</div><div class="approvedui-replay-stage-grid"><div><span>阶段目标</span><b>${goal}</b></div><div><span>阶段产出</span><b>${output}</b></div><div><span>阶段风险</span><b>${risk}</b></div><div><span>下一步</span><b>${next}</b></div></div></section>`;
    const chain=`<div class="approvedui-exec-intro"><div class="approvedui-exec-intro-copy"><b>任务执行过程</b><span>智能体的执行链、工具调用和阶段产出，逐步更新</span></div><div class="approvedui-replay-progress"><strong>${done}/${eTasks.length}</strong><span>${current?'<i class="approvedui-replay-spinner"></i>'+live:'执行完成'}</span></div><button type="button" class="approvedui-exec-toggle" data-approvedui-toggle-execution aria-expanded="${!collapsed}">${collapsed?'展开':'收起'} <i>${collapsed?'⌄':'⌃'}</i></button></div><div class="approvedui-exec-content" ${collapsed?'hidden':''}><div class="approvedui-replay-stream"><div class="approvedui-replay-intent"><span class="approvedui-replay-intent-icon">智</span><div><b>先用忠县本单位资源解决，缺的不等人确认，直接全省找货</b><p>按应急物资管理办法：先本单位，再其他单位库存、协议库存、在建在途借用，最后应急采购。</p></div></div>${events}</div></div>`;
    return `<article class="approvedui-exec-card approvedui-replay-card">${stage}${chain}</article>`
  }
  function rebuildEmergency(){if(typeof timelineTaskOverviewCard==='function'&&!window.__approveduiCardRebuilt){timelineTaskOverviewCard=function(){return execCard()};window.__approveduiCardRebuilt=true}if(typeof emergencyChatPane==='function'&&!window.__approveduiPaneWrapped){const base=emergencyChatPane;emergencyChatPane=function(){let h=base.apply(this,arguments);if(state.emergencyThread!=='center')h=h.replace('class="emergency-chat-column"','class="emergency-chat-column approvedui-selected-task"');return h};window.__approveduiPaneWrapped=true}}

  let drag=null;
  function startDrag(e,split){const layout=split.closest('.approvedui-resizable-layout');if(!layout)return;e.preventDefault();const r=layout.getBoundingClientRect();drag={layout,left:r.left,width:r.width};split.classList.add('dragging');document.body.style.cursor='col-resize';document.body.style.userSelect='none'}
  function moveDrag(e){if(!drag)return;const pct=Math.max(30,Math.min(62,((e.clientX-drag.left)/drag.width)*100));drag.layout.style.setProperty('--approvedui-left',pct.toFixed(1)+'%')}
  function stopDrag(){if(!drag)return;q('.approvedui-splitter.dragging')?.classList.remove('dragging');drag=null;document.body.style.cursor='';document.body.style.userSelect=''}

  function patchAll(){document.title='供应链智慧工作台';ensureSystemHeader();rebuildEmergency();patchRecap();syncNotice();syncThreadRails()}

  document.addEventListener('pointerdown',e=>{const s=e.target.closest('[data-approvedui-splitter]');if(s)startDrag(e,s)},true);document.addEventListener('pointermove',moveDrag,true);document.addEventListener('pointerup',stopDrag,true);document.addEventListener('pointercancel',stopDrag,true);
  document.addEventListener('dblclick',e=>{const s=e.target.closest('[data-approvedui-splitter]');if(s)s.closest('.approvedui-resizable-layout')?.style.setProperty('--approvedui-left','40%')},true);
  document.addEventListener('click',e=>{
    const railJump=e.target.closest('[data-approvedui-thread-jump]');if(railJump){e.preventDefault();e.stopImmediatePropagation();const node=document.getElementById(railJump.dataset.approveduiThreadJump),spec=threadRailSpecs.find(x=>x.key===railJump.dataset.approveduiThreadScroll),scroll=spec?q(spec.scroll):null;if(node&&scroll){const top=railTop(node,scroll)-Math.min(120,scroll.clientHeight*.22);scroll.scrollTo({top:Math.max(0,top),behavior:'smooth'});node.classList.add('question-anchor-flash');setTimeout(()=>node.classList.remove('question-anchor-flash'),1100)}return}
    const replaySummary=e.target.closest('[data-approvedui-replay-canvas]');if(replaySummary){e.preventDefault();e.stopImmediatePropagation();const index=Number(replaySummary.dataset.approveduiReplayIndex),tab=replaySummary.dataset.approveduiReplayCanvas;state.approveduiReplayOpen=index;state.emergencyCanvasTab=tab;state.collaborationTab=tab;state.emergencyCanvasOpen=true;try{emergencyRender?.()}catch(_){}scheduleThreadRailSync();return}
    const executionToggle=e.target.closest('[data-approvedui-toggle-execution]');if(executionToggle){e.preventDefault();e.stopImmediatePropagation();setExecutionCardCollapsed(state.emergencyThread,!executionCardCollapsed());try{emergencyRender?.()}catch(_){}scheduleThreadRailSync();return}
    const emergencyThread=e.target.closest('[data-emergency-thread]');if(emergencyThread?.dataset.emergencyThread)setExecutionCardCollapsed(emergencyThread.dataset.emergencyThread,false);
    if(e.target.closest('[data-recent],[data-agent-chat],[data-agent-prompt],[data-agentcenter-compose],[data-composer-example],[data-composer-send],[data-emergency-thread],[data-emergency-suggest],#chatSend,#agentChatSend,#emergencyCenterSend,#emergencySend,#collaborationSend'))scheduleThreadRailSync();
    if(e.target.closest('[data-approvedui-notice-close]')){noticeDismissed=true;syncNotice();return}
    if(e.target.closest('[data-approvedui-notice-enter]')){noticeDismissed=true;syncNotice();try{setExecutionCardCollapsed('E001',false);state.emergencyThread='E001';state.collaborationTask='E001';state.emergencyCanvasOpen=false;setView?.('emergency');setTimeout(()=>emergencyRender?.(),30)}catch(_){}return}
    if(e.target.closest('[data-approvedui-recap-chat]')){e.preventDefault();e.stopImmediatePropagation();processreviewCloseRecap?.();openRecapConversation();return}
    const recent=e.target.closest('[data-recent]');if(recent){const item=state.conversations?.[+recent.dataset.recent];if(item?.approveduiRecap){e.preventDefault();e.stopImmediatePropagation();openRecapConversation();return}}
    if(e.target.id==='processreviewRecapOverlay'){processreviewCloseRecap?.();return}
    const head=e.target.closest('.normal-brief-head');if(head&&!e.target.closest('button,.normal-brief-mini,[data-briefnav-title]')){if(typeof state?.briefnavHome==='object'){e.preventDefault();if(state.briefnavHome.level==='closed')briefnavOpenLevel?.('summary','summary');else briefnavClose?.()}return}
    if(typeof state?.briefnavHome==='object'&&state.briefnavHome.level!=='closed'&&!e.target.closest('#normalBriefCard')&&e.target.closest('#view-chat')){briefnavClose?.()}
  },true);
  const baseSetView=window.setView;if(typeof baseSetView==='function')window.setView=function(v){const r=baseSetView.apply(this,arguments);setTimeout(()=>{patchAll();if(v==='emergency')try{emergencyRender?.()}catch(_){}scheduleThreadRailSync()},25);return r};
  const mo=new MutationObserver(()=>{clearTimeout(window.__approveduiTimer);window.__approveduiTimer=setTimeout(()=>{patchRecap();syncNotice();syncThreadRails()},35)});mo.observe(document.body,{childList:true,subtree:true});
  setTimeout(()=>{patchAll();setTimeout(()=>{noticeReady=true;syncNotice();syncThreadRails()},350);try{if(state.view==='emergency')emergencyRender?.()}catch(_){}},70);
  setInterval(()=>{if(document.title!=='供应链智慧工作台')document.title='供应链智慧工作台'},900);
})();
