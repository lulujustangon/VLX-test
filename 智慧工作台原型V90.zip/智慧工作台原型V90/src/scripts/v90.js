/* V90（10/23 技术处汇报）2026-10-20 按演示全流程（10.20 修订版）和三位业务老师的确认单改，演示三段：
   第一段 忠县公司履约专责（H，打开时默认）在今日简报点「重点事项」→ 订单 4500951207 超期交货（进度轴＋AI 建议）→ 查看分析过程（07:32—08:51 已完成的记录）
          → 确认，去办理 → 确认办理（同步 ERP 收货单据至电子签章平台、分配签章人员）→ 回查结果，核对无误确认；
   第二段 办完后讲解人按 E（40 秒兜底），画面时间跳到 10:15，弹出忠县应急，处理过程在 emergency-live.js；
   第三段 切到物资部数字化管理专责（A），首页就是工单运营看板（M0）：总览三项、走势/按专业/按单位/按人/异常关注，
          对话生成新图 → 电商逾期支付按业务时限分两类 → 形成监督检查线索、分配物资部对应专责确认时限（按 R 专责回复）→ 对话生成月报。
   1019 版的三级履约协调（R1）、我的关注（K1）、电商逾期支付线程（M1）代码保留、不再登记。 */
(() => {
  const EM = window.EM;
  if (!EM || !window.SCENES) return;
  const { h, say, later, confirm, draw, finish, toast } = EM;
  /* V89 的 state 是脚本级常量，不在 window 上 */
  const S8 = () => (typeof state !== "undefined" ? state : {});
  /* 汇报演示中不弹 V89 的 17:00「今日复盘」 */
  clearTimeout(window.__processreviewRecapTimer);
  /* 也不自动冒出 V89 的「主变压器订单发货确认」新增任务（履约内容，本次不演示） */
  try { sensingDetectNewTask = function () {}; } catch (_) {}

  /* ---------- 通用小件（与 scene-flows.js 同一套样式） ---------- */
  const chip = (t, tone = "") => `<span class="sc-chip ${tone}">${h(t)}</span>`;
  const btn = (t, a, kind = "", dis = false) => `<button class="em-btn ${kind === "p" ? "em-btn-p" : ""}" data-em-act="${a}" ${dis ? "disabled" : ""}>${h(t)}</button>`;
  const tbl = (head, rows, cls = "") => `<div class="sc-tw"><table class="sc-t ${cls}"><thead><tr>${head.map((x) => `<th>${h(x)}</th>`).join("")}</tr></thead><tbody>${rows.map((r) => `<tr${r.cls ? ` class="${r.cls}"` : ""}>${(r.cells || r).map((c) => `<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
  const kpis = (list) => `<div class="sc-kpis">${list.map((k) => `<div class="sc-kpi ${k.tone || ""}"><b>${h(k.v)}</b><span>${h(k.k)}</span>${k.s ? `<small>${h(k.s)}</small>` : ""}</div>`).join("")}</div>`;
  const page = (title, sub, body) => `<div class="sc-page"><div class="sc-ph"><div><h3>${h(title)}</h3>${sub ? `<p>${sub}</p>` : ""}</div></div>${body}</div>`;
  const sec = (title, body) => `<section class="sc-sec"><h4>${title}</h4>${body}</section>`;
  const kv = (rows) => `<dl class="sc-kv">${rows.map((r) => `<div><dt>${h(r[0])}</dt><dd>${r[1]}</dd></div>`).join("")}</dl>`;
  const empty = (t) => `<div class="sc-empty"><i class="v90-spin"></i>${h(t)}</div>`;
  const used = (T, a) => !!(T.used && T.used[a]);
  const mark = (T, a) => ((T.used = T.used || {}), (T.used[a] = true));

  /* 逐行调用能力：{say} 自述打算，停一会儿；{grp} 专业组合能力分组；{call} 先显示「正在调用」转圈，ms 毫秒后返回结论。
     每行完成时回调 onRow(行, 序号)，用来同步右侧画布。整体节奏按讲话速度定，脚本里的等待时间按实测记 */
  function think(T, title, rows, done, onRow) {
    T.busy = true;
    const m = say(T, { k: "chain", title, items: [], live: true });
    let t = 350;
    rows.forEach((r, i) => {
      if (r.call) {
        const row = Object.assign({}, r, { pending: true });
        later(T, t, () => { m.items.push(row); draw(T); });
        t += r.ms || 1200;
        later(T, t, () => { row.pending = false; if (onRow) onRow(r, i); draw(T); });
        t += 450;
      } else {
        later(T, t, () => { m.items.push(r); if (onRow) onRow(r, i); draw(T); });
        t += r.say ? r.wait || 2200 : r.grp ? 500 : r.wait || 1000;
      }
    });
    later(T, t, () => { m.live = false; T.busy = false; if (done) done(); draw(T); });
  }
  /* 对话里有待确认的卡片时，用户说「确认」等于点确认 */
  const pendingOk = (v) => {
    if (!/^(确认|可以|同意|没问题|好的?|写入|提交|就这样)/.test(v.trim())) return false;
    const b = document.querySelector('#emThread [data-em-act="c-ok"]');
    if (!b) return false;
    setTimeout(() => b.click(), 300);
    return true;
  };

  /* ================= 第一段：供应链运营中心专责办一件三级履约协调 =================
     订单、项目、交货期、供应商答复取 V89 履约收资（scene-data.js lvyue.万马），供应商名称一律用打码名；
     库存、工程里程碑、质量抽检三步的结论为演示设定。约谈时间、超期天数按当天日期算。 */
  const LYD = (window.SCENE_DATA || {}).lvyue || {};
  const WM = LYD.万马 || { 订单: "", rows: [], 交货期: "2026-10-10", 项目: "", 方式: "" };
  const WMN = WM.供应商名 || "供应商";
  const WMSUM = (WM.rows || []).reduce((a, r) => a + r.金额, 0);
  const num2 = (n, d = 2) => Number(n).toLocaleString("zh-CN", { maximumFractionDigits: d });
  const wan = (n) => `${num2(n / 10000, 2)} 万元`;
  const mono = (v) => `<span class="em-mono">${h(v)}</span>`;
  const today0 = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
  const overDays = (ymd) => Math.floor((today0() - new Date(`${ymd}T00:00:00`)) / 86400000);
  const overTxt = (ymd) => { const n = overDays(ymd); return n > 0 ? `已超 ${n} 天` : "—"; };
  /* 约谈放在下一个工作日 14:00（周五办理则约在下周一） */
  const meetTxt = () => { const d = today0(); do { d.setDate(d.getDate() + 1); } while (d.getDay() === 0 || d.getDay() === 6); const tmr = (d - today0()) / 86400000 === 1; return `${tmr ? "明天" : `${d.getMonth() + 1} 月 ${d.getDate()} 日`} 14:00`; };
  const CROSS = [
    ["市区供电分公司", WM.订单, `220kV电缆终端等 ${(WM.rows || []).length} 行`, wan(WMSUM), WM.交货期],
    ["市北供电分公司", "4500946215", "电力电缆 AC10kV YJV 3×400", "386.40 万元", "2026-10-12"],
    ["市北供电分公司", "4500951137", "10kV电缆中间接头 3×400", "42.18 万元", "2026-10-28"],
    ["市北供电分公司", "4500953560", "1kV电缆终端 4×185", "8.65 万元", "2026-11-06"],
    ["物资公司直管", "4500949902", "110kV电缆终端", "612.00 万元", "2026-10-09"],
    ["物资公司直管", "4500955018", "电力电缆 AC110kV 1×800", "1,286.50 万元", "2026-11-20"],
  ];
  const R1_FORM = () => [
    ["受理意见", "同意受理，由物资公司统一约谈供应商"],
    ["约谈时间", `${meetTxt()}，物资公司 3 楼会议室`],
    ["约谈要求", "10 月 30 日前发货并出具书面承诺"],
    ["一并督办", "同一供应商超期订单 3 张（市区、市北、物资公司直管）"],
    ["通知方式", "e物资发约谈通知，抄送市区、市北供电分公司"],
  ];
  const R1_THINK = () => [
    { say: "这是市区供电分公司提的三级履约协调申请。按「三级履约协调」思维链，受理前我先核对四件事：申请是否属实、是不是供应商整体有问题、有没有库存可以调、工程最晚能等到哪天，再决定受理还是退回。", wait: 3600 },
    { grp: "履约风险研判" },
    { cap: "查询", call: "工单中心 · 三级履约协调工单", t: `订单 ${WM.订单}，${(WM.rows || []).length} 行，${wan(WMSUM)}，确定交货期 ${WM.交货期}，${overTxt(WM.交货期)}。`, from: "工单中心；e物资订单", ms: 1000 },
    { cap: "查询", call: "e物资 · 供应商答复", t: "供应商答复：220kV 电缆终端附件（应力锥）到厂延误，预计 10 月 30 日发货、11 月 2 日到货。", from: "e物资答复原文", ms: 2000 },
    { cap: "查询", call: "ECP · 各单位供应计划", t: "同一供应商全省在途订单 6 张，超期 3 张：市区、市北、物资公司直管各 1 张。", from: "ECP 供应计划（37 家单位）", ms: 1900 },
    { cap: "审核", call: "合同专用条款", t: "合同有迟延交货违约条款，可以约谈供应商并主张违约金。", from: "合同第 12 条 迟延交货", ms: 700 },
    { grp: "替代资源测算" },
    { cap: "查询", call: "ERP · 全省库存", t: "全省没有同型号 220kV 电缆终端附件可以调用，只能催供应商发货。", from: "ERP 库存（各单位）", ms: 2700 },
    { grp: "工程影响研判" },
    { cap: "查询", call: "项目里程碑计划", t: "附件 11 月 2 日前到货不影响送电；再晚就要调整送电计划。", from: "芯联微电子 220kV 业扩配套工程里程碑", ms: 1200 },
    { cap: "查询", call: "质量抽检记录", t: "这家供应商近一年抽检合格，问题集中在交期。", from: "近 12 个月抽检记录", ms: 1400 },
    { say: "三家单位同时超期，是供应商整体履约问题，单靠市区催不动，适合物资公司出面统一约谈。我按 ESC 受理单把要填的内容填好。", wait: 2800 },
    { cap: "写作", call: "ESC 受理单 · 三级履约协调", t: "受理意见、约谈时间、约谈要求、督办订单、通知方式已填好，见右侧。", from: "ESC 三级履约协调受理单模板", ms: 2000 },
  ];
  const R1 = {
    pane: "画布",
    tabs: ["受理单", "申请与订单"],
    init(T) { T.done = false; T.form = 0; T.tab = 1; },
    bg: () => [["申请单位", "市区供电分公司"], ["订单", `${WM.订单}｜${wan(WMSUM)}`], ["时限", "今日 17:00"]],
    intro(T) {
      think(T, "受理前核对", R1_THINK(), () => {
        say(T, { k: "ai", html: "建议受理，由物资公司统一约谈供应商：<br>· 这家供应商全省 3 张订单同时超期，单靠市区催不动；<br>· 全省没有同型号库存可以调用，只能催供应商发货；<br>· 11 月 2 日前到货不影响送电，约谈时要求 10 月 30 日前发货并书面承诺。<br>受理单已按 ESC 格式填好，您核对后确认，我通过接口写入 ESC。" });
        R1.ask(T);
      }, (r) => { if (r.cap === "写作") { T.form = 1; T.tab = 0; } });
    },
    ask(T) {
      confirm(T, {
        title: "写入 ESC 受理单",
        action: "在 ESC 受理这张三级履约协调，并发出约谈通知：",
        rows: R1_FORM().map((r) => [r[0], r[1], ""]),
        note: "以您的账号通过接口写入 ESC，只写这张受理单；ESC 回执回到这里，操作记录留存备查。",
        ok: "确认写入",
        onOk: () => R1.write(T),
        onCancel: () => { say(T, { k: "ai", html: "已取消，受理单保留在右侧。要改哪一项直接告诉我，比如「约谈改到后天下午」。" }); },
      });
    },
    write(T) {
      think(T, "写入 ESC", [
        { cap: "办理", call: "ESC 接口 · 三级履约协调受理", t: "受理单已写入，ESC 返回受理成功。", from: "ESC 回执", ms: 3200 },
        { cap: "协同提醒", call: "e物资 · 约谈通知", t: "约谈通知已发给供应商，抄送市区、市北供电分公司。", from: "e物资发送记录", ms: 1800 },
      ], () => {
        T.done = true; T.form = 2;
        say(T, { k: "result", title: "ESC 已受理", lines: [`三级履约协调已受理，约谈定在${meetTxt()}`, "约谈通知已经 e物资发给供应商，抄送市区、市北", "3 张超期订单已列入督办", "操作记录：本人账号 · 接口写入 ESC · 可在 ESC 查到这次受理"] });
        finish(T.id, { status: "external", current: `已受理，约谈定在${meetTxt()}`, remain: "待约谈", log: "受理三级履约协调" });
        S8().v91R1Done = true;
        EM.refreshHome();
        /* 第二段：讲解人说完这件按 E 弹出应急提醒卡；没按的话约 15 秒后自动弹出 */
        setTimeout(releaseNotice, 15000);
      });
    },
    used: (T, a) => used(T, a),
    act() {},
    reply(T, v) {
      if (T.done) return false;
      if (pendingOk(v)) return true;
      if (/后天/.test(v) && /约谈/.test(v)) {
        say(T, { k: "ai", html: "约谈时间可以改，改好后会重新请您确认。演示中先保持原时间。" });
        return true;
      }
      return false;
    },
    right(T) {
      const form = R1_FORM();
      if ((T.tab || 0) === 0) {
        if (!T.form) return page("ESC 受理单 · 三级履约协调", "", empty("正在核对，核对完由我填写"));
        return page("ESC 受理单 · 三级履约协调", T.form === 2 ? chip("ESC 已受理", "ok") : chip("AI 已填写 · 待您确认", "warn"),
          kv(form.map((r) => [r[0], `${h(r[1])}${T.form === 1 ? ' <em class="v92-ai-tag">AI 填写</em>' : ""}`])) +
          sec("填写依据", kv([["超期订单", "ECP 供应计划：同一供应商 6 张在途、3 张超期"], ["交期要求", "项目里程碑：11 月 2 日前到货不影响送电"], ["违约约束", "合同第 12 条 迟延交货"]])));
      }
      return page("三级履约协调申请", `市区供电分公司 · ${h(WMN)} · 订单 ${mono(WM.订单)}`,
        sec("申请内容", kv([["订单", `${mono(WM.订单)} · ${(WM.rows || []).length} 行 · ${h(wan(WMSUM))} · ${h(WM.方式 || "")}`], ["项目", h(WM.项目 || "")], ["确定交货期", `${h(WM.交货期)} · <b class="sc-red">${h(overTxt(WM.交货期))}</b>`], ["供应商答复", "“220kV 电缆终端附件（应力锥）到厂延误，预计 10 月 30 日发货，11 月 2 日到货。”"], ["市区意见", "要求 10 月 30 日前发货并书面承诺；用于重点用户业扩送电，申请物资公司协调"]])) +
        sec("同一供应商全省在途订单 · 6 张", tbl(["单位", "订单", "物料", "金额", "确定交货期", "超期"], CROSS.map((r) => { const o = overTxt(r[4]); return [h(r[0]), mono(r[1]), h(r[2]), h(r[3]), h(r[4]), o === "—" ? "—" : `<b class="sc-red">${h(o)}</b>`]; }))) +
        sec("订单明细", tbl(["行", "物料编码", "物料", "数量", "金额（元）"], (WM.rows || []).map((r) => [h(r.行), mono(r.物料编码), h(r.物料), num2(r.数量, 3), num2(r.金额, 2)]), "sc-t-dense")));
    },
  };

  /* ---------- 今日简报里另外两件要办的事：只给出核对和建议，本次演示不展开 ---------- */
  const simple = (title, rows, advice, right) => ({
    pane: "画布", tabs: [title], init() {}, bg: () => [],
    intro(T) { think(T, "查看情况", rows, () => say(T, { k: "ai", html: advice })); },
    act() {}, right: () => page(title, "", right),
  });
  const R2 = simple("供货单状态", [
    { cap: "查询", call: "ECP · 供货单", t: "2 张供货单的发货状态 3 天没有更新，工单时限 2 天，已超 1 天。", from: "ECP 供货单", ms: 1900 },
    { cap: "查询", call: "e物资 · 供应商联系人", t: "两家供应商的履约联系人都已在 e物资维护。", from: "e物资", ms: 2200 },
  ], "建议今天通过 e物资催两家供应商更新发货状态，明天还没更新再电话联系。要我起草催办消息，直接告诉我。",
  kv([["供货单", "2 张"], ["状态", "发货状态 3 天未更新"], ["工单时限", "2 天，已超 1 天"], ["建议", "e物资催供应商更新"]]));
  const R3 = simple("协议库存匹配", [
    { cap: "查询", call: "ERP · 协议库存匹配结果", t: "3 条匹配结果待确认：2 条匹配到同物料号，1 条匹配到相近规格。", from: "ERP 协议库存匹配", ms: 2800 },
    { cap: "审核", call: "相近规格替代规则", t: "相近规格那条需要需求单位确认能否替代。", from: "规则库 · 协议库存匹配", ms: 600 },
  ], "同物料号的 2 条可以直接确认；相近规格的 1 条，建议先问需求单位能否替代。",
  kv([["待确认", "3 条"], ["同物料号", "2 条，可直接确认"], ["相近规格", "1 条，需需求单位确认"]]));

  /* ================= 第一段（2026-10-20 改）：忠县公司履约专责办一张超期交货督办 =================
     依据《到期收货问题.docx》（业务确认单1020/）：超期交货督办按 ECP 供应计划确定交货期触发；是否到货经 e物资问供应商；
     收货三步：① 供应商在 ECP 确认发货通知 ② ERP 收货单据同步电子签章平台并分配签章人员 ③ 在 e物资签章。演示走第 ② 步卡住。
     订单号、物资、金额、项目、日期、签章人员为演示设定；供应商取自《市区公司10-11月供应计划》里同类物资的供应商（用户 10 月 20 日定），见客户交付说明。 */
  const OD = {
    no: "4500951207", sup: "西安西电高压开关有限责任公司", mat: "110kV 组合电器（GIS）2 间隔", amt: "1,452.60 万元",
    prj: "忠县 110kV 新立输变电工程", wh: "忠县驼丘仓库", due: "2026-10-10", signer: "驼丘仓库库管员、项目部物资员",
  };
  const S1_SIGNERS = [OD.signer, "驼丘仓库库管员、忠县公司物资部专责"];
  const odOver = () => overDays(OD.due);
  /* 和画面日期有关的天数都按 DEMO_CLOCK 推算，汇报改期只改 demo-clock.js 的 DAY */
  const S2_DUE = "2026-10-18";
  const s2Over = () => overDays(S2_DUE);
  const todayMD = () => { const d = new Date(); return `${d.getMonth() + 1} 月 ${d.getDate()} 日`; };
  const useLeft = () => -overDays("2026-10-28");
  window.__v96Days = { od: odOver, s2: s2Over };
  /* 收货三步的状态随办理推进：0 办理前，1 已办理 */
  const STEPS3 = (T) => [
    ["① 确认发货通知", "ECP", "ok", "供应商 10 月 15 日已确认"],
    ["② 收货单据同步电子签章平台、分配签章人员", "ERP · 电子签章平台", T.handled ? "ok" : "bad", T.handled ? `已同步；签章人员：${T.sign || OD.signer}` : "未同步；签章人员未分配"],
    ["③ 签章", "e物资", T.handled ? "run" : "todo", T.handled ? "待签章，签章提醒已推送" : "未开始"],
  ];
  const ST_TXT = { ok: "✓ 已完成", bad: "✗ 卡在这一步", run: "进行中", todo: "— 未开始" };
  /* 进度轴：首页详情和线程画布共用 */
  function axis(T) {
    const done = !!(T && T.handled);
    const nodes = [
      ["d", "7 月 15 日", "签订合同"],
      ["k", "10 月 10 日", "ECP 供应计划确定交货期"],
      ["d", "10 月 15 日", "供应商在 ECP 确认发货通知"],
      ["d", "10 月 16 日", `货到${OD.wh}`, "供应商回复"],
      done ? ["d", "今天", "ERP 单据已同步电子签章平台", "签章人员已分配"] : ["x", "卡住", "ERP 收货单据未同步电子签章平台", "签章人员未分配"],
      done ? ["r", "进行中", "e物资签章", "签章提醒已推送"] : ["t", "未开始", "e物资签章"],
      ["n", todayMD(), "工单推送", `已超 ${odOver()} 天`],
    ];
    return `<ol class="v93-axis">${nodes.map(([c, a, b, s]) => `<li class="${c}"><i></i><time>${h(a)}</time><b>${h(b)}</b>${s ? `<small>${h(s)}</small>` : ""}</li>`).join("")}</ol>`;
  }
  const S1_ADVICE = () => `<b>不是供应商违约。</b>供应商回复 10 月 16 日已送到${h(OD.wh.replace("忠县", ""))}，收货卡在第 2 步：ERP 收货单据没同步到电子签章平台，签章人员未分配。<br><b>较急：</b>项目 10 月 28 日要领用安装，收货不办完，出库领用和到货款结算都要往后拖。<br><b>建议：</b>今天同步单据、分配签章人员，同时告知项目经理和结算专责。`;
  /* 首页里点开这张工单：上方进度轴，下方 AI 建议 */
  function s1Detail(e, crumb, rootName) {
    const T = (EM.S.threads || {}).S1 || {};
    const fin = !!T.closed;
    return `<div class="homebrief-panel">${crumb([{ label: rootName, back: "root" }, { label: e.cat, back: "list" }, { label: e.title }])}
      <article class="homebrief-detail v93-od">
        <header><div><strong>${h(e.title)}</strong><span>超期交货督办 · 今天 07:32 推送</span></div><em class="${fin ? "ok" : "risk"}">${fin ? "已办理 · 待签章" : `已超 ${odOver()} 天`}</em></header>
        <p class="v93-od-meta">${h(OD.sup)} · ${h(OD.mat)} · ${h(OD.amt)} · ${h(OD.prj)}</p>
        ${axis(T)}
        <section class="v93-ai"><h4>AI 建议</h4><p>${fin ? `单据已同步电子签章平台，签章人员已分配，收货进入第 3 步。签章完成、ERP 收货后工单自动办结。` : S1_ADVICE()}</p></section>
        <div class="v93-od-acts"><button class="em-btn em-btn-p" data-v93-open="S1">查看分析过程</button>${fbBox()}</div>
      </article></div>`;
  }
  /* 业务人员觉得这张工单推得不对，可以直接反馈给工单中心管理人员 */
  const FB_WHY = ["推送对象不对", "办理时限不合理", "工单内容不属实"];
  function fbBox() {
    const f = S8().v94Fb || {};
    if (f.st === "sent") return `<span class="v94-fb-done">已反馈「${h(f.why)}」，工单中心管理人员（物资部数字化管理专责）处理后结果回到今日简报</span>`;
    if (f.st !== "open") return `<button class="em-btn" data-v94-fb="open">反馈工单不合理</button>`;
    return `<div class="v94-fb"><b>反馈工单不合理</b><div>${FB_WHY.map((w, i) => `<label><input type="radio" name="v94fb" value="${h(w)}" ${i === (f.i || 0) ? "checked" : ""}>${h(w)}</label>`).join("")}</div><p>提交给工单中心管理人员。反馈先作为规则修改候选，经确认后才改规则。</p><span><button class="em-btn" data-v94-fb="cancel">取消</button><button class="em-btn em-btn-p" data-v94-fb="send">提交</button></span></div>`;
  }
  /* 分析过程：工单推送后 07:32—08:51 已经做完，打开时按段展开（不重跑） */
  const S1_REC = [
    { t: "核对工单", at: "07:32", calls: [
      ["查询", "ECP · 供应计划", `确定交货期 10 月 10 日，到今天已超 ${odOver()} 天。`, "ECP 供应计划"],
      ["查询", "ERP · 收货记录", `订单 ${OD.no} 没有收货记录，督办属实。`, "ERP 采购订单收货"],
    ], so: "工单属实。超期没收货有两种情形：货没送到，或货到了没办收货。系统判断不了，先问供应商。" },
    { t: "分清情形", at: "07:32—08:50", calls: [
      ["协同提醒", "e物资 · 向供应商征询", `07:32 已发：“订单 ${OD.no} 是否已送达？请回复送达日期和地点。”`, "e物资消息记录"],
      ["查询", "e物资 · 供应商回复", `08:50 回复：“10 月 16 日已送达${OD.wh}。”`, "e物资回复原文"],
      ["审核", "ECP · 发货通知", "供应商 10 月 15 日已在 ECP 确认发货通知，和回复对得上。", "ECP 发货通知"],
    ], so: `供应商回复 10 月 16 日已送达${OD.wh}；已到货、未办收货，不属于供应商违约。` },
    { t: "查收货卡在哪一步", at: "08:51", calls: [
      ["审核", "思维链 · 收货入库", "收货分三步：供应商在 ECP 确认发货通知 → ERP 收货单据同步电子签章平台并分配签章人员 → 在 e物资签章。", "思维链 · 收货入库"],
      ["查询", "ECP · 发货通知", "① 确认发货通知：已完成。", "ECP"],
      ["查询", "ERP · 单据同步状态", "② 收货单据未同步电子签章平台，签章人员未分配。", "ERP"],
      ["查询", "e物资 · 签章", "③ 签章：未开始。", "e物资"],
    ], so: "卡在第 2 步。" },
    { t: "研判紧急程度和影响", at: "08:51", calls: [
      ["审核", "思维链 · 超期交货督办", `已到货未办收货的，不属于供应商违约，不启动约谈、发函；超期 ${odOver()} 天，按一般超期处理。`, "思维链 · 超期交货督办"],
      ["查询", "ERP · 项目物资需求计划", `${OD.prj}计划 10 月 28 日领用这批组合电器安装，收货过账后才能出库领用，还剩 ${useLeft()} 天。`, "ERP 项目物资需求计划"],
      ["审核", "思维链 · 物资结算", "收货入账后才能办到货款结算，收货拖得越久，到货款支付越晚。", "思维链 · 物资结算"],
      ["审核", "思维链 · 质量抽检", "组合电器不在抽检范围，不需要通知质量专责。", "思维链 · 质量抽检"],
    ], so: "紧急程度：较急，10 月 28 日要领用安装；严重程度：一般，不是供应商违约；影响环节：出库领用、到货款结算。" },
    { t: "建议", at: "08:51", calls: [
      ["查询", "电子签章平台 · 近 3 个月签章记录", `${OD.wh}同类订单由库管员、项目部物资员签章。`, "电子签章平台"],
    ], so: `建议：今天把 ERP 收货单据同步到电子签章平台，签章人员分配${OD.signer}；同时告知项目经理 10 月 28 日前签完即可领用、结算专责收货后办到货款。如果供应商回复没送货，按逾期程度建议约谈或发函催告。` },
  ];
  const S1_CHAINS = ["超期交货督办", "收货入库", "物资结算", "质量抽检"];
  /* 折叠区的开合状态：画面重画后保持用户点开、收起的样子 */
  const FOLDS = {};
  document.addEventListener("toggle", (e) => {
    const d = e.target;
    if (!d || !d.matches) return;
    if (d.matches("details[data-v95-fold]")) FOLDS[d.dataset.v95Fold] = d.open;
    else if (d.matches("details[data-v95-rec]")) { const T = (EM.S.threads || {}).S1; if (T) { T.recOpen = T.recOpen || {}; T.recOpen[d.dataset.v95Rec] = d.open; } }
  }, true);
  window.__v95Folds = FOLDS;
  const nCalls = S1_REC.reduce((a, s) => a + s.calls.length, 0);
  function s1Rec(T) {
    const n = T.recN || 0;
    /* 每一步默认只露结论，点开看调用了什么、依据是什么（邱主任 10.15 D-3；10 月 20 日晚为减少画面信息量改为默认收起） */
    T.recOpen = T.recOpen || {};
    const secs = S1_REC.slice(0, n).map((s, i) => `<li class="em-gen-in"><details class="v95-sec" data-v95-rec="${i}" ${T.recOpen[i] ? "open" : ""}><summary><header><i>${i + 1}</i><b>${h(s.t)}</b><time>${h(s.at)}</time><em class="v95-n">${s.calls.length} 项调用 ›</em></header><p class="v93-so">${h(s.so)}</p></summary><ol>${s.calls.map(([c, call, t, from]) => `<li><p><em class="em-cap">${h(c)}</em><span class="em-call">${h(call)}</span>${h(t)}</p><small>依据：${h(from)}</small></li>`).join("")}</ol></details></li>`).join("");
    const full = n >= S1_REC.length;
    const st = T.closed ? ["ok", "已办理"] : T.go ? ["run", "办理中"] : ["wait", "待决策"];
    return `<div class="em-m em-m-card v93-rec"><h5>分析过程<span class="em-chain-done">已完成 · 07:32—08:51 · 调用 ${nCalls} 项能力</span><b class="v93-st ${st[0]}">${st[1]}</b></h5><p class="v94-chains">沿实物流调用 ${S1_CHAINS.length} 条思维链：${S1_CHAINS.map((c) => `<em>${h(c)}</em>`).join("→")}</p><ol class="v93-secs">${secs}</ol>${full ? `<div class="em-m-btns"><button class="em-btn em-btn-p" data-em-act="s-s1-go" ${T.go ? "disabled" : ""}>确认，去办理</button></div>` : ""}</div>`;
  }
  function s1Confirm(T) {
    const wait = T.cf === "wait";
    const sel = wait ? `<select class="v93-sel" data-v93-sign>${S1_SIGNERS.map((x) => `<option ${x === (T.sign || OD.signer) ? "selected" : ""}>${h(x)}</option>`).join("")}</select>` : h(T.sign || OD.signer);
    return `<div class="em-m em-m-card em-confirm-card ${wait ? "wait" : "ok"} v93-cf"><h5>需要你确认：办理收货第 2 步</h5>
      <table class="em-ct"><thead><tr><th>项</th><th>AI 填写</th><th>依据</th></tr></thead><tbody>
      <tr><td>单据同步</td><td>ERP 收货单据 → 电子签章平台</td><td>收货第 2 步未同步</td></tr>
      <tr><td>签章人员</td><td>${sel}</td><td>近 3 个月同类订单签章记录</td></tr>
      <tr><td>签章提醒</td><td>内部人员推工单；供应商经 e物资提醒</td><td>第 3 步在 e物资签章</td></tr>
      <tr><td>同步告知</td><td>项目经理：10 月 28 日前签完即可领用；结算专责：收货入账后办到货款</td><td>思维链 · 物资结算；项目物资需求计划</td></tr></tbody></table>
      <p class="em-sub">以您的账号办理，操作留痕。</p>
      ${wait ? `<div class="em-m-btns"><button class="em-btn" data-em-act="s-s1-no">取消</button><button class="em-btn em-btn-w" data-em-act="s-s1-ok">确认办理</button></div>` : `<p class="em-ct-state">${T.cf === "ok" ? `已确认 · ${h(T.cfAt)}` : `已取消 · ${h(T.cfAt)}`}</p>`}</div>`;
  }
  function s1Check(T) {
    const wait = !T.closed;
    const rows = [["电子签章平台单据", "无", "已到达，待签章"], ["签章人员", "未分配", T.sign || OD.signer], ["收货进度", "第 2 步", "第 3 步 · e物资签章"], ["签章提醒", "—", "已推送签章人员和供应商"], ["相关专业", "—", "已告知项目经理、结算专责"]];
    return `<div class="em-m em-m-card v93-check"><h5>办理结果核对</h5><table class="em-ct"><thead><tr><th>项</th><th>办理前</th><th>回查</th></tr></thead><tbody>${rows.map((r) => `<tr><td>${h(r[0])}</td><td>${h(r[1])}</td><td><b>${h(r[2])}</b></td></tr>`).join("")}</tbody></table><p class="em-sub">回查依据：电子签章平台单据状态、ERP 收货流程状态。</p>${wait ? `<div class="em-m-btns"><button class="em-btn em-btn-p" data-em-act="s-s1-check">核对无误，确认</button></div>` : `<p class="em-ct-state">已确认 · ${h(T.closeAt)}</p>`}</div>`;
  }
  /* 8 个步骤：智能体 6 个，人 2 个 */
  /* 办理流程对照：节点、原来人工怎么做、现在谁做 */
  const S1_FLOW = [
    ["智能体", "核对工单", "rec", 1, "登录 ECP、ERP，分别查交货期和收货记录"], ["智能体", "问供应商是否送达", "rec", 2, "打电话或在 e物资问供应商，等回复"],
    ["智能体", "读回复，和 ECP 发货通知对账", "rec", 2, "拿回复和 ECP 发货通知人工比对"], ["智能体", "查收货卡在哪一步", "rec", 3, "分别登录 ECP、ERP、电子签章平台、e物资查进度"],
    ["智能体", "研判紧急程度，推荐签章人员", "rec", 5, "凭经验判断轻重，翻签章记录找人"], ["人", "确认怎么办", "cf", 0, "自己决定"],
    ["智能体", "办理并回查", "do", 0, "登录 ERP 同步单据、到签章平台分配人员、逐个电话通知"], ["人", "确认办成了", "close", 0, "再登录各系统核对"],
  ];
  function s1FlowSt(T, k, n) {
    if (k === "rec") return (T.recN || 0) >= n ? "ok" : "todo";
    if (k === "cf") return T.cf === "ok" ? "ok" : T.go ? "run" : "todo";
    if (k === "do") return T.handled ? "ok" : T.cf === "ok" ? "run" : "todo";
    return T.closed ? "ok" : T.handled ? "run" : "todo";
  }
  /* 操作记录：按工单办理进度逐条列出 */
  function s1Log(T) {
    const n = T.recN || 0;
    const L = [["07:32", "工单中心", "推送超期交货督办工单", "ECP 供应计划确定交货期 10 月 10 日，ERP 无收货", "已接收"]];
    if (n >= 2) L.push(["07:32", "智能体", "经 e物资向供应商征询是否送达", "工单属实，是否到货系统判定不了", "已发送"], ["08:50", "供应商", "回复 10 月 16 日已送达" + OD.wh.replace("忠县", ""), "e物资回复原文", "已归集"]);
    if (n >= 3) L.push(["08:51", "智能体", "查收货三步", "ECP、ERP、电子签章平台、e物资", "卡在第 2 步"]);
    if (n >= 5) L.push(["08:51", "智能体", "研判并给出建议", "思维链 · " + S1_CHAINS.join("、") + "；近 3 个月签章记录", "待决策"]);
    if (T.cf === "no") L.push([T.cfAt, "您", "取消办理", "—", "未办理"]);
    if (T.cf === "ok") L.push([T.cfAt, "您", "确认办理", "签章人员：" + (T.sign || OD.signer), "已确认"]);
    if (T.handled) L.push(
      [T.doAt, "智能体（以您的账号）", "同步 ERP 收货单据至电子签章平台", "确认办理", "ERP 返回成功"],
      [T.doAt, "智能体（以您的账号）", "分配签章人员", "确认办理", "已分配"],
      [T.doAt, "智能体", "推送签章提醒、告知项目经理和结算专责", "工单中心、e物资", "已发送"],
      [T.doAt, "智能体", "回查单据状态和收货流程", "电子签章平台、ERP", "待签章，进入第 3 步"]);
    if (T.closed) L.push([T.closeAt, "您", "核对办理结果", "办理前后对比", "确认无误"]);
    return L;
  }
  const S1 = {
    pane: "画布",
    tabs: ["工单与分析", "办理流程对照", "操作记录"],
    placeholder: "就这张工单提问，例如：签章人员为什么推荐这两位",
    init(T) { T.recN = 0; T.tab = 0; T.sign = OD.signer; },
    bg: () => [],
    intro(T) {
      say(T, { k: "raw", html: s1Rec });
      S1_REC.forEach((_, i) => later(T, 500 + i * 900, () => { T.recN = i + 1; draw(T); }));
    },
    used: () => false,
    act(T, a) {
      if (T.busy) return;
      if (a === "s-s1-go" && !T.go && (T.recN || 0) >= S1_REC.length) {
        T.go = true; T.cf = "wait"; T.tab = 1;
        say(T, { k: "raw", html: s1Confirm });
        draw(T);
      }
      if (a === "s-s1-no" && T.cf === "wait") {
        T.cf = "no"; T.cfAt = EM.now(); T.go = false;
        say(T, { k: "ai", html: "已取消，没有办理。要换签章人员，直接告诉我。" });
        draw(T);
      }
      if (a === "s-s1-ok" && T.cf === "wait") {
        T.cf = "ok"; T.cfAt = EM.now();
        think(T, "办理 · ERP", [
          { say: "按确认的内容办：先把 ERP 收货单据同步到电子签章平台，再分配签章人员、发签章提醒，办完回头查一遍。", wait: 2400 },
          { cap: "办理", call: "ERP · 同步收货单据至电子签章平台", t: "同步请求已提交，ERP 返回成功。", from: "ERP 接口回执", ms: 3500 },
          { cap: "办理", call: "电子签章平台 · 分配签章人员", t: `已分配：${T.sign}。`, from: "电子签章平台接口回执", ms: 3000 },
          { cap: "协同提醒", call: "工单中心 · 签章提醒", t: "已向签章人员推送签章工单。", from: "工单中心", ms: 1100 },
          { cap: "协同提醒", call: "e物资 · 供应商签章提醒", t: "已提醒供应商在 e物资签章。", from: "e物资发送记录", ms: 1300 },
          { cap: "协同提醒", call: "工单中心 · 相关专业告知", t: "已告知项目经理、结算专责：签章完成、收货入账后即可领用和办到货款。", from: "工单中心", ms: 1500 },
          { cap: "查询", call: "电子签章平台 · 单据状态（回查）", t: "收货单据已到电子签章平台，状态：待签章。", from: "电子签章平台", ms: 900 },
          { cap: "查询", call: "ERP · 收货流程（回查）", t: "收货流程从第 2 步进入第 3 步。", from: "ERP", ms: 2000 },
        ], () => {
          T.handled = true; T.doAt = EM.now(); T.tab = 0;
          say(T, { k: "raw", html: s1Check });
          EM.refreshHome();
        });
        draw(T);
      }
      if (a === "s-s1-check" && T.handled && !T.closed) {
        T.closed = true; T.closeAt = EM.now();
        say(T, { k: "result", title: "工单状态：待签章", lines: ["签章完成、ERP 收货后，这张工单自动办结", "签章人员没有及时签章的，我会继续提醒", "8 个步骤中智能体完成 6 个，您确认了 2 次"] });
        finish(T.id, { status: "external", current: "待签章", remain: "签章完成后自动办结", log: "同步收货单据并分配签章人员" });
        S8().v93S1Done = true;
        EM.refreshHome();
        /* 第二段：讲解人说完按 E 弹出应急提醒卡；没按的话约 40 秒后自动弹出（点确认后讲稿还剩约 30 秒） */
        setTimeout(releaseNotice, 40000);
      }
    },
    input(T, el) { if (el.hasAttribute("data-v93-sign")) T.sign = el.value; },
    reply(T, v) {
      if (/确认/.test(v)) {
        const b = document.querySelector('#emThread [data-em-act="s-s1-ok"], #emThread [data-em-act="s-s1-check"], #emThread [data-em-act="s-s1-go"]:not([disabled])');
        if (b) { setTimeout(() => b.click(), 300); return true; }
      }
      if (/签章人|为什么推荐|这两位/.test(v)) {
        say(T, { k: "ai", html: `${h(OD.wh)}近 3 个月的同类订单，都由库管员和项目部物资员签章，所以推荐这两位。要换人，在确认卡里改。` });
        return true;
      }
      return false;
    },
    right(T) {
      if ((T.tab || 0) === 2) {
        const rows = s1Log(T);
        return page("操作记录", `${rows.length} 条：谁做的、依据什么、结果如何`, tbl(["时间", "操作人", "操作", "依据", "结果"], rows.map(([t, w, a, b, r]) => [h(t), h(w), h(a), h(b), h(r)])));
      }
      if ((T.tab || 0) === 1) {
        const stTxt = (st) => (st === "ok" ? "已完成" : st === "run" ? "进行中" : "待进行");
        return page("办理流程对照", "原来 8 个节点都要人做；现在智能体做 6 个，留 2 个给您确认",
          `<div class="sc-tw"><table class="sc-t v94-cmp"><thead><tr><th>节点</th><th>原来人工怎么做</th><th>现在</th><th>状态</th></tr></thead><tbody>${S1_FLOW.map(([who, t, k, n, old], i) => { const st = s1FlowSt(T, k, n); return `<tr class="${who === "人" ? "me" : ""}"><td><b>${i + 1}</b> ${h(t)}</td><td>${h(old)}</td><td>${who === "人" ? "由您确认" : "智能体"}</td><td><span class="v94-st ${st}">${st === "ok" ? "✓ " : ""}${stTxt(st)}</span></td></tr>`; }).join("")}</tbody></table></div>`);
      }
      /* 首屏只放进度轴、研判和推荐办理；基础信息、供应商回复、收货三步明细收起，点开再看（10 月 20 日晚减少画面信息量） */
      const n = T.recN || 0;
      const fold = (title, body) => `<details class="v95-fold" data-v95-fold="${h(title.replace(/<[^>]*>/g, ""))}" ${FOLDS[title.replace(/<[^>]*>/g, "")] ? "open" : ""}><summary>${title}</summary>${body}</details>`;
      const base = fold("工单基础信息", kv([["工单", "超期交货督办 · 工单中心今天 07:32 推送"], ["订单", `${h(OD.no)} · ${h(OD.mat)} · ${h(OD.amt)}`], ["供应商", h(OD.sup)], ["项目", h(OD.prj)], ["交货期", `${h(OD.due)}（ECP 供应计划确定）· <b class="sc-red">已超 ${odOver()} 天</b>`], ["收货地点", h(OD.wh)], ["关联单据", "合同 → ECP 供应计划、发货通知 → ERP 收货单据 → 电子签章平台 → e物资签章"]]));
      const reply = `<h5 class="v94-h5">供应商回复 · e物资</h5><div class="v93-msg"><time>07:32 征询</time><p>订单 ${h(OD.no)} 是否已送达？请回复送达日期和地点。</p></div><div class="v93-msg in"><time>08:50 ${h(OD.sup)}</time><p>10 月 16 日已送达${h(OD.wh)}。</p></div>`;
      const steps = `<h5 class="v94-h5">收货三步</h5>${tbl(["步骤", "系统", "状态", "说明"], STEPS3(T).map(([a, b, st, c]) => [h(a), h(b), `<b class="v93-s3 ${st}">${ST_TXT[st]}</b>`, h(c)]))}`;
      const detail = n >= 3 ? fold(`供应商回复与收货三步 <small class="v94-src">思维链 · ${S1_CHAINS.join("、")}</small>`, reply + steps) : "";
      const judge = n >= 4 ? sec("研判", `<div class="v95-judge"><div><span>紧急程度</span><b class="r">较急</b><small>10 月 28 日要领用安装，还剩 ${useLeft()} 天</small></div><div><span>严重程度</span><b>一般</b><small>已到货，不是供应商违约</small></div><div><span>影响环节</span><b>2 个</b><small>出库领用、到货款结算</small></div></div>`) : "";
      const rec = n >= 5 ? sec("推荐办理", kv([["处理方式", "办理收货第 2 步：同步单据、分配签章人员"], ["签章人员", h(T.sign || OD.signer)], ["同步告知", "项目经理、结算专责"], ["工单状态", T.closed ? "待签章（签章完成、ERP 收货后自动办结）" : T.handled ? "已办理，待您核对" : T.go ? "办理中" : "待决策"]])) : "";
      return page(`订单 ${OD.no} 超期交货`, `${h(OD.sup)} · ${h(OD.mat)} · ${h(OD.amt)}`, axis(T) + judge + rec + detail + base);
    },
  };

  /* 今日简报里的其余事项：只给出核对和建议，本次演示不展开 */
  const S2 = simple("订单 4500949833 超期交货", [
    { cap: "查询", call: "ECP · 供应计划", t: `确定交货期 10 月 18 日，已超 ${s2Over()} 天，ERP 没有收货记录。`, from: "ECP 供应计划；ERP", ms: 1700 },
    { cap: "查询", call: "e物资 · 供应商回复", t: "08:40 回复：排产延误，10 月 27 日发货。", from: "e物资回复原文", ms: 1300 },
  ], "货还没送，属于物资未送达。逾期 5 天，建议先经 e物资发函催告，要求按 10 月 27 日发货并书面确认。",
  kv([["情形", "物资未送达"], ["逾期", "5 天"], ["供应商回复", "10 月 27 日发货"], ["建议", "发函催告，要求书面确认发货日期"]]));
  const G2 = simple("「供货单状态」督办", [
    { cap: "查询", call: "ECP · 供货单", t: "供货单发货状态 3 天没有更新，工单时限 2 天，已超 1 天。", from: "ECP 供货单", ms: 1500 },
  ], "建议今天经 e物资催供应商更新发货状态，明天还没更新再电话联系。", kv([["状态", "发货状态 3 天未更新"], ["工单时限", "2 天，已超 1 天"], ["建议", "e物资催供应商更新"]]));
  const P2 = simple("协议库存匹配待确认", [
    { cap: "查询", call: "ERP · 协议库存匹配结果", t: "匹配结果待确认。", from: "ERP 协议库存匹配", ms: 2100 },
  ], "同物料号的可以直接确认；相近规格的，先问需求单位能否替代。", kv([["建议", "同物料号直接确认，相近规格先问需求单位"]]));

  /* ================= 第三段前半：运营中心专责的「我的关注」（两个看板组，可编辑） =================
     业务指标组三项及其 4—8 月走势、本人 8 月工单数及 4—7 月应办结未办结率为演示设定；
     物资公司 8 月 5 张电商逾期支付全部超期（8 月 15—20 日触发）为真实数据，推给本账号为演示设定。 */
  const MY_TYPES = [
    ["协议库存匹配", 21, 0], ["供货单状态督办", 18, 1], ["采购关键节点提醒", 15, 0], ["三级履约协调", 12, 0], ["电商逾期支付督办", 5, 5],
    ["应急物资主动保障", 4, 0], ["合同变更完成通知", 4, 0], ["特殊业务催办", 4, 0], ["履约保证金退还", 3, 0],
  ];
  /* 看板组件：zone 分区（biz 业务指标、ops 我的工单运营指标），from 来源（tpl 模板、chat 对话生成），st 可选样式，s 为 4—8 月走势 */
  const MON = ["4 月", "5 月", "6 月", "7 月", "8 月"];
  const WG = {
    turn: { zone: "biz", from: "tpl", name: "库存周转率", v: "3.2", u: "次/年", d: "比 7 月 ↑0.2 次", dt: "ok", s: [2.9, 3.0, 3.1, 3.0, 3.2], f: (x) => x.toFixed(1), st: ["num", "line"] },
    aging: { zone: "biz", from: "tpl", name: "长库龄物资积压", v: "1,286", u: "万元", tone: "bad", d: "比 7 月 ↓4.2%", dt: "ok", s: [1410, 1385, 1366, 1342, 1286], f: (x) => x.toLocaleString("en-US"), st: ["num", "line"] },
    plan: { zone: "biz", from: "tpl", name: "供应计划完成率", v: "93.6%", u: "", d: "比 7 月 ↑1.8 个百分点", dt: "ok", s: [90.2, 92.5, 91.0, 91.8, 93.6], f: (x) => `${x.toFixed(1)}%`, st: ["num", "line"] },
    mine: { zone: "ops", from: "tpl", name: "本人工单概况", v: "19.4%", u: "应办结未办结率", tone: "bad", d: "比 7 月 ↑2.7 个百分点", dt: "bad", s: [12.5, 15.0, 14.3, 16.7, 19.4], f: (x) => `${x.toFixed(1)}%`, st: ["num", "line"], go: true },
    ecom: { zone: "ops", from: "chat", name: "电商逾期支付督办", st: ["num"], ask: "把电商逾期支付督办的超期情况放到看板上" },
    late: { zone: "ops", from: "tpl", name: "超期工单清单", st: ["list"], ask: "把我名下超期的工单列个清单放到看板上" },
    /* 2026-10-20：「我的看板」按账号给内容。H 忠县公司履约专责（本人工单数为演示设定）；A 物资部数字化管理专责（全公司数取 8 月运营月报） */
    mineH: { p: "H", zone: "ops", from: "tpl", name: "本人工单概况", v: "13.6%", u: "应办结未办结率", tone: "bad", d: "比 7 月 ↑1.5 个百分点", dt: "bad", s: [9.8, 11.2, 10.5, 12.1, 13.6], f: (x) => `${x.toFixed(1)}%`, st: ["num", "line"], go: true },
    supH: { p: "H", zone: "ops", from: "chat", name: "超期交货督办", st: ["num"], ask: "把超期交货督办放到看板上" },
    lateH: { p: "H", zone: "ops", from: "tpl", name: "超期工单清单", st: ["list"], ask: "把我名下超期的工单列个清单放到看板上" },
    trigA: { p: "A", zone: "ops", from: "tpl", name: "全公司工单触发量", v: "118,427", u: "条 · 8 月", d: "比 7 月 ↑23%", dt: "ok", s: [122183, 94184, 121951, 96274, 118427], f: (x) => x.toLocaleString("en-US"), st: ["num", "line"] },
    rateA: { p: "A", zone: "ops", from: "tpl", name: "全公司应办结未办结率", v: "4.8%", u: "8 月", d: "21 家单位高于平均", dt: "bad", st: ["num"] },
    typesA: { p: "A", zone: "ops", from: "tpl", name: "在用工单", v: "113", u: "类", d: "本月新接入 12 类", dt: "ok", st: ["num"] },
  };
  ["mine", "ecom", "late"].forEach((k) => (WG[k].p = "0"));
  const profOf = (T) => (T.id === "K1A" ? "A" : T.id === "K1H" ? "H" : "0");
  const inProf = (T, id) => !WG[id].p || WG[id].p === profOf(T);
  const ZONES = [["biz", "业务指标"], ["ops", "我的工单运营指标"]];
  const LAY0 = (T) => ({ biz: [{ id: "turn", w: 2, h: 2, st: "num" }, { id: "aging", w: 2, h: 2, st: "num" }, { id: "plan", w: 2, h: 2, st: "num" }],
    ops: profOf(T) === "H" ? [{ id: "mineH", w: 4, h: 2, st: "num" }, { id: "supH", w: 2, h: 2, st: "num" }]
      : profOf(T) === "A" ? [{ id: "trigA", w: 2, h: 2, st: "num" }, { id: "rateA", w: 2, h: 2, st: "num" }, { id: "typesA", w: 2, h: 2, st: "num" }]
      : [{ id: "mine", w: 4, h: 2, st: "num" }, { id: "ecom", w: 2, h: 2, st: "num" }] });
  const COLS = 6, ROW = 52, GAP = 10;
  const allIds = (T) => [...T.lay.biz, ...T.lay.ops].map((x) => x.id);
  function addWidget(T, id, from) {
    if (allIds(T).includes(id)) return false;
    const d = WG[id];
    T.lay[d.zone].push({ id, w: /late/.test(id) ? 3 : 2, h: /late/.test(id) ? 3 : 2, st: d.st[0], from });
    return true;
  }
  const spark = (d, it) => {
    const mn = Math.min(...d.s), r = Math.max(...d.s) - mn || 1;
    const pts = d.s.map((v, i) => `${4 + i * 23},${(36 - ((v - mn) / r) * 30).toFixed(1)}`).join(" ");
    const lbl = `${d.name} 4 月至 8 月：${d.s.map(d.f).join("、")}`;
    return `<svg class="k1-svg" viewBox="0 0 100 40" preserveAspectRatio="none" role="img" aria-label="${h(lbl)}"><polyline points="${pts}" fill="none" stroke="${d.dt === "bad" ? "#c14943" : "#0b6e66"}" stroke-width="2" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>` +
      `<div class="k1-ax">${MON.map((m, i) => `<span>${m}${it.w >= 4 ? ` ${d.f(d.s[i])}` : ""}</span>`).join("")}</div>`;
  };
  function wBody(T, d, it) {
    const val = `<div class="k1-v"><b class="${d.tone || ""}">${h(d.v)}</b>${d.u ? `<i>${h(d.u)}</i>` : ""}</div><div class="k1-d ${d.dt}">${h(d.d)}</div>`;
    if (it.st === "line") return val + spark(d, it);
    if (it.id === "mine") {
      const all = [["19.4%", "应办结未办结率", "bad"], ["6 条", "超期未办结", "bad"], ["86 条", "处理工单"], ["9 类", "涉及"]];
      const n = Math.min(4, it.h >= 3 ? it.w * 2 : it.w);
      return `<div class="k1-mini">${all.slice(0, n).map((k) => `<div><b class="${k[2] || ""}">${k[0]}</b><span>${k[1]}</span></div>`).join("")}</div><div class="k1-d bad">应办结未办结率比 7 月 ↑2.7 个百分点</div>`;
    }
    if (it.id === "ecom")
      return `<div class="k1-v"><b class="bad">5 张</b><i>8 月收到 · 全部超期</i></div><div class="k1-d">8 月 15—20 日触发 · 工单时限 5 天</div>${it.h >= 3 ? `<div class="k1-q">“${h(d.ask)}”</div>` : ""}`;
    if (it.id === "late") return `<ul class="k1-li"><li><b class="sc-red">电商逾期支付督办 5 张</b> · 全部超期（8 月 15—20 日触发）</li><li>供货单状态督办 1 条 · 超 1 天</li></ul>`;
    if (it.id === "mineH") {
      const all = [["13.6%", "应办结未办结率", "bad"], ["3 条", "超期未办结", "bad"], ["64 条", "处理工单"], ["7 类", "涉及"]];
      const n = Math.min(4, it.h >= 3 ? it.w * 2 : it.w);
      return `<div class="k1-mini">${all.slice(0, n).map((k) => `<div><b class="${k[2] || ""}">${k[0]}</b><span>${k[1]}</span></div>`).join("")}</div><div class="k1-d bad">应办结未办结率比 7 月 ↑1.5 个百分点</div>`;
    }
    if (it.id === "supH") return `<div class="k1-v"><b class="bad">2 张</b><i>今天推送</i></div><div class="k1-d">1 张收货卡在签章环节，1 张供应商 10 月 27 日发货</div>${it.h >= 3 ? `<div class="k1-q">“${h(d.ask)}”</div>` : ""}`;
    if (it.id === "lateH") return `<ul class="k1-li"><li><b class="sc-red">超期交货督办 2 张</b> · 已超 ${odOver()} 天、${s2Over()} 天</li><li>供货单状态督办 1 条 · 超 1 天</li></ul>`;
    return val;
  }
  function board(T) {
    const ed = !!T.edit;
    const tools = (d, it) => !ed ? "" : `<span class="k1w-tools">${d.st.length > 1 ? d.st.map((s) => `<button class="${it.st === s ? "on" : ""}" data-em-act="s-k1-st" data-w="${it.id}" data-st="${s}">${s === "num" ? "数字" : "折线"}</button>`).join("") : ""}<button data-em-act="s-k1-rm" data-w="${it.id}" aria-label="移除组件">移除</button></span>`;
    const card = (it) => {
      const d = WG[it.id], from = it.from || d.from;
      const go = !ed && d.go ? ` go" data-em-act="s-k1-ops` : "";
      return `<div class="k1w${go}" data-k1w="${it.id}" data-zone="${d.zone}" style="grid-column:span ${it.w};grid-row:span ${it.h}">` +
        `<div class="k1w-hd"><b>${h(d.name)}</b><span class="k1-from ${from}">${from === "chat" ? "对话生成" : "模板"}</span>${!ed && d.go ? '<span class="k1-more">点开看每一类 ›</span>' : ""}${tools(d, it)}</div>` +
        `${wBody(T, d, it)}${ed ? '<i class="k1w-rs" data-k1-rs title="拖动调整大小"></i>' : ""}</div>`;
    };
    const tplRow = (id) => {
      const d = WG[id], on = allIds(T).includes(id);
      return `<div class="k1-tpl"><span>${h(d.name)}</span><small>${d.st.includes("line") ? "数字或折线" : d.st[0] === "list" ? "清单" : "数字"}</small>${on ? "<em>已在看板</em>" : btn("添加", "s-k1-add", "", false).replace("<button", `<button data-w="${id}"`)}</div>`;
    };
    const drawer = ed && T.drawer ? `<div class="k1-drawer"><div><h5>从模板选择</h5>${ZONES.map(([z, n]) => `<h6>${n}</h6>${Object.keys(WG).filter((id) => WG[id].zone === z && WG[id].from === "tpl" && inProf(T, id)).map(tplRow).join("")}`).join("")}</div>` +
      `<div class="k1-ask"><h5>对话生成</h5><p>在左侧对话里说想看什么，生成的组件放到对应分区。</p><div class="k1-q">例如：“${h(WG.late.ask)}”</div></div></div>` : "";
    const zones = ZONES.map(([z, n]) => `<section class="k1-zone"><div class="k1-zh"><b>${n}</b><span>${T.lay[z].length} 个组件</span></div><div class="k1-grid" data-k1-grid="${z}">${T.lay[z].map(card).join("")}</div></section>`).join("");
    const acts = ed ? btn(T.drawer ? "收起添加组件" : "添加组件", "s-k1-drawer") + btn("取消", "s-k1-cancel") + btn("保存", "s-k1-save", "p")
      : btn("编辑看板", "s-k1-edit", "", T.busy || T.k < 3);
    return `<div class="sc-page${ed ? " k1-edit" : ""}"><div class="sc-ph"><div><h3>${profOf(T) === "0" ? "我的关注" : "我的看板"}</h3><p>${ed ? "编辑中 · 拖动组件标题调整位置，拖右下角调整大小" : K1SUB[profOf(T)]}</p></div><div class="sc-ph-r">${acts}</div></div>${drawer}${zones}</div>`;
  }
  const K1SUB = { 0: "供应链运营中心专责 · 8 月", H: "忠县公司履约专责 · 数据范围：忠县公司、本人经手 · 8 月 · 模板组件和对话生成的组件放在一起，可编辑", A: "物资部数字化管理专责 · 8 月 · 模板组件和对话生成的组件放在一起，可编辑" };
  const MY_TYPES_H = [["到货验收提醒", 18, 0], ["协议库存匹配", 15, 0], ["供货单状态督办", 11, 1], ["超期交货督办", 9, 2], ["供应计划变更通知", 6, 0], ["履约保证金退还", 3, 0], ["发票结算提醒", 2, 0]];
  /* 编辑操作后重绘：先登记画布内容，避免整块重新浮现 */
  function redraw(T) { T.genSeen = T.genSeen || {}; T.genSeen[T.tab] = K1.right(T); draw(T); }
  const K1 = {
    pane: "画布", tabs: ["看板", "工单运营指标"],
    init(T) { T.k = 0; T.fb = 0; T.lay = LAY0(T); T.edit = false; T.drawer = false; },
    bg: () => [["看板组", "业务指标、我的工单运营指标"], ["统计期", "8 月"]],
    intro(T) {
      if (profOf(T) === "H") {
        think(T, "汇总我的看板", [
          { say: "看板分两组：业务指标、我的工单运营指标。我先取数，再看哪几类工单办得慢。", wait: 900 },
          { cap: "查询", call: "供应链运营看板 · 业务指标", t: "库存周转率 3.2 次/年，长库龄物资积压 1,286 万元，供应计划完成率 93.6%。", from: "供应链运营看板（8 月）", ms: 1100 },
          { cap: "查询", call: "工单中心 · 本人工单", t: "8 月您处理工单 64 条，涉及 7 类；应办结 22 条，未办结 3 条，应办结未办结率 13.6%。", from: "工单中心 8 月工单明细", ms: 1200 },
          { cap: "审核", call: "各类工单办结时长 · 对照工单时限", t: "超期的 3 条：超期交货督办 2 张，供货单状态督办 1 条。", from: "工单台账：各类工单办理时限", ms: 500 },
        ], () => say(T, { k: "ai", html: "8 月您处理工单 64 条，涉及 7 类，应办结未办结率 13.6%。没按时办结的 3 条：超期交货督办 2 张、供货单状态督办 1 条，今天的重点事项里都有。<br>看板在右边，点「编辑看板」可以从模板加组件、拖动位置、调整大小，也可以直接说想看什么。" }), (r, i) => { T.k = Math.max(T.k, i); });
        return;
      }
      if (profOf(T) === "A") {
        think(T, "汇总我的看板", [
          { cap: "查询", call: "供应链运营看板 · 业务指标", t: "库存周转率 3.2 次/年，长库龄物资积压 1,286 万元，供应计划完成率 93.6%。", from: "供应链运营看板（8 月）", ms: 1400 },
          { cap: "查询", call: "工单中心 · 8 月运行数据", t: "在用工单 113 类，8 月触发 118,427 条，应办结未办结率 4.8%。", from: "工单中心 8 月运营月报", ms: 1200 },
        ], () => { T.k = 3; say(T, { k: "ai", html: "看板在右边：业务指标三项，工单运营指标三项。全公司各单位、各专业的情况在「工单运营看板」。点「编辑看板」可以从模板加组件、拖动位置、调整大小。" }); }, (r, i) => { T.k = Math.max(T.k, i + 1); });
        return;
      }
      think(T, "汇总我的关注", [
        { say: "您关注的指标分两个看板组：业务指标、我的工单运营指标。我先取数，再看哪几类工单办得慢。", wait: 2400 },
        { cap: "查询", call: "供应链运营看板 · 业务指标", t: "库存周转率 3.2 次/年，长库龄物资积压 1,286 万元，供应计划完成率 93.6%。", from: "供应链运营看板（8 月）", ms: 1400 },
        { cap: "查询", call: "工单中心 · 本人工单", t: "8 月您处理工单 86 条，涉及 9 类；应办结 31 条，未办结 6 条，应办结未办结率 19.4%。", from: "工单中心 8 月工单明细", ms: 1600 },
        { cap: "审核", call: "各类工单办结时长 · 对照工单时限", t: "办得慢的有 2 类：电商逾期支付督办 5 张全部超期；供货单状态督办 18 条，1 条超期。", from: "工单台账：各类工单办理时限", ms: 600 },
      ], () => {
        say(T, { k: "ai", html: "8 月您处理工单 86 条，涉及 9 类，应办结未办结率 19.4%。6 条没按时办结，5 条是电商逾期支付督办，1 条是供货单状态督办。建议后续重点关注这两类。<br>两个看板组在右边，点「本人工单概况」可以往下看每一类。" });
      }, (r, i) => { T.k = Math.max(T.k, i); });
    },
    used: (T, a) => used(T, a),
    act(T, a, el) {
      const w = el && el.dataset.w;
      if (a === "s-k1-ops") { T.tab = 1; draw(T); return; }
      if (a === "s-k1-m0") { EM.openThread("M0"); return; }
      if (a === "s-k1-edit") { T.layBak = JSON.parse(JSON.stringify(T.lay)); T.edit = true; T.drawer = false; }
      else if (a === "s-k1-cancel") { T.lay = T.layBak || LAY0(T); T.edit = false; }
      else if (a === "s-k1-save") { T.edit = false; toast("看板已保存"); }
      else if (a === "s-k1-drawer") T.drawer = !T.drawer;
      else if (a === "s-k1-add") addWidget(T, w);
      else if (a === "s-k1-rm") ZONES.forEach(([z]) => (T.lay[z] = T.lay[z].filter((x) => x.id !== w)));
      else if (a === "s-k1-st") {
        const it = allIds(T).includes(w) && [...T.lay.biz, ...T.lay.ops].find((x) => x.id === w);
        if (it) { it.st = el.dataset.st; if (it.st === "line") it.h = Math.max(it.h, 3); }
      } else return;
      redraw(T);
    },
    feedback(T) {
      T.fb = 1;
      think(T, "整理反馈", [
        { cap: "查询", call: "工单台账 · 电商逾期支付督办", t: "规则：距支付到期日 40、50、60 天触发；办理时限为预警之日起 5 天内；办结条件是支付完成。", from: "工单更名台账（113 类）", ms: 800 },
        { cap: "审核", call: "思维链 · 电商订单支付", t: "支付要经付款申请、预算提报、实际支付，约 45 天，5 天内办不完；业务上只要在支付到期日前付完即可。", from: "8 月运营月报；思维链 · 电商订单支付", ms: 800 },
        { cap: "写作", call: "工单反馈意见", t: "反馈意见已写好：办理时限 5 天短于付款流程，建议按支付到期日判定办结。", ms: 2300 },
      ], () => {
        confirm(T, {
          title: "提交工单反馈",
          action: "把下面的反馈提交给工单中心管理人员（物资部数字化管理专责）：",
          rows: [["工单", "电商逾期支付_督办工单", ""], ["问题", "办理时限 5 天，付款流程约 45 天，按流程办也会超期", ""], ["建议", "按支付到期日判定办结，或把办理时限调到与付款流程一致", ""], ["涉及", "本人 8 月 5 张，全部超期", ""]],
          note: "提交后，处理结果回到您的今日简报。",
          ok: "确认提交",
          onOk: () => {
            T.fb = 2;
            S8().v91Feedback = true;
            say(T, { k: "result", title: "反馈已提交", lines: ["已推送给物资部数字化管理专责（工单中心管理人员）", "处理结果会回到今日简报"] });
            finish(T.id, { status: "running", current: "已反馈电商逾期支付办理时限", remain: "等工单中心处理", log: "反馈工单时限" });
            EM.refreshHome();
          },
          onCancel: () => { T.fb = 0; },
        });
      });
    },
    reply(T, v) {
      if (pendingOk(v)) return true;
      if (T.busy) return false;
      if (/反馈|不合理|设得|设置/.test(v) && profOf(T) !== "0") { say(T, { k: "ai", html: "在工单详情页点「反馈工单不合理」，选原因后提交给工单中心管理人员；也可以直接告诉我是哪张工单、哪里不合理。" }); return true; }
      if (/反馈|不合理|设得|设置/.test(v) && !T.fb) { this.feedback(T); return true; }
      if (/看板/.test(v) && /放到|加到|添加|生成|加个|加一个/.test(v)) {
        const lateId = profOf(T) === "H" ? "lateH" : "late";
        if (profOf(T) === "A" || !/超期/.test(v) || allIds(T).includes(lateId)) {
          say(T, { k: "ai", html: allIds(T).includes(lateId) && /超期/.test(v) ? "看板上已经有「超期工单清单」。" : profOf(T) === "A" ? "请说明要放什么数据，例如：把超高压的应办结未办结率放到看板上。" : "请说明要放什么数据，例如：把我名下超期的工单列个清单放到看板上。" });
          return true;
        }
        think(T, "生成看板组件", [
          { cap: "查询", call: "工单中心 · 本人超期工单", t: profOf(T) === "H" ? "超期未办结 3 条：超期交货督办 2 张，供货单状态督办 1 条。" : "8 月超期未办结 6 条：电商逾期支付督办 5 张，供货单状态督办 1 条。", from: "工单中心 8 月工单明细", ms: 1000 },
          { cap: "写作", call: "看板组件 · 清单", t: "按超期情况列成清单，放在「我的工单运营指标」分区。", ms: 2700 },
        ], () => {
          addWidget(T, lateId, "chat");
          T.tab = 0;
          say(T, { k: "ai", html: "「超期工单清单」已放到看板的「我的工单运营指标」分区。点「编辑看板」可以拖动位置、调整大小。" });
          redraw(T);
        });
        return true;
      }
      if (/工单运营|往下|每一类|明细/.test(v)) { T.tab = 1; say(T, { k: "ai", html: "每一类工单的应办结未办结情况在右侧「工单运营指标」。" }); return true; }
      return false;
    },
    right(T) {
      const ready = !T.busy || T.k >= 2;
      if ((T.tab || 0) === 0) {
        if (T.k < 2) return page(profOf(T) === "0" ? "我的关注" : "我的看板", K1SUB[profOf(T)],
          `<div class="v92-group"><header><b>业务指标</b></header>${T.k >= 1 ? kpis([{ k: "库存周转率", v: "3.2 次/年" }, { k: "长库龄物资积压", v: "1,286 万元", tone: "r" }, { k: "供应计划完成率", v: "93.6%" }]) : empty("取数中")}</div>` +
          `<div class="v92-group"><header><b>我的工单运营指标</b></header>${empty("取数中")}</div>`);
        return board(T);
      }
      if (!ready) return page("我的工单运营指标", "", empty("取数中"));
      if (profOf(T) === "A") return page("工单运营指标", "", `<div class="sc-empty">全公司各单位、各专业、各人的工单运营情况在「工单运营看板」。</div><div class="sc-foot"><span></span><div>${btn("打开工单运营看板", "s-k1-m0", "p")}</div></div>`);
      if (profOf(T) === "H") {
        const rowsH = MY_TYPES_H.map(([n, c, o]) => `<div class="v90-bar"><span>${h(n)}</span><i><b class="${o ? "r" : "g"}" style="width:${(c / 18) * 100}%"></b></i><em>${c} 条${o ? ` · <b class="sc-red">超期 ${o}</b>` : ""}</em></div>`).join("");
        return page("我的工单运营指标", "8 月 · 64 条 · 7 类", kpis([{ k: "应办结", v: "22 条" }, { k: "已办结", v: "19 条" }, { k: "未办结", v: "3 条", tone: "r" }, { k: "应办结未办结率", v: "13.6%", tone: "r" }]) + sec("按工单类型", rowsH) + sec("超期的工单", tbl(["工单", "张数", "情况"], [["超期交货督办", "2", "<b class='sc-red'>已超 ${odOver()} 天、${s2Over()} 天</b>，今日重点事项"], ["供货单状态督办", "1", "超 1 天"]])));
      }
      const rows = MY_TYPES.map(([n, c, o]) => `<div class="v90-bar"><span>${h(n)}</span><i><b class="${o ? "r" : "g"}" style="width:${(c / 21) * 100}%"></b></i><em>${c} 条${o ? ` · <b class="sc-red">超期 ${o}</b>` : ""}</em></div>`).join("");
      const late = T.k >= 3 ? sec("办得慢的工单", tbl(["工单", "张数", "工单时限", "情况"], [["电商逾期支付督办", "5", "预警之日起 5 天内", "<b class='sc-red'>全部超期</b>（8 月 15—20 日触发）"], ["供货单状态督办", "1", "2 天", "超 1 天"]])) : "";
      const fb = T.fb === 2 ? sec("我的反馈", kv([["工单", "电商逾期支付督办"], ["建议", "按支付到期日判定办结"], ["状态", "已推送工单中心管理人员"]])) : "";
      return page("我的工单运营指标", "8 月 · 86 条 · 9 类", kpis([{ k: "应办结", v: "31 条" }, { k: "已办结", v: "25 条" }, { k: "未办结", v: "6 条", tone: "r" }, { k: "应办结未办结率", v: "19.4%", tone: "r" }]) + sec("按工单类型", rows) + late + fb);
    },
  };

  /* 看板编辑：按住组件标题拖到同一分区的其他组件前后；拖右下角按栅格调整宽高。拖动中只改样式，松手后写回布局再重绘 */
  let drag = null, eatClick = 0;
  const k1T = () => { const T = EM.S.threads[EM.S.open]; return T && /^K1/.test(T.id) && T.edit ? T : null; };
  const findIt = (T, id) => [...T.lay.biz, ...T.lay.ops].find((x) => x.id === id);
  document.addEventListener("pointerdown", (e) => {
    const T = k1T();
    if (!T || e.button !== 0 || T.busy) return;
    const w = e.target.closest("#emThreadWork .k1w");
    if (!w || e.target.closest("button")) return;
    const rs = e.target.closest("[data-k1-rs]");
    if (!rs && !e.target.closest(".k1w-hd")) return;
    const it = findIt(T, w.dataset.k1w);
    const grid = w.parentElement, gw = grid.getBoundingClientRect().width;
    drag = { T, w, it, rs: !!rs, x: e.clientX, y: e.clientY, moved: false, col: (gw - GAP * (COLS - 1)) / COLS, nw: it.w, nh: it.h, tgt: null, after: false };
    e.preventDefault();
  }, true);
  document.addEventListener("pointermove", (e) => {
    if (!drag) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    if (!drag.moved && Math.abs(dx) + Math.abs(dy) < 5) return;
    drag.moved = true;
    const { w, it } = drag;
    if (drag.rs) {
      w.classList.add("rs");
      drag.nw = Math.max(2, Math.min(COLS, Math.round((it.w * (drag.col + GAP) + dx) / (drag.col + GAP))));
      drag.nh = Math.max(2, Math.min(6, Math.round((it.h * (ROW + GAP) + dy) / (ROW + GAP))));
      w.style.gridColumn = `span ${drag.nw}`;
      w.style.gridRow = `span ${drag.nh}`;
      return;
    }
    w.classList.add("drag");
    w.style.transform = `translate(${dx}px,${dy}px)`;
    if (drag.tgt) drag.tgt.classList.remove("tgt-b", "tgt-a");
    drag.tgt = null;
    w.style.pointerEvents = "none";
    const o = document.elementFromPoint(e.clientX, e.clientY);
    w.style.pointerEvents = "";
    const t = o && o.closest(".k1w");
    if (t && t !== w && t.dataset.zone === w.dataset.zone) {
      const r = t.getBoundingClientRect();
      drag.after = e.clientX > r.left + r.width / 2;
      drag.tgt = t;
      t.classList.add(drag.after ? "tgt-a" : "tgt-b");
    }
  }, true);
  document.addEventListener("pointerup", () => {
    if (!drag) return;
    const d = drag;
    drag = null;
    if (!d.moved) return;
    eatClick = Date.now() + 400;
    if (d.rs) { d.it.w = d.nw; d.it.h = d.nh; }
    else if (d.tgt) {
      const list = d.T.lay[d.w.dataset.zone];
      list.splice(list.indexOf(d.it), 1);
      const i = list.findIndex((x) => x.id === d.tgt.dataset.k1w);
      list.splice(d.after ? i + 1 : i, 0, d.it);
    }
    redraw(d.T);
    /* 内容相同不会重绘，拖动留下的样式在这里清掉 */
    const w = document.querySelector(`#emThreadWork .k1w[data-k1w="${d.it.id}"]`);
    if (w) { w.classList.remove("drag", "rs"); w.style.transform = ""; }
    document.querySelectorAll("#emThreadWork .k1w.tgt-a, #emThreadWork .k1w.tgt-b").forEach((x) => x.classList.remove("tgt-a", "tgt-b"));
  }, true);
  window.addEventListener("click", (e) => {
    if (Date.now() < eatClick && e.target.closest && e.target.closest("#emThreadWork")) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);

  /* ================= 第三段后半：物资部数字化管理专责看全公司（8 月工单真实数据） ================= */

  /* 出处：《供应链工单中心运营月报8月》表 1、表 5、表 10、表 11 及正文；
     各单位分布按《8月物资工单.xlsx》「排重后」页签，工单名称＝电商逾期支付_督办工单，工单状态＝超期未办结 计数 */
  const UNITS = [["綦江", 132, 132], ["垫江", 121, 121], ["长寿", 120, 120], ["酉阳", 42, 42], ["云阳", 38, 38], ["丰都", 38, 38], ["南川", 26, 26], ["本部", 23, 23], ["信通公司", 8, 8], ["电科院", 5, 5], ["物资公司", 5, 5], ["彭水", 108, 107], ["忠县", 22, 21], ["铜梁", 48, 42], ["璧山", 142, 123], ["开州", 104, 82], ["大足", 194, 140], ["永川", 174, 123], ["送变电", 10, 5], ["奉节", 42, 20], ["市北", 174, 81], ["超高压", 481, 223], ["合川", 117, 54], ["江津", 140, 64], ["城口", 78, 34], ["武隆", 103, 43], ["北碚", 378, 146], ["黔江", 136, 39], ["万州", 156, 41], ["巫山", 39, 9], ["市南", 533, 122], ["潼南", 110, 24], ["川东", 106, 17], ["石柱", 66, 0], ["巫溪", 40, 0], ["秀山", 18, 0], ["市区", 234, 0]];
  const pct = (n, d) => (d ? Math.round((n / d) * 1000) / 10 : 0);
  const TYPES = [["借用物资超期_督办工单", 100, "专业确认维持 6 个月触发，不算异常"], ["电商逾期支付_督办工单", 49.13], ["合同变更完成通知_督办工单", 45.45], ["采购不成功流标计划退回_提醒工单", 41.54], ["物资发票结算预警_督办工单", 23.53], ["采购关键节点_提醒工单", 16.6], ["供应链监督检查整改_办理工单", 14.29]];
  /* 8 月推送条数：《8月物资工单.xlsx》「排重后」页签按接收人计数（按环节计，不含未匹配接收人的 18,486 条）；姓名只显示姓 */
  const PEOPLE = [["物资公司", "包*", 11531, "协议库存匹配"], ["物资公司", "胡**", 5659, "物资款项预算提报"], ["市南", "靳*", 2575, "协议库存匹配"], ["物资公司", "向**", 2134, "采购计划上报（退回）"], ["忠县", "黄*", 1653, "协议库存匹配"], ["武隆", "陈**", 1542, "协议库存匹配"], ["巫山", "陈**", 1528, "协议库存匹配"], ["物资公司", "郭*", 1460, "供货单状态督办"]];
  const KPI = "8 月 · 在用工单 <b>113</b> 类 · 触发 <b>118,427</b> 条 · 应办结未办结率 <b>4.8%</b> · 超期未办结 <b>4,094</b> 条 · 长时未触发 <b>10</b> 类";

  /* 按业务时限分两类：工单时限＝预警之日起 5 天内（工单台账）；业务时限＝支付到期日（工单按距支付到期日 40、50、60 天触发）。
     8 月超期的 2,118 张跟踪到 9 月 30 日的结果（已办结 2,045、未到期未办结 64、已过到期日 9：垫江 6、綦江 3）为演示设定，拿到 9 月工单明细后替换 */
  const B_UNITS = [["垫江", 6], ["綦江", 3]];
  const CLASSIFY = [
    { say: "电商逾期支付有两个时限：工单时限是预警之日起 5 天内，业务时限是合同约定的支付到期日。我把超期的工单和支付到期日对一遍，分清是工单设得偏严，还是业务没办到位。", wait: 3400 },
    { cap: "查询", call: "工单中心 · 8 月工单明细", t: "37 家单位超期未办结 2,118 张，都在 8 月 15 日至 23 日触发；11 家全部超期，4 家全部办结。", from: "8 月工单明细「排重后」", ms: 1300 },
    { cap: "审核", call: "思维链 · 电商订单支付", t: "业务时限：在支付到期日前完成支付即符合要求。工单按距支付到期日 40、50、60 天触发，8 月触发的单子支付到期日最早 9 月 24 日。", from: "思维链 · 电商订单支付；工单更名台账（113 类）", ms: 600 },
    { cap: "查询", call: "工单中心 · 跟踪到 9 月 30 日", t: "这 2,118 张到 9 月 30 日已办结 2,045 张；仍未办结 73 张，其中 64 张还没到支付到期日，9 张已过：垫江 6 张、綦江 3 张。", from: "工单中心运行数据", ms: 1700 },
    { a: "得结论", t: "2,109 张只超工单时限、没超业务时限，属工单时限设得偏严；垫江、綦江 9 张两个时限都超了，属业务管理不到位。", wait: 1500 },
    { cap: "协同提醒", call: "询问提醒 · 垫江、綦江", t: "已向垫江、綦江发出询问提醒，同时抄送供应链监督检查作为线索。", from: "工单中心；供应链监督检查", ms: 600 },
  ];
  const REPORT = [
    { say: "按工单中心现行月报的结构写：本月概况、历史异常工单分析与处置、异常监控。写完和 8 月统计数逐项对一遍。", wait: 2400 },
    { cap: "查询", call: "工单中心 · 8 月运行数据", t: "取 113 类工单的触发、应办结、已办结和各单位数据。", from: "工单中心 8 月运行数据", ms: 1200 },
    { cap: "写作", call: "月报 · 三部分", t: "三部分已写好，逐段放在右侧。", ms: 2800 },
    { cap: "审核", call: "统计数核对", t: "正文「未办结 4,096 条」与 85,268－81,174＝4,094 差 2 条，已标黄。", from: "8 月运营月报", ms: 1200 },
  ];
  const REPORT_SECS = [
    ["一、本月概况", "在用工单 113 类，其中业务办理类 54 类、预警督办类 38 类、纯提醒类 4 类、数据类 17 类；本月新接入 12 类，在建 15 类。8 月触发工单 118,427 条，环比上升 23%；应办结 85,268 条，已办结 81,174 条，<mark>应办结未办结 4,094 条（工单中心月报正文为 4,096 条，按 85,268－81,174 计为 4,094 条）</mark>，应办结未办结率 4.8%，高于平均值的单位 21 家，超高压最高（35.54%）。"],
    ["二、历史异常工单分析与处置", "本月 5 类工单由异常转为正常。剩余异常工单 10 类，均属长时未触发或触发较少：低频业务 5 类持续评估，系统缺陷 5 类已优化触发逻辑、待触发后评估。"],
    ["三、异常监控", "触发预警 11,417 条，「合同签订_办理工单」占比最大（30.09%）。长时未触发较上月减少 1 类，无新增。应办结未办结率较高的工单中，「借用物资超期_督办工单」经专业确认维持 6 个月触发；<b>「电商逾期支付_督办工单」应办结未办结率 49.13%，按业务时限分两类：只超工单时限的属工单时限偏严，建议调整办结周期；两个时限都超的属业务管理不到位。跟踪到 9 月 30 日，垫江、綦江 9 张已过支付到期日，已发询问提醒并抄送供应链监督检查</b>。环节长时滞留最长 9 天，涉及 1 类工单。"],
  ];
  const CHANGE = [
    { cap: "查询", call: "工单台账 · 电商逾期支付督办", t: "现行规则：距支付到期日 40、50、60 天触发，办理时限为预警之日起 5 天内，办结条件为支付完成。", from: "工单更名台账（113 类）", ms: 900 },
    { cap: "查询", call: "7 月、8 月运营月报", t: "付款流程：8 月月报记约 45 天，7 月月报记约 30 天，两处不一致，申请里请履约专业确认。", from: "7 月、8 月运营月报", ms: 1200 },
    { cap: "写作", call: "工单修改申请", t: "按工单需求模板写好修改申请，提交由您决定。", ms: 2400 },
  ];

  const M1 = {
    pane: "画布",
    tabs: ["看板", "分析", "修改申请", "8 月月报"],
    init(T) { T.cls = -1; T.board = 0; T.change = ""; T.report = false; T.repN = 0; },
    bg: () => [["工单", "8 月在用 113 类"], ["重点", "电商逾期支付_督办工单 49.13%"], ["范围", "37 家单位"]],
    intro(T) {
      T.tab = 0;
      think(T, "统计 8 月工单运行", [
        { cap: "查询", call: "工单中心 · 8 月运行数据", t: "8 月在用 113 类，触发 118,427 条，应办结未办结率 4.8%，超期未办结 4,094 条。", from: "工单中心 8 月运营月报", ms: 1100 },
        { cap: "查询", call: "工单中心 · 8 月工单明细", t: "按单位、按接收人汇总推送量：推送最多的 20 人占已匹配接收人推送量的 37.1%。", from: "8 月工单明细「排重后」", ms: 1500 },
        { cap: "审核", call: "历次月报已确认情况", t: "「借用物资超期」100%，专业已确认维持 6 个月触发，不算异常；「电商逾期支付」49.13%，4 月起每期月报都列为异常。", from: "工单中心 4—8 月运营月报", ms: 700 },
      ], () => {
        const fb = (S8() || {}).v91Feedback ? "运营中心刚反馈：它的办理时限比付款流程短。" : "4 月起每期月报都把它列为异常。";
        say(T, { k: "ai", html: `8 月在用 113 类工单，应办结未办结率 4.8%。按工单类型，最高的「借用物资超期」100%，专业已确认维持 6 个月触发，不算异常；其次是「电商逾期支付」49.13%，${fb}<br>看板在右边：关键指标、推送量最多的人、各类工单应办结未办结率。点「电商逾期支付」一行可以按单位看。` });
      }, (r, i) => { T.board = i + 1; });
    },
    used: (T, a) => used(T, a),
    drill(T) {
      if (used(T, "s-m1-drill") || T.board < 3) return;
      mark(T, "s-m1-drill");
      T.tab = 1; T.cls = 0;
      think(T, "按业务时限分析超期", CLASSIFY, () => {
        say(T, { k: "ai", html: "电商逾期支付这类工单，工单时限是预警之日起 5 天内，业务时限是合同约定的支付到期日。<br>· 2,109 张只超了工单时限，到期前都能付完，属工单时限设得偏严，建议调整办结周期，修改申请我可以起草；<br>· 垫江 6 张、綦江 3 张过了支付到期日还没付，两个时限都超了，属业务管理不到位。我已向两家发出询问提醒，同时抄送供应链监督检查作为线索。" });
        finish(T.id, { status: "running", current: "已按业务时限分类，2 家单位已发询问", remain: "跟踪中", log: "按业务时限分类" });
      }, (r, i) => { T.cls = i + 1; });
    },
    act(T, a) {
      if (T.busy) return;
      if (a === "s-m1-drill") { say(T, { k: "me", text: "点进电商逾期支付，按单位看。" }); this.drill(T); }
      if (a === "s-m1-submit" && T.change === "draft") {
        T.change = "review";
        say(T, { k: "result", title: "已提交", lines: ["工单修改申请已提交物资部审核", "审核通过后，工单中心按新办结周期判定超期"] });
      }
    },
    report(T) {
      if (T.report) return;
      T.report = true; T.tab = 3; T.repN = 0;
      think(T, "写 8 月工单运营月报", REPORT, () => {
        T.repN = REPORT_SECS.length;
        say(T, { k: "card", title: "8 月工单运营月报（草稿）", html: "<p>8 月触发工单 118,427 条，环比上升 23%；应办结未办结 4,094 条，应办结未办结率 4.8%，高于平均值的单位 21 家。</p><p>重点问题：「电商逾期支付_督办工单」应办结未办结率 49.13%，按业务时限分两类处理；跟踪到 9 月 30 日，垫江、綦江 9 张已过支付到期日，已发询问并抄送监督检查。</p><p>和工单中心 8 月统计数逐项核对：正文「未办结 4,096 条」与 85,268－81,174＝4,094 差 2 条，已标黄。完整内容在右边。</p>" });
      }, (r, i) => { if (r.cap === "写作") T.repN = REPORT_SECS.length; else if (i >= 1) T.repN = Math.max(T.repN, 1); });
    },
    save(T) {
      if (T.saved || !T.repN) return;
      T.saved = true;
      say(T, { k: "result", title: "已保存到「我的常用」", lines: ["每月 3 日 07:00 生成上月工单运营月报，8:00 发您审", "在左侧「我的常用」里可以查看、修改或停用"] });
      finish(T.id, { status: "running", current: "已分类处理，月报已设为每月自动生成", remain: "跟踪中", log: "保存月报为我的常用" });
      try {
        const st = S8();
        if (st.scheduled && !st.scheduled.some((x) => x.v90Report)) {
          st.scheduled.unshift({ id: 90, v90Report: true, name: "上月工单运营月报", desc: "每月 3 日取上月工单数据生成运营月报，8:00 发您审。",
            schedule: "每月 3 日 07:00", next: "11月3日 07:00", status: "已启用", context: "每次新建对话", last: "今天 · 试运行（8 月月报）", triggerKey: "plan", runsToday: 1, successRate: 100 });
          st.selectedSchedule = 90;
          if (typeof renderSchedules === "function") renderSchedules();
        }
        const b = document.getElementById("scheduleCountBadge");
        if (b && st.scheduled) b.textContent = String(st.scheduled.length);
      } catch (_) { /* 我的常用页未加载时只提示 */ }
      toast("已保存到我的常用");
    },
    change(T) {
      if (T.change) return;
      T.change = "writing";
      think(T, "整理工单修改申请", CHANGE, () => {
        T.change = "draft"; T.tab = 2;
        say(T, { k: "ai", html: "建议不新建工单，调整「电商逾期支付」督办工单的办结周期：40、50、60 天三次提醒不变，办结按支付到期日判定，天数请履约专业确认。修改申请已写好，在右边，确认后我提交物资部审核。" });
      });
    },
    reply(T, v) {
      if (pendingOk(v) && T.change !== "draft") return true;
      if (T.busy) return false;
      if (/点进|按单位|电商逾期/.test(v) && !used(T, "s-m1-drill")) { this.drill(T); return true; }
      if (/常用|每月|自动/.test(v) && T.report) { this.save(T); return true; }
      if (/月报|运营情况|分析报告/.test(v)) { this.report(T); return true; }
      if (/修改申请|办结周期|调整/.test(v)) { this.change(T); return true; }
      if (/提交/.test(v) && T.change === "draft") { this.act(T, "s-m1-submit"); return true; }
      return false;
    },
    right(T) {
      const t = T.tab || 0;
      const unitBars = () => UNITS.map(([n, d, o]) => { const v = pct(o, d); const b = B_UNITS.find((x) => x[0] === n); return `<div class="v90-bar${b && T.cls >= 4 ? " v92-hit" : ""}"><span>${h(n)}${b && T.cls >= 4 ? ` · 已过期 ${b[1]} 张` : ""}</span><i><b class="${v >= 50 ? "r" : v > 0 ? "a" : "g"}" style="width:${v}%"></b></i><em>${v}% · ${o}/${d}</em></div>`; }).join("");
      if (t === 0) {
        if (!T.board) return page("看板", "8 月 · 工单运行", empty("正在取数"));
        const k = kpis([{ k: "在用工单", v: "113 类" }, { k: "触发", v: "118,427" }, { k: "应办结未办结率", v: "4.8%" }, { k: "超期未办结", v: "4,094", tone: "r" }]);
        const ppl = T.board >= 2 ? sec("推送量最多的人", `<p class="v90-sub">8 月推送条数（按环节计）· 前 20 人占 37.1%</p>${tbl(["单位", "接收人", "推送条数", "最多的工单"], PEOPLE.map((p) => [h(p[0]), h(p[1]), p[2].toLocaleString("zh-CN"), h(p[3])]))}`) : "";
        const types = T.board >= 3 ? sec("各类工单应办结未办结率", `<p class="v90-sub">全部工单平均 4.8% · 点一行看各单位</p>${TYPES.map(([n, v, note]) => { const on = n.startsWith("电商逾期支付"); return `<div class="v90-bar ${on ? "v90-click" : ""}" ${on ? 'data-em-act="s-m1-drill"' : ""}><span title="${h(note || "")}">${h(n.replace(/_.*$/, ""))}</span><i><b class="${v >= 40 ? "r" : ""}" style="width:${v}%"></b></i><em>${v}%</em></div>${note ? `<p class="v90-note">${h(note)}</p>` : ""}`; }).join("")}`) : "";
        return page("看板", "8 月 · 工单运行 · 全公司 37 家单位", k + types + ppl);
      }
      if (t === 1) {
        if (T.cls < 0) return page("分析", "", `<div class="sc-empty">在看板里点一类工单，这里显示分析。</div>`);
        const head = kpis([{ k: "触发", v: "4,311" }, { k: "已办结", v: "2,193" }, { k: "超期未办结", v: "2,118", tone: "r" }, { k: "应办结未办结率", v: "49.13%", tone: "r" }]);
        const rule = T.cls >= 3 ? sec("工单时限与业务时限", kv([["工单时限", "预警之日起 5 天内（工单台账）"], ["业务时限", "合同约定的支付到期日（思维链 · 电商订单支付）"], ["触发", "距支付到期日 40、50、60 天"], ["付款流程", "付款申请 → 预算提报 → 实际支付，约 45 天（8 月月报）"]])) : "";
        const two = T.cls >= 5 ? sec("按业务时限分两类 · 8 月超期的 2,118 张跟踪到 9 月 30 日", kpis([{ k: "只超工单时限 · 工单时限偏严", v: "2,109 张" }, { k: "两个时限都超 · 业务管理不到位", v: "9 张", tone: "r" }])) : "";
        const ask = T.cls >= 6 ? sec("询问提醒", tbl(["单位", "已过支付到期日", "询问提醒", "抄送"], B_UNITS.map(([u, n]) => [h(u), `${n} 张`, chip("已发出", "ok"), "供应链监督检查"]))) : "";
        return page("电商逾期支付_督办工单 · 8 月", "37 家单位", head + two + ask + rule + sec("各单位应办结未办结率", `<p class="v90-sub">超期未办结 / 应办结；11 家 100%，4 家 0%</p>${unitBars()}`));
      }
      if (t === 2) {
        if (!T.change || T.change === "writing") return page("修改申请", "", T.change ? empty("正在起草") : `<div class="sc-empty">还没有修改申请。</div>`);
        return page("工单修改申请", T.change === "review" ? chip("物资部审核中", "warn") : chip("草稿", ""), kv([
          ["工单", "电商逾期支付_督办工单"], ["修改类型", "优化（不新建）"], ["修改内容", "40、50、60 天三次提醒不变；办结按支付到期日判定"], ["调整天数", "待履约专业确认（8 月月报记约 45 天，7 月月报记约 30 天）"], ["依据", "8 月应办结未办结率 49.13%；4 月起每期月报列为异常；运营中心反馈"], ["提出人", "物资部 · 数字化管理"], ["审核", "物资部"], ["审核通过后", "工单中心按新办结周期判定超期"],
        ]) + (T.change === "draft" ? `<div class="sc-foot"><span>按工单需求模板生成</span><div>${btn("提交审核", "s-m1-submit", "p")}</div></div>` : ""));
      }
      if (!T.report) return page("8 月月报", "", `<div class="sc-empty">还没有月报。</div>`);
      const n = T.repN || 0;
      if (!n) return page("8 月工单运营月报（草稿）", "生成中", empty("正在取数"));
      return page("8 月工单运营月报（草稿）", n >= REPORT_SECS.length && !T.busy ? "已与工单中心 8 月统计数逐项核对" : "生成中", `<div class="v90-report">${REPORT_SECS.slice(0, n).map(([a, b]) => `<h5>${a}</h5><p>${b}</p>`).join("")}</div>`);
    },
  };


  /* ================= 第三段（2026-10-20 改）：物资部数字化管理专责的首页＝工单运营看板 =================
     总览只放在用工单、触发量、应办结未办结率三项（董老师确认单第 1、2 题）；按人显示全名和单位（第 4、5 题）；
     异常分三类；电商逾期支付按业务时限分两类：9 张直接形成监督检查线索，2,109 张时限偏紧由数字化管理专责分配物资部对应专责确认（第 11—16 题）。
     出处：《供应链工单中心运营月报》4—8 月正文、8 月表 3、表 4、表 5、表 7、表 10、表 11；《8月物资工单.xlsx》「排重后」页签。
     8 月超期 2,118 张跟踪到 9 月 30 日的分类结果（2,109 / 9，垫江 6、綦江 3）、专责回复为演示设定。 */
  const TREND = [["4 月", 122183], ["5 月", 94184], ["6 月", 121951], ["7 月", 96274], ["8 月", 118427]];
  const MAJORS = [["合同", 7.99, 2488], ["仓储", 5.77, 1530], ["综合", 1.72, 1], ["计划", 1.07, 66], ["督察", 0.30, 3], ["废旧", 0.22, 4], ["质量", 0.12, 2], ["履约", 0, 0], ["应急", 0, 0]];
  const U37 = [["超高压", 35.54], ["大足", 22.30], ["垫江", 21.34], ["綦江", 16.25], ["电科院", 16.13], ["彭水", 15.22], ["信通公司", 12.50], ["云阳", 12.30], ["送变电", 11.59], ["璧山", 10.84], ["长寿", 10.33], ["奉节", 9.80], ["酉阳", 8.61], ["开州", 8.35], ["永川", 7.06], ["丰都", 6.90], ["市北", 6.43], ["本部", 6.35], ["江津", 6.23], ["城口", 6.23], ["北碚", 5.57], ["黔江", 4.80], ["合川", 4.60], ["铜梁", 4.40], ["巫溪", 4.39], ["潼南", 3.91], ["武隆", 3.67], ["市南", 3.20], ["南川", 3.13], ["万州", 3.12], ["忠县", 3.11], ["石柱", 2.26], ["川东", 1.97], ["巫山", 1.18], ["物资公司", 0.97], ["秀山", 0.87], ["市区", 0.27]];
  const PEOPLE5 = [["包鑫", "物资公司", 11533, "协议库存匹配"], ["胡若涵", "物资公司", 5660, "物资款项预算提报"], ["靳川", "市南", 3290, "协议库存匹配"], ["郭强", "物资公司", 2925, "供货单状态督办"], ["向洪伟", "物资公司", 2320, "采购计划上报（退回）"]];
  /* 高于平均的 21 家单位，超期未办结按专业拆分（条）：《8月物资工单.xlsx》「排重后」，工单状态＝超期未办结，按单位简称×专业计数；各单位合计与月报表 5 一致 */
  const GEN = [["超高压", { 合同: 223, 仓储: 184, 其他: 1 }], ["大足", { 合同: 143, 仓储: 47 }], ["垫江", { 合同: 126, 仓储: 1 }], ["綦江", { 合同: 132, 仓储: 65 }], ["电科院", { 合同: 6, 计划: 4 }], ["彭水", { 合同: 169, 仓储: 114, 计划: 2 }], ["信通公司", { 合同: 8 }], ["云阳", { 合同: 43, 仓储: 332 }], ["送变电", { 合同: 5, 计划: 3 }], ["璧山", { 合同: 123, 仓储: 32, 计划: 2 }], ["长寿", { 合同: 125, 仓储: 32, 计划: 7, 其他: 1 }], ["奉节", { 合同: 20 }], ["酉阳", { 合同: 44, 仓储: 52, 计划: 1 }], ["开州", { 合同: 84, 仓储: 23, 计划: 5, 其他: 1 }], ["永川", { 合同: 123, 仓储: 61, 计划: 4 }], ["丰都", { 合同: 42, 仓储: 3, 计划: 3 }], ["市北", { 合同: 88, 仓储: 46, 计划: 10 }], ["本部", { 合同: 23 }], ["江津", { 合同: 64, 计划: 6 }], ["城口", { 合同: 34 }], ["北碚", { 合同: 149, 仓储: 67, 其他: 1 }]];
  const GEN_K = ["合同", "仓储", "计划", "其他"];
  const genSum = (k) => GEN.reduce((a, [, o]) => a + (o[k] || 0), 0);
  const genAll = () => GEN_K.reduce((a, k) => a + genSum(k), 0);
  const RATE_HI = [["电商逾期支付", 49.13, 4311, true], ["合同变更完成通知", 45.45, 14], ["采购不成功流标计划退回", 41.54, 65], ["物资发票结算预警", 23.53, 204], ["采购关键节点", 16.60, 395], ["供应链监督检查整改", 14.29, 13]];
  const LONG10 = ["招标过程不良行为（诚信问题）移交约谈", "报废处置计划修改", "拆解产物统计确认", "寄存物资临期预警", "出库过账", "非集中结算订单暂估款消纳", "非集中结算交货款支付", "非集中结算验收款支付", "非集中结算结清款支付", "废旧物资管控"];
  const ASSIGNEES = ["物资部 · 合同专业专责", "物资部 · 履约专业专责", "物资部 · 计划专业专责"];
  const fmt = (n) => Number(n).toLocaleString("en-US");
  const bar = (name, v, max, txt, cls = "", attr = "") => `<div class="v90-bar ${cls}" ${attr}><span>${name}</span><i><b class="${cls.includes("hi") ? "r" : ""}" style="width:${max ? Math.max(0.6, (v / max) * 100) : 0}%"></b></i><em>${txt}</em></div>`;
  const CLASSIFY2 = [
    { say: "应办结未办结率高，可能是工单时限设得紧，也可能是业务真没办到位。我调出电商订单支付的思维链，把超期的工单和支付到期日对一遍。", wait: 3000 },
    { cap: "查询", call: "工单中心 · 8 月工单明细", t: "电商逾期支付 8 月触发 4,311 张，超期未办结 2,118 张，都在 8 月 15 日至 23 日触发。", from: "8 月工单明细「排重后」", ms: 1200 },
    { cap: "审核", call: "思维链 · 电商订单支付", t: "工单时限：预警之日起 5 天；业务时限：合同约定的支付到期日，到期前付款即合规。", from: "思维链 · 电商订单支付；工单更名台账", ms: 800 },
    { cap: "查询", call: "工单中心 · 跟踪到 9 月 30 日", t: "2,118 张里，2,109 张已付或还没到支付到期日；9 张过了支付到期日仍未付：垫江 6 张、綦江 3 张。", from: "工单中心运行数据", ms: 1000 },
    { a: "得结论", t: "2,109 张只超工单时限，属工单时限偏紧；9 张两个时限都超，属业务风险。", wait: 1200 },
  ];
  const REPORT2 = [
    { say: "按工单中心现行月报的结构写：本月概况、历史异常工单分析与处置、异常监控。写完和工单中心 8 月统计数逐项核对。", wait: 2400 },
    { cap: "查询", call: "工单中心 · 8 月运行数据", t: "取 113 类工单的触发、应办结、已办结和各单位数据。", from: "工单中心 8 月运行数据", ms: 1200 },
    { cap: "写作", call: "月报 · 三部分", t: "三部分已写好，逐段放在右侧。", ms: 2800 },
    { cap: "审核", call: "统计数核对", t: "工单中心月报正文写「未办结 4,096 条」，按 85,268－81,174 计为 4,094 条，差 2 条，已标黄。", from: "8 月运营月报", ms: 1200 },
  ];
  const REPORT2_SECS = () => {
    const S = (EM.S.threads || {}).M0 || {};
    const clue = S.clue ? "已直接形成监督检查线索 2 条，推送物资公司供应链监督检查专责、物资部督查专责" : "建议形成监督检查线索";
    const lim = S.reply ? "经物资部合同专业专责确认，保留原工单办理时限不变，同类情况不再询问" : S.assign ? "已分配物资部对应专责确认是否调整" : "建议由物资部对应专责确认是否调整";
    return [
      ["一、本月概况", "在用工单 113 类，其中业务办理类 54 类、预警督办类 38 类、纯提醒类 4 类、数据类 17 类。8 月触发工单 118,427 条，环比上升 23%；应办结 85,268 条，已办结 81,174 条，<mark>应办结未办结 4,094 条（工单中心月报正文为 4,096 条，按 85,268－81,174 计为 4,094 条）</mark>，应办结未办结率 4.8%；高于平均的单位 21 家，超高压最高（35.54%）。"],
      ["二、历史异常工单分析与处置", "本月 5 类工单由异常转为正常。剩余异常工单 10 类，均属长时未触发或触发较少：低频业务 5 类持续评估，系统缺陷 5 类已优化触发逻辑、待触发后评估。"],
      ["三、异常监控", `触发预警 11,417 条，「合同签订_办理工单」占比最大（30.09%）。长时未触发较上月减少 1 类，无新增。<b>「电商逾期支付_督办工单」应办结未办结率 49.13%，按业务时限分两类：8 月超期 2,118 张跟踪到 9 月 30 日，2,109 张只超工单时限，属工单时限偏紧，${lim}；垫江 6 张、綦江 3 张过了支付到期日仍未付，属业务风险，${clue}。</b>环节长时滞留最长 9 天，涉及 1 类工单。`],
    ];
  };
  function m0Log(T, op, obj, res) { T.log = T.log || []; T.log.push([EM.now(), op, obj, res]); }
  /* 看板组件模板库（10 月 20 日夜改）：看板上每块都是模板库里的一种图；对话生成时，智能体按数据的结构选模板 */
  const TPL = [
    ["kpi", "指标卡", "一个数，带环比或对比", '<rect x="8" y="8" width="34" height="14" rx="2" fill="#173b38"/><rect x="8" y="28" width="52" height="5" rx="2" fill="#c9d8d5"/>'],
    ["spark", "迷你走势", "一个数，带近几个月走势", '<rect x="8" y="7" width="24" height="10" rx="2" fill="#173b38"/><polyline points="8,36 22,28 36,32 50,22 64,26 74,15" fill="none" stroke="#0b6e66" stroke-width="2"/>'],
    ["line", "趋势折线", "按月看变化", '<path d="M8 6V38H76" fill="none" stroke="#c9d8d5" stroke-width="1.5"/><polyline points="12,30 28,18 44,24 60,12 72,20" fill="none" stroke="#0b6e66" stroke-width="2"/><circle cx="60" cy="12" r="2.5" fill="#0b6e66"/>'],
    ["donut", "构成环形", "看各部分占多少", '<circle cx="40" cy="22" r="14" fill="none" stroke="#e0a240" stroke-width="7"/><circle cx="40" cy="22" r="14" fill="none" stroke="#c14943" stroke-width="7" stroke-dasharray="54 34" transform="rotate(-90 40 22)"/>'],
    ["rank", "排名条形", "按大小排序比较", '<rect x="8" y="6" width="64" height="6" rx="2" fill="#c14943"/><rect x="8" y="15" width="48" height="6" rx="2" fill="#0b6e66"/><rect x="8" y="24" width="34" height="6" rx="2" fill="#0b6e66"/><rect x="8" y="33" width="20" height="6" rx="2" fill="#0b6e66"/>'],
    ["stack", "堆叠柱形", "分组比较，每组再拆构成", '<rect x="10" y="14" width="9" height="16" fill="#c14943"/><rect x="10" y="6" width="9" height="8" fill="#e0a240"/><rect x="25" y="22" width="9" height="8" fill="#c14943"/><rect x="25" y="16" width="9" height="6" fill="#e0a240"/><rect x="40" y="10" width="9" height="20" fill="#c14943"/><rect x="55" y="24" width="9" height="6" fill="#c14943"/><rect x="55" y="14" width="9" height="10" fill="#e0a240"/><path d="M6 30.5H72" stroke="#c9d8d5"/>'],
    ["heat", "热力图", "两个维度交叉，看集中在哪", [0.9, 0.3, 0.15, 0.6, 0.1, 0.45, 0.2, 0.25, 0.7, 0.1, 0.35, 0.15, 0.05, 0.1, 0.5, 0.2, 0.1, 0.3].map((a, i) => `<rect x="${8 + (i % 6) * 11}" y="${6 + Math.floor(i / 6) * 11}" width="10" height="10" fill="#c14943" fill-opacity="${a}"/>`).join("")],
    ["table", "明细表", "逐条列出", '<rect x="8" y="6" width="64" height="7" fill="#dfeae8"/><path d="M8 19H72M8 26H72M8 33H72" stroke="#c9d8d5" stroke-width="2"/><path d="M8 19H30M8 26H24M8 33H28" stroke="#173b38" stroke-width="2"/>'],
    ["alert", "异常卡片", "按异常类型归类", '<rect x="6" y="9" width="20" height="26" rx="3" fill="#fbfdfc" stroke="#c9d8d5"/><rect x="30" y="9" width="20" height="26" rx="3" fill="#fff8f7" stroke="#e8a9a3"/><rect x="54" y="9" width="20" height="26" rx="3" fill="#fbfdfc" stroke="#c9d8d5"/><rect x="34" y="14" width="10" height="3" fill="#c14943"/>'],
  ];
  const TPL_NAME = Object.fromEntries(TPL.map(([k, n]) => [k, n]));
  /* 默认布局：12 栏，w 为占几栏，hp 为拖动后定下的高度（像素），没拖过的按内容自适应 */
  const MLAY0 = () => [{ id: "abn", w: 12 }, { id: "rate", w: 7 }, { id: "major", w: 5 }, { id: "unit", w: 5 }, { id: "people", w: 7 }];
  const MCOLS = 12, MGAP = 12;
  function m0Spark() {
    const vs = TREND.map((x) => x[1]), mx = Math.max(...vs), mn = Math.min(...vs);
    const pts = vs.map((v, i) => [10 + i * 60, 44 - ((v - mn) / (mx - mn)) * 34]);
    return `<div class="m0-spark"><svg width="260" height="52" viewBox="0 0 260 52" role="img" aria-label="${TREND.map(([m, v]) => `${m} ${fmt(v)} 条`).join("、")}"><polyline points="${pts.map(([x, y]) => `${x},${y.toFixed(1)}`).join(" ")}" fill="none" stroke="#0b6e66" stroke-width="2" stroke-linejoin="round"/>` +
      `${pts.map(([x, y], i) => `<circle cx="${x}" cy="${y.toFixed(1)}" r="${i === pts.length - 1 ? 3.5 : 2.5}" fill="${i === pts.length - 1 ? "#0b6e66" : "#fff"}" stroke="#0b6e66" stroke-width="1.5"><title>${TREND[i][0]} ${fmt(TREND[i][1])} 条</title></circle>`).join("")}</svg>` +
      `<div class="m0-spark-ax">${TREND.map(([m]) => `<span>${m}</span>`).join("")}</div></div>`;
  }
  /* 按专业：应办结未办结条数的构成（月报表 5 各专业条数），图例带各专业的应办结未办结率 */
  function m0Donut() {
    const main = ["合同", "仓储", "计划"].map((n) => MAJORS.find((x) => x[0] === n));
    const rest = MAJORS.filter((x) => !main.includes(x) && x[2] > 0), zero = MAJORS.filter((x) => x[2] === 0);
    const parts = main.map(([n, v, c]) => [n, c, `${v.toFixed(2)}%`, v > 4.8]).concat([["其他", rest.reduce((a, x) => a + x[2], 0), `${rest.length} 个专业`, false]]);
    const tot = parts.reduce((a, x) => a + x[1], 0), C = 2 * Math.PI * 48;
    let acc = 0;
    const segs = parts.map(([, c], i) => { const len = (c / tot) * C, s = `<circle cx="70" cy="70" r="48" fill="none" class="m0-dn c${i}" stroke-width="22" stroke-dasharray="${len.toFixed(2)} ${(C - len).toFixed(2)}" stroke-dashoffset="${(-acc).toFixed(2)}" transform="rotate(-90 70 70)"/>`; acc += len; return s; }).join("");
    const pc = Math.round((parts[0][1] / tot) * 100);
    return `<div class="m0-donut"><svg width="140" height="140" viewBox="0 0 140 140" role="img" aria-label="${parts.map(([n, c]) => `${n} ${fmt(c)} 条`).join("、")}">${segs}<text x="70" y="66" text-anchor="middle" class="m0-dn-k">合同占</text><text x="70" y="88" text-anchor="middle" class="m0-dn-v">${pc}%</text></svg>` +
      `<ul class="m0-dn-lg"><li class="h"><b>专业</b><span>条数</span><em>应办结未办结率</em></li>${parts.map(([n, c, r, hi], i) => `<li><b><i class="c${i}"></i>${n}</b><span>${fmt(c)}</span><em class="${hi ? "hi" : ""}">${r}</em></li>`).join("")}</ul></div>` +
      `<p class="m0-note">其他：${rest.map((x) => x[0]).join("、")}；${zero.map((x) => x[0]).join("、")} 8 月没有应办结未办结</p>`;
  }
  /* 对话生成的图：同一份数据可用堆叠柱形或热力图展示 */
  const genTot = (o) => GEN_K.reduce((a, k) => a + (o[k] || 0), 0);
  function m0Stack() {
    const mx = Math.max(...GEN.map(([, o]) => genTot(o)));
    return `<div class="v93-legend">${GEN_K.map((k, i) => `<span><i class="c${i}"></i>${k}</span>`).join("")}</div><div class="m0-cols">${GEN.map(([u, o]) => `<div class="m0-col" title="${h(u)} ${genTot(o)} 条：${GEN_K.filter((k) => o[k]).map((k) => `${k} ${o[k]}`).join("、")}"><em>${genTot(o)}</em><i style="height:calc((100% - 50px) * ${(genTot(o) / mx).toFixed(3)})">${GEN_K.map((k, j) => (o[k] ? `<b class="c${j}" style="flex:${o[k]} 0 0"></b>` : "")).join("")}</i><span>${h(u)}</span></div>`).join("")}</div>`;
  }
  const genCells = () => GEN.flatMap(([u, o]) => GEN_K.map((k) => [u, k, o[k] || 0]));
  function m0Heat() {
    const mx = Math.max(...genCells().map((x) => x[2]));
    const cell = (v) => { if (!v) return "<td></td>"; const a = 0.08 + 0.87 * Math.sqrt(v / mx); return `<td style="background:rgba(193,73,67,${a.toFixed(2)})${a > 0.55 ? ";color:#fff" : ""}">${v}</td>`; };
    return `<div class="m0-heat-w"><table class="m0-heat"><thead><tr><th></th>${GEN.map(([u]) => `<th>${h(u)}</th>`).join("")}</tr></thead><tbody>${GEN_K.map((k) => `<tr><th>${k}</th>${GEN.map(([, o]) => cell(o[k] || 0)).join("")}</tr>`).join("")}</tbody></table></div>` +
      `<div class="m0-heat-lg"><span>1 条</span><i></i><span>${mx} 条</span><small>颜色越深，超期未办结越多</small></div>`;
  }
  function m0Panels(T) {
    const units = T.allU ? U37 : U37.slice(0, 6);
    return {
      gen: T.gen && { s: "对话生成的新图", tpl: T.heat ? "heat" : "stack", cls: "v94-gen",
        title: `高于平均的 21 家单位 · 超期未办结按专业拆分 <em class="v93-tag">对话生成 · ${T.heat ? "热力图" : "堆叠柱形"}</em>`,
        sub: `合计 ${fmt(genAll())} 条：合同 ${fmt(genSum("合同"))}、仓储 ${fmt(genSum("仓储"))}、计划 ${fmt(genSum("计划"))}、其他 ${fmt(genSum("其他"))}`,
        body: T.heat ? m0Heat() : m0Stack() },
      abn: { s: "异常关注", tpl: "alert", title: "异常关注", sub: "8 月触发预警 11,417 条",
        body: `<div class="v94-abn"><div><b>长时未触发 <em>10 类</em></b><p>剩余异常 10 类，均属长时未触发或触发较少：低频业务 5 类持续评估，系统缺陷 5 类已优化触发逻辑、待触发后评估</p><small>${LONG10.slice(0, 4).map(h).join("、")} 等 10 类</small></div>
        <div class="hot"><b>应办结未办结率高 <em>${RATE_HI.length} 类</em></b><p>最高：电商逾期支付 49.13%（2,118 / 4,311）</p><button class="v94-link" data-em-act="s-m0-ecom">看电商逾期支付分析 ›</button></div>
        <div><b>环节长时滞留 <em>1 类</em></b><p>电商逾期支付_督办工单，电商订单支付环节规定 5 天，最长滞留 9 天，长时滞留 95 张</p></div></div>` },
      rate: { s: "各类工单", tpl: "rank", title: "各类工单应办结未办结率", sub: "平均 4.8% · 点一行看分析",
        body: RATE_HI.map(([n, v, c, go]) => bar(h(n), v, 60, `${v.toFixed(2)}% · 触发 ${fmt(c)}`, `${v > 40 ? "hi" : ""} ${go ? "v90-click" : ""}`, go ? 'data-em-act="s-m0-ecom"' : "")).join("") },
      major: { s: "按专业", tpl: "donut", title: "按专业 · 应办结未办结构成", sub: "应办结未办结率高于平均的标红", body: m0Donut() },
      unit: { s: "按单位", tpl: "rank", cls: "m0-u", title: "按单位 · 应办结未办结率", sub: "37 家单位，21 家高于平均",
        body: units.map(([n, v]) => bar(h(n), v, 40, `${v.toFixed(2)}%`, v > 4.8 ? "hi" : "")).join("") + `<button class="v94-more-btn" data-em-act="s-m0-allu">${T.allU ? "收起" : "展开全部 37 家"}</button>` },
      people: { s: "按人", tpl: "table", title: "按人 · 8 月触发次数", sub: "接收人 1,617 人，人均约 107 次",
        body: tbl(["接收人", "单位", "触发次数", "", "涉及最多的工单"], PEOPLE5.map(([n, u, c, t]) => [`<b>${h(n)}</b>`, h(u), fmt(c), `<i class="v93-pbar"><b style="width:${(c / 11533) * 100}%"></b></i>`, h(t)]), "v93-people") },
    };
  }
  function m0Tpls(P, lay) {
    const use = { kpi: ["应办结未办结率"], spark: ["8 月触发"] };
    lay.forEach((it) => { const d = P[it.id]; (use[d.tpl] = use[d.tpl] || []).push(d.s); });
    return `<div class="m0-tpls"><header><b>组件模板 ${TPL.length} 种</b><span>在右侧对话里说想看什么，智能体按数据的结构选模板、取数、出图；拖动组件标题调整位置，拖右下角调整大小</span></header>` +
      `<div class="m0-tpl-g">${TPL.map(([k, n, d, svg]) => `<div class="m0-tpl${use[k] ? " on" : ""}"><svg width="80" height="44" viewBox="0 0 80 44" aria-hidden="true">${svg}</svg><div><b>${n}</b><small>${d}</small><em>${use[k] ? `看板上：${use[k].join("、")}` : "可选用"}</em></div></div>`).join("")}</div></div>`;
  }
  /* 看板首页：指标卡在上（M0.right），下面各组件按布局排在 12 栏网格里；对话生成的新图放在最上面 */
  function m0Board(T) {
    const P = m0Panels(T);
    const lay = (T.mlay = T.mlay || MLAY0()).filter((it) => P[it.id]);
    const card = (it) => { const d = P[it.id], fresh = it.id === "gen" && Date.now() - (T.genAt || 0) < 1500;
      return `<section class="v94-pn m0w ${d.cls || ""}${fresh ? " em-gen-in" : ""}" data-m0w="${it.id}" style="grid-column:span ${it.w}${it.hp ? `;height:${it.hp}px` : ""}"><header class="m0w-hd"><h4>${d.title}</h4><span>${d.sub}<em class="m0w-tpl">${TPL_NAME[d.tpl]}</em></span></header><div class="m0w-bd">${d.body}</div><i class="m0w-rs" data-m0-rs title="拖动调整大小"></i></section>`; };
    return `${T.tpl ? m0Tpls(P, lay) : ""}<div class="m0-grid">${lay.map(card).join("")}</div>`;
  }
  function m0Pane(T) {
    const sub = T.sub || "board";
    if (sub === "board") return m0Board(T);
    if (sub === "ecom") {
      const c = T.cls || 0;
      const head = kpis([{ k: "触发", v: "4,311" }, { k: "已办结", v: "2,193" }, { k: "超期未办结", v: "2,118", tone: "r" }, { k: "应办结未办结率", v: "49.13%", tone: "r" }]);
      if (c < 3) return `<p class="v93-back"><button data-em-act="s-sub-board">← 返回看板</button></p>${head}${empty("正在分析")}`;
      const rule = sec("工单时限与业务时限", kv([["工单时限", "预警之日起 5 天"], ["业务时限", "合同约定的支付到期日（思维链 · 电商订单支付）"]]));
      const two = c >= 5 ? sec("8 月超期 2,118 张 · 跟踪到 9 月 30 日", `<div class="v93-two"><div><b>2,109 张</b><span>只超工单时限</span><em>工单时限偏紧</em></div><div class="r"><b>9 张</b><span>两个时限都超 · 垫江 6 张、綦江 3 张</span><em>业务风险</em></div></div>`) : "";
      const act = c >= 5 && !T.busy ? sec("处置", `<div class="v93-acts">
          <div><p><b>业务风险 9 张</b>直接形成监督检查线索，推送物资公司供应链监督检查专责、物资部督查专责</p>${T.clue ? chip("已形成线索 2 条", "ok") : btn("形成监督检查线索", "s-m0-clue", "p", T.clueCf === "wait")}</div>
          <div><p><b>时限偏紧 2,109 张</b>分配给物资部对应专责确认是否调整工单时限</p>${T.reply ? chip("专责已回复：保留原时限", "ok") : T.assign ? chip("已分配，等专责回复", "warn") : `<span class="v93-assign"><select data-v93-assignee>${ASSIGNEES.map((x) => `<option ${x === (T.assignee || ASSIGNEES[0]) ? "selected" : ""}>${h(x)}</option>`).join("")}</select>${btn("分配给对应专责", "s-m0-assign", "p")}</span><small class="v90-sub">按工单所属专业：合同</small>`}</div></div>`) : "";
      const log = (T.log || []).length ? sec("操作日志", tbl(["时间", "操作", "对象", "结果"], T.log.map(([t, a, b, r]) => [h(t), h(a), h(b), h(r)]))) : "";
      return `<p class="v93-back"><button data-em-act="s-sub-board">← 返回看板</button></p>${head}${two}${act}${log}${rule}`;
    }
    if (sub === "report") {
      const n = T.repN || 0;
      if (!n) return sec("8 月工单运营月报", empty("正在取数"));
      const secs = REPORT2_SECS().slice(0, n).map(([a, b]) => `<h5>${a}</h5><p>${b}</p>`).join("");
      const done = n >= 3 && !T.busy;
      return `<p class="v93-back"><button data-em-act="s-sub-board">← 返回看板</button></p><section class="sc-sec"><h4>8 月工单运营月报 ${done ? chip("已与工单中心统计数逐项核对", "ok") : ""}</h4><div class="v90-report">${secs}</div>${done ? `<div class="sc-foot"><span>${T.saved ? "已保存到我的常用，每月最后一天自动生成" : "标黄处为与统计数不一致的地方"}</span><div>${btn("下载 Word", "s-m0-word")}${btn(T.saved ? "已保存" : "保存到我的常用", "s-m0-save", "p", !!T.saved)}</div></div>` : ""}</section>`;
    }
    return "";
  }
  const M0 = {
    pane: "看板",
    layout: "board",
    home: true,
    tabs: ["工单运营看板"],
    placeholder: "问看板，例如：8 月未办结率高于平均的单位，按专业拆开",
    headNote: "看板上没有的维度，直接问",
    init(T) { T.sub = "board"; T.log = []; T.mlay = MLAY0(); },
    bg: () => [],
    intro(T) {
      say(T, { k: "ai", html: "8 月工单运行：在用 113 类，触发 118,427 条，应办结未办结率 4.8%。异常已按长时未触发、应办结未办结率高、环节长时滞留三类归好，在看板「异常关注」里，最突出的是电商逾期支付 49.13%。看板上没有的维度，直接问我。" });
    },
    used: () => false,
    act(T, a) {
      if (a.startsWith("s-sub-")) { T.sub = a.slice(6); draw(T); return; }
      if (a === "s-m0-allu") { T.allU = !T.allU; draw(T); return; }
      if (a === "s-m0-tpl") { T.tpl = !T.tpl; T.sub = "board"; draw(T); return; }
      if (a === "s-m0-report") { if (!T.busy) { say(T, { k: "me", text: "生成 8 月工单运营月报" }); m0Report(T); } return; }
      if (T.busy) return;
      if (a === "s-m0-ecom" && !T.cls) {
        T.sub = "ecom"; T.cls = 0; T.ecomSeen = true;
        say(T, { k: "me", text: "看电商逾期支付" });
        think(T, "分析电商逾期支付", CLASSIFY2, () => {
          say(T, { k: "ai", html: "分清了：<br>· 2,109 张只超工单时限，属<b>工单时限偏紧</b>，要不要调整，建议交物资部对应专责确认；<br>· 垫江 6 张、綦江 3 张过了支付到期日还没付，属<b>业务风险</b>，建议直接形成监督检查线索。<br>两项都在右侧「处置」里，确认后我来办。" });
          draw(T);
        }, (r, i) => { T.cls = i + 1; });
        return;
      }
      if (a === "s-m0-clue" && !T.clue && T.clueCf !== "wait") {
        T.clueCf = "wait";
        say(T, { k: "raw", html: (T2) => `<div class="em-m em-m-card em-confirm-card ${T2.clueCf === "wait" ? "wait" : "ok"}"><h5>需要你确认：形成监督检查线索</h5><table class="em-ct"><thead><tr><th>项</th><th>内容</th></tr></thead><tbody><tr><td>线索</td><td>2 条：垫江 6 张、綦江 3 张电商订单过了支付到期日仍未付</td></tr><tr><td>推送</td><td>物资公司供应链监督检查专责、物资部督查专责</td></tr><tr><td>附件</td><td>9 张工单明细、合同支付到期日</td></tr></tbody></table><p class="em-sub">以您的账号推送，操作留痕。</p>${T2.clueCf === "wait" ? `<div class="em-m-btns"><button class="em-btn" data-em-act="s-m0-clue-no">取消</button><button class="em-btn em-btn-w" data-em-act="s-m0-clue-ok">确认</button></div>` : `<p class="em-ct-state">${T2.clueCf === "ok" ? "已确认" : "已取消"} · ${h(T2.clueAt)}</p>`}</div>` });
        draw(T);
        return;
      }
      if (a === "s-m0-clue-no" && T.clueCf === "wait") { T.clueCf = "no"; T.clueAt = EM.now(); draw(T); return; }
      if (a === "s-m0-clue-ok" && T.clueCf === "wait") {
        T.clueCf = "ok"; T.clueAt = EM.now();
        think(T, "形成监督检查线索", [
          { cap: "写作", call: "监督检查线索 · 2 条", t: "垫江、綦江各 1 条，附 9 张工单明细和支付到期日。", ms: 2900 },
          { cap: "协同提醒", call: "工单中心 · 推送", t: "已推送物资公司供应链监督检查专责、物资部督查专责。", from: "工单中心推送记录", ms: 1300 },
        ], () => {
          T.clue = true;
          m0Log(T, "形成监督检查线索", "物资公司供应链监督检查专责、物资部督查专责", "已推送 2 条");
          say(T, { k: "result", title: "监督检查线索已推送", lines: ["垫江 6 张、綦江 3 张，2 条线索", "推送物资公司供应链监督检查专责、物资部督查专责"] });
          draw(T);
        });
        return;
      }
      if (a === "s-m0-assign" && !T.assign) {
        T.assignee = T.assignee || ASSIGNEES[0];
        think(T, "分配确认", [
          { cap: "协同提醒", call: `工单中心 · 推送「${T.assignee}」`, t: "请专责确认电商逾期支付督办的工单时限是否调整，附 2,109 张只超工单时限的明细。", from: "工单中心推送记录", ms: 1200 },
        ], () => {
          T.assign = true;
          m0Log(T, "分配确认", T.assignee, "已分配，等回复");
          say(T, { k: "ai", html: `已分配给${h(T.assignee)}，请专责确认工单时限要不要调。回复到了我记下来。` });
          draw(T);
          window.__v93ReplyTimer = setTimeout(m0Reply, 20000);
        });
        return;
      }
      if (a === "s-m0-word") { m0Word(); return; }
      if (a === "s-m0-save" && !T.saved && (T.repN || 0) >= 3) { m0Save(T); }
    },
    input(T, el) { if (el.hasAttribute("data-v93-assignee")) T.assignee = el.value; },
    reply(T, v) {
      if (T.busy) return false;
      if (/确认/.test(v) && T.clueCf === "wait") { this.act(T, "s-m0-clue-ok"); return true; }
      if (/高于平均/.test(v) && /专业/.test(v)) { m0Gen(T); return true; }
      if (/热力图/.test(v)) { m0Swap(T, "heat"); return true; }
      if (/柱形|柱状|换回/.test(v) && T.gen) { m0Swap(T, "stack"); return true; }
      if (/常用|每月|自动/.test(v) && (T.repN || 0) >= 3) { m0Save(T); return true; }
      if (/月报|运营情况/.test(v)) { m0Report(T); return true; }
      if (/电商逾期/.test(v)) { this.act(T, "s-m0-ecom"); return true; }
      return false;
    },
    right(T) {
      const subs = [["board", "看板"]].concat(T.ecomSeen ? [["ecom", "电商逾期支付"]] : []).concat(T.repStarted ? [["report", "8 月月报"]] : []);
      const cur = T.sub || "board";
      const tabs = subs.length > 1 ? `<nav class="v93-subtabs">${subs.map(([k, n]) => `<button class="${cur === k ? "on" : ""}" data-em-act="s-sub-${k}">${h(n)}</button>`).join("")}</nav>` : "";
      const top = `<div class="v93-bh"><div><h3>工单运营看板</h3><span>授权范围：全公司 37 家单位 · 8 月在用工单 113 类 · 统计期 8 月（自然月）</span></div><div class="v94-bh-r">${btn(T.tpl ? "收起组件模板" : "组件模板", "s-m0-tpl")}${btn(T.repStarted ? "8 月月报" : "生成本月月报", T.repStarted ? "s-sub-report" : "s-m0-report", "", !!T.busy)}</div></div>` +
        `<div class="v93-kpis m0-kpis"><div class="m0k"><div><b>118,427</b><span>8 月触发（条）</span><small>比 7 月 ↑23%</small></div>${m0Spark()}</div><div class="m0k"><div><b>4.8%</b><span>应办结未办结率</span><small>37 家单位中 21 家高于平均</small></div></div></div>`;
      return `<div class="v93-board">${top}${tabs}<div class="v93-pane">${m0Pane(T)}</div></div>`;
    },
  };
  function m0Gen(T) {
    if (T.gen) { T.sub = "board"; draw(T); return; }
    think(T, "编排新图", [
      { say: "看板上没有这个维度。我从 8 月工单明细取高于平均的 21 家单位，把超期未办结按专业拆开，再从看板模板库里选一种图。", wait: 2600 },
      { cap: "查询", call: "工单中心 · 8 月工单明细", t: `21 家单位超期未办结 ${fmt(genAll())} 条，按 4 个专业汇总。`, from: "8 月工单明细「排重后」", ms: 1200 },
      { cap: "查询", call: `看板模板库 · ${TPL.length} 种`, t: "数据是 21 家单位 × 4 个专业：要比各单位多少、再看专业构成，选堆叠柱形；要看集中在哪几格，热力图更直观。", from: "看板模板库", ms: 700 },
      { cap: "写作", call: "图表编排 · 堆叠柱形", t: "每家单位一根柱，按专业分色，放到看板最上面。", ms: 3100 },
    ], () => {
      T.gen = true; T.sub = "board"; T.genAt = Date.now();
      if (!T.mlay.some((x) => x.id === "gen")) T.mlay.unshift({ id: "gen", w: 12 });
      const pc = Math.round((genSum("合同") / genAll()) * 100);
      say(T, { k: "ai", html: `图已放到看板最上面。21 家单位的超期未办结 ${fmt(genAll())} 条里，合同专业 ${fmt(genSum("合同"))} 条，约占 ${pc}%；云阳例外，主要是仓储（332 条）。想换一种图直接说，例如「换成热力图」。` });
      draw(T);
    });
  }
  /* 对话换图：数据不变，只换模板；组件位置和大小不变 */
  function m0Swap(T, to) {
    if (!T.gen) { say(T, { k: "ai", html: "先说想看哪些数据，例如：8 月未办结率高于平均的单位，按专业拆开。" }); return; }
    const name = TPL_NAME[to];
    if ((to === "heat") === !!T.heat) { say(T, { k: "ai", html: `看板最上面那张图已经是${name}。` }); return; }
    think(T, "换图", [
      { cap: "查询", call: `看板模板库 · ${name}`, t: to === "heat" ? "数据不变，换成热力图：每行一个专业，每列一家单位，颜色越深条数越多。" : "数据不变，换回堆叠柱形。", from: "看板模板库", ms: 600 },
      { cap: "写作", call: `图表编排 · ${name}`, t: "已替换看板最上面那张图，位置和大小不变。", ms: 1800 },
    ], () => {
      T.heat = to === "heat"; T.sub = "board"; T.genAt = Date.now();
      const top3 = genCells().sort((a, b) => b[2] - a[2]).slice(0, 3).map(([u, k, v]) => `${h(u)}${k} ${v} 条`).join("、");
      say(T, { k: "ai", html: T.heat ? `换好了。颜色最深的三格：${top3}；合同这一行整体最深。` : "已换回堆叠柱形。" });
      draw(T);
    });
  }
  function m0Reply() {
    const T = (EM.S.threads || {}).M0;
    clearTimeout(window.__v93ReplyTimer);
    if (!T || !T.assign || T.reply) return;
    T.reply = true;
    /* 专责看到分配后要过一段时间才回复：画面时间跳到 15:40（只往后跳） */
    if (window.DEMO_CLOCK) window.DEMO_CLOCK.set(15, 40, 0);
    m0Log(T, "专责回复", "电商逾期支付督办 · 工单时限", "保留原时限，不再询问");
    m0Log(T, "写入规则库", "电商逾期支付督办 · 工单时限", "保留预警之日起 5 天，不再询问");
    say(T, { k: "raw", html: `<div class="em-m v93-in"><header><b>${h(T.assignee || ASSIGNEES[0])}</b><time>${h(EM.now())}</time></header><p>业务上只要求支付到期日前付款，但为加强各单位支付及时性、避免积压，保留原工单办理时限不变。</p></div>` });
    later(T, 600, () => say(T, { k: "ai", html: "已记录：电商逾期支付督办保留原工单办理时限，同类情况以后不再询问。这条已写入规则库，写明由物资部专责确认。如果专责确认要调，我会在工单中心修改规则，再把修改结果反馈给您。" }));
    draw(T);
  }
  window.v93M0Reply = m0Reply;

  /* 工单运营看板的组件：按住标题拖到其他组件前后换位置；拖右下角按 12 栏调宽、按 10 像素调高。拖动中只改样式，松手后写回布局再重绘 */
  let mdrag = null;
  const m0Drag = () => { const T = EM.S.threads[EM.S.open]; return T && T.id === "M0" && (T.sub || "board") === "board" && !T.busy ? T : null; };
  document.addEventListener("pointerdown", (e) => {
    if (e.button !== 0 || !e.target.closest) return;
    const w = e.target.closest("#emThreadWork .m0w");
    if (!w || e.target.closest("button, select, input, a")) return;
    const rs = e.target.closest("[data-m0-rs]");
    if (!rs && !e.target.closest(".m0w-hd")) return;
    const T = m0Drag();
    const it = T && T.mlay.find((x) => x.id === w.dataset.m0w);
    if (!it) return;
    const gw = w.parentElement.getBoundingClientRect().width;
    mdrag = { T, w, it, rs: !!rs, x: e.clientX, y: e.clientY, moved: false, col: (gw - MGAP * (MCOLS - 1)) / MCOLS, h0: w.getBoundingClientRect().height, nw: it.w, nh: it.hp || 0, tgt: null, after: false };
    e.preventDefault();
  }, true);
  document.addEventListener("pointermove", (e) => {
    if (!mdrag) return;
    const d = mdrag, dx = e.clientX - d.x, dy = e.clientY - d.y;
    if (!d.moved && Math.abs(dx) + Math.abs(dy) < 5) return;
    d.moved = true;
    if (d.rs) {
      d.w.classList.add("rs");
      d.nw = Math.max(3, Math.min(MCOLS, Math.round((d.it.w * (d.col + MGAP) + dx) / (d.col + MGAP))));
      if (Math.abs(dy) > 8) d.nh = Math.max(140, Math.round((d.h0 + dy) / 10) * 10);
      d.w.style.gridColumn = `span ${d.nw}`;
      if (d.nh) d.w.style.height = `${d.nh}px`;
      return;
    }
    d.w.classList.add("drag");
    d.w.style.transform = `translate(${dx}px,${dy}px)`;
    if (d.tgt) d.tgt.classList.remove("tgt-b", "tgt-a");
    d.tgt = null;
    d.w.style.pointerEvents = "none";
    const o = document.elementFromPoint(e.clientX, e.clientY);
    d.w.style.pointerEvents = "";
    const t = o && o.closest(".m0w");
    if (t && t !== d.w) {
      const r = t.getBoundingClientRect();
      d.after = e.clientX > r.left + r.width / 2;
      d.tgt = t;
      t.classList.add(d.after ? "tgt-a" : "tgt-b");
    }
  }, true);
  document.addEventListener("pointerup", () => {
    if (!mdrag) return;
    const d = mdrag;
    mdrag = null;
    if (!d.moved) return;
    eatClick = Date.now() + 400;
    if (d.rs) { d.it.w = d.nw; if (d.nh) d.it.hp = d.nh; }
    else if (d.tgt) {
      const L = d.T.mlay;
      L.splice(L.indexOf(d.it), 1);
      const i = L.findIndex((x) => x.id === d.tgt.dataset.m0w);
      L.splice(d.after ? i + 1 : i, 0, d.it);
    }
    d.T.genSeen = d.T.genSeen || {};
    d.T.genSeen[d.T.tab] = M0.right(d.T);
    draw(d.T);
    /* 内容相同不会重绘，拖动留下的样式在这里清掉 */
    const w = document.querySelector(`#emThreadWork .m0w[data-m0w="${d.it.id}"]`);
    if (w) { w.classList.remove("drag", "rs"); w.style.transform = ""; }
    document.querySelectorAll("#emThreadWork .m0w.tgt-a, #emThreadWork .m0w.tgt-b").forEach((x) => x.classList.remove("tgt-a", "tgt-b"));
  }, true);
  function m0Report(T) {
    if (T.repN || T.repStarted) { T.sub = "report"; draw(T); return; }
    T.repN = 0; T.repStarted = true; T.sub = "report";
    think(T, "写 8 月工单运营月报", REPORT2, () => {
      T.repN = 3; T.sub = "report";
      say(T, { k: "ai", html: "8 月月报已按现行月报结构写好，在右侧。数字和工单中心统计数逐项核对过：月报正文「未办结 4,096 条」与 85,268－81,174＝4,094 差 2 条，已标黄。可以下载 Word，也可以存到我的常用。" });
      draw(T);
    }, (r) => { if (r.cap === "写作") { T.repN = 3; T.sub = "report"; } else if (r.cap === "查询") { T.repN = 1; T.sub = "report"; } });
  }
  function m0Word() {
    const html = `<html><head><meta charset="utf-8"><title>8 月工单运营月报</title></head><body><h1>8 月工单运营月报</h1>${REPORT2_SECS().map(([a, b]) => `<h2>${a}</h2><p>${b}</p>`).join("")}</body></html>`;
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob(["﻿", html], { type: "application/msword" }));
    a.download = "8月工单运营月报.doc";
    document.body.appendChild(a); a.click(); a.remove();
    toast("已下载 8月工单运营月报.doc");
  }
  function m0Save(T) {
    T.saved = true;
    say(T, { k: "result", title: "已保存到「我的常用」", lines: ["每月最后一天 07:00 自动生成当月工单运营月报", "在左侧「我的常用」里可以查看、修改或停用"] });
    try {
      const st = S8();
      if (st.scheduled && !st.scheduled.some((x) => x.v90Report)) {
        st.scheduled.unshift({ id: 90, v90Report: true, name: "工单运营月报", desc: "每月最后一天取当月工单数据生成运营月报。",
          schedule: "每月最后一天 07:00", next: "10月31日 07:00", status: "已启用", context: "每次新建对话", last: "今天 · 试运行（8 月月报）", triggerKey: "plan", runsToday: 1, successRate: 100 });
        st.selectedSchedule = 90;
        if (typeof renderSchedules === "function") renderSchedules();
      }
      const b = document.getElementById("scheduleCountBadge");
      if (b && st.scheduled) b.textContent = String(st.scheduled.length);
    } catch (_) { /* 我的常用页未加载时只提示 */ }
    draw(T);
    toast("已保存到我的常用");
  }
  /* 1019 版事项（三级履约协调、我的关注、电商逾期支付线程等）撤出演示路径，代码保留在上面，不再登记 */
  const odItem = (id, cat, title, o) => Object.assign({ id, who: "H", cat, title, status: "pending", deadline: "今天", reason: "时限｜督办", impact: "—" }, o);
  const ITEMS = [
    odItem("S1", "超期交货督办", `订单 ${OD.no} 超期交货`, { object: `${OD.sup}｜${OD.mat}｜${OD.amt}`, current: "货已到仓库，收货卡在第 2 步", remain: `已超 ${odOver()} 天`,
      risk: "ERP 收货单据未同步电子签章平台", impact: `影响${OD.prj}物资入账`, advice: "同步单据并分配签章人员", reason: "风险｜超期交货" }),
    odItem("S2", "超期交货督办", "订单 4500949833 超期交货", { object: "华力通线缆股份有限公司｜10kV 电力电缆 YJV22 3×300｜86.40 万元", current: "供应商回复 10 月 27 日发货", remain: `已超 ${s2Over()} 天`,
      risk: "物资未送达", advice: "经 e物资发函催告", reason: "风险｜超期交货" }),
    odItem("G1", "供货单状态督办", "供货单 GHD2026101102 发货状态未更新", { object: "江苏金逸电力科技有限公司｜耐张线夹等 6 项", current: "发货状态 3 天未更新", remain: "已超 1 天", risk: "工单时限 2 天", advice: "经 e物资催供应商更新" }),
    odItem("G2", "供货单状态督办", "供货单 GHD2026101187 发货状态未更新", { object: "醴陵市东方电瓷电器有限公司｜复合绝缘子 FXBW-110/100", current: "发货状态 3 天未更新", remain: "已超 1 天", risk: "工单时限 2 天", advice: "经 e物资催供应商更新" }),
    odItem("P1", "协议库存匹配待确认", "协议库存匹配结果待确认：电力电缆 YJV22 3×70", { object: "同物料号", current: "待确认", deadline: "明天 17:00", remain: "未超期", risk: "—", advice: "可直接确认", reason: "办理｜确认" }),
    odItem("P2", "协议库存匹配待确认", "协议库存匹配结果待确认：柱上断路器 630A", { object: "同物料号", current: "待确认", deadline: "明天 17:00", remain: "未超期", risk: "—", advice: "可直接确认", reason: "办理｜确认" }),
    odItem("P3", "协议库存匹配待确认", "协议库存匹配结果待确认：钢芯铝绞线 JL/G1A-240/30", { object: "相近规格", current: "待确认", deadline: "明天 17:00", remain: "未超期", risk: "需需求单位确认能否替代", advice: "先问需求单位", reason: "办理｜确认" }),
  ];
  /* 一般事项 16 项、我的关注 3 项：只在今日简报里列出，点开看 AI 分析 */
  const gen = (id, cat, title, object, current, advice) => ({ id, who: "H", cat, title, status: "pending", object, current, deadline: "本周", remain: "未超期", risk: "—", impact: "—", advice, reason: "一般｜提醒" });
  const H_GENERAL = [
    ...["4500950316", "4500950427", "4500950538", "4500950612", "4500950744", "4500950809"].map((n, i) => gen(`HG${i + 1}`, "到货验收提醒", `订单 ${n} 到货待验收`, "供应商已确认发货通知", "待到货验收", "到货后按 ECP 发货通知核对")),
    ...["新立", "拔山", "白石", "涂井"].map((n, i) => gen(`HG${7 + i}`, "供应计划变更通知", `110kV ${n}输变电工程供应计划变更`, "ECP 供应计划交货期调整", "待查看", "核对变更后的交货期")),
    ...["4500948821", "4500948933", "4500949017"].map((n, i) => gen(`HG${11 + i}`, "履约保证金退还", `订单 ${n} 履约保证金待退还`, "合同已履约完毕", "待发起退还", "核对履约完毕后发起退还")),
    ...["4500947702", "4500947815", "4500947936"].map((n, i) => gen(`HG${14 + i}`, "发票结算提醒", `订单 ${n} 发票待结算`, "发票已到", "待结算", "核对发票与收货数量")),
  ];
  const H_FOLLOW = [
    gen("HF1", "订单跟踪", `订单 ${OD.no} 收货跟踪`, "智能体自动跟踪", "跟踪签章与 ERP 收货", "签章完成后自动办结"),
    gen("HF2", "工程物资跟踪", `${OD.prj}物资到货跟踪`, "智能体自动跟踪", "关键物资 9 项，已到 7 项", "未到的 2 项按交货期跟踪"),
    gen("HF3", "供应商跟踪", "华力通线缆股份有限公司发货跟踪", "智能体自动跟踪", "10 月 27 日发货", "到期未发货自动提醒"),
  ];
  H_FOLLOW.forEach((x) => (x.reason = "我的关注"));
  window.SCENE_LIST = (w, k) => (w === "H" ? (k === "general" ? H_GENERAL : k === "follow" ? H_FOLLOW : null) : w === "A" ? (k === "general" ? A_GEN : k === "follow" ? A_FOL : null) : null);

  /* ================= 10 月 20 日晚：物资部数字化管理专责的今日简报 =================
     首页先给结论和要办的事，看板放到「动态看板 › 工单运营看板」。数字取自 8 月运营月报；统计期按自然月标（董老师确认单第 3 题，用户 10 月 20 日定）。 */
  const m0T = () => (EM.S.threads || {}).M0 || {};
  const A_FOCUS = [
    { id: "AE", open: "M0", act: "s-m0-ecom", cat: "工单运营异常", title: "电商逾期支付 8 月超期 2,118 张", p: "应办结未办结率 49.13%｜AI 建议：对照工单时限和支付到期日，分两类处置" },
    { id: "AR", open: "M0", act: "s-m0-report", cat: "月报", title: "8 月工单运营月报", p: "按现行月报结构写，数字与工单中心统计数逐项核对" },
  ];
  const A_GEN = [
    { id: "M2", cat: "工单运营", title: "超期未办结 4,094 条", status: "pending", remain: "8 月", p: "21 家单位高于平均 4.8%，最高超高压 35.54%" },
    { id: "M4", cat: "工单运营", title: "长时未触发 10 类", status: "pending", remain: "8 月", p: "低频业务 5 类持续评估；系统缺陷 5 类已优化触发逻辑、待触发后评估" },
  ];
  const A_FOL = [{ id: "AF", open: "M0", act: "s-sub-board", cat: "看板", title: "工单运营看板 · 全公司 37 家单位", remain: "8 月", p: "统计期 8 月（自然月）" }];
  const aDone = (e) => { const T = m0T(); return e.id === "AE" ? !!(T.clue && T.reply) : e.id === "AR" ? !!T.saved : false; };
  const aRemain = (e) => {
    const T = m0T();
    if (e.id === "AE") return aDone(e) ? "已处置" : T.cls ? "处置中" : "待处置";
    if (e.id === "AR") return T.saved ? "已存到我的常用" : (T.repN || 0) >= 3 ? "已生成" : "待生成";
    return e.remain || "";
  };
  const aRow = (e) => `<button class="homebrief-task-row v93-row" data-v95-open="${e.open || e.id}"${e.act ? ` data-v95-act="${e.act}"` : ""}><div class="top"><strong>${h(e.title)}</strong><em class="${e.cat === "工单运营异常" && !aDone(e) ? "risk" : ""}">${h(aRemain(e))}</em></div><p>${h(e.p)}</p></button>`;
  function aRoot(root, crumb) {
    const name = { focus: "重点事项", general: "一般事项", follow: "我的关注", new: "新增任务" }[root];
    if (!name) return "";
    const list = root === "focus" ? A_FOCUS : root === "general" ? A_GEN : root === "follow" ? A_FOL : [];
    const sub = { focus: "工单运营里要您处理的事", general: "工单运营的其他情况，点开看分析", follow: "智能体持续跟踪", new: "工单中心有新推送时出现在这里" }[root];
    const body = list.length ? `<div class="v93-cats"><section>${list.map(aRow).join("")}</section></div>` : `<div class="homebrief-empty"><strong>暂无新增任务</strong>工单中心有新推送时会出现在这里</div>`;
    return `<div class="homebrief-panel">${crumb([{ label: name }])}<div class="homebrief-panel-head"><div><h3>${name} · ${list.length}项</h3><p>${sub}</p></div></div>${body}</div>`;
  }
  function aBrief() {
    const T = m0T();
    const ecom = aDone(A_FOCUS[0])
      ? `<li><b>电商逾期支付 8 月超期 2,118 张：</b>已处置：9 张形成监督检查线索，2,109 张经物资部专责确认保留原工单时限。<button class="v93-link" data-v95-open="M0" data-v95-act="s-m0-ecom">查看</button></li>`
      : `<li><b>电商逾期支付 8 月超期 2,118 张：</b>应办结未办结率 49.13%，三类异常里最突出。我对照了工单时限和支付到期日，可以分两类处置。<button class="v93-link" data-v95-open="M0" data-v95-act="s-m0-ecom">看分析</button></li>`;
    const rep = (T.repN || 0) >= 3;
    const report = `<li><b>8 月工单运营月报${rep ? "已生成" : "待生成"}：</b>${rep ? (T.saved ? "已存到我的常用，每月最后一天自动生成。" : "数字已和工单中心统计数逐项核对。") : "按现行月报结构写，数字和工单中心统计数逐项核对。"}<button class="v93-link" data-v95-open="M0" data-v95-act="s-m0-report">${rep ? "查看" : "去生成"}</button></li>`;
    const sum = `<li><b>全公司概况：</b>在用工单 113 类，8 月触发 118,427 条，应办结未办结率 4.8%，37 家单位里 21 家高于平均。</li>`;
    const left = A_FOCUS.filter((e) => !aDone(e)).length;
    return `<section class="homebrief-analysis fouranalysis-focus-analysis v90-brief-msg"><p class="v90-greet">${greet()}。工单中心 8 月的运行数据我已读过（统计期按自然月），${left ? `要您处理的有 ${left} 件` : "要您处理的事都已办完"}：</p><ol class="v93-lines">${ecom}${report}${sum}</ol><p class="v94-more"><span>各单位、各专业、按人的情况在工单运营看板里</span><button class="v93-link" data-v95-open="M0" data-v95-board>进入工单运营看板 ›</button></p></section>`;
  }
  /* 从简报、菜单打开看板时直接到对应的一步；分析、月报做过的只切过去看，不重做 */
  function v95M0Act(a) {
    const T = m0T();
    if (!T.id || !a || T.busy) return;
    if (a === "s-m0-ecom" && T.cls) a = "s-sub-ecom";
    if (a === "s-m0-report" && T.repStarted) a = "s-sub-report";
    M0.act(T, a);
  }
  function v95Open(id, act) {
    if (!EM.openThread(id)) return;
    if (id === "M0" && act) v95M0Act(act);
  }
  window.v95Open = v95Open;

  /* ================= 智能问数：按账号的授权范围给数，答案写明来源和统计期 =================
     履约专责：忠县公司、本人经手；数字化管理专责：全公司 37 家单位。超出范围的问题直接说明，不给数。 */
  const SCOPE = { H: "忠县公司 · 本人经手的工单和订单", A: "全公司 37 家单位" };
  const askScene = (title, rows, advice, right, w) => ({
    pane: "画布", tabs: [title], init() {}, bg: () => [["数据范围", SCOPE[w]]],
    intro(T) { say(T, { k: "me", text: title }); think(T, "取数", rows, () => say(T, { k: "ai", html: advice })); },
    act() {}, right: () => page(title, `数据范围：${h(SCOPE[w])}`, right),
  });
  const top5 = U37.slice(0, 5);
  const ht5 = GEN.map(([u, o]) => [u, o.合同 || 0]).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const QA = {
    QA1: ["8 月各单位应办结未办结率前五", [
      { cap: "查询", call: "工单中心 · 8 月运营月报表 5", t: `37 家单位里 21 家高于平均 4.8%。前五：${top5.map(([u, v]) => `${u} ${v.toFixed(2)}%`).join("、")}。`, from: "8 月运营月报表 5（统计期 8 月）", ms: 1500 },
    ], `前五是${top5.map(([u, v]) => `${u} ${v.toFixed(2)}%`).join("、")}；21 家高于平均 4.8%。要按专业拆开看，在工单运营看板里说「高于平均的单位按专业拆开」。`,
      tbl(["单位", "应办结未办结率"], top5.map(([u, v]) => [u, `${v.toFixed(2)}%`]))],
    QA2: ["合同专业超期未办结最多的 5 家单位", [
      { cap: "查询", call: "工单中心 · 8 月工单明细", t: `高于平均的 21 家单位，合同专业超期未办结 ${fmt(genSum("合同"))} 条。最多的 5 家：${ht5.map(([u, v]) => `${u} ${v} 条`).join("、")}。`, from: "8 月工单明细「排重后」，工单状态＝超期未办结", ms: 1100 },
    ], `合同专业超期未办结最多的是${ht5.map(([u, v]) => `${u} ${v} 条`).join("、")}。这 5 家合计 ${ht5.reduce((a, [, v]) => a + v, 0)} 条，占 21 家合同专业超期未办结的 ${Math.round((ht5.reduce((a, [, v]) => a + v, 0) / genSum("合同")) * 100)}%。`,
      tbl(["单位", "合同专业超期未办结（条）"], ht5.map(([u, v]) => [u, String(v)]))],
    QA3: ["8 月触发次数最多的 5 个人", [
      { cap: "查询", call: "工单中心 · 8 月运营月报表 3", t: `接收人 1,617 人，人均约 107 次。最多的 5 人：${PEOPLE5.map(([n, u, c]) => `${n}（${u}）${fmt(c)} 次`).join("、")}。`, from: "8 月运营月报表 3", ms: 1100 },
    ], `最多的是${PEOPLE5[0][0]}（${PEOPLE5[0][1]}）${fmt(PEOPLE5[0][2])} 次，主要是${PEOPLE5[0][3]}；前 5 人里 4 人在物资公司。`,
      tbl(["接收人", "单位", "触发次数", "涉及最多的工单"], PEOPLE5.map(([n, u, c, t]) => [n, u, fmt(c), t]))],
  };
  Object.entries(QA).forEach(([id, [q, rows, adv, right]]) => {
    window.SCENES[id] = askScene(q, rows, adv, right, "A");
    EM.register(id, { mode: "scene", who: "A", tabs: [q], why: "" }, { id, who: "A", cat: "查询", title: q, status: "done", object: "—", current: "—", deadline: "—", remain: "—", risk: "—", impact: "—", advice: "—", reason: "查询" });
  });
  window.V95_QS = { get H() { return window.V94_QS || []; }, A: Object.entries(QA).map(([id, [q]]) => [id, q]) };
  const ASK_MATCH = {
    H: [[/到期|未收货/, "Q1"], [/线缆|在途/, "Q2"], [/OPGW|光缆|驼丘/, "Q3"]],
    A: [[/未办结率|前五|排名/, "QA1"], [/合同/, "QA2"], [/触发.*人|按人|最多.*人/, "QA3"]],
  };
  let askN = 0;
  /* 输入框里的问题：对得上的打开对应答案；履约专责问全公司的数，说明超出范围；没接入的如实说 */
  window.v95Ask = function (q) {
    const w = who();
    const hit = (ASK_MATCH[w] || []).find(([re]) => re.test(q));
    if (hit) return EM.openThread(hit[1]);
    const out = w === "H" && /全公司|全省|各单位|其他单位|37 家|物资部/.test(q);
    const id = `QX${++askN}`;
    const tip = (window.V95_QS[w] || []).map(([, x]) => `「${h(x)}」`).join("、");
    window.SCENES[id] = askScene(q, [{ cap: "审核", call: "数据权限", t: out ? `问题涉及忠县公司以外的数据，您的授权范围是${SCOPE.H}。` : `授权范围内：${SCOPE[w]}。`, from: "工作台数据权限", ms: 500 }],
      out ? `这个问题超出您的数据范围：您能查的是${SCOPE.H}。需要全公司的数，可以请物资部数字化管理专责查询。` : `我需要先确认口径：您要看的是哪个统计期、哪类工单或物资？说清楚这两点我马上取数。也可以这样问：${tip}。`,
      kv([["问题", h(q)], ["数据范围", SCOPE[w]], ["结果", out ? "超出授权范围，不取数" : "待确认统计期和对象"]]), w);
    EM.register(id, { mode: "scene", who: w, tabs: [q], why: "" }, { id, who: w, cat: "查询", title: q, status: "done", object: "—", current: "—", deadline: "—", remain: "—", risk: "—", impact: "—", advice: "—", reason: "查询" });
    return EM.openThread(id);
  };
  /* 智能问数首页：说明数据范围，列出常问的问题 */
  function askHome(w) {
    const qs = (window.V95_QS[w] || []).map(([id, q]) => `<li><button class="v93-link" data-v94-q="${id}">${h(q)}</button></li>`).join("");
    return `<section class="homebrief-analysis fouranalysis-focus-analysis v90-brief-msg v95-ask"><p class="v90-greet"><b>智能问数</b> · 数据范围：${h(SCOPE[w])}</p><p>直接问数，我按您的授权范围取数，答案写明数据来源和统计期；超出范围的不取数。常问的：</p><ol class="v93-lines">${qs}</ol><p class="v90-sub">答案里的图表可以存到看板，常问的可以存到「我的常用」定期推送。</p></section>`;
  }

  /* ---------- M2、M4：只给出分析，不在本次演示展开 ---------- */
  const M2 = simple("超期未办结", [
    { cap: "查询", call: "8 月运营月报", t: "8 月应办结 85,268 条，已办结 81,174 条，应办结未办结 4,094 条，应办结未办结率 4.8%。", from: "8 月运营月报", ms: 1200 },
    { cap: "查询", call: "8 月运营月报 · 各单位", t: "21 家单位高于平均 4.8%，最高的是超高压 35.54%（408 条），其次大足 22.30%、垫江 21.34%。", from: "8 月运营月报表 5", ms: 1000 },
  ], "建议按单位推送超期清单，下周看变化。", kv([["应办结未办结", "4,094 条（4.8%）"], ["高于平均的单位", "21 家"], ["最高", "超高压 35.54%、大足 22.30%、垫江 21.34%"], ["建议", "按单位推送超期清单"]]));
  const M4 = simple("长时未触发", [
    { cap: "查询", call: "8 月运营月报", t: "剩余异常工单 10 类：9 类上线后从未触发，1 类触发小于 100。", from: "8 月运营月报表 7", ms: 1200 },
  ], "低频业务 5 类持续评估；系统缺陷 5 类已优化触发逻辑，等触发后评估。", kv([["类数", "10 类"], ["低频业务", "5 类，持续评估"], ["系统缺陷", "5 类，已优化触发逻辑，待评估"]]));

  /* ---------- M5：应急工单跟踪（应急实施方案确认后出现，数据由 emergency-live.js 给出） ---------- */
  const M5 = {
    pane: "画布", tabs: ["工单跟踪"], init() {}, bg: () => [["来源", "忠县石拔南线 22 号塔滑坡应急"]],
    intro(T) {
      const tk = (window.v92Tickets && window.v92Tickets()) || [];
      say(T, { k: "ai", html: `忠县应急刚生成 ${tk.length} 张工单，已纳入监控。超过 30 分钟未接收的，我会自动提醒对方。` });
    },
    act() {},
    right: () => {
      const tk = (window.v92Tickets && window.v92Tickets()) || [];
      return page("应急工单跟踪", "派发 → 接收 → 办理 → 回执", tk.map(([n, st, l]) => `<div class="v90-track"><div class="v90-track-h"><b>${h(n)}</b>${chip(l, l === "待接收" || l === "待确认" ? "warn" : "ok")}</div><ol>${["派发", "接收", "办理", "回执"].map((x, i) => `<li class="${st[i] ? "d" : ""}"><i></i>${x}</li>`).join("")}</ol></div>`).join(""));
    },
  };

  /* ---------- E1：今日简报里的应急事项，直接进入应急任务（emergency-live.js） ---------- */
  const openEmergency = () => window.v92OpenEmergency && window.v92OpenEmergency();
  const E1 = {
    pane: "画布", tabs: ["应急任务"], init() {}, bg: () => [],
    intro() { openEmergency(); },
    act() {},
    right: () => page("应急任务", "", `<div class="sc-empty">在应急任务中心处理。</div>`),
  };

  /* 首页「也可以直接问」：业务人员主动发起查询 */
  const QS = {
    Q1: ["本周还有哪些订单到期未收货", simple("本周到期未收货订单", [
      { cap: "查询", call: "ECP · 供应计划", t: "本周（10 月 19 日—25 日）确定交货期已到、ERP 没有收货的订单 3 张。", from: "ECP 供应计划；ERP 收货记录", ms: 1600 },
      { cap: "查询", call: "e物资 · 供应商回复", t: "4500951207 已送达驼丘仓库；4500949833 排产延误，10 月 27 日发货；4500950744 已确认发货通知，预计 10 月 25 日到货。", from: "e物资回复原文", ms: 2100 },
    ], "本周到期未收货 3 张：<br>· 4500951207：货已到驼丘仓库，收货卡在签章环节，在今日重点事项里；<br>· 4500949833：供应商回复 10 月 27 日发货，建议发函催告；<br>· 4500950744：10 月 25 日到期，供应商已确认发货通知，预计按期到货。",
      tbl(["订单", "交货期", "情况"], [["4500951207", "10 月 10 日", "已到货，收货卡在签章环节"], ["4500949833", "10 月 18 日", "10 月 27 日发货"], ["4500950744", "10 月 25 日", "已确认发货通知"]]))],
    Q2: ["华力通线缆股份有限公司在途订单的交货情况", simple("华力通线缆股份有限公司在途订单", [
      { cap: "查询", call: "ECP · 供应计划", t: `在途订单 2 张：4500949833 交货期 10 月 18 日，已超 ${s2Over()} 天；4500950812 交货期 11 月 6 日。`, from: "ECP 供应计划", ms: 1600 },
      { cap: "查询", call: "e物资 · 供应商回复", t: "4500949833 排产延误，10 月 27 日发货；4500950812 按期生产。", from: "e物资回复原文", ms: 1300 },
    ], `这家供应商在途 2 张：4500949833 已超 ${s2Over()} 天，供应商回复 10 月 27 日发货，建议发函催告并要求书面确认；4500950812 交货期 11 月 6 日，按期生产。`,
      tbl(["订单", "物资", "交货期", "情况"], [["4500949833", "10kV 电力电缆 YJV22 3×300", "10 月 18 日", `已超 ${s2Over()} 天，10 月 27 日发货`], ["4500950812", "10kV 电缆终端", "11 月 6 日", "按期生产"]]))],
    Q3: ["忠县驼丘仓库 OPGW 光缆还有多少", simple("驼丘仓库 OPGW 光缆库存", [
      { cap: "查询", call: "ERP · 库存（忠县驼丘仓库）", t: "OPGW 光缆库存 0 千米；最近一次出库 9 月 12 日，1.8 千米。", from: "ERP 库存", ms: 2900 },
    ], "驼丘仓库现在没有 OPGW 光缆库存，最近一次是 9 月 12 日出库 1.8 千米。要用的话，我可以在全省库存、协议库存和在建工程里同时查。",
      kv([["库存", "0 千米"], ["最近出库", "9 月 12 日，1.8 千米"]]))],
  };
  Object.entries(QS).forEach(([id, [q, sc]]) => { window.SCENES[id] = sc; EM.register(id, { mode: "scene", who: "H", tabs: sc.tabs, why: "" }, { id, who: "H", cat: "查询", title: q, status: "done", object: "—", current: "—", deadline: "—", remain: "—", risk: "—", impact: "—", advice: "—", reason: "查询" }); });
  window.V94_QS = Object.entries(QS).map(([id, [q]]) => [id, q]);
  const simpleOf = (it) => simple(it.title, [{ cap: "查询", call: "工单中心 · 工单详情", t: `${it.object}；${it.current}。`, from: "工单中心", ms: 1700 }], `建议：${it.advice}。`, kv([["事项", it.title], ["当前", it.current], ["建议", it.advice]]));
  const HSC = {};
  [...H_GENERAL, ...H_FOLLOW].forEach((it) => (HSC[it.id] = simpleOf(it)));
  Object.assign(window.SCENES, { M1, M2, M4, M5, E1, R1, R2, R3, K1, S1, S2, G1: G2, G2, P1: P2, P2, P3: P2, M0 }, HSC);
  /* 管理岗今日简报「一般事项」里的两项 */
  A_GEN.forEach((it) => EM.register(it.id, { mode: "scene", who: "A", tabs: window.SCENES[it.id].tabs, why: "" }, Object.assign({ who: "A", object: "全公司 · 8 月", current: it.p, deadline: "—", risk: "—", impact: "—", advice: "—", reason: "工单运营" }, it)));
  const focus = window.homeBriefFocusItems || [];
  /* V89 的物资公司管理人员事项（V85—V88 演示用）本次不显示，代码与数据保留 */
  focus.forEach((it) => { if ((it.who || "A") === "A" && !/^M\d$/.test(it.id)) it.who = "A-V89"; });
  ITEMS.forEach((it) => {
    EM.register(it.id, { mode: "scene", who: it.who, tabs: window.SCENES[it.id].tabs, why: "" });
    if (!focus.some((x) => x.id === it.id)) focus.push(it);
  });
  [...H_GENERAL, ...H_FOLLOW].forEach((it) => EM.register(it.id, { mode: "scene", who: "H", tabs: window.SCENES[it.id].tabs, why: "" }, it));
  /* 动态看板 › 我的看板：两个账号各一份 */
  window.SCENES.K1H = K1; window.SCENES.K1A = K1;
  const k1Item = (id, w) => ({ id, who: w, cat: "看板", title: "我的看板", status: "running", object: "8 月", current: "业务指标、我的工单运营指标", deadline: "持续", remain: "—", risk: "—", impact: "—", advice: "—", reason: "看板" });
  EM.register("K1H", { mode: "scene", who: "H", tabs: K1.tabs, why: "" }, k1Item("K1H", "H"));
  EM.register("K1A", { mode: "scene", who: "A", tabs: K1.tabs, why: "" }, k1Item("K1A", "A"));
  EM.register("M0", { mode: "scene", who: "A", tabs: M0.tabs, why: "" }, { id: "M0", who: "A", cat: "工单运营", title: "工单运营看板", status: "running", object: "全公司 · 8 月", current: "8 月工单运行", deadline: "持续", remain: "—", risk: "—", impact: "—", advice: "—", reason: "看板" });

  /* ---------- 今日简报（2026-10-20 改，V88 结构）：重点事项按类列出，下方四个计数（新增、重点、一般、关注） ---------- */
  const greet = () => { const hr = new Date().getHours(); return hr < 11 ? "早上好" : hr < 13 ? "中午好" : hr < 18 ? "下午好" : "晚上好"; };
  const baseSummary = window.SCENE_SUMMARY;
  const byCat = (cat) => focus.filter((x) => x.who === "H" && x.cat === cat);
  window.SCENE_SUMMARY = function (who) {
    const s = S8() || {};
    if (s.v95Ask) return askHome(who);
    if (who === "A") return aBrief();
    if (who === "H") {
      const rel = !!window.__v90NoticeReleased;
      const emg = rel ? `<li class="${window.__V92E && window.__V92E.t0 ? "" : "v94-new"}"><b>应急保障 1 条：忠县 110kV 石拔南线 22 号塔滑坡，</b>${s.v90EmgDone ? "物资部已选定保障方案，后续事项已发起。" : "运检部提报 23 种抢修物资，智能体正在处理。"} <button class="v93-link" data-v90-open-emg>查看</button></li>` : "";
      const s1 = s.v93S1Done ? `订单 ${OD.no} 已同步单据、分配签章人员，待签章；` : `订单 ${OD.no} 货已到驼丘仓库，收货卡在签章环节，10 月 28 日要领用，建议先办；`;
      const lines = [emg,
        `<li><b>超期交货督办 ${byCat("超期交货督办").length} 条：</b>${s1}订单 4500949833 供应商回复 10 月 27 日发货。</li>`,
        `<li><b>「供货单状态」督办 ${byCat("供货单状态督办").length} 条：</b>两家供应商发货状态 3 天未更新，已超工单时限 1 天，建议今天经 e物资催更新。</li>`,
        `<li><b>协议库存匹配待确认 ${byCat("协议库存匹配待确认").length} 条：</b>同物料号 2 条可直接确认，相近规格 1 条需问需求单位。</li>`].filter(Boolean);
      /* 事项多了只列前 3 类，其余收成一行，从「重点事项」进去看全部 */
      const more = lines.length > 3 ? `<p class="v94-more"><span>还有 ${lines.length - 3} 类：协议库存匹配待确认 ${byCat("协议库存匹配待确认").length} 条</span><button class="v93-link" data-homebrief-root="focus">查看全部重点事项 ›</button></p>` : "";
      const head = rel ? `工单中心推给您的 24 项事情我已读过，重点事项 8 条，按紧急程度列前 3 类：` : `工单中心推给您的 23 项事情我已读过，重点事项 7 条，分 3 类：`;
      /* 夜间自主办理的结果（我的常用「超期交货督办夜间巡查」，李崇阳 10.19 评审一）：只提醒供应商，要人确认的留到早上，不进演示步骤 */
      const night = `<p class="v96-night"><b>夜间巡查（今天 00:30）：</b>已经 e物资提醒 2 家没在 ECP 确认发货通知的供应商；要您确认的都列在上面。<button class="v93-link" data-v95-sched>查看</button></p>`;
      return `<section class="homebrief-analysis fouranalysis-focus-analysis v90-brief-msg"><p class="v90-greet">${greet()}。${head}</p><ol class="v93-lines">${lines.slice(0, 3).join("")}</ol>${more}${night}</section>`;
    }
    return baseSummary ? baseSummary(who) : "";
  };
  /* 点「重点事项」：按工单类型分类，每类下面直接列工单 */
  window.SCENE_ROOT = function (root, who, crumb) {
    if (who === "A") return aRoot(root, crumb);
    if (who === "H" && root === "new" && window.__v90NoticeReleased)
      return `<div class="homebrief-panel">${crumb([{ label: "新增任务" }])}<div class="homebrief-panel-head"><div><h3>新增任务 · 1项</h3><p>工单中心 10:15 推送</p></div></div><div class="v93-cats"><section><header><b>应急保障</b><em>1</em></header><button class="homebrief-task-row v93-row" data-v90-open-emg><div class="top"><strong>忠县 110kV 石拔南线 22 号塔滑坡</strong><em class="risk">${S8().v90EmgDone ? "后续事项已发起" : "处理中"}</em></div><p>运检部提报 23 种抢修物资｜市内 2 小时、省内 4 小时、跨省 8 小时出库</p></button></section></div></div>`;
    if (who !== "H" || root !== "focus") return "";
    const cats = ["超期交货督办", "供货单状态督办", "协议库存匹配待确认"];
    const rel = !!window.__v90NoticeReleased;
    /* 2026-10-21 改成与一般事项一样的分类卡：先分类，点类卡再到单条（董老师 10.19「先分类再到单条」） */
    const card = (c) => { const list = byCat(c), e = list[0]; return `<button class="homebrief-category-card" data-homebrief-category="${h(c)}"><div class="top"><strong>${h(c)}</strong><b>${list.length}</b></div><p>${h(e.title)}</p><small class="${/已超/.test(e.remain) ? "risk" : ""}">${h(e.remain)}｜AI 建议：${h(e.advice)}</small></button>`; };
    const emgCard = rel ? `<button class="homebrief-category-card" data-v90-open-emg><div class="top"><strong>应急保障</strong><b>1</b></div><p>忠县 110kV 石拔南线 22 号塔滑坡</p><small class="risk">${S8().v90EmgDone ? "后续事项已发起" : "处理中"}｜运检部提报 23 种抢修物资</small></button>` : "";
    return `<div class="homebrief-panel">${crumb([{ label: "重点事项" }])}<div class="homebrief-panel-head"><div><h3>重点事项 · ${rel ? 8 : 7}项</h3><p>按工单类型分 ${rel ? 4 : 3} 类，每张工单智能体都已读过</p></div></div><div class="homebrief-category-grid approvedui-category-count-${rel ? 4 : 3}">${emgCard}${cats.map(card).join("")}</div></div>`;
  };
  /* 应急放出后：重点事项多 1 条；还没点开时算 1 项新增任务 */
  window.__v94FocusAdd = (w) => (w === "H" && window.__v90NoticeReleased ? 1 : w === "A" ? A_FOCUS.filter((e) => !aDone(e)).length : 0);
  window.__v94New = () => who() === "H" && !!window.__v90NoticeReleased && !(window.__V92E && window.__V92E.t0);
  window.SCENE_TASK_DETAIL = (e, crumb, rootName) => (e && e.id === "S1" ? s1Detail(e, crumb, rootName) : "");
  document.addEventListener("click", (e) => {
    const fb = e.target.closest("[data-v94-fb]");
    if (fb) {
      e.preventDefault(); e.stopImmediatePropagation();
      const k = fb.dataset.v94Fb, s = S8();
      if (k === "open") s.v94Fb = { st: "open" };
      else if (k === "cancel") s.v94Fb = {};
      else { const r = document.querySelector('input[name="v94fb"]:checked'); s.v94Fb = { st: "sent", why: r ? r.value : FB_WHY[0] }; toast("反馈已提交"); }
      EM.refreshHome();
      return;
    }
    if (e.target.closest("[data-v90-open-emg]")) { e.preventDefault(); e.stopImmediatePropagation(); openEmergency(); return; }
    const o5 = e.target.closest("[data-v95-open]");
    if (o5) { e.preventDefault(); e.stopImmediatePropagation(); v95Open(o5.dataset.v95Open, o5.dataset.v95Act || ""); return; }
    const o = e.target.closest("[data-v93-open]");
    if (o) { e.preventDefault(); e.stopImmediatePropagation(); EM.openThread(o.dataset.v93Open); }
  }, true);

  /* ---------- 应急提醒：第一段办完后才出现；之前任何地方都看不到这件应急。弹出时画面时间跳到 10:15 ---------- */
  function releaseNotice() {
    if (window.__v90NoticeReleased) return;
    window.__v90NoticeReleased = true;
    if (window.DEMO_CLOCK) window.DEMO_CLOCK.set(10, 15, 0);
    document.body.classList.remove("v90-hold-notice", "v91-pre-emg");
    document.body.classList.add("v90-notice-live");
    const card = document.getElementById("emergencyNotifyCard");
    if (card) {
      const tm = card.querySelector(".approvedui-notice-time");
      if (tm && window.DEMO_CLOCK) tm.textContent = window.DEMO_CLOCK.hm();
      card.classList.add("show");
    }
    EM.refreshHome();
    if (window.v92SideRefresh) window.v92SideRefresh();
  }
  window.v92ReleaseNotice = releaseNotice;
  const who = () => (window.execWho ? window.execWho() : "H");
  function syncHold() {
    document.body.classList.toggle("v90-hold-notice", !window.__v90NoticeReleased);
    document.body.classList.toggle("v91-pre-emg", !window.__v90NoticeReleased);
  }
  syncHold();
  /* 10 月 20 日晚起物资部数字化管理专责的首页是今日简报对话，工单运营看板从简报或「动态看板」进入，不再自动打开
     （用户 10 月 20 日定；邱主任 10.15 C-7 看板不要太抢眼；董老师 1017-18 今日简报第一块放要处理的工作） */
  document.addEventListener("click", (ev) => {
    if (ev.target.closest && ev.target.closest("[data-em-who]")) setTimeout(syncHold, 30);
  }, true);
  /* 演示控件（界面上不显示）：E 弹出应急提醒卡（提醒卡没出现或误关时用）；R 在看板里让专责回复到达 */
  document.addEventListener("keydown", (e) => {
    if (e.target && (/INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || e.target.isContentEditable)) return;
    const k = (e.key || "").toLowerCase();
    if (k === "r" && EM.S.open === "M0") { m0Reply(); return; }
    if (k !== "e") return;
    if (!window.__v90NoticeReleased) releaseNotice();
    else if (!document.body.classList.contains("v90-emg-done")) document.getElementById("emergencyNotifyCard")?.classList.add("show");
  });

  /* Tab 自动打字用：当前打开的任务线程这一步该说的话 */
  window.v92ThreadLine = function () {
    const T = EM.S.threads[EM.S.open];
    if (!T || T.busy) return "";
    if (T.id === "M0") {
      if (!T.gen) return "8 月未办结率高于平均的单位，按专业拆开";
      if (!T.heat && !T.ecomSeen) return "换成热力图";
      if (!T.repStarted) return "生成 8 月工单运营月报";
    }
    return "";
  };

  EM.refreshHome();
})();
