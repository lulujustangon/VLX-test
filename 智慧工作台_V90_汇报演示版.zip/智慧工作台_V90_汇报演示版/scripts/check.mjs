import fs from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const sourceDir = path.join(root, "src");
const index = await fs.readFile(path.join(sourceDir, "index.html"), "utf8");
const expectedStyles = [
  "foundation.css",
  "prototype-history.css",
  "home.css",
  "workspace-layout.css",
  "agent-center.css",
  "approvedui.css",
  "exec-modes.css",
  "scene.css",
];
const expectedScripts = [
  "core.js",
  "prototype-history.js",
  "home.js",
  "workspace-layout.js",
  "agent-center.js",
  "approvedui.js",
  "exec-shots.js",
  "exec-modes.js",
  "scene-data.js",
  "scene-flows.js",
];
/* 截图数据文件内是 base64，不做命名检查 */
const dataScripts = new Set(["exec-shots.js", "scene-data.js"]);

const linkedStyles = [...index.matchAll(/<link\s+rel="stylesheet"\s+href="\.\/styles\/([^"]+)"\s*\/>/g)].map(
  (match) => match[1],
);
const linkedScripts = [...index.matchAll(/<script\s+src="\.\/scripts\/([^"]+)"><\/script>/g)].map(
  (match) => match[1],
);

assertList("style load order", linkedStyles, expectedStyles);
assertList("script load order", linkedScripts, expectedScripts);
assertCount(index, "<!-- build:styles -->", 1);
assertCount(index, "<!-- /build:styles -->", 1);
assertCount(index, "<!-- build:scripts -->", 1);
assertCount(index, "<!-- /build:scripts -->", 1);

if (/<style(?:\s|>)/i.test(index) || /<script(?!\s+src=)[^>]*>/i.test(index)) {
  throw new Error("src/index.html must not contain inline style or runtime blocks");
}
assertNoVersionedImplementationNames("src/index.html", index);

for (const file of expectedStyles) {
  const content = await fs.readFile(path.join(sourceDir, "styles", file), "utf8");
  if (!content.trim()) throw new Error(`Empty stylesheet: ${file}`);
  assertNoVersionedImplementationNames(`src/styles/${file}`, content);
}
for (const file of expectedScripts) {
  const content = await fs.readFile(path.join(sourceDir, "scripts", file), "utf8");
  if (!content.trim()) throw new Error(`Empty runtime module: ${file}`);
  if (!dataScripts.has(file)) assertNoVersionedImplementationNames(`src/scripts/${file}`, content);
  try {
    Function(content);
  } catch (error) {
    throw new Error(`Syntax error in src/scripts/${file}: ${error.message}`);
  }
}

console.log(`Structure check passed: 1 HTML shell, ${expectedStyles.length} style modules, ${expectedScripts.length} runtime modules, semantic implementation names.`);

function assertList(label, actual, expected) {
  if (JSON.stringify(actual) !== JSON.stringify(expected)) {
    throw new Error(`${label} changed:\nactual: ${actual.join(", ")}\nexpected: ${expected.join(", ")}`);
  }
}

function assertCount(content, token, expected) {
  const actual = content.split(token).length - 1;
  if (actual !== expected) throw new Error(`Expected ${expected} occurrence(s) of ${token}, found ${actual}`);
}

function assertNoVersionedImplementationNames(filename, content) {
  const candidates = new Set([
    ...(content.match(/\b[A-Za-z_$][A-Za-z0-9_$]*[vV]\d+[A-Za-z0-9_$]*\b/g) || []),
    ...(content.match(/\b[vV]\d+[_$A-Za-z][A-Za-z0-9_$]*\b/g) || []),
    ...(content.match(/[-_][vV]\d+\b/g) || []),
  ]);
  const invalid = [...candidates].filter((name) => !/^YJV\d+$/.test(name));
  if (invalid.length) {
    throw new Error(
      `${filename} contains version-number implementation names: ${invalid.slice(0, 12).join(", ")}`,
    );
  }
}
