import fs from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
if (process.env.REEXTRACT_ACCEPTED_SOURCE !== "1") {
  throw new Error(
    "This is a one-time migration tool and would overwrite src/. " +
      "Set REEXTRACT_ACCEPTED_SOURCE=1 only when intentionally rebuilding src/ from the untouched accepted source file.",
  );
}
const sourceFile = path.join(root, "智慧工作台_综合高保真交互原型_V85_修复版.html");
const source = await fs.readFile(sourceFile, "utf8");
const styles = [...source.matchAll(/<style([^>]*)>([\s\S]*?)<\/style>/g)].map((match, index) => ({
  index: index + 1,
  attrs: match[1],
  content: match[2].trim(),
}));
const scripts = [...source.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/g)].map((match, index) => ({
  index: index + 1,
  attrs: match[1],
  content: match[2].trim(),
}));

// These historical layers are fully superseded by the accepted UI. Each
// entry is protected by the visual and interaction regression suite.
const omittedStyleBlocks = new Set([6, 8, 9, 17, 25, 26]);
const omittedRuntimeBlocks = new Set([5, 6, 7, 15, 24, 25, 27, 28]);

if (styles.length !== 33 || scripts.length !== 33) {
  throw new Error(`Unexpected accepted-source shape: ${styles.length} style blocks, ${scripts.length} script blocks`);
}

const styleGroups = [
  ["foundation.css", 1, 7],
  ["prototype-history.css", 8, 28],
  ["home.css", 29, 29],
  ["workspace-layout.css", 30, 31],
  ["agent-center.css", 32, 32],
  ["approvedui.css", 33, 33],
];
const scriptGroups = [
  ["core.js", 1, 2],
  ["prototype-history.js", 3, 26],
  ["home.js", 29, 29],
  ["workspace-layout.js", 30, 31],
  ["agent-center.js", 32, 32],
  ["approvedui.js", 33, 33],
];

await fs.mkdir(path.join(root, "src/styles"), { recursive: true });
await fs.mkdir(path.join(root, "src/scripts"), { recursive: true });

for (const [name, start, end] of styleGroups) {
  const content = styles
    .slice(start - 1, end)
    .filter((block) => !omittedStyleBlocks.has(block.index))
    .map((block) => `/* Source style block ${block.index}${block.attrs.trim() ? ` ${block.attrs.trim()}` : ""} */\n${block.content}`)
    .join("\n\n");
  await fs.writeFile(path.join(root, "src/styles", name), `${content}\n`);
}
for (const [name, start, end] of scriptGroups) {
  const content = scripts
    .slice(start - 1, end)
    .filter((block) => !omittedRuntimeBlocks.has(block.index))
    .map((block) => `/* Source runtime block ${block.index}${block.attrs.trim() ? ` ${block.attrs.trim()}` : ""} */\n${block.content}`)
    .join("\n\n");
  await fs.writeFile(path.join(root, "src/scripts", name), `${content}\n`);
}

const styleLinks = styleGroups.map(([name]) => `    <link rel="stylesheet" href="./styles/${name}" />`).join("\n");
const scriptLinks = scriptGroups.map(([name]) => `    <script src="./scripts/${name}"></script>`).join("\n");
let document = source
  .replace(/\s*<style[^>]*>[\s\S]*?<\/style>/g, "")
  .replace(/\s*<script[^>]*>[\s\S]*?<\/script>/g, "")
  .replace("</head>", `    <!-- build:styles -->\n${styleLinks}\n    <!-- /build:styles -->\n  </head>`)
  .replace("</body>", `    <!-- build:scripts -->\n${scriptLinks}\n    <!-- /build:scripts -->\n  </body>`);
await fs.writeFile(path.join(root, "src/index.html"), document);

console.log(
  `Scanned ${styles.length} style blocks and ${scripts.length} script blocks; ` +
    `wrote ${styles.length - omittedStyleBlocks.size} style blocks and ` +
    `${scripts.length - omittedRuntimeBlocks.size} runtime blocks into src/`,
);
