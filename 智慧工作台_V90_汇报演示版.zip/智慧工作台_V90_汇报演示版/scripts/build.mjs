import fs from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const sourceDir = path.join(root, "src");
let document = await fs.readFile(path.join(sourceDir, "index.html"), "utf8");

assertSingleBuildRegion(document, "styles");
assertSingleBuildRegion(document, "scripts");

const inlinedStyles = await inlineAssets(document, "link", "href", "style");
const inlinedScripts = await inlineAssets(document, "script", "src", "script");
document = document.replace(
  /\s*<!-- build:styles -->[\s\S]*?<!-- \/build:styles -->/,
  () => inlinedStyles,
);
document = document.replace(
  /\s*<!-- build:scripts -->[\s\S]*?<!-- \/build:scripts -->/,
  () => inlinedScripts,
);

const outputDir = path.join(root, "dist");
await fs.mkdir(outputDir, { recursive: true });
const output = path.join(
  outputDir,
  process.env.BUILD_FILE || "智慧工作台_V89_高频场景版.html",
);
if (path.dirname(output) !== outputDir) {
  throw new Error("BUILD_FILE must be a file name inside dist/");
}
const temporaryOutput = `${output}.tmp`;
await fs.writeFile(temporaryOutput, document);
await fs.rename(temporaryOutput, output);
console.log(`Built ${path.relative(root, output)} (${Buffer.byteLength(document).toLocaleString()} bytes)`);

function assertSingleBuildRegion(html, name) {
  const openings = html.match(new RegExp(`<!-- build:${name} -->`, "g")) || [];
  const closings = html.match(new RegExp(`<!-- /build:${name} -->`, "g")) || [];
  if (openings.length !== 1 || closings.length !== 1) {
    throw new Error(`src/index.html must contain exactly one ${name} build region`);
  }
}

async function inlineAssets(html, tag, attribute, outputTag) {
  const pattern = tag === "link"
    ? /<link\s+rel="stylesheet"\s+href="([^"]+)"\s*\/>/g
    : /<script\s+src="([^"]+)"><\/script>/g;
  const assets = [...html.matchAll(pattern)];
  const chunks = [];
  for (const match of assets) {
    const file = path.resolve(sourceDir, match[1]);
    const content = filterSourceBlocks(await fs.readFile(file, "utf8"), outputTag);
    chunks.push(`\n    <${outputTag} data-source="${path.relative(sourceDir, file)}">\n${content.trim()}\n    </${outputTag}>`);
  }
  return chunks.join("");
}

function filterSourceBlocks(content, kind) {
  const variable = kind === "script" ? "OMIT_RUNTIME_BLOCKS" : "OMIT_STYLE_BLOCKS";
  const omitted = new Set(
    (process.env[variable] || "")
      .split(",")
      .map(Number)
      .filter(Number.isFinite),
  );
  if (!omitted.size) return content;
  const marker = kind === "script" ? "runtime" : "style";
  const pattern = new RegExp(
    `(^/\\* Source ${marker} block (\\d+)[^\\n]*\\*/[\\s\\S]*?)(?=^/\\* Source ${marker} block \\d+|(?![\\s\\S]))`,
    "gm",
  );
  return content.replace(pattern, (block, _whole, blockNumber) =>
    omitted.has(Number(blockNumber)) ? "" : block,
  );
}
