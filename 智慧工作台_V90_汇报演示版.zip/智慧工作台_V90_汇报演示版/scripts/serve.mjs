import http from "node:http";
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const port = Number(process.env.PORT || 4173);
const defaultDocument = "/dist/智慧工作台_V88_执行方式改版.html";
const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8" };

http
  .createServer((request, response) => {
    const pathname = decodeURIComponent(new URL(request.url, `http://${request.headers.host}`).pathname);
    const file = path.resolve(root, `.${pathname === "/" ? defaultDocument : pathname}`);
    if (file !== root && !file.startsWith(`${root}${path.sep}`)) {
      response.writeHead(403).end("Forbidden");
      return;
    }
    fs.createReadStream(file)
      .on("error", () => response.writeHead(404).end("Not found"))
      .once("open", () => response.writeHead(200, { "content-type": types[path.extname(file)] || "application/octet-stream" }))
      .pipe(response);
  })
  .listen(port, "127.0.0.1", () => console.log(`Prototype server: http://127.0.0.1:${port}/`));
