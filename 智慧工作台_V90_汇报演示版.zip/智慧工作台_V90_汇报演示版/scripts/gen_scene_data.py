# 生成原型 V89 的 scene-data.js
# 履约：市区公司 L1（10—11 月供应计划）、L2（长缆收货记录）的真实数据，答复原文与分级为构造
# 仓储：市北 C1 库存清单、C2 专业仓、C3 借用物资收集表、C6 以大代小规则、C8 消纳计划表与库龄规定；提报清单行、试验记录、审批条目为构造
# 用法：python3 -I gen_scene_data.py <L1.xls> <L2.xls> <输出 scene-data.js> <C1.xls> <C2.xls> <C3.xls> <C8.xls>
import sys, json, collections as C, re
import xlrd

L1, L2, OUT = sys.argv[1:4]
TODAY = "2026-10-15"


def rows(path):
    s = xlrd.open_workbook(path).sheet_by_index(0)
    h = [c.value for c in s.row(0)]
    return [dict(zip(h, [c.value for c in s.row(i)])) for i in range(1, s.nrows)]


R = rows(L1)
B = rows(L2)

PROV = ["浙江", "河北", "山东", "江苏", "广东", "沈阳", "重庆", "四川", "湖南", "湖北", "河南", "安徽", "上海", "北京", "天津", "福建", "江西", "陕西", "辽宁", "宁波", "保定", "西安", "许继", "特变"]


GENERIC = sorted(["有限责任公司", "股份有限公司", "有限公司", "集团", "股份", "公司", "科技", "电力", "电气", "电缆", "线缆", "电工", "器材", "设备", "开关", "制造", "线路",
                  "互感器", "控制", "系统", "实业", "材料", "工程", "技术", "电子", "智能", "电器", "绝缘子", "金具", "铁塔", "变压器", "防火", "通信", "能源", "机电",
                  "输变电", "装备", "厂", "光电", "成套", "自动化", "电网", "铁附件", "附件", "仪表", "环保", "建设", "发展", "贸易"], key=len, reverse=True)


def mask(n):
    """保留省市前缀和行业通用词，品牌部分换成＊＊"""
    pre = ""
    for p in PROV:
        if n.startswith(p) and p not in ("许继", "特变"):
            pre = n[:len(p) + (1 if n[len(p):len(p) + 1] in ("省", "市") else 0)]
            break
    rest = n[len(pre):]
    tail = ""
    while True:
        for g in GENERIC:
            if rest.endswith(g) and len(rest) > len(g):
                tail = g + tail
                rest = rest[: -len(g)]
                break
        else:
            break
    return pre + "＊＊" + tail


SUP = {}
for r in R:
    SUP.setdefault(r["供应商名称"], mask(r["供应商名称"]))


def day(a, b):
    import datetime as dt
    f = lambda x: dt.date.fromisoformat(x)
    return (f(b) - f(a)).days


def wan(x):
    return round(x / 10000, 2)


def short(desc):
    return desc.replace(",", " ").replace("，", " ")[:28]


# ---------- 履约 ----------
ask = [r for r in R if r["供应计划状态描述"] == "已确认"]
due = [r for r in R if r["供应计划状态描述"] == "待交货"]
over = [r for r in due if r["确定交货期"] < TODAY]

# L2：长缆历史晚到
late = [x["收货记账日期"] - x["项目交货日期"] for x in B if isinstance(x["收货记账日期"], float) and isinstance(x["项目交货日期"], float)]
HIST = {"长缆科技集团股份有限公司": f"今年收货 {len(late)} 行中晚到 {sum(d > 0 for d in late)} 行，最晚 {int(max(late))} 天"}

# 问询清单：按供应商合并
g = C.defaultdict(list)
for r in ask:
    g[r["供应商名称"]].append(r)
ask_rows = []
for n, rs in g.items():
    ask_rows.append({
        "供应商": n, "订单": len({r["采购订单号"] for r in rs}), "行": len(rs),
        "金额": wan(sum(r["总值"] for r in rs)), "最早交货期": min(r["确定交货期"] for r in rs),
        "项目": len({r["项目定义"] for r in rs}), "以往": HIST.get(n, ""),
        "剔除": "",
    })
ask_rows.sort(key=lambda x: (-x["订单"], x["最早交货期"]))
due_sup = {r["供应商名称"] for r in due}

# 订单级汇总（分级、催货共用）
def orders(rs):
    o = C.defaultdict(list)
    for r in rs:
        o[(r["采购订单号"], r["供应商名称"])].append(r)
    out = []
    for (no, sup), ls in o.items():
        out.append({
            "订单": no, "供应商": sup, "行": len(ls), "金额": round(sum(r["总值"] for r in ls), 2),
            "交货期": min(r["确定交货期"] for r in ls), "物料": ls[0]["物料小类描述"], "描述": short(ls[0]["物料描述"]),
            "项目": ls[0]["项目描述"], "状态": ls[0]["供应计划状态描述"], "方式": ls[0]["采购方式描述"],
        })
    return out

O_ask = orders(ask)
O_due = orders(due)
allo = {o["订单"]: o for o in O_ask}
for o in O_due:
    allo[o["订单"]] = o
ALL = list(allo.values())
for o in ALL:
    o["超期"] = max(0, day(o["交货期"], TODAY)) if o["状态"] == "待交货" else 0

# 分级（构造规则，作用在真实订单上）
breach = ["4500953501"]  # 孟邦，全套合同材料已到
od = sorted([o for o in ALL if o["超期"] > 0], key=lambda o: -o["金额"])
tri = [o["订单"] for o in od[:6]]
small_old = sorted([o for o in ALL if o["超期"] >= 7 and o["订单"] not in tri + breach], key=lambda o: (-o["超期"], o["金额"]))
breach += [o["订单"] for o in small_old[:2]]
NOREP_SUP = []
for o in sorted([o for o in ALL if o["状态"] == "已确认"], key=lambda o: o["订单"]):
    if o["供应商"] not in NOREP_SUP and len(NOREP_SUP) < 8 and "长缆" not in o["供应商"] and "孟邦" not in o["供应商"]:
        if sum(1 for x in ALL if x["供应商"] == o["供应商"]) <= 3:
            NOREP_SUP.append(o["供应商"])
# 问询清单里剔除的示例：只有已确认订单、不在未回复名单里的一家
for r in ask_rows:
    if r["供应商"] not in due_sup and r["供应商"] not in NOREP_SUP and 2 <= r["订单"] <= 5:
        r["剔除"] = "已电话沟通（10-09）"
        break
REPLIES_VAGUE = ["正在安排生产，尽量月底前发货。", "原材料到货后排产，具体时间另行通知。", "已在排产，发货时间待确认。", "近期订单较多，会尽快安排。", "图纸还在确认中，确认后排产。"]
REPLIES_OK = ["已排产，图纸已确认，按确定交货期发货。", "货物已备齐，按期发货。", "已发货在途，预计按期到货。", "已到货，待现场验收。"]
level = {}
rep = {}
k = 0
for o in ALL:
    n = o["订单"]
    if o["供应商"] in NOREP_SUP:
        level[n] = "未回复"
        continue
    if n in breach:
        level[n] = "违约处理"
    elif n in tri:
        level[n] = "三级履约协调"
    elif o["超期"] > 0:
        # 超期订单：答复明确（已发货、到货待验收）的正常跟进，其余提级
        level[n] = "提级管控" if (int(n[-2:]) % 5 in (0, 1)) else "正常跟进"
    elif "长缆" in o["供应商"] and o["状态"] == "已确认" and o["交货期"] <= "2026-11-15":
        level[n] = "提级管控"
    else:
        level[n] = "提级管控" if int(n[-3:]) % 23 == 0 else "正常跟进"
for o in ALL:
    o["级别"] = level[o["订单"]]
    lv = o["级别"]
    i = int(o["订单"][-3:])
    if lv == "提级管控":
        o["答复"] = REPLIES_VAGUE[i % len(REPLIES_VAGUE)]
        if o["超期"]:
            o["理由"] = f"已超确定交货期 {o['超期']} 天，答复未给出发货日期"
        elif "长缆" in o["供应商"]:
            o["答复"] = "按计划生产，预计按期。"
            o["理由"] = "以往延期：" + HIST["长缆科技集团股份有限公司"]
        else:
            o["理由"] = "答复含糊，未给出排产和发货日期"
        o["建议"] = "每周跟进一次，要求书面给出排产计划和发货日期"
    elif lv == "正常跟进":
        o["答复"] = REPLIES_OK[3 if o["超期"] else i % 3]
    elif lv == "未回复":
        o["答复"] = ""
for o in ALL:
    if o["级别"] in ("提级管控", "正常跟进") and o["超期"] and o["级别"] == "正常跟进":
        o["答复"] = "已到货，待现场验收。" if int(o["订单"][-1]) % 2 else "已发货在途，预计 2 日内到货。"

# 重点订单的答复与建议（构造）
SPEC = {
    "4500942044": {"答复": "220kV 电缆终端附件（应力锥）到厂延误，预计 10 月 30 日发货，11 月 2 日到货。", "解析": ["排产：本体已完成，附件未到", "图纸：已确认", "预计到货：2026-11-02", "原因：附件到厂延误"],
                   "理由": "已超确定交货期 5 天；用于芯联微电子 220kV 业扩配套，属重点用户工程；订单金额在本月 606 张订单中排第 1",
                   "建议": "申请物资公司三级履约协调，要求供应商 10 月 30 日前发货并书面承诺"},
    "4500953501": {"答复": "", "解析": ["排产：未答复", "图纸：—", "预计到货：未答复", "原因：未答复"],
                   "理由": "6 行已超确定交货期 3—7 天；到期前 10 天经 e物资催货未回复，10 月 13 日电话催货仍未给出交货日期；同一供应商另有 2 张订单超期",
                   "建议": "按合同违约条款处置：约谈并计迟延交货违约金"},
}
for o in ALL:
    if o["订单"] in SPEC:
        o.update(SPEC[o["订单"]])
    elif o["级别"] == "三级履约协调":
        o["答复"] = ["设备已完成出厂试验，待安排运输，预计月底前到货。", "关键元器件缺货，交货期需顺延 3 周。", "生产线检修，预计 11 月上旬发货。", "钢材到厂延误，正在加紧生产。", "已发货一部分，剩余部分 11 月中旬发货。"][int(o["订单"][-1]) % 5]
        o["理由"] = f"已超确定交货期 {o['超期']} 天；订单金额 {wan(o['金额'])} 万元，在超期订单中排前 6"
        o["建议"] = "申请物资公司三级履约协调"
    elif o["级别"] == "违约处理":
        o["答复"] = "暂无法确定交货时间。"
        o["理由"] = f"已超确定交货期 {o['超期']} 天，答复无法确定交货时间"
        o["建议"] = "按合同违约条款处置"
    if o["级别"] in ("三级履约协调", "违约处理", "提级管控") and "解析" not in o:
        a = o.get("答复", "")
        o["解析"] = [
            "排产：" + ("已完成" if "完成" in a or "发货" in a else "进行中" if "排产" in a or "生产" in a else "未说明"),
            "图纸：" + ("确认中" if "图纸" in a else "未说明"),
            "预计到货：" + (re.search(r"(\d+ 月[^，。]*)", a).group(1) if re.search(r"\d+ 月", a) else "未给出日期"),
            "原因：" + (a.split("，")[0] if a else "未答复"),
        ]
for o in ALL:
    o["供应商名"] = SUP[o["供应商"]]

cnt = C.Counter(o["级别"] for o in ALL)
norep_orders = [o for o in ALL if o["级别"] == "未回复"]


def pick(o, keys):
    return {k: o[k] for k in keys if k in o}

KEYS = ["订单", "供应商", "供应商名", "行", "金额", "交货期", "超期", "物料", "描述", "项目", "状态", "方式", "级别", "答复", "解析", "理由", "建议"]
lv_rows = {lv: [pick(o, KEYS) for o in sorted([o for o in ALL if o["级别"] == lv], key=lambda o: (o["订单"] not in SPEC, -o["超期"], -o["金额"]))] for lv in ["违约处理", "三级履约协调", "提级管控"]}
normal_sample = [pick(o, KEYS) for o in sorted([o for o in ALL if o["级别"] == "正常跟进"], key=lambda o: o["交货期"])[:40]]

# 催货：待交货，距确定交货期 10 天触发；同一供应商合并
cuihuo_day = "2026-10-25"
cg = C.defaultdict(list)
for r in due:
    if r["确定交货期"] == cuihuo_day:
        cg[r["供应商名称"]].append(r)
cui_today = [{"供应商": n, "供应商名": SUP[n], "订单": len({r["采购订单号"] for r in rs}), "行": len(rs), "交货期": cuihuo_day, "物料": rs[0]["物料小类描述"], "回复": "已发送，待回复"} for n, rs in cg.items()]
# 未回复再推：10 天前触发的（交货期 10-23、10-24）
cg2 = C.defaultdict(list)
for r in due:
    if r["确定交货期"] in ("2026-10-23", "2026-10-24"):
        cg2[r["供应商名称"]].append(r)
cui_prev = []
for j, (n, rs) in enumerate(sorted(cg2.items(), key=lambda kv: -len(kv[1]))):
    st = ["已回复：按期", "已回复：按期", "未回复，今日自动再推", "已回复：晚 2 天", "已回复：按期"][j % 5]
    cui_prev.append({"供应商": n, "供应商名": SUP[n], "订单": len({r["采购订单号"] for r in rs}), "行": len(rs), "交货期": min(r["确定交货期"] for r in rs), "物料": rs[0]["物料小类描述"], "回复": st})

# 开票提醒：交货次日第 1 次，20 天后第 2 次（30 天截止）
ig = C.defaultdict(list)
for r in R:
    if r["交货日期"] and r["入库物料凭证"]:
        ig[(r["采购订单号"], r["供应商名称"], r["交货日期"])].append(r)
inv = []
for (no, sup, dd), rs in ig.items():
    first = day(dd, TODAY)
    if 1 <= first <= 7:
        inv.append({"订单": no, "供应商": sup, "供应商名": SUP[sup], "入库凭证": rs[0]["入库物料凭证"], "交货日期": dd, "行": len(rs), "金额": round(sum(r["总值"] for r in rs), 2), "提醒": f"{dd[5:]} 次日第 1 次", "状态": "已开票" if int(no[-1]) % 3 == 0 else "未开票"})
    elif 20 <= first <= 24:
        inv.append({"订单": no, "供应商": sup, "供应商名": SUP[sup], "入库凭证": rs[0]["入库物料凭证"], "交货日期": dd, "行": len(rs), "金额": round(sum(r["总值"] for r in rs), 2), "提醒": "第 2 次（交货后 20 天）", "状态": "已开票" if int(no[-1]) % 2 == 0 else "未开票，30 天截止"})
inv.sort(key=lambda x: x["交货日期"], reverse=True)

# 孟邦订单 4500953501 明细与违约金
mb = [r for r in R if r["采购订单号"] == "4500953501"]
mb_rows = []
pen = 0
for r in sorted(mb, key=lambda r: r["采购订单行项目"]):
    d = day(r["确定交货期"], TODAY)
    p = round(r["总值"] * d / 1000, 2)
    pen += p
    mb_rows.append({"行": r["采购订单行项目"], "物料编码": r["物料编码"], "物料": short(r["物料描述"]), "数量": r["计划交货数量"], "金额": r["总值"], "确定交货期": r["确定交货期"], "超期": d, "违约金": p, "项目": r["项目描述"], "供应计划": r["物资供应计划ID"]})
mb_other = sorted({r["采购订单号"] for r in over if "孟邦" in r["供应商名称"] and r["采购订单号"] != "4500953501"})

# 万马 4500942044
wm = [r for r in R if r["采购订单号"] == "4500942044"]
wm_rows = [{"行": r["采购订单行项目"], "物料编码": r["物料编码"], "物料": short(r["物料描述"]), "数量": r["计划交货数量"], "金额": r["总值"]} for r in sorted(wm, key=lambda r: r["采购订单行项目"])]

lvyue = {
    "unit": "市区供电分公司",
    "工厂名称": "国网重庆市电力公司市区供电分公司",
    "实名": True,
    "供应商对照": {k: v for k, v in SUP.items()},
    "问询": {"生成": "2026-10-10 09:00", "确认": "2026-10-10 10:26", "回收": "2026-10-15", "订单": len({r["采购订单号"] for r in ask}), "行": len(ask), "供应商": len(g), "项目": len({r["项目定义"] for r in ask}), "rows": ask_rows},
    "催货": {"订单": len({r["采购订单号"] for r in due}), "行": len(due), "供应商": len({r["供应商名称"] for r in due}),
             "超期订单": len({r["采购订单号"] for r in over}), "超期行": len(over), "超期供应商": len({r["供应商名称"] for r in over}),
             "十天内订单": len({r["采购订单号"] for r in due if TODAY <= r["确定交货期"] <= "2026-10-25"}),
             "今日": cui_today, "前次": cui_prev, "触发日": cuihuo_day},
    "分级": {"订单": len(ALL), "正常跟进": cnt["正常跟进"], "提级管控": cnt["提级管控"], "三级履约协调": cnt["三级履约协调"], "违约处理": cnt["违约处理"],
             "未回复供应商": len(NOREP_SUP), "未回复订单": len(norep_orders), "未回复": NOREP_SUP, "未回复名": [SUP[n] for n in NOREP_SUP], "rows": lv_rows, "正常样例": normal_sample},
    "开票": inv[:40],
    "孟邦": {"订单": "4500953501", "供应商": "河北孟邦电力科技有限公司", "供应商名": SUP["河北孟邦电力科技有限公司"], "rows": mb_rows, "金额": round(sum(r["总值"] for r in mb), 2), "违约金": round(pen, 2),
             "合同号": "SGCQWZ00HTMM2601674", "ECP合同号": "CQ20260000579", "合同名称": "国网重庆公司2026年防火堵料协议库存招标采购防火堵料等采购合同",
             "合同价": 2232586.20, "不含税": 1975740.00, "其他超期订单": mb_other},
    "万马": {"订单": "4500942044", "供应商": "浙江万马股份有限公司", "供应商名": SUP["浙江万马股份有限公司"], "rows": wm_rows, "金额": round(sum(r["总值"] for r in wm), 2), "项目": wm[0]["项目描述"], "交货期": wm[0]["确定交货期"], "方式": wm[0]["采购方式描述"]},
}

# 项目管理人员查询：百士特 10kV 业扩配套（含孟邦防火堵料超期行），订单、状态、交货期取 L1，答复与级别沿用上面的分级
PJ = "18200126001H"
pr = [r for r in R if r["项目定义"] == PJ]
po = C.defaultdict(list)
for r in pr:
    po[r["采购订单号"]].append(r)
pj_rows = []
for no, ls in po.items():
    st = ls[0]["供应计划状态描述"]
    dd = min(r["确定交货期"] for r in ls)
    o = allo.get(no, {})
    pj_rows.append({"订单": no, "供应商": ls[0]["供应商名称"], "供应商名": SUP[ls[0]["供应商名称"]], "物料": ls[0]["物料小类描述"], "行": len(ls),
                    "金额": round(sum(r["总值"] for r in ls), 2), "交货期": dd, "状态": st, "到货": max(r["交货日期"] for r in ls) if st == "已验收" else "",
                    "超期": max(0, day(dd, TODAY)) if st == "待交货" else 0, "级别": o.get("级别", ""), "答复": o.get("答复", "")})
ORD = {"已验收": 0, "待交货": 1, "已确认": 2}
pj_rows.sort(key=lambda x: (ORD[x["状态"]], -x["超期"], x["订单"]))
lvyue["项目"] = {"名称": pr[0]["项目描述"], "编号": PJ, "订单": len(po), "行": len(pr), "金额": round(sum(r["总值"] for r in pr), 2),
                 "状态": dict(C.Counter(x["状态"] for x in pj_rows)), "rows": pj_rows}

# ---------- 仓储（市北 C1—C8 真实数据；提报清单行、试验记录、审批条目为构造） ----------
import email, datetime as _dt
from html.parser import HTMLParser


class _T(HTMLParser):
    def __init__(s):
        super().__init__()
        s.tables, s.row, s.cell, s.span = [], None, None, 1

    def handle_starttag(s, t, a):
        if t == "table":
            s.tables.append([])
        elif t == "tr":
            s.row = []
        elif t in ("td", "th"):
            s.cell, s.span = [], int(dict(a).get("colspan", 1) or 1)

    def handle_endtag(s, t):
        if t in ("td", "th") and s.cell is not None:
            s.row.append(re.sub(r"\s+", " ", "".join(s.cell)).strip())
            s.row += [""] * (s.span - 1)
            s.cell = None
        elif t == "tr" and s.row is not None:
            if s.tables:
                s.tables[-1].append(s.row)
            s.row = None

    def handle_data(s, d):
        if s.cell is not None:
            s.cell.append(d)


def mht(path):
    """Excel 另存的网页格式 .xls：按 sheet 顺序返回行字典列表"""
    msg = email.message_from_bytes(open(path, "rb").read())
    out = []
    for part in msg.walk():
        loc = part.get("Content-Location", "")
        if part.get_content_type() == "text/html" and re.search(r"sheet\d+\.htm", loc):
            raw = part.get_payload(decode=True)
            try:
                txt = raw.decode(part.get_content_charset() or "utf-8")
            except Exception:
                txt = raw.decode("gbk", "ignore")
            p = _T()
            p.feed(txt)
            t = p.tables[0] if p.tables else [[]]
            out.append([dict(zip(t[0], r)) for r in t[1:] if any(x.strip() for x in r)])
    return out


def ymd(x):
    x = str(x).strip().replace("/", "-")
    m = re.match(r"(\d{4})-(\d{1,2})-(\d{1,2})", x)
    return _dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None


T0 = _dt.date.fromisoformat(TODAY)
age_d = lambda d: (T0 - d).days if d else None
C1, C2P, C3P, C8P = sys.argv[4:8]
s1, s2, s3 = mht(C1)[:3]
c8 = mht(C8P)
b2 = xlrd.open_workbook(C2P).sheet_by_index(0)
h2 = [c.value for c in b2.row(0)]
SP = [dict(zip(h2, [c.value for c in b2.row(i)])) for i in range(1, b2.nrows)]
b3 = xlrd.open_workbook(C3P).sheet_by_index(0)
C3 = [[c.value for c in b3.row(i)] for i in range(1, b3.nrows)]


def fnum(x):
    m = re.match(r"\s*([\d.]+)", str(x))
    return float(m.group(1)) if m else 0.0


lk = [r for r in s1 if r["利库/应急"] == "利库"]
yj = [r for r in s1 if r["利库/应急"] == "应急"]
SP_OK = ("备品备件", "工程待用", "工程拆旧")
sp = [r for r in SP if r["物资种类（用途维度）"] in SP_OK]
c3left = [r for r in C3 if fnum(r[4]) > 0]
b3date = {r["批次号"]: ymd(r["最近入库日期"]) for r in s3}
pool_total = len(lk) + len(s2) + len(c3left) + len(sp)

# 库龄：市北消纳计划表页签（寄存+项目暂存 12-2、应急储备 36-6、借用库 12-2、项目代保管 12-3），专业仓备品备件按 3 年
LIM = {"实体库": 12, "应急库": 36, "代保管库": 12, "借用超量": 12, "专业仓": 36}
src_dates = {
    "实体库": [ymd(r["最近入库日期"]) for r in lk],
    "应急库": [ymd(r["最近入库日期"]) for r in yj],
    "代保管库": [ymd(r["最近入库日期"]) for r in s2],
    "借用超量": [b3date.get(str(r[5]).replace(".0", "")) for r in c3left],
    "专业仓": [ymd(r["入库时间"]) for r in sp],
}
BUCK = ["1年以内", "1—2年", "2—3年", "3年以上"]
age_rows = []
for k, ds in src_dates.items():
    v = [0, 0, 0, 0]
    for d in ds:
        a = age_d(d)
        if a is None:
            continue
        v[min(3, a // 365)] += 1
    age_rows.append({"来源": k, "值": v, "无日期": sum(1 for d in ds if d is None)})
over = []
for k, ds in src_dates.items():
    lim = LIM[k] * 30.4
    o = sum(1 for d in ds if d and age_d(d) > lim)
    soon = sum(1 for d in ds if d and lim - 30 < age_d(d) <= lim)
    o1 = sum(1 for d in ds if d and age_d(d) > 365)
    soon1 = sum(1 for d in ds if d and 335 < age_d(d) <= 365)
    over.append({"来源": k, "规定": f"{LIM[k]} 个月", "已超期": o, "三十天内": soon, "按一年已超期": o1, "按一年三十天内": soon1})

strip_names = lambda t: re.sub(r"[，,]?专责[一-龥]{2,3}|张碧胜|龙剑锐|汪子柠|陈卓", "", str(t)).strip("，, ")


def find(rows, **kw):
    for r in rows:
        if all(str(r.get(k, "")) == v for k, v in kw.items()):
            return r
    raise SystemExit(f"找不到 {kw}")


r10 = find(s2, 物料号="500108195", 批次号="3000454913")
r20 = find(s3, 批次号="4000341310")
r30 = find(s2, 批次号="3000349790")
seg = [int(x) for x in re.findall(r"\d+", r20["物料扩展描述1"].split("段长")[-1])]
desc = {}
for r in R:
    desc.setdefault(r["物料编码"], r["物料描述"])
for r in s1 + s3:
    desc.setdefault(r["物料号"], r["物料号描述"])
for r in s2:
    desc.setdefault(r["物料号"], r["物料号描述"])
D300 = "电力电缆,AC10kV,YJV,300,3,22,ZB,无阻水"
LOC = {"QD01": "QD01 国网重庆电力市北仓库", "9602": "9602 应急变电备品备件虚拟库", "9300": "9300 借用物资库"}
ageym = lambda d: f"{age_d(d) // 365} 年 {age_d(d) % 365 // 30} 个月" if age_d(d) >= 365 else f"{max(1, age_d(d) // 30)} 个月"
used = ["500107429", "500108195", "500007396"]
others = []
for r in R:
    c = r["物料编码"]
    if c not in used and c not in [o[0] for o in others] and r["物料大类描述"] in ("装置性材料", "一次设备", "五金材料"):
        others.append((c, r["物料描述"], r["计划交货数量"], r["物料小类描述"]))
    if len(others) >= 31:
        break
UNIT = lambda d: "千米" if "电缆" in d or "导线" in d or "绞线" in d else "台" if any(x in d for x in ("变电站", "环网", "断路器", "开关柜", "变压器")) else "套" if any(x in d for x in ("接头", "终端")) else "只" if any(x in d for x in ("箱", "避雷器", "互感器")) else "件"
RULES = ["同型号不同容量的变压器（箱式变电站、环网箱），容量梯度相邻的", "同型号直径不同的电缆，直径梯度相邻的，大直径代小直径", "架空绝缘导线，铜芯可代铝芯，大直径代小直径", "水泥杆，大代小", "电缆附件，户外终端可代户内终端", "环网箱，用户分界可通用"]
plan_rows = [
    {"行": 10, "物料编码": "500107429", "物料描述": D300, "数量": 0.6, "单位": "千米", "匹配": {"类型": "以大代小", "物料编码": "500108195", "物料描述": r10["物料号描述"], "库存地点": "代保管库 · " + LOC["QD01"], "批次": r10["批次号"], "可用": fnum(r10["实际库存数量"]), "库龄": ageym(ymd(r10["最近入库日期"])), "规则": "本单位规则：" + RULES[1]}},
    {"行": 20, "物料编码": "500108195", "物料描述": r20["物料号描述"], "数量": 0.45, "单位": "千米", "匹配": {"类型": "同物料号（借用库）", "物料编码": "500108195", "物料描述": r20["物料号描述"], "库存地点": LOC["9300"], "批次": r20["批次号"], "可用": fnum(r20["非限制库存数量"]), "库龄": ageym(ymd(r20["最近入库日期"])), "段": seg, "扩展": "段长" + "+".join(map(str, seg)) + "等"}},
    {"行": 30, "物料编码": "500007396", "物料描述": r30["物料号描述"], "数量": 1, "单位": "台", "匹配": {"类型": "同物料号（代保管）", "物料编码": "500007396", "物料描述": r30["物料号描述"], "库存地点": "代保管库 · " + LOC["QD01"], "批次": r30["批次号"], "可用": 1, "库龄": ageym(ymd(r30["最近入库日期"]))}},
]
for j, (c, d_, q, sub) in enumerate(others):
    u = UNIT(d_)
    qty = round(q, 3) if u == "千米" else max(1, int(q) % 40 or 2)
    plan_rows.append({"行": 40 + j * 10, "物料编码": c, "物料描述": d_, "数量": qty, "单位": u, "匹配": None})

# 资源池样例行（个人姓名已去掉）
def prow(src, loc, r, qty_key="非限制库存数量", unit_key="计量单位", date_key="最近入库日期", mark=""):
    d = ymd(r[date_key])
    return [src, loc, r.get("物料号") or r.get("物料编码"), r.get("物料号描述") or r.get("物料名称"), f'{fnum(r[qty_key]):g} {r[unit_key]}', ageym(d) if d else "—", mark]

pool_rows = [
    prow("代保管库", LOC["QD01"], r10, qty_key="实际库存数量", mark="项目代保管，可利库"),
    prow("借用超量", LOC["9300"], r20, mark="段长 " + "+".join(map(str, seg)) + " 等；借出项目：两江战新科技业扩"),
    prow("代保管库", LOC["QD01"], r30, qty_key="实际库存数量", mark="退役再利用"),
]
for r in lk:
    if r["物料号"] == "500007402" and r["批次号"] == "1005317016":
        pool_rows.append(prow("实体库", LOC["QD01"], r, mark=strip_names(r["物料扩展描述1"])))
for r in s2:
    if r["物料号描述"].startswith("环网箱,AC10kV,2,4"):
        pool_rows.append(prow("代保管库", LOC["QD01"], r, qty_key="实际库存数量", mark="退役再利用"))
        break
for want in ("4000322107", "4000330076"):
    r = next(x for x in C3 if str(x[5]).replace(".0", "") == want)
    d = b3date.get(want)
    pool_rows.append(["借用超量", LOC["9300"], str(r[1]).replace(".0", ""), r[2], f"{fnum(r[4]):g}（借出 {fnum(r[3]):g}）", ageym(d) if d else "—", "需求部门 10 月填报未用完"])
for r in sorted(sp, key=lambda x: str(x["入库时间"]))[:2] + [x for x in sp if x["专业仓名称"] == "江北中心营销仓"][:1]:
    pool_rows.append(prow("专业仓", r["专业仓名称"], r, qty_key="库存", unit_key="计量单位", date_key="入库时间", mark=r["物资种类（用途维度）"]))
for r in yj[:1]:
    pool_rows.append(prow("应急库", LOC.get(r["库存地"], r["库存地"]), r, mark="抢修储备，只进应急看板"))

# 消纳计划：市北消纳计划表（借用库、计量调拨中转、项目代保管、跨单位调拨中转）
C8LIM = {4: ("跨单位调拨中转库", 6), 5: ("计量调拨中转", 6), 8: ("借用库", 12), 9: ("项目代保管", 12)}
xn = []
for i, (cat, lim) in C8LIM.items():
    for r in c8[i]:
        d = ymd(r["最近入库日期"])
        due_ = _dt.date(d.year + (d.month - 1 + lim) // 12, (d.month - 1 + lim) % 12 + 1, min(d.day, 28))
        xn.append({"部门": r["责任部门"], "类别": cat, "规定": f"{lim} 个月", "库存地": r["库存地"], "物料编码": r["物料号"], "物料": r["物料号描述"], "数量": f'{fnum(r["非限制库存数量"]):g} {r["计量单位"]}', "金额": fnum(r["总价值"]), "入库": str(d), "到期": str(due_), "超期": (T0 - due_).days})
dept = sorted({x["部门"] for x in xn})
xn_over = [x for x in xn if x["超期"] > 0]

# 应急备查：应急库按物资大类汇总
yj_g = C.Counter(r["物料号描述"].split(",")[0] for r in yj)
yj_rows = [[r["物料号描述"], f'{fnum(r["非限制库存数量"]):g} {r["计量单位"]}', LOC.get(r["库存地"], r["库存地"])] for r in yj[:8]]
# 已超期样例：按超出规定的天数排
ov = []
for k, rs, dk, qk, uk, nk in [("代保管库", s2, "最近入库日期", "实际库存数量", "计量单位", "物料号描述"), ("专业仓", sp, "入库时间", "库存", "计量单位", "物料名称"), ("实体库", lk, "最近入库日期", "非限制库存数量", "计量单位", "物料号描述")]:
    for r in rs:
        d = ymd(r[dk])
        if d and age_d(d) > LIM[k] * 30.4:
            ov.append((age_d(d) - LIM[k] * 30.4, [k, r[nk], f"{fnum(r[qk]):g} {r[uk]}", ageym(d)]))
ov_rows = [x[1] for x in sorted(ov, key=lambda x: -x[0])[:3]] + [x[1] for x in sorted([o for o in ov if o[1][0] == "代保管库"], key=lambda x: -x[0])[:2]]

cangchu = {
    "unit": "市北供电分公司",
    "项目": "10kV观音桥片区配网改造",
    "清单": "观音桥片区配网改造设计物资清单.xlsx",
    "月份": "2026年11月",
    "采购申请": "3806512870",
    "工厂": "0500",
    "工厂名称": "国网重庆市电力公司市北供电分公司",
    "plan": plan_rows,
    "rules": RULES,
    "reasons": [
        {"k": "spec", "name": "规格不匹配"},
        {"k": "param", "name": "参数不匹配"},
        {"k": "install", "name": "安装不匹配", "num": "管孔或桥架允许的最大电缆外径（毫米）"},
        {"k": "broken", "name": "库存有损坏"},
        {"k": "price", "name": "价格超预算"},
        {"k": "seg", "name": "盘长/段长不匹配", "num": "施工需要的单段长度（米）"},
        {"k": "far", "name": "利库运输距离远", "num": "库存地点到施工现场的距离（公里）"},
        {"k": "lent", "name": "已借用物资不能利库"},
        {"k": "quota", "name": "业扩定额物资，暂不能使用"},
        {"k": "refill", "name": "库存不满足寄存定额，需补库"},
    ],
    "试验记录": {"名称": "10kV变压器退役试验记录（批次 3000349790）", "日期": "2025-07-18", "结论": "绕组绝缘电阻低于交接试验标准；绝缘油色谱乙炔含量超过注意值", "建议": "返厂检修后方可再利用"},
    "erp直提": {"采购申请": "3806513044", "行": "00010", "物料编码": "500107429", "物料描述": D300, "数量": 0.3, "单位": "千米", "项目": "10kV鹞子丘线新建", "提报": "10-15 09:12", "部门": "运检部"},
    "审批": {"核验通过": 9, "专责认定": 4, "直提": 1},
    "pool": {"total": pool_total, "利库": len(lk), "应急": len(yj), "代保管": len(s2), "借用记录": len(s3), "借用填报": len(C3), "借用超量": len(c3left),
             "专业仓全部": len(SP), "专业仓": len(sp), "专业仓剔除": len(SP) - len(sp), "rows": pool_rows},
    "库龄规定": "实体库（寄存、项目暂存）12 个月，借用库 12 个月，项目代保管 12 个月，应急储备 36 个月，专业仓备品备件 3 年",
    "库龄出处": "市北消纳计划表；国网重庆市电力公司物资部《实物资源规范管理工作方案》",
    "库龄": {"段": BUCK, "rows": age_rows},
    "超期": over,
    "消纳": {"rows": xn, "部门": dept, "超期": len(xn_over), "总": len(xn)},
    "应急": {"count": len(yj), "groups": yj_g.most_common(6), "rows": yj_rows},
    "超期样例": ov_rows,
    "借用填报": [{"批次": str(r[5]).replace(".0", ""), "物料编码": str(r[1]).replace(".0", ""), "物料": r[2], "借出": fnum(r[3]), "剩余": str(r[4])} for r in C3 if str(r[1]).strip() and str(r[5]).strip()][:3],
}

data = {"today": TODAY, "lvyue": lvyue, "cangchu": cangchu}
js = "/* 场景数据。由 gen_scene_data.py 生成，不手改。\n   履约：市区供电公司 10—11 月供应计划（L1）、长缆收货记录（L2）为真实导出；答复原文、分级和跨单位订单为构造。\n   仓储：市北 C1 库存、C2 专业仓、C3 借用收集表、C6 以大代小规则、C8 消纳计划与库龄为真实导出；提报清单行、试验记录、审批条目为构造。\n   供应商名称：实名为 false 时显示打码名称，确认后改为 true。 */\nwindow.SCENE_DATA = " + json.dumps(data, ensure_ascii=False, indent=1) + ";\n"
open(OUT, "w", encoding="utf-8").write(js)
print("ok", cnt, "orders", len(ALL), "norep sup", len(NOREP_SUP), "inv", len(inv), "pen", round(pen, 2), "mb_other", mb_other, "tri", tri, "breach", breach)
print("cui_today", cui_today, "cui_prev", len(cui_prev))
