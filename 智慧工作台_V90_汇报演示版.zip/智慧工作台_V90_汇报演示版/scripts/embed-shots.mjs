/* 把 参考图/照片 下的源端截图转成 data URI，写入 src/scripts/exec-shots.js。
   截图更新后运行：node scripts/embed-shots.mjs，再 npm run build。 */
import fs from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const photoDir = path.resolve(root, "..", "参考图", "照片");
const shots = {
  zmm20188Sel: "ERP/CC图片20260915155142.jpg",
  zmm20188List: "ERP/CC图片20260915155146.jpg",
  zmm20188List8: "ERP/CC图片20260915155150.jpg",
  payAudit: "运营平台/CC图片20260915154948.jpg",
  wmsOut: "实物资源一体化/办理页面.jpg",
};

const lines = [];
for (const [key, file] of Object.entries(shots)) {
  const data = await fs.readFile(path.join(photoDir, file));
  lines.push(`  ${key}: "data:image/jpeg;base64,${data.toString("base64")}",`);
}
const output = `/* 源端系统截图（由 scripts/embed-shots.mjs 生成，勿手改） */\nwindow.EXEC_SHOTS = {\n${lines.join("\n")}\n};\n`;
await fs.writeFile(path.join(root, "src", "scripts", "exec-shots.js"), output);
console.log(`Embedded ${lines.length} screenshots (${Buffer.byteLength(output).toLocaleString()} bytes)`);
