import { chromium } from 'playwright';
import fs from 'fs'; import path from 'path';
const dir = process.argv[2];
const b = await chromium.launch({ executablePath: '/usr/bin/google-chrome' }); const p = await b.newPage({ deviceScaleFactor: 2 });
for (const f of fs.readdirSync(dir).filter(x => x.endsWith('.svg'))) {
  const s = fs.readFileSync(path.join(dir, f), 'utf8');
  const w = +s.match(/width='(\d+)'/)[1], h = +s.match(/height='(\d+)'/)[1];
  await p.setViewportSize({ width: w, height: h });
  await p.setContent(`<html><body style="margin:0">${s}</body></html>`);
  await p.screenshot({ path: path.join(dir, f.replace('.svg', '.png')), clip: { x: 0, y: 0, width: w, height: h } });
}
await b.close(); console.log('ok');
