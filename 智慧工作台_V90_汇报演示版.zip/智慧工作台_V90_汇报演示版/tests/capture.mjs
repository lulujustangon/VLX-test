import { chromium } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

const target = path.resolve(process.argv[2]);
const output = path.resolve(process.argv[3] || "artifacts/capture");
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({
  viewport: { width: 1440, height: 900 },
  deviceScaleFactor: 1,
  locale: "zh-CN",
  colorScheme: "light",
  reducedMotion: "reduce",
});

await context.addInitScript(() => {
  localStorage.clear();
  const fixedNow = new Date("2026-08-12T09:30:00+08:00").valueOf();
  const NativeDate = Date;
  class FixedDate extends NativeDate {
    constructor(...args) {
      super(...(args.length ? args : [fixedNow]));
    }
    static now() {
      return fixedNow;
    }
  }
  Object.defineProperty(window, "Date", { value: FixedDate });
});

const page = await context.newPage();
page.setDefaultTimeout(4_000);
const errors = [];
page.on("pageerror", (error) => errors.push(`pageerror: ${error.message}`));
page.on("console", (message) => {
  if (message.type() === "error") errors.push(`console: ${message.text()}`);
});

await fs.mkdir(output, { recursive: true });
await page.goto(pathToFileURL(target).href, { waitUntil: "load" });
await page.waitForTimeout(1300);
await freezePrototypeTimers(page);

async function settle() {
  await page.waitForTimeout(240);
  await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
}

async function shot(name) {
  await settle();
  await page.screenshot({ path: path.join(output, `${name}.png`), animations: "disabled" });
}

async function view(name) {
  await page.evaluate((nextView) => window.setView?.(nextView), name);
  await settle();
}

await shot("01-home-notice");
await page.locator("[data-approvedui-notice-close]").last().click().catch(() => {});
await shot("02-home");

await view("chats");
await shot("03-chats");

await view("agents");
await shot("04-agents");
await page.locator("[data-agentcenter-mode=workshop]").click();
await shot("05-abilities");
await page.locator("[data-agentcenter-compose]").click();
await shot("06-compose-empty");
await page.locator("[data-composer-example]").first().click();
await page.locator("[data-composer-send]").click();
await shot("07-compose-report");

await view("knowledge");
await shot("08-knowledge");

await view("scheduled");
await shot("09-scheduled");

await view("emergency");
await shot("10-emergency-center");
const task = page.locator("[data-emergency-thread=E001]").first();
if (await task.count()) {
  await task.click();
  await shot("11-emergency-task");
}

const diagnostics = await page.evaluate(() => ({
  title: document.title,
  stateView: window.state?.view,
  views: [...document.querySelectorAll(".view")].map((node) => ({
    id: node.id,
    active: node.classList.contains("active"),
  })),
  styleSheets: document.styleSheets.length,
  scripts: document.scripts.length,
  elements: document.getElementsByTagName("*").length,
}));

await fs.writeFile(
  path.join(output, "diagnostics.json"),
  `${JSON.stringify({ target, diagnostics, errors }, null, 2)}\n`,
);
await browser.close();

if (errors.length) {
  console.error(errors.join("\n"));
  process.exitCode = 1;
}

async function freezePrototypeTimers(targetPage) {
  await targetPage.evaluate(() => {
    try { clearTimeout(livebriefRefreshTimer); } catch {}
  });
}
