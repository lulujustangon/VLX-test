import fs from "node:fs/promises";
import path from "node:path";
import pixelmatch from "pixelmatch";
import { PNG } from "pngjs";

const baselineDir = path.resolve(process.argv[2] || "artifacts/baseline");
const candidateDir = path.resolve(process.argv[3] || "artifacts/candidate");
const diffDir = path.resolve(process.argv[4] || "artifacts/diff");
await fs.mkdir(diffDir, { recursive: true });

const files = (await fs.readdir(baselineDir)).filter((name) => name.endsWith(".png"));
let failed = false;
const results = [];

for (const file of files) {
  const baseline = PNG.sync.read(await fs.readFile(path.join(baselineDir, file)));
  const candidate = PNG.sync.read(await fs.readFile(path.join(candidateDir, file)));
  if (baseline.width !== candidate.width || baseline.height !== candidate.height) {
    failed = true;
    results.push({ file, error: "viewport mismatch" });
    continue;
  }
  const diff = new PNG({ width: baseline.width, height: baseline.height });
  let rawPixels = 0;
  let maxChannelDelta = 0;
  for (let offset = 0; offset < baseline.data.length; offset += 4) {
    let changed = false;
    for (let channel = 0; channel < 4; channel += 1) {
      const delta = Math.abs(baseline.data[offset + channel] - candidate.data[offset + channel]);
      if (delta) changed = true;
      maxChannelDelta = Math.max(maxChannelDelta, delta);
    }
    if (changed) rawPixels += 1;
  }
  const perceptualPixels = pixelmatch(
    baseline.data,
    candidate.data,
    diff.data,
    baseline.width,
    baseline.height,
    { threshold: 0.05 },
  );
  if (perceptualPixels) await fs.writeFile(path.join(diffDir, file), PNG.sync.write(diff));
  if (perceptualPixels > 0) failed = true;
  results.push({ file, rawPixels, maxChannelDelta, perceptualPixels });
}

console.table(results);
if (failed) process.exitCode = 1;
