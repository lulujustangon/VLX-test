import { chromium } from "playwright";
import path from "node:path";
const [out, wh, acts] = process.argv.slice(2);
const [W, H] = wh.split("x").map(Number);
const b = await chromium.launch({ executablePath: "/usr/bin/google-chrome", args: ["--no-sandbox"] });
const p = await b.newPage({ viewport: { width: W, height: H } });
const errs = []; p.on("pageerror", (e) => errs.push(e.message));
await p.goto(`file://${path.resolve("dist/智慧工作台_V90_汇报演示版.html")}`);
await p.waitForTimeout(1500);
for (const a of JSON.parse(acts)) {
  if (a.click) await p.locator(a.click).first().click();
  if (a.eval) console.log(await p.evaluate(a.eval));
  await p.waitForTimeout(a.wait || 700);
  if (a.shot) await p.screenshot({ path: path.join(out, a.shot + ".png") });
}
console.log("errors:", errs.join(" | ") || "无");
await b.close();
