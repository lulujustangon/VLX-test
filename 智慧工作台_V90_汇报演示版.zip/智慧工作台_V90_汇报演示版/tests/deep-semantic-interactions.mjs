import { chromium } from "playwright";
import path from "node:path";
import { pathToFileURL } from "node:url";

const target = path.resolve(process.argv[2] || "dist/智慧工作台_综合高保真交互原型_V85_重构版.html");
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: "zh-CN" });
await context.addInitScript(() => localStorage.clear());
const page = await context.newPage();
page.setDefaultTimeout(5_000);
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));

await page.goto(pathToFileURL(target).href, { waitUntil: "load" });
await page.waitForTimeout(1_200);
await page.evaluate(() => {
  window.setView?.("workbench");
  state.wbTab = "plans";
  window.renderWorkbench?.();
});

const planCards = page.locator("[data-plan-card-id]");
if ((await planCards.count()) < 2) throw new Error("Plan cards were not rendered");
await page.evaluate(() => document.querySelector("[data-plan-card-id]")?.click());
if (!(await page.locator("#planDetailDrawer").isVisible())) throw new Error("Plan detail drawer did not open");
if (!(await page.locator("#planDetailTitle").textContent())?.trim()) throw new Error("Plan detail title is empty");
await page.evaluate(() => window.closeOverlay?.("planDetailDrawer"));

await page.evaluate(() => {
  state.task.finalSolutionGenerated = true;
  state.task.selectedDecisionPlan = "time";
  state.wbTab = "plans";
  window.renderWorkbench?.();
});
const finalReport = page.locator("[data-final-report-id]");
if ((await finalReport.count()) !== 1) throw new Error("Final report action was not rendered");
await page.evaluate(() => document.querySelector("[data-final-report-id]")?.click());
if (!(await page.locator("#planDetailDrawer").isVisible())) throw new Error("Final report drawer did not open");
await page.evaluate(() => window.closeOverlay?.("planDetailDrawer"));
await page.evaluate(() => document.querySelector("[data-enter-execution]")?.click());
if ((await page.evaluate(() => state.wbTab)) !== "execution") throw new Error("Execution handoff did not switch tabs");

await page.evaluate(() => window.setView?.("agents"));
await page.locator('[data-agentcenter-mode="workshop"]').click();
await assertWorkshopFilters();

await page.evaluate(() => window.setView?.("emergency"));
await page.locator('[data-emergency-thread="E001"]').first().click();
await assertEmergencyExecutionCard();

await browser.close();
if (errors.length) throw new Error(`Browser errors: ${errors.join(" | ")}`);
console.log("Deep semantic interactions passed: plan details, execution handoff, workshop filters and emergency orchestration.");

async function assertWorkshopFilters() {
  const expectedCounts = { 专业能力: 9, 通用能力: 4, 复用能力: 8 };
  const alignment = await page.locator(".agentcenter-cats").evaluate((nav) => {
    const labels = [...nav.querySelectorAll(":scope > button > span")].map((node) => node.getBoundingClientRect().left);
    const counts = [...nav.querySelectorAll(":scope > button[data-agentcenter-cat] > small:not(:empty)")].map((node) => node.getBoundingClientRect().right);
    return { labelSpread: Math.max(...labels) - Math.min(...labels), countSpread: Math.max(...counts) - Math.min(...counts) };
  });
  if (alignment.labelSpread > 0.6 || alignment.countSpread > 0.6) {
    throw new Error(`Workshop navigation is not aligned: ${JSON.stringify(alignment)}`);
  }

  for (const [category, count] of Object.entries(expectedCounts)) {
    const button = page.locator(`[data-agentcenter-cat="${category}"]`);
    if ((await button.locator("small").textContent())?.trim() !== String(count)) throw new Error(`${category} count is not ${count}`);
    await button.click();
    if ((await page.locator(".agentcenter-cap-row").count()) !== count) throw new Error(`${category} did not filter to ${count} capabilities`);
    const types = await page.locator(".agentcenter-cap-row .agentcenter-type").allTextContents();
    if (types.some((type) => type.trim() !== category)) throw new Error(`${category} filter contains another capability type`);
  }

  await page.locator('[data-agentcenter-cat="全部能力"]').click();
  if ((await page.locator(".agentcenter-cap-row").count()) !== 21) throw new Error("原子能力 did not restore all 21 capabilities");
  await page.locator("[data-agentcenter-compose]").click();
  if (!(await page.locator(".composer-compose").isVisible())) throw new Error("能力编排 entry is not clickable");
}

async function assertEmergencyExecutionCard() {
  const expected = [
    "解析应急需求清单",
    "查询本单位库存",
    "查询跨单位库存",
    "查询协议库存",
    "查询应急抢单资源",
    "查询在途资源",
    "查询在建订单资源",
    "查询供应商现货及交期",
    "计算资源缺口",
    "比较资源方案",
    "生成寻源方案",
    "发送资源确认",
    "汇总资源确认",
    "调整寻源方案",
    "生成寻源报告",
    "回写寻源结果",
  ];
  const actual = await page.locator(".approvedui-exec-card .approvedui-cap-chip").allTextContents();
  if (JSON.stringify(actual) !== JSON.stringify(expected)) throw new Error(`Emergency atomic capabilities changed: ${JSON.stringify(actual)}`);
  if (!(await page.locator(".approvedui-replay-stream").isVisible())) throw new Error("Emergency execution replay stream is missing");
  if (!(await page.locator(".approvedui-replay-stage").isVisible())) throw new Error("Emergency stage information is missing before execution chain");
  const firstChainNode = await page.locator(".approvedui-replay-event").first().boundingBox();
  const stageBox = await page.locator(".approvedui-replay-stage").boundingBox();
  if (!firstChainNode || !stageBox || stageBox.y >= firstChainNode.y) throw new Error("Emergency stage information is not rendered before execution chain");
  if ((await page.locator(".approvedui-replay-event").count()) !== expected.length) throw new Error("Emergency replay does not contain one event per atomic capability");
  if (!(await page.locator(".approvedui-exec-content").isVisible())) throw new Error("Emergency orchestration is not expanded on entry");
  await page.locator('.approvedui-replay-event[data-approvedui-replay-event="0"] > summary').click();
  await page.waitForFunction(() => state.emergencyCanvasOpen && state.emergencyCanvasTab === "materials");
  await page.locator('.approvedui-replay-event[data-approvedui-replay-event="9"] > summary').click();
  await page.waitForFunction(() => state.emergencyCanvasOpen && state.emergencyCanvasTab === "plans");

  await page.locator("[data-approvedui-toggle-execution]").click();
  if (await page.locator(".approvedui-exec-content").isVisible()) throw new Error("Emergency orchestration did not collapse");
  if (!(await page.locator(".approvedui-replay-stage").isVisible())) throw new Error("Stage information disappeared when execution collapsed");
  if (!/展开/.test((await page.locator("[data-approvedui-toggle-execution]").textContent()) || "")) throw new Error("Collapsed emergency card has no expand action");

  await page.locator('[data-emergency-thread="E003"]').first().click();
  if (!(await page.locator(".approvedui-exec-content").isVisible())) throw new Error("Another emergency task did not open expanded by default");
  await page.locator('[data-emergency-thread="E001"]').first().click();
  if (!(await page.locator(".approvedui-exec-content").isVisible())) throw new Error("Re-entered emergency task did not reset to expanded");
}
