/* 从今日关注点进事项详情，再点「去办理」进入任务线程。用法：node tests/home-path.mjs <截图目录> [浏览器路径] */
import { chromium } from "playwright";
import path from "node:path";
const out = process.argv[2] || "shots";
const exe = process.argv[3];
const b = await chromium.launch(exe ? { executablePath: exe, args: ["--no-sandbox"] } : {});
const p = await b.newPage({ viewport: { width: 1600, height: 900 } });
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
await p.goto(`file://${path.resolve("dist/智慧工作台_V89_高频场景版.html")}`);
await p.waitForTimeout(1200);
for (const [who, cat, id] of [["D", "需求计划提报", "W2"], ["F", "问询答复", "L2"]]) {
  await p.click("#emUserBtn");
  await p.click(`[data-em-who="${who}"]`);
  await p.waitForTimeout(500);
  await p.click('[data-homebrief-root="focus"]');
  await p.waitForTimeout(300);
  await p.click(`[data-homebrief-category="${cat}"]`);
  await p.waitForTimeout(300);
  const task = p.locator(`[data-homebrief-task="${id}"]`);
  if (await task.count()) await task.first().click();
  await p.waitForTimeout(300);
  await p.screenshot({ path: path.join(out, `home-${id}-detail.png`) });
  await p.click('[data-homebrief-action="dialog"]');
  await p.waitForTimeout(800);
  const open = await p.evaluate(() => document.querySelector("#emThreadHead h3")?.textContent || "");
  console.log(who, id, "thread:", open);
  await p.click('#emThread [data-em-act="close"]');
  await p.waitForTimeout(300);
}
console.log(errs.length ? errs.join("\n") : "no page errors");
await b.close();
