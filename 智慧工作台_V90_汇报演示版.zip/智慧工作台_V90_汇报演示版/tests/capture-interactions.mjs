import { chromium } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

const target = path.resolve(process.argv[2]);
const output = path.resolve(process.argv[3] || "artifacts/interactions");
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({
  viewport: { width: 1440, height: 900 },
  deviceScaleFactor: 1,
  locale: "zh-CN",
  colorScheme: "light",
  reducedMotion: "reduce",
});
await context.addInitScript(() => {
  localStorage.clear();
  const fixedNow = new Date("2026-08-12T09:30:00+08:00").valueOf();
  const NativeDate = Date;
  class FixedDate extends NativeDate {
    constructor(...args) { super(...(args.length ? args : [fixedNow])); }
    static now() { return fixedNow; }
  }
  Object.defineProperty(window, "Date", { value: FixedDate });
});

const page = await context.newPage();
page.setDefaultTimeout(4_000);
const errors = [];
page.on("pageerror", (error) => errors.push(`pageerror: ${error.message}`));
page.on("console", (message) => {
  if (message.type() === "error") errors.push(`console: ${message.text()}`);
});
await fs.mkdir(output, { recursive: true });
await page.goto(pathToFileURL(target).href, { waitUntil: "load" });
await page.waitForTimeout(1300);
await freezePrototypeTimers(page);

async function settle() {
  await page.waitForTimeout(220);
  await page.evaluate(() => new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve))));
}
async function shot(name) {
  await settle();
  await page.screenshot({ path: path.join(output, `${name}.png`), animations: "disabled" });
}
async function view(name) {
  await page.evaluate((nextView) => window.setView?.(nextView), name);
  await settle();
}

await page.locator("[data-approvedui-notice-close]").last().click().catch(() => {});
await page.locator(".homebrief-root-card[data-homebrief-root=focus]").click();
await shot("12-home-focus");
await page.locator(".homebrief-category-card").first().click();
await shot("13-home-category");
if (await page.locator(".homebrief-task-row").count()) {
  await page.locator(".homebrief-task-row").first().click();
}
if (await page.locator(".homebrief-detail").count()) {
  await shot("14-home-task");
  await page.locator("[data-homebrief-action=detail]").click();
  await shot("15-home-action-toast");
  await page.waitForTimeout(2_000);
}

await view("chat");
const recapOpened = await page.evaluate(() => {
  if (typeof window.processreviewOpenRecap !== "function") return false;
  window.processreviewOpenRecap();
  return true;
});
if (recapOpened) {
  await shot("16-recap-modal");
  await page.locator("#processreviewRecapOverlay").click({ position: { x: 5, y: 5 } });
}

await view("agents");
await page.locator("[data-agentcenter-detail]").first().click();
await shot("17-agent-detail");
await page.locator("[data-agentcenter-back]").click();
await page.locator("[data-agentcenter-mode=workshop]").click();
await page.locator("[data-agentcenter-cap]").first().click();
await shot("18-ability-drawer");
await page.locator("[data-agentcenter-close]").first().click();

await view("knowledge");
await page.locator("[data-knowledge-tab=library]").click();
await shot("19-knowledge-library");
await page.locator("[data-knowledge-tab=graph]").click();
await shot("20-knowledge-graph");

await view("scheduled");
await page.locator("#newScheduleBtn").click();
await shot("21-schedule-modal");
await page.evaluate(() => window.closeOverlay?.("scheduleModal"));

await view("emergency");
await page.locator("[data-emergency-thread=E001]").first().click();
await page.evaluate(() => {
  state.emergencyCanvasOpen = true;
  state.emergencyCanvasTab = "plans";
  state.collaborationTab = "plans";
  window.emergencyRender?.();
});
await shot("22-emergency-plan-canvas");
const materialTab = page.locator('[data-emergency-canvas-tab="materials"]');
if (await materialTab.count()) {
  await materialTab.click();
  await shot("23-emergency-materials");
}

await page.locator("#collapseSidebar").click();
await shot("24-sidebar-collapsed");

await fs.writeFile(path.join(output, "errors.json"), `${JSON.stringify(errors, null, 2)}\n`);
await browser.close();
if (errors.length) {
  console.error(errors.join("\n"));
  process.exitCode = 1;
}

async function freezePrototypeTimers(targetPage) {
  await targetPage.evaluate(() => {
    try { clearTimeout(livebriefRefreshTimer); } catch {}
  });
}
