import { chromium } from "playwright";
import path from "node:path";
import { pathToFileURL } from "node:url";

const target = path.resolve(process.argv[2] || "dist/智慧工作台_综合高保真交互原型_V85_重构版.html");
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, locale: "zh-CN" });
await context.addInitScript(() => localStorage.clear());
const page = await context.newPage();
page.setDefaultTimeout(5_000);
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));

await page.goto(pathToFileURL(target).href, { waitUntil: "load" });
await page.waitForTimeout(1_200);

await page.locator("#recentList [data-recent]").nth(2).click();
await assertQuestionRail("main", "#chatThread .message.user", 1);
await clickLastAnchor("main");
await assertRailAfterViewRoundTrip("main", "#chatThread .message.user", "chats");

await page.evaluate(() => window.setView?.("agents"));
await page.locator('[data-agent-chat="1"]').first().click();
await page.locator(".agent-prompt-chip").first().click();
await assertQuestionRail("agent", "#agentChatStream .agent-chat-message.user", 1);
await assertRailAfterViewRoundTrip("agent", "#agentChatStream .agent-chat-message.user", "knowledge", "agentchat");

await page.evaluate(() => window.setView?.("agents"));
await page.locator("[data-agentcenter-mode=workshop]").click();
await page.locator("[data-agentcenter-compose]").click();
await page.locator("[data-composer-example]").first().click();
await page.locator("[data-composer-send]").click();
await assertQuestionRail("compose", ".composer-chat-scroll .composer-msg.user", 1);
await assertRailAfterViewRoundTrip("compose", ".composer-chat-scroll .composer-msg.user", "scheduled", "agents");

await page.evaluate(() => window.setView?.("emergency"));
await page.locator("[data-emergency-thread=E001]").first().click();
await assertQuestionRail("emergency", ".emergency-thread-body .emergency-message.user", 5);
await assertEmergencyExampleQuestions();
await assertEmergencyExampleActions();
await page.locator('.emergency-suggestions [data-emergency-suggest="前两项采用AI方案，第三项保留原系统方案。"]').click();
await assertQuestionRail("emergency", ".emergency-thread-body .emergency-message.user", 6);
const decisions = await page.evaluate(() => ({
  first: state.collaborationDecisions.M01,
  second: state.collaborationDecisions.M03,
  third: state.collaborationDecisions.M04,
}));
if (JSON.stringify(decisions) !== JSON.stringify({ first: "ai", second: "ai", third: "original" })) {
  throw new Error(`Batch confirmation example did not execute: ${JSON.stringify(decisions)}`);
}
await clickLastAnchor("emergency");
await assertRailAfterViewRoundTrip("emergency", ".emergency-thread-body .emergency-message.user", "scheduled", "emergency");

await browser.close();
if (errors.length) throw new Error(`Browser errors: ${errors.join(" | ")}`);
console.log("User-question locators passed: main, agent, compose and emergency conversations.");

async function assertRailAfterViewRoundTrip(key, questionSelector, awayView, returnView = "chat") {
  for (let cycle = 0; cycle < 2; cycle += 1) {
    await page.evaluate((view) => window.setView?.(view), awayView);
    await page.waitForTimeout(420);
    await assertNoVisibleQuestionRails(awayView);
    await page.evaluate((view) => window.setView?.(view), returnView);
    await assertQuestionRail(key, questionSelector, 1);
  }
}

async function assertNoVisibleQuestionRails(view) {
  const visible = await page.locator(".approvedui-thread-rail").evaluateAll((nodes) =>
    nodes.filter((node) => {
      const style = getComputedStyle(node);
      return style.display !== "none" && style.visibility !== "hidden" && node.getClientRects().length > 0;
    }).map((node) => node.dataset.approveduiRail),
  );
  if (visible.length) throw new Error(`${view} is not a conversation view but shows question locators: ${visible.join(", ")}`);
}

async function assertQuestionRail(key, questionSelector, minimumQuestions) {
  await page.waitForFunction(
    ({ railKey, selector, minimum }) => {
      const rail = document.querySelector(`.approvedui-thread-rail[data-approvedui-rail="${railKey}"]`);
      const questions = document.querySelectorAll(selector).length;
      return questions >= minimum && rail?.classList.contains("has-items") && rail.querySelectorAll(".approvedui-thread-rail-mark").length === questions;
    },
    { railKey: key, selector: questionSelector, minimum: minimumQuestions },
  );
  const rail = page.locator(`.approvedui-thread-rail[data-approvedui-rail="${key}"]`);
  if (!(await rail.locator(".approvedui-thread-rail-mark").first().isVisible())) throw new Error(`${key} conversation locator marker is not visible`);
  const visual = await rail.evaluate((node) => {
    const mark = node.querySelector(".approvedui-thread-rail-mark");
    const rect = mark?.getBoundingClientRect();
    const marker = mark ? getComputedStyle(mark, "::after") : null;
    return { width: rect?.width || 0, height: rect?.height || 0, markerWidth: marker?.width, markerColor: marker?.backgroundColor };
  });
  if (visual.width < 10 || visual.height < 10 || visual.markerWidth === "0px" || visual.markerColor === "rgba(0, 0, 0, 0)") {
    throw new Error(`${key} conversation locator has no visible marker: ${JSON.stringify(visual)}`);
  }
}

async function assertEmergencyExampleQuestions() {
  const expected = [
    "这条任务现在到哪一步了？",
    "为什么还有3项需要我确认？",
    "长寿公司具体回复了什么？",
    "原系统方案和AI方案差在哪里？",
    "采用长寿资源有什么风险？",
  ];
  const actual = await page.locator(".emergency-thread-body .emergency-message.user .emergency-bubble").allTextContents();
  if (JSON.stringify(actual.slice(0, expected.length)) !== JSON.stringify(expected)) {
    throw new Error(`Emergency example questions changed: ${JSON.stringify(actual)}`);
  }
  const locatorLabels = await page
    .locator('.approvedui-thread-rail[data-approvedui-rail="emergency"] .approvedui-thread-rail-text')
    .allTextContents();
  if (JSON.stringify(locatorLabels.slice(0, expected.length)) !== JSON.stringify(expected)) {
    throw new Error(`Emergency locator labels do not match user questions: ${JSON.stringify(locatorLabels)}`);
  }
}

async function assertEmergencyExampleActions() {
  const expectedPrompts = [
    "这条任务现在到哪一步了？",
    "长寿公司具体回复了什么？",
    "原系统方案和AI方案差在哪里？",
    "前两项采用AI方案，第三项保留原系统方案。",
  ];
  const actualPrompts = await page.locator(".emergency-suggestions [data-emergency-suggest]").evaluateAll((nodes) =>
    nodes.map((node) => node.dataset.emergencySuggest),
  );
  if (JSON.stringify(actualPrompts) !== JSON.stringify(expectedPrompts)) {
    throw new Error(`Emergency example actions changed: ${JSON.stringify(actualPrompts)}`);
  }
}

async function clickLastAnchor(key) {
  const result = await page.evaluate((railKey) => {
    const rail = document.querySelector(`.approvedui-thread-rail[data-approvedui-rail="${railKey}"]`);
    const marks = [...(rail?.querySelectorAll(".approvedui-thread-rail-mark") || [])];
    const mark = marks.at(-1);
    const anchorId = mark?.dataset.approveduiThreadJump;
    mark?.click();
    return { anchorId, count: marks.length };
  }, key);
  if (!result.anchorId || result.count < 1) throw new Error(`${key} locator has no clickable anchors`);
  await page.waitForFunction((anchorId) => document.getElementById(anchorId)?.classList.contains("question-anchor-flash"), result.anchorId);
}
