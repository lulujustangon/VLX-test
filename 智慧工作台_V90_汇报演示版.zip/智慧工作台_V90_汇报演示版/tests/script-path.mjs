/* 严格按《演示操作脚本1015》从首页卡片点进每个事项，逐步核对按钮可点、未被遮挡。
   用法：node tests/script-path.mjs <截图目录> [浏览器路径] */
import { chromium } from "playwright";
import path from "node:path";
import fs from "node:fs/promises";

const out = process.argv[2] || "shots";
const exe = process.argv[3];
await fs.mkdir(out, { recursive: true });
const b = await chromium.launch(exe ? { executablePath: exe, args: ["--no-sandbox"] } : {});
const p = await b.newPage({ viewport: { width: 1920, height: 1080 } });
const errs = [];
p.on("pageerror", (e) => errs.push(e.message));
await p.goto(`file://${path.resolve("dist/智慧工作台_V89_高频场景版.html")}`);
await p.waitForTimeout(1500);
const wait = (ms) => p.waitForTimeout(ms);
let n = 0;
const shot = async (name) => p.screenshot({ path: path.join(out, `s${String(++n).padStart(2, "0")}-${name}.png`) });

/* 点之前确认元素中心点没有被别的元素盖住 */
async function click(loc, label) {
  /* 「今日复盘」按 V88 约 60 秒后自动弹出，演示时手动关闭：点弹窗外空白处 */
  if (await p.locator("#processreviewRecapOverlay.open").count()) {
    await p.mouse.click(30, 1060);
    await wait(400);
  }
  await loc.scrollIntoViewIfNeeded();
  const box = await loc.boundingBox();
  if (!box) throw new Error(`不可见：${label}`);
  const covered = await loc.evaluate((el, pt) => {
    const top = document.elementFromPoint(pt.x, pt.y);
    return top && !el.contains(top) && !top.contains(el) ? top.id || top.className : "";
  }, { x: box.x + box.width / 2, y: box.y + box.height / 2 });
  if (covered && /RecapOverlay|recap-overlay/.test(covered)) return click(loc, label);
  if (covered) throw new Error(`${label} 被遮挡：${covered}`);
  await loc.click();
  await wait(350);
}
const who = async (k) => {
  await click(p.locator("#emUserBtn"), "切换");
  await click(p.locator(`[data-em-who="${k}"]`), `账号 ${k}`);
  await wait(500);
};
async function go(cat) {
  if (await p.locator('#emThread [data-em-act="close"]').count()) await click(p.locator('#emThread [data-em-act="close"]'), "返回");
  await click(p.locator('[data-homebrief-root="focus"]').first(), "重点事项");
  await click(p.locator(`[data-homebrief-category="${cat}"]`), cat);
  const task = p.locator("[data-homebrief-task]");
  if (await task.count()) await click(task.first(), "事项");
  await click(p.locator('[data-homebrief-action="dialog"]'), "去办理");
  await wait(600);
}
const btn = (a, extra = "") => p.locator(`#emThread [data-em-act="${a}"]${extra}:not([disabled])`).first();
const ok = async () => click(p.locator('#emThread [data-em-act="c-ok"]').last(), "确认");
const say = async (t) => {
  await p.fill("#chatInput", t);
  await p.keyboard.press("Enter");
  await wait(700);
};

/* 仓储 */
await who("D");
await go("需求计划提报");
await click(btn("s-w2-up"), "上传设计物资清单");
await wait(4500);
await click(btn("s-row-yes", '[data-row="10"]'), "行10 采纳");
await click(btn("s-row-no", '[data-row="20"]'), "行20 不采纳");
await p.selectOption('#emThread [data-row-r="20"]', "seg");
await say("单段要450米，电缆沟里直埋段不能做中间接头");
await wait(3000);
await click(btn("s-row-no", '[data-row="30"]'), "行30 不采纳");
await p.selectOption('#emThread [data-row-r="30"]', "broken");
await say("这台箱变去年8月退役，试验时高压侧绝缘电阻偏低，负荷开关也卡，直接用不放心");
await wait(3000);
await click(btn("s-w2-submit"), "提交并传 ERP");
await ok();
await wait(2800);
await shot("W2");
await who("C");
await go("不利库原因审核");
await wait(3200);
await click(btn("s-w3-ok"), "认定不利库");
await ok();
await who("E");
await go("不利库审批");
await wait(3000);
await click(btn("s-w4-g1"), "通过这 9 条");
await ok();
await click(btn("s-w4-w6"), "查看 ERP 直接提报");
await shot("W6");
await who("C");
await say("库龄超过1年的物资，每周一早上推给我，按来源分开");
await say("按各自规定，再加上30天内就要超期的");
await wait(800);
await click(btn("s-cz-save"), "保存为个人场景");
await shot("CZ");

/* 履约 */
await who("F");
await go("问询清单");
await shot("L1");
await go("问询答复");
await wait(3800);
await click(btn("s-l2-up", '[data-o="4500942044"]'), "确认提级");
await ok();
await click(btn("s-l2-l4", '[data-o="4500953501"]'), "查看处置材料");
await wait(3800);
await click(p.locator('#emThread [data-em-tab="1"]'), "约谈提纲");
await click(btn("s-l4-ok"), "确认处置方式");
await ok();
await shot("L4");
await who("A");
await shot("A-home");
await go("三级履约协调");
await wait(3500);
await click(btn("s-l5-ok"), "受理并约谈供应商");
await ok();
await shot("L5");

/* 附页 */
await who("C");
await go("资源池");
await click(p.locator('#emThread [data-em-tab="1"]'), "应急备查看板");
await go("消纳计划");
await shot("W1-pool");
await who("D");
await go("仓储数据填报");
await go("不利库原因补填");
await go("资源池");
await shot("W1V");
await who("G");
await shot("G-home");
await go("项目物资进度");
await shot("L6");
await click(p.locator('#emThread [data-em-tab="1"]'), "收货确认");
await p.selectOption('#emThread select[data-f="r0"]', "推迟到11月30日");
await click(btn("s-l6-recv"), "提交收货确认");
await click(p.locator('#emThread [data-em-tab="2"]'), "供货异常");
await p.fill('#emThread input[data-f="fbDate"]', "10月20日");
await p.fill('#emThread input[data-f="fbWhy"]', "电缆沟封堵完成后才能送电");
await click(btn("s-l6-fb"), "反馈给履约专责");
await wait(1800);
await shot("L6-done");
await click(p.locator('#emThread [data-em-act="close"]'), "返回");
await say("我的项目物资到哪了");
await wait(1500);
await shot("LP");
await who("F");
await go("延期处置");
await click(p.locator('#emThread [data-em-tab="1"]'), "约谈提纲");
await shot("L4-with-G");
await who("F");
await go("催货与开票");
await click(p.locator('#emThread [data-em-tab="1"]'), "开票提醒");
await say("把这次问询催货的情况写个简报给主任");
await wait(1500);
await who("C");
await say("把本月库存消纳情况写个月报");
await wait(1500);
await click(p.locator('#emThread [data-em-act="close"]'), "返回");
await say("看看资源池的库龄分布");
await wait(1500);
await shot("CQ");

console.log(errs.length ? errs.join("\n") : "script path ok, no page errors");
await b.close();
