import { chromium } from "playwright";
import path from "node:path";
import { pathToFileURL } from "node:url";

const target = path.resolve(process.argv[2] || "dist/智慧工作台_综合高保真交互原型_V85_重构版.html");
const browser = await chromium.launch({ headless: true });

try {
  await verifyPublishOnly();
  await verifyPublishAndFollow();
  console.log("Four-analysis lifecycle passed: 3/4/3 → 4/4/3 or 4/5/4.");
} finally {
  await browser.close();
}

async function createPage() {
  const context = await browser.newContext({
    viewport: { width: 1440, height: 900 },
    locale: "zh-CN",
    reducedMotion: "reduce",
  });
  await context.addInitScript(() => localStorage.clear());
  const page = await context.newPage();
  page.setDefaultTimeout(5_000);
  await page.goto(pathToFileURL(target).href, { waitUntil: "load" });
  await page.waitForTimeout(1_300);
  return { context, page };
}

async function openCompletedComposition(page) {
  await page.evaluate(() => window.setView?.("agents"));
  await page.locator("[data-agentcenter-mode=workshop]").click();
  await page.locator("[data-agentcenter-compose]").click();
  await page.locator("[data-composer-example]").first().click();
  await page.locator("[data-composer-send]").click();
}

async function lifecycleState(page) {
  return page.evaluate(() => ({
    agents: state.agents.length,
    schedules: state.scheduled.length,
    follows: window.homeBriefFollowItems?.length,
    hasAgent: state.agents.some((item) => item.name === "计划专业四同分析智能体"),
    hasSchedule: state.scheduled.some((item) => item.name === "计划专业四同分析"),
    hasFollow: window.homeBriefFollowItems?.some((item) => item.id === "W4"),
  }));
}

async function verifyPublishOnly() {
  const { context, page } = await createPage();
  try {
    assertState(await lifecycleState(page), { agents: 3, schedules: 4, follows: 3 }, "initial");
    await openCompletedComposition(page);
    assertState(await lifecycleState(page), { agents: 3, schedules: 4, follows: 3 }, "composed");
    await page.locator("[data-four-analysis-publish]").click();
    assertState(await lifecycleState(page), {
      agents: 4,
      schedules: 4,
      follows: 3,
      hasAgent: true,
      hasSchedule: false,
      hasFollow: false,
    }, "published");
  } finally {
    await context.close();
  }
}

async function verifyPublishAndFollow() {
  const { context, page } = await createPage();
  try {
    await openCompletedComposition(page);
    await page.locator("[data-four-analysis-follow]").click();
    assertState(await lifecycleState(page), {
      agents: 4,
      schedules: 5,
      follows: 4,
      hasAgent: true,
      hasSchedule: true,
      hasFollow: true,
    }, "followed");
    await page.evaluate(() => window.setView?.("scheduled"));
    await page.waitForTimeout(100);
    if (!(await page.locator("#scheduleList").getByText("计划专业四同分析", { exact: true }).count())) {
      throw new Error("followed: scheduled-task UI is missing");
    }
    await page.evaluate(() => window.setView?.("chat"));
    await page.locator(".homebrief-root-card[data-homebrief-root=follow]").click();
    if (!(await page.getByText("计划专业四同分析", { exact: true }).count())) {
      throw new Error("followed: home-brief UI is missing");
    }
    await page.reload({ waitUntil: "load" });
    await page.waitForTimeout(1_300);
    assertState(await lifecycleState(page), {
      agents: 3,
      schedules: 4,
      follows: 3,
      hasAgent: false,
      hasSchedule: false,
      hasFollow: false,
    }, "refreshed");
  } finally {
    await context.close();
  }
}

function assertState(actual, expected, stage) {
  for (const [key, value] of Object.entries(expected)) {
    if (actual[key] !== value) {
      throw new Error(`${stage}: expected ${key}=${value}, received ${actual[key]} (${JSON.stringify(actual)})`);
    }
  }
}
