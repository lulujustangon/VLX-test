import { chromium } from "playwright";
import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

const target = path.resolve(process.argv[2]);
const output = path.resolve(process.argv[3] || "artifacts/mobile");
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({
  viewport: { width: 390, height: 844 },
  deviceScaleFactor: 1,
  isMobile: true,
  hasTouch: true,
  locale: "zh-CN",
  reducedMotion: "reduce",
});
await context.addInitScript(() => localStorage.clear());
const page = await context.newPage();
page.setDefaultTimeout(4_000);
const errors = [];
page.on("pageerror", (error) => errors.push(error.message));
await fs.mkdir(output, { recursive: true });
await page.goto(pathToFileURL(target).href, { waitUntil: "load" });
await page.waitForTimeout(1300);

async function shot(name) {
  await page.waitForTimeout(220);
  await page.screenshot({ path: path.join(output, `${name}.png`), animations: "disabled" });
}
async function view(name) {
  await page.evaluate((nextView) => window.setView?.(nextView), name);
  await page.waitForTimeout(260);
}

await shot("25-mobile-home-notice");
await page.locator("[data-approvedui-notice-close]").last().click().catch(() => {});
await shot("26-mobile-home");
await view("agents");
await shot("27-mobile-agents");
await view("knowledge");
await shot("28-mobile-knowledge");
await view("emergency");
await shot("29-mobile-emergency");

await fs.writeFile(path.join(output, "errors.json"), `${JSON.stringify(errors, null, 2)}\n`);
await browser.close();
if (errors.length) process.exitCode = 1;
