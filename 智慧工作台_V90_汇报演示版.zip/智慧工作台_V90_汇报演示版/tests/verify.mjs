import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

const root = process.cwd();
const target = path.join(root, "dist", "智慧工作台_V88_执行方式改版.html");
const temporary = await fs.mkdtemp(path.join(os.tmpdir(), "approvedui-visual-verify-"));
const suites = [
  ["tests/capture.mjs", "artifacts/baseline", "desktop-main"],
  ["tests/capture-interactions.mjs", "artifacts/baseline-interactions", "desktop-interactions"],
  ["tests/capture-mobile.mjs", "artifacts/baseline-mobile", "mobile"],
];

try {
  await run("node", ["scripts/check.mjs"]);
  await run("node", ["scripts/build.mjs"]);
  await run("node", ["tests/four-analysis-lifecycle.mjs", target]);
  await run("node", ["tests/deep-semantic-interactions.mjs", target]);
  await run("node", ["tests/thread-locator.mjs", target]);
  for (const [captureScript, baseline, name] of suites) {
    const candidate = path.join(temporary, name);
    const diff = path.join(temporary, `${name}-diff`);
    await run("node", [captureScript, target, candidate]);
    await run("node", ["tests/visual-regression.mjs", baseline, candidate, diff]);
  }
  console.log("Verification passed: business lifecycle, deep interactions, four user-question locators and 29 visual states, no perceptible pixel differences.");
} finally {
  if (process.env.KEEP_VISUAL_ARTIFACTS === "1") {
    console.log(`Verification artifacts kept at ${temporary}`);
  } else {
    await fs.rm(temporary, { recursive: true, force: true });
  }
}

function run(command, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd: root, stdio: "inherit" });
    child.once("error", reject);
    child.once("exit", (code, signal) => {
      if (code === 0) resolve();
      else reject(new Error(`${command} ${args.join(" ")} failed (${signal || code})`));
    });
  });
}
