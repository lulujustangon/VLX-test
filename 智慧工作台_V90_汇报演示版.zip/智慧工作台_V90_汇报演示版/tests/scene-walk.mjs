/* 按演示脚本顺序走一遍高频场景主线，逐屏截图，收集页面报错。
   用法：node tests/scene-walk.mjs <截图目录> [浏览器路径] */
import { chromium } from "playwright";
import path from "node:path";
import fs from "node:fs/promises";

const out = process.argv[2] || "shots";
const exe = process.argv[3];
await fs.mkdir(out, { recursive: true });
const file = path.resolve("dist/智慧工作台_V89_高频场景版.html");
const browser = await chromium.launch(exe ? { executablePath: exe, args: ["--no-sandbox"] } : {});
const page = await browser.newPage({ viewport: { width: 1600, height: 900 } });
const errors = [];
page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));
page.on("console", (m) => m.type() === "error" && errors.push(`console: ${m.text()}`));
await page.goto(`file://${file}`);
await page.waitForTimeout(1500);

let n = 0;
const shot = async (name) => {
  n += 1;
  await page.screenshot({ path: path.join(out, `${String(n).padStart(2, "0")}-${name}.png`) });
};
const wait = (ms) => page.waitForTimeout(ms);
/* 「今日复盘」约 60 秒后自动弹出，演示时点弹窗外空白处关闭 */
const unrecap = async () => {
  if (await page.locator("#processreviewRecapOverlay.open").count()) {
    await page.mouse.click(30, 880);
    await wait(400);
  }
};
const who = async (k) => {
  await unrecap();
  await page.click("#emUserBtn");
  await page.click(`[data-em-who="${k}"]`);
  await wait(600);
};
const open = async (id) => {
  await page.evaluate((x) => window.execThreadOpen(x), id);
  await wait(500);
};
const act = async (a, nth = 0) => {
  await unrecap();
  const el = page.locator(`#emThread [data-em-act="${a}"]:not([disabled])`).nth(nth);
  await el.click();
  await wait(300);
};
const send = async (text) => {
  await page.fill("#chatInput", text);
  await page.keyboard.press("Enter");
  await wait(600);
};
const okConfirm = async () => {
  await page.locator('#emThread [data-em-act="c-ok"]').last().click();
};

/* 仓储：D 提报 */
await who("D");
await shot("D-home");
await open("W2");
await act("s-w2-up");
await wait(4500);
await shot("W2-matched");
await page.locator('#emThread [data-em-act="s-row-yes"][data-row="10"]').click();
await wait(300);
await page.locator('#emThread [data-em-act="s-row-no"][data-row="20"]').click();
await page.selectOption('#emThread [data-row-r="20"]', "seg");
await wait(400);
await send("单段要450米，电缆沟里直埋段不能做中间接头");
await wait(3200);
await page.locator('#emThread [data-em-act="s-row-no"][data-row="30"]').click();
await page.selectOption('#emThread [data-row-r="30"]', "broken");
await wait(400);
await send("这台箱变去年8月退役，试验时高压侧绝缘电阻偏低，负荷开关也卡，直接用不放心");
await wait(3200);
await shot("W2-rows-done");
await act("s-w2-submit");
await wait(300);
await okConfirm();
await wait(3000);
await shot("W2-submitted");

/* C 专责审核 */
await who("C");
await shot("C-home");
await open("W3");
await wait(3500);
await shot("W3-review");
await act("s-w3-ok");
await okConfirm();
await wait(500);

/* E 主任审批、ERP 直接提报 */
await who("E");
await shot("E-home");
await open("W4");
await wait(3000);
await shot("W4-approve");
await act("s-w4-g1");
await okConfirm();
await wait(400);
await act("s-w4-w6");
await wait(600);
await shot("W6-erp");

/* C 对话组装 */
await who("C");
await send("库龄超过1年的物资，每周一早上推给我，按来源分开");
await wait(800);
await send("按各自规定，再加上30天内就要超期的");
await wait(1200);
await shot("CZ-draft");
await act("s-cz-save");
await wait(400);
await shot("CZ-saved");

/* 履约：F */
await who("F");
await shot("F-home");
await open("L1");
await shot("L1-list");
await open("L2");
await wait(4000);
await shot("L2-levels");
await page.locator('#emThread [data-em-act="s-l2-up"][data-o="4500942044"]').click();
await okConfirm();
await wait(500);
await shot("L2-escalated");
await open("L4");
await wait(4000);
await shot("L4-basis");
await page.locator('#emThread [data-em-tab="1"]').click();
await wait(300);
await shot("L4-outline");
await open("L3");
await shot("L3-cuihuo");

/* A 物资公司 */
await who("A");
await shot("A-home");
await open("L5");
await wait(3500);
await shot("L5-coord");

/* 其余线程打开即截图 */
await who("C");
for (const id of ["W1", "W5"]) {
  await open(id);
  await wait(400);
  await shot(id);
}
await who("D");
for (const id of ["W6B", "W7"]) {
  await open(id);
  await wait(400);
  await shot(id);
}
await who("F");
await send("把这次问询催货的情况写个简报给主任");
await wait(2000);
await shot("LW");

console.log(errors.length ? errors.join("\n") : "no page errors");
await browser.close();
