/* 左侧菜单（2026-10-20 按设计稿改）：新建对话 / 今日简报 / 智能办理 / 任务跟踪 / 动态看板 / 智能问数 / 我的常用 / 最近对话。
   智能办理下挂正在办的事项；办完转「任务跟踪」，应急放出后也挂在「任务跟踪」下；动态看板下挂工单运营看板（管理岗）和我的看板。
   原「查询对话」「应急任务中心」入口撤下，应急工作区改从「任务跟踪」进入。 */
(() => {
  const EM = window.EM;
  if (!EM) return;
  const h = EM.h;
  const S8 = () => (typeof state !== "undefined" ? state : {});
  const who = () => (window.execWho ? window.execWho() : "H");
  const T = (id) => (EM.S.threads || {})[id];
  const open = () => EM.S.open || "";
  const fold = {}; /* 用户手动展开、收起的分组 */

  /* ---------- 各账号挂在菜单下的事项 ---------- */
  function doing() {
    if (who() !== "H") return [];
    const s1 = T("S1");
    const list = [];
    if (!(s1 && s1.closed)) list.push({ id: "S1", t: "订单 4500951207 超期交货", s: s1 && s1.handled ? "已办理 · 待您核对" : s1 && s1.go ? "办理中" : "待决策 · 已超 13 天" });
    list.push({ id: "S2", t: "订单 4500949833 超期交货", s: "已超 5 天" });
    list.push({ id: "G1", t: "「供货单状态」督办 2 张", s: "已超工单时限 1 天" });
    list.push({ id: "P1", t: "协议库存匹配待确认 3 条", s: "明天 17:00" });
    return list;
  }
  function emgMeta() {
    try { return emergencyTaskMeta.E001; } catch (_) { return null; }
  }
  function tracking() {
    const list = [];
    if (who() === "H") {
      if (window.__v90NoticeReleased) {
        const m = emgMeta();
        list.push({ id: "E001", t: "忠县 110kV 石拔南线 22 号塔滑坡", s: m ? `${m.status} · ${m.detail}` : "处理中", emg: true });
      }
      const s1 = T("S1");
      if (s1 && s1.closed) list.push({ id: "S1", t: "订单 4500951207 超期交货", s: "待签章 · 签章完成后自动办结" });
      list.push({ id: "HF2", t: "忠县 110kV 新立输变电工程物资到货", s: "关键物资 9 项，已到 7 项" });
      list.push({ id: "HF3", t: "＊＊线缆股份有限公司发货", s: "10 月 27 日发货" });
    } else {
      const m0 = T("M0");
      if (m0 && m0.clue) list.push({ id: "M0", sub: "ecom", t: "监督检查线索 · 垫江、綦江", s: "已推送 2 条" });
      if (m0 && m0.assign) list.push({ id: "M0", sub: "ecom", t: "电商逾期支付 · 工单时限确认", s: m0.reply ? "专责已回复 · 保留原时限" : "已分配 · 等专责回复" });
    }
    return list;
  }
  function boards() {
    return who() === "A"
      ? [{ id: "M0", sub: "board", t: "工单运营看板", s: "全公司 · 37 家单位" }, { id: "K1A", t: "我的看板", s: "岗位指标" }]
      : [{ id: "K1H", t: "我的看板", s: "业务指标 · 我的工单运营指标" }];
  }

  /* 当前所在：任务线程 id、应急、首页 */
  function here() {
    const s = S8();
    if (s.view === "emergency" && s.emergencyThread === "E001") return { id: "E001" };
    if (open()) { const t = T(open()); return { id: open(), sub: t && t.sub }; }
    if (s.view === "scheduled") return { view: "scheduled" };
    if (s.view === "chat") return { view: "home" };
    return {};
  }
  const isOn = (it, cur) => it.id === cur.id && (!it.sub || it.sub === "board" ? cur.sub !== "ecom" : cur.sub === it.sub);

  const ICON = { brief: "i-list", do: "i-nav-do", track: "i-nav-track", board: "i-nav-board", ask: "i-search", star: "i-nav-star" };
  const ico = (k) => `<svg class="icon"><use href="#${ICON[k]}" /></svg>`;
  function group(key, name, list, cur, empty) {
    const has = list.some((it) => isOn(it, cur));
    const show = fold[key] != null ? fold[key] : has;
    const badge = list.length && key !== "board" ? `<span class="nav-badge${key === "track" && list.some((x) => x.emg) ? " alert" : ""}">${list.length}</span>` : "";
    const items = list.length
      ? list.map((it) => `<button class="v94-sub${isOn(it, cur) ? " on" : ""}" data-v94-item="${it.id}"${it.sub ? ` data-v94-sub="${it.sub}"` : ""}><span>${h(it.t)}</span><small>${h(it.s)}</small></button>`).join("")
      : `<p class="v94-none">${empty}</p>`;
    return `<button class="nav-btn v94-nav${has ? " active" : ""}" data-v94-group="${key}" aria-expanded="${show}">${ico(key)}<span class="side-text">${name}</span>${badge}<i class="v94-caret${show ? " open" : ""}"></i></button><div class="v94-subnav${show ? "" : " fold"}">${items}</div>`;
  }
  function render() {
    const box = document.querySelector("#sidebar .sidebar-scroll .nav-group");
    if (!box) return;
    const cur = here();
    const nSched = (S8().scheduled || []).length || 4;
    const html = `<button class="nav-btn v94-nav${cur.view === "home" ? " active" : ""}" data-v94-home>${ico("brief")}<span class="side-text">今日简报</span></button>` +
      group("do", "智能办理", doing(), cur, "暂无待办理的事项") +
      group("track", "任务跟踪", tracking(), cur, "暂无跟踪中的事项") +
      group("board", "动态看板", boards(), cur, "") +
      `<button class="nav-btn v94-nav" data-v94-ask>${ico("ask")}<span class="side-text">智能问数</span></button>` +
      `<button class="nav-btn v94-nav${cur.view === "scheduled" ? " active" : ""}" data-view="scheduled">${ico("star")}<span class="side-text">我的常用</span><span class="nav-badge" id="scheduleCountBadge">${nSched}</span></button>`;
    if (box.dataset.v94 === html) return;
    box.dataset.v94 = html;
    box.innerHTML = html;
  }
  window.v94SideRender = render;

  /* 原「应急任务中心」下的任务列表不再显示；最近对话里的任务线程不再单独成组 */
  function trimRecent() {
    document.getElementById("timelineSidebarEmergencyThreads")?.remove();
  }
  /* 顶栏右侧显示当天日期 */
  function dateTag() {
    const hd = document.getElementById("approveduiSystemHeader");
    if (!hd || hd.querySelector(".v94-date")) return;
    const d = new Date();
    hd.insertAdjacentHTML("beforeend", `<span class="v94-date">${d.getMonth() + 1} 月 ${d.getDate()} 日 周${"日一二三四五六"[d.getDay()]}</span>`);
  }
  /* 首页输入框上方「也可以直接问」（业务人员账号） */
  function quickAsk() {
    const wrap = document.querySelector("#view-chat .composer-wrap");
    const cur = document.getElementById("v94qk");
    const show = wrap && who() === "H" && !open() && window.V94_QS;
    if (!show) { cur?.remove(); return; }
    if (cur) return;
    wrap.insertAdjacentHTML("afterbegin", `<div id="v94qk" class="v94-qk"><span>也可以直接问：</span>${window.V94_QS.map(([id, q]) => `<button data-v94-q="${id}">${h(q)}</button>`).join("")}</div>`);
  }
  const tick = () => { try { render(); trimRecent(); dateTag(); quickAsk(); } catch (_) { /* 侧栏未加载时不处理 */ } };
  document.addEventListener("click", (e) => {
    const q = e.target.closest && e.target.closest("[data-v94-q]");
    if (!q) return;
    e.preventDefault(); e.stopImmediatePropagation();
    EM.openThread(q.dataset.v94Q);
    setTimeout(tick, 60);
  }, true);

  function openItem(id, sub) {
    if (id === "E001") { window.v92OpenEmergency && window.v92OpenEmergency(); return; }
    if (!EM.openThread(id)) return;
    const t = T(id);
    if (t && sub && id === "M0") { t.sub = sub === "board" ? "board" : sub; EM.draw(t); }
  }

  /* 捕获阶段处理：分组展开收起不能触发「点菜单就关闭任务线程」 */
  window.addEventListener("click", (e) => {
    const t = e.target;
    if (!t.closest || !t.closest("#sidebar")) return;
    let el;
    if ((el = t.closest("[data-v94-group]"))) {
      e.preventDefault(); e.stopImmediatePropagation();
      const k = el.dataset.v94Group;
      const sub = el.nextElementSibling;
      fold[k] = sub ? sub.classList.contains("fold") : true;
      render();
      return;
    }
    if ((el = t.closest("[data-v94-item]"))) {
      e.preventDefault(); e.stopImmediatePropagation();
      openItem(el.dataset.v94Item, el.dataset.v94Sub);
      setTimeout(tick, 60);
      return;
    }
    if (t.closest("[data-v94-home]")) {
      e.preventDefault(); e.stopImmediatePropagation();
      if (open()) document.querySelector('#emThread [data-em-act="close"]')?.click();
      try { window.setView("chat"); } catch (_) {}
      /* 回到今日简报：展开到摘要层 */
      try { const s = S8(); if (s.briefnavHome) { s.briefnavHome.level = "summary"; } if (s.homebriefBrief) s.homebriefBrief.root = "summary"; } catch (_) {}
      EM.refreshHome();
      setTimeout(tick, 60);
      return;
    }
    if (t.closest("[data-v94-ask]")) {
      e.preventDefault(); e.stopImmediatePropagation();
      if (open()) document.querySelector('#emThread [data-em-act="close"]')?.click();
      try { window.setView("chat"); } catch (_) {}
      const inp = document.getElementById("chatInput");
      if (inp) { inp.placeholder = "问数据，例如：本周还有哪些订单到期未收货"; inp.focus(); }
      setTimeout(tick, 60);
    }
  }, true);
  /* 任务线程、应急、账号切换都会改菜单，统一在这些动作后重画 */
  ["click", "keydown"].forEach((ev) => document.addEventListener(ev, () => setTimeout(tick, 80), true));
  setInterval(tick, 1000);
  tick();
})();
