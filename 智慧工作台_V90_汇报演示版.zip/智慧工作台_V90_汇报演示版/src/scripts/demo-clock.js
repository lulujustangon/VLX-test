/* 演示时钟（2026-10-20）：画面日期锁定在汇报当天 2026 年 10 月 23 日，打开页面时为 09:05，此后按真实流逝走。
   应急提醒、回复归集、物资部选定等时间点由 DEMO_CLOCK.set 跳到演示全流程写定的时刻。汇报改期只改 DAY。 */
(() => {
  const DAY = [2026, 9, 23]; /* 月份从 0 起：9 即 10 月 */
  const Real = Date;
  const realNow = () => Real.now();
  let base = new Real(DAY[0], DAY[1], DAY[2], 9, 5, 0).getTime();
  let t0 = realNow();
  const fake = () => base + (realNow() - t0);
  class DemoDate extends Real {
    constructor(...a) {
      if (a.length) super(...a);
      else super(fake());
    }
    static now() {
      return fake();
    }
  }
  window.Date = DemoDate;
  window.DEMO_CLOCK = {
    set(hh, mm, ss = 0) {
      const d = new Real(fake());
      d.setHours(hh, mm, ss, 0);
      if (d.getTime() < fake()) return; /* 只往后跳 */
      base = d.getTime();
      t0 = realNow();
    },
    hm(ms) {
      const d = new Real(ms == null ? fake() : ms);
      return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
    },
  };
})();
