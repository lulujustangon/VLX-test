/* Source runtime block 29 id="homebriefRuntime" */
!(function () {
        const t = (t) =>
          String(t ?? "").replace(
            /[&<>\"]/g,
            (t) =>
              ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[t],
          );
        state.homebriefBrief = state.homebriefBrief || {
          root: "summary",
          filter: "all",
          category: "",
          task: "",
        };
        const e = {
            all: "全部",
            pending: "待处理",
            running: "处理中",
            external: "待外部响应",
            done: "今日完成",
          },
          a = [
            {
              id: "D1",
              entry: { sys: "ERP", menu: "ZMM20188 集中招标批次计划审批" },
              cat: "采购计划审批",
              title: "集中招标批次计划审批",
              status: "pending",
              object: "招标计划编号 202197｜采购申请 3800530813",
              current: "待本人审批",
              deadline: "今日17:00",
              remain: "剩余6小时",
              risk: "未审批的批次无法进入本轮集中招标",
              impact: "影响本批次招标文件编制和发布",
              advice: "由 AI 在 ERP 网页版填写查询条件并定位采购申请，核对后批准",
              reason: "审批待办｜时限临近",
            },
            {
              id: "D2",
              entry: { sys: "智慧供应链运营平台", menu: "付款申请管理-专责审核" },
              cat: "合同结算",
              title: "付款申请专责审核",
              status: "pending",
              object: "采购凭证 4300132824｜到货款",
              current: "待专责审核",
              deadline: "今日17:00",
              remain: "剩余6小时",
              risk: "付款申请未提交，到货款无法按期支付",
              impact: "影响合同结算进度",
              advice: "打开运营平台，按采购凭证号查询并提交付款申请",
              reason: "审核待办｜时限临近",
            },
            {
              id: "D3",
              entry: { sys: "ESC", menu: "网省风险预警展示" },
              cat: "风险预警督办",
              title: "网省风险预警待反馈查询",
              status: "pending",
              object: "工厂 大足｜状态 待反馈",
              current: "待查询预警明细",
              deadline: "明日08:30",
              remain: "剩余1天",
              risk: "超过环节处理截止时间未反馈将转入督办",
              impact: "影响本单位风险预警反馈及时率",
              advice: "查询大足待反馈的风险预警，确认当前环节和处理人",
              reason: "风险预警｜待核查",
            },
            {
              id: "D4",
              who: "B",
              entry: { sys: "ESC", menu: "网省风险预警反馈" },
              cat: "风险预警督办",
              title: "物资交付逾期预警反馈",
              status: "pending",
              object: "预警 物资交付逾期｜未收货｜大足",
              current: "待基层单位专责反馈",
              deadline: "明日08:30",
              remain: "剩余1天",
              risk: "超过环节处理截止时间未反馈将转入督办",
              impact: "影响本单位风险预警反馈及时率",
              advice: "填写问题分类、是否属实、问题原因和佐证，提交反馈",
              reason: "风险预警｜待反馈",
            },
            {
              id: "D5",
              entry: { sys: "实物资源一体化", menu: "仓储工作台-代保管出库" },
              cat: "仓储作业",
              title: "退役资产代保管出库",
              status: "pending",
              object: "单据号 TYCK0300000000002766｜10kV 变压器 1 台",
              current: "待下架",
              deadline: "今日17:00",
              remain: "剩余6小时",
              risk: "未下架过账，退役资产无法发货",
              impact: "影响退役资产处置进度",
              advice: "现场完成下架后，在仓储工作台提交过账",
              reason: "作业待办｜时限临近",
            },
            {
              id: "D6",
              who: "B",
              entry: { sys: "ERP", menu: "ZMM20012 采购申请受理及平衡利库--基层" },
              cat: "采购申请受理",
              title: "采购申请受理及平衡利库",
              status: "pending",
              object: "需求工厂 大足｜采购申请 3800531206｜2 行",
              current: "待受理",
              deadline: "今日17:00",
              remain: "剩余6小时",
              risk: "未受理的采购申请无法进入本月采购计划",
              impact: "影响工程物资需求按期上报",
              advice: "在 ERP 查询大足待审批采购申请，按库存可用量先平衡利库，再受理",
              reason: "受理待办｜时限临近",
            },
            {
              id: "F1",
              entry: { sys: "ERP", menu: "ZMM20012 采购申请受理及平衡利库--基层" },
              cat: "采购请示处理",
              title: "迎峰度夏重点工程采购流标处置",
              status: "pending",
              object: "迎峰度夏重点工程｜采购批次2026-08",
              current: "采购方式确认",
              deadline: "今日16:00",
              remain: "剩余5小时20分钟",
              risk: "采购流标后按常规重新采购预计延期5天",
              impact: "压缩采购文件、开标、合同签订和生产交付时间",
              advice: "今日确认加急采购方式或最近可执行批次，并同步采购负责人和项目发起人",
              reason: "保障相关｜时间紧迫",
            },
            {
              id: "FNEW",
              entry: { sys: "ERP", menu: "ZMMR040 采购订单执行情况" },
              cat: "合同履约异常",
              title: "主变压器订单发货确认",
              status: "external",
              object: "主变压器订单 CQ-2026-0187",
              current: "等待供应商确认发货",
              deadline: "今日16:00",
              remain: "已超期1天｜距验收剩余3天",
              risk: "继续延迟将压缩到货验收与投运准备时间",
              impact: "下游验收和项目投运节点可能受影响",
              advice: "立即催办，未反馈时升级督办并同步发起人",
              reason: "新增预警｜履约异常",
              dynamic: !0,
            },
            {
              id: "F4",
              entry: { sys: "物资仓储管理系统", menu: "入库" },
              cat: "重点工程保障",
              title: "重点工程关键物资到货保障",
              status: "running",
              object: "重庆北部500千伏输变电工程｜主变压器、10千伏开关柜及电力电缆",
              current: "智能体正在核验3项关键物资承诺交期",
              deadline: "明日12:00",
              remain: "剩余26小时",
              risk: "主变压器尚未确认发货，开关柜与电力电缆交期存在不确定性",
              impact: "可能影响8月22日现场安装窗口",
              advice: "今日16:00前确认主变压器发货时间，同时准备开关柜与电缆替代来源",
              reason: "重点工程｜关键物资",
            },
            {
              id: "F5",
              entry: { sys: "智慧供应链运营平台", menu: "抽检计划执行" },
              cat: "质量问题处置",
              title: "抽检不合格物资处置确认",
              status: "pending",
              object: "南岸配网工程｜10千伏电力电缆｜质量抽检单Q-2026-071",
              current: "处置方式确认",
              deadline: "今日15:30",
              remain: "剩余4小时50分钟",
              risk: "复检与退换货方式未确认，可能形成不合格物资领用风险",
              impact: "影响南岸配网工程8月20日施工备料",
              advice: "今日15:30前确认复检计划和退换货方案，并通知供应商与项目单位",
              reason: "质量风险｜合规异常",
            },
            {
              id: "F6",
              entry: { sys: "智慧供应链运营平台", menu: "跨单位调拨征询反馈" },
              cat: "应急协同处置",
              title: "忠县石拔南线#22滑坡应急资源确认",
              status: "pending",
              object: "忠县石拔南线#22滑坡应急｜23项物资需求",
              current: "资源组合确认",
              deadline: "今日13:00",
              remain: "剩余2小时20分钟",
              risk: "OPGW光缆等3项资源组合待人工确认",
              impact: "影响应急调拨和最晚到货时间",
              advice: "优先确认3项方案差异，随后生成寻源报告并启动资源调拨",
              reason: "应急响应｜时间紧迫",
            },
          ],
          n = [];
        let s = 0;
        const EM_ENTRY = {
          到货信息维护: { sys: "物资仓储管理系统", menu: "入库" },
          合同信息确认: { sys: "智慧供应链运营平台", menu: "合同电子档案查询" },
          采购文件审核: { sys: "ERP", menu: "ZMM20188 招标批次计划审批" },
          跨单位协同: { sys: "物资仓储管理系统", menu: "跨单位调拨" },
          其他日常事项: { sys: "物资仓储管理系统", menu: "出（移）库维护" },
        };
        const EM_TITLES = {
          到货信息维护: [
            "电缆到货信息补录",
            "变压器到货时间确认",
            "金具到货凭证维护",
            "绝缘子到货地点更新",
            "光缆到货状态核验",
            "开关柜到货信息确认",
            "导线到货记录补充",
          ],
          合同信息确认: [
            "合同交付地点确认",
            "合同联系人信息补充",
            "合同生效日期核验",
            "供应商交期确认",
            "合同附件完整性确认",
          ],
          采购文件审核: [
            "采购文件条款审核",
            "采购范围确认",
            "技术规范引用核验",
            "采购文件版本确认",
          ],
          跨单位协同: [
            "跨单位库存回复确认",
            "协调函反馈跟踪",
            "单位联系人确认",
          ],
          其他日常事项: ["日常统计口径确认"],

        };
        [
          ["到货信息维护", 7, [3, 2, 1, 1]],
          ["合同信息确认", 5, [1, 2, 1, 1]],
          ["采购文件审核", 4, [1, 1, 1, 1]],
          ["跨单位协同", 3, [1, 0, 1, 1]],
          ["其他日常事项", 1, [1, 0, 0, 0]],
        ].forEach(([t, e, a]) => {
          let ti = 0;
          ["pending", "running", "external", "done"].forEach((e, r) => {
            for (let o = 0; o < a[r]; o++) {
              s++;
              const a = EM_TITLES[t][ti++];
              n.push({
                id: `G${s}`,
                entry: EM_ENTRY[t],
                cat: t,
                title: a,
                status: e,
                object: `${t}业务单据 ${String(s).padStart(3, "0")}`,
                current:
                  "pending" === e
                    ? "待本人处理"
                    : "running" === e
                      ? "本人或智能体处理中"
                      : "external" === e
                        ? "等待外部反馈"
                        : "今日已完成",
                deadline:
                  "done" === e ? "已完成" : o % 2 ? "明日12:00" : "今日17:00",
                remain:
                  "done" === e ? "已闭环" : o % 2 ? "剩余1天" : "剩余6小时",
                risk:
                  "pending" === e && 0 === o ? "临近办理时限" : "当前风险可控",
                impact: "影响后续业务环节按计划推进",
                advice:
                  "pending" === e
                    ? "按时完成当前环节"
                    : "external" === e
                      ? "持续跟踪并在超时后催办"
                      : "继续按计划推进",
                reason: "一般事项",
              });
            }
          });
        });
        const r = [
          {
            id: "W1",
              entry: { sys: "ERP", menu: "ZMM20087 采购申请执行情况表" },
            cat: "重点项目",
            title: "迎峰度夏项目物资保障",
            status: "running",
            object: "用户主动关注",
            current: "完成率82%",
            deadline: "8月8日",
            remain: "3项交期风险",
            risk: "关键物资交期仍需持续跟踪",
            impact: "可能影响项目里程碑",
            advice: "持续跟踪并准备替代来源",
            reason: "我的关注",
          },
          {
            id: "W2",
              entry: { sys: "ERP", menu: "ZMM039 采购申请执行情况统计" },
            cat: "采购批次",
            title: "采购批次2026-08",
            status: "running",
            object: "节点持续跟踪",
            current: "需求审查已完成",
            deadline: "明日",
            remain: "即将进入采购文件确认",
            risk: "当前无明显风险",
            impact: "影响后续采购文件编制",
            advice: "明日关注节点切换结果",
            reason: "我的关注",
          },
          {
            id: "W3",
              entry: { sys: "ERP", menu: "ME23N 显示采购订单" },
            cat: "订单及物资",
            title: "主变压器订单持续跟踪",
            status: "external",
            object: "智能体自动执行",
            current: "持续核验供应商发货状态",
            deadline: "今日16:00",
            remain: "等待供应商反馈",
            risk: "交期信息尚未确认",
            impact: "可能影响验收安排",
            advice: "到时未反馈则自动催办",
            reason: "我的关注",
          },
        ];
        const fourAnalysisFollowItem = {id:"W4",entry: { sys: "ERP", menu: "ZMMR045 查询框架协议单价及执行情况" },cat:"计划分析",title:"计划专业四同分析",status:"running",object:"已固化的四同分析任务",current:"持续跟踪并生成分析报告",deadline:"按定时任务执行",remain:"最近一次结果已生成",risk:"关注省间价格偏差与策略执行异常",impact:"支持计划专业采购策略优化",advice:"持续运行，出现异常变化时进入今日简报",reason:"我的关注"};
        window.homeBriefFocusItems = a;
        window.homeBriefFollowItems = r;
        function syncFourAnalysisHomeFollow() {
          const lifecycle = window.__fourAnalysisLifecycle ||
            (window.__fourAnalysisLifecycle = { published: false, followed: false });
          const followed = lifecycle.followed === true;
          const index = r.findIndex((item) => item.id === fourAnalysisFollowItem.id);
          if (followed && index < 0) r.push({...fourAnalysisFollowItem});
          if (!followed && index >= 0) r.splice(index, 1);
        }
        syncFourAnalysisHomeFollow();
        function o() {
          /* 高频场景：应急放出后、还没点开时算 1 项新增任务（v90.js 给出） */
          if ("function" == typeof window.__v94New && window.__v94New()) return !0;
          return !(!state.sensingSense || !state.sensingSense.detected);
        }
        const who = () => (window.execWho ? window.execWho() : "A");
        /* 高频场景账号的一般事项、我的关注由 v90.js 给出（window.SCENE_LIST），没有时沿用 V89 */
        const ext = (k) => ("function" == typeof window.SCENE_LIST ? window.SCENE_LIST(who(), k) : null);
        function i() {
          return a.filter((t) => !t.dynamic && (t.who || "A") === who());
        }
        function l() {
          return {
            new: o() ? 1 : 0,
            focus: i().length + ("function" == typeof window.__v94FocusAdd ? window.__v94FocusAdd(who()) : 0),
            general: (ext("general") || ("A" === who() ? n : [])).length,
            follow: (ext("follow") || ("A" === who() ? r : [])).length,
          };
        }
        function c(t) {
          return (
            {
              new: "新增任务",
              focus: "重点事项",
              general: "一般事项",
              follow: "我的关注",
            }[t] || "今日简报"
          );
        }
        function v(t) {
          return "focus" === t
            ? i()
            : "general" === t
              ? ext("general") || ("A" === who() ? n : [])
              : "follow" === t
                ? ext("follow") || ("A" === who() ? r : [])
                : o()
                  ? [a.find((t) => "FNEW" === t.id)]
                  : [];
        }
        function d(t) {
          const e = v(t);
          return "all" === state.homebriefBrief.filter ||
            "follow" === t ||
            "new" === t
            ? e
            : e.filter((t) => t.status === state.homebriefBrief.filter);
        }
        function u(t, e, a, n = "") {
          return `<button class="${n} ${state.homebriefBrief.root === t && "closed" !== state.briefnavHome.level ? "active" : ""}" data-homebrief-root="${t}"><b>${a}</b>${e}</button>`;
        }
        function f() {
          const t = l();
          const out = `<div class="homebrief-shell"><section class="homebrief-analysis fouranalysis-focus-analysis"><div class="homebrief-analysis-head"><strong>重点事项</strong><span>${"A" === who() ? "4项需优先关注" : "2项需优先关注"}</span></div>${"A" !== who() ? '<ol class="fouranalysis-focus-lines"><li><b>1. 大足物资交付逾期预警待反馈：</b>ESC 网省风险预警显示 1 条“物资交付逾期｜未收货”待基层单位反馈，环节截止 2026-09-16 08:30:02；建议今日核实收货情况并提交反馈。</li><li><b>2. 大足采购申请 3800531206 待受理：</b>ERP 采购申请 2 行今日 17:00 前需受理，电力电缆 YJV22 3×300 库存可用 0.8 KM；建议先平衡利库，再受理进入本月采购计划。</li></ol>' : ""}<ol class="fouranalysis-focus-lines"${"A" !== who() ? " hidden" : ""}><li><b>1. 迎峰度夏重点工程采购批次2026-08流标：</b>距要求到货仅剩18天，按常规重新采购预计晚5天；建议今日16:00前确认加急采购方式或并入最近可执行批次。</li><li><b>2. 重庆北部500千伏输变电工程关键物资到货：</b>主变压器尚未确认发货，10千伏开关柜和电力电缆交期存在不确定性；建议今日确认主变发货时间并准备两类物资替代来源。</li><li><b>3. 南岸配网工程电力电缆抽检不合格：</b>质量抽检单Q-2026-071仍待确认复检与退换货方案；建议今日15:30前完成处置，避免影响8月20日施工备料。</li><li><b>4. 忠县石拔南线#22滑坡应急：</b>23项需求已完成多渠道寻源，OPGW光缆等3项方案差异等待确认；建议确认后立即生成寻源报告并启动调拨。</li></ol></section><div class="homebrief-root-grid"><button class="homebrief-root-card new ${o() ? "unread" : ""}" data-homebrief-root="new"><b>${t.new}</b><strong>新增任务</strong><span>${o() ? "刚刚发现，待查看" : "持续感知业务变化"}</span></button><button class="homebrief-root-card focus" data-homebrief-root="focus"><b>${t.focus}</b><strong>重点事项</strong><span>保障、时限与风险异常</span></button><button class="homebrief-root-card" data-homebrief-root="general"><b>${t.general}</b><strong>一般事项</strong><span>按业务类型和状态筛选</span></button><button class="homebrief-root-card" data-homebrief-root="follow"><b>${t.follow}</b><strong>我的关注</strong><span>项目、订单和自动跟踪</span></button></div></div>`;
          /* 高频场景账号的重点事项摘要由 scene-flows.js 给出 */
          const sx = "function" == typeof window.SCENE_SUMMARY ? window.SCENE_SUMMARY(who()) : "";
          return sx ? out.replace(/<section class="homebrief-analysis[\s\S]*?<\/section>/, sx) : out;
        }
        function p(e) {
          const first = e[0] || {}, last = e[e.length - 1] || {}, back = first.back || "summary", backLabel = first.back ? `返回${t(first.label)}` : "返回今日简报";
          return `<div class="homebrief-breadcrumb approvedui-backbar"><button class="approvedui-back-button" data-homebrief-back="${back}">← ${backLabel}</button>${last.label ? `<strong>${t(last.label)}</strong>` : ""}</div>`;
        }
        function g(a) {
          /* 高频场景账号的分类页由 v90.js 给出（window.SCENE_ROOT） */
          const sr = "function" == typeof window.SCENE_ROOT ? window.SCENE_ROOT(a, who(), p) : "";
          if (sr) return sr;
          const n = (function (t) {
              const e = {};
              return (
                d(t).forEach((t) => {
                  ((e[t.cat] = e[t.cat] || []), e[t.cat].push(t));
                }),
                e
              );
            })(a),
            s = d(a).length,
            r =
              "focus" === a
                ? "重点事项优先展示保障、时限和风险异常业务"
                : "general" === a
                  ? "按状态筛选后，各业务类型数量实时联动"
                  : "用户主动关注和智能体持续跟踪事项";
          return `<div class="homebrief-panel approvedui-brief-root approvedui-brief-root-${a}">${p([{ label: c(a) }])}<div class="homebrief-panel-head"><div><h3>${c(a)} · ${s}项</h3><p>${r}</p></div></div>${(function (
            t,
          ) {
            if ("new" === t || "follow" === t) return "";
            const a = v(t),
              n = {
                all: a.length,
                pending: a.filter((t) => "pending" === t.status).length,
                running: a.filter((t) => "running" === t.status).length,
                external: a.filter((t) => "external" === t.status).length,
                done: a.filter((t) => "done" === t.status).length,
              };
            return `<div class="homebrief-filter-row">${Object.keys(e)
              .map(
                (t) =>
                  `<button class="${state.homebriefBrief.filter === t ? "active" : ""}" data-homebrief-filter="${t}">${e[t]}<b>${n[t]}</b></button>`,
              )
              .join("")}</div>`;
          })(a)}${
            s
              ? `<div class="homebrief-category-grid approvedui-category-count-${Object.keys(n).length}">${Object.entries(n)
                  .map(
                    ([e, a]) =>
                      `<button class="homebrief-category-card" data-homebrief-category="${t(e)}"><div class="top"><strong>${t(e)}</strong><b>${a.length}</b></div><p>${t(a[0].title)}</p><small>${t(a[0].remain)}｜${t(a[0].risk)}</small></button>`,
                  )
                  .join("")}</div>`
              : '<div class="homebrief-empty"><strong>当前筛选条件下暂无事项</strong>切换“全部”查看完整业务分类</div>'
          }</div>`;
        }
        function b(e) {
          return `<button class="homebrief-task-row${e.__emlog ? " em-row-done" : ""}" data-homebrief-task="${e.id}"><div class="top"><strong>${t(e.title)}</strong><em class="${e.reason.includes("风险") || e.id.startsWith("F") ? "risk" : ""}">${t(e.reason)}</em></div><p>${t(e.object)}｜${t(e.current)}</p><div class="meta"><span>截止：<b>${t(e.deadline)}</b></span><span>时间：<b>${t(e.remain)}</b></span><span>风险：<b>${t(e.risk)}</b></span>${"function" == typeof window.execModeBadge ? window.execModeBadge(e) : ""}</div></button>`;
        }
        function m(t) {
          return [...a, ...n, ...r, ...(ext("general") || []), ...(ext("follow") || [])].find((e) => e.id === t);
        }
        window.homeBriefFind = m;
        const $ = window.briefnavPanelMarkup;
        function refreshHomeBrief() {
          if ("function" == typeof briefnavRerender) briefnavRerender();
          else {
            const t = document.getElementById("normalBriefCard");
            t &&
              (t.outerHTML = briefdrillBriefMarkup(
                t.classList.contains("livebrief-intro"),
                !1,
              ));
          }
        }
        window.homeBriefRefresh = refreshHomeBrief;
        function k() {
          document
            .querySelectorAll(
              "#emergencyHomeBanner,.emergency-home-banner,.taskcenter-home-emergency",
            )
            .forEach((t) => t.remove());
        }
        ((window.homebriefSummaryMarkup = f),
          (window.briefdrillSummaryMarkup = f),
          (window.briefnavPanelMarkup = function () {
            const e = state.briefnavHome.level;
            return "summary" === e || "homebrief-summary" === e
              ? `<div class="briefnav-panel">${f()}</div>`
              : "homebrief-root" === e
                ? g(state.homebriefBrief.root)
                : "homebrief-new" === e
                  ? (function () {
                      const t = o() ? a.find((t) => "FNEW" === t.id) : null;
                      return `<div class="homebrief-panel">${p([{ label: "新增任务" }])}${t ? `<div class="homebrief-panel-head"><div><h3>新增任务 · 1项</h3><p>已同步纳入重点事项和对应业务分类</p></div></div>${b(t)}` : '<div class="homebrief-empty"><strong>暂无新增任务</strong>智能体正在持续感知任务、工单和业务系统变化</div>'}</div>`;
                    })()
                  : "homebrief-list" === e
                    ? (function (e, a) {
                        const n = d(e).filter((t) => t.cat === a);
                        return `<div class="homebrief-panel">${p([{ label: c(e), back: "root" }, { label: a }])}<div class="homebrief-panel-head"><div><h3>${t(a)} · ${n.length}项</h3><p>查看事项进度、风险和办理动作</p></div></div><div class="homebrief-task-list">${n.map(b).join("")}</div></div>`;
                      })(state.homebriefBrief.root, state.homebriefBrief.category)
                    : "homebrief-task" === e
                      ? (function () {
                          const e = m(state.homebriefBrief.task) || a[0];
                          /* 高频场景事项的详情页由 v90.js 给出（window.SCENE_TASK_DETAIL） */
                          const sd = "function" == typeof window.SCENE_TASK_DETAIL ? window.SCENE_TASK_DETAIL(e, p, c(state.homebriefBrief.root)) : "";
                          if (sd) return sd;
                          const stages = /工单/.test(e.cat) ? ["异常识别","原因分析","办理","规则优化","运行跟踪"] : /应急|调拨|协同/.test(e.title) ? ["需求确认","资源寻源","方案比对","人工确认","结果回写"] : /质量|抽检/.test(e.title) ? ["异常识别","证据核验","规则判断","处置确认","结果回写"] : /订单|履约|发货/.test(e.title) ? ["订单确认","履约跟踪","风险识别","交付确认","到货闭环"] : ["事项确认","风险研判","方案生成","人工确认","执行闭环"];
                          const currentStage = "done" === e.status ? 4 : "running" === e.status ? 2 : /工单/.test(e.cat) ? 1 : 3;
                          const why = `${e.current}。${e.risk}；${e.impact}`;
                          return `<div class="homebrief-panel">${p([{ label: c(state.homebriefBrief.root), back: "new" === state.homebriefBrief.root ? "new" : "root" }, { label: e.cat, back: "list" }, { label: e.title }])}<article class="homebrief-detail approvedui-task-detail"><div class="approvedui-task-head"><strong>${t(e.title)}</strong><span>${"general" === state.homebriefBrief.root ? "一般事项" : "follow" === state.homebriefBrief.root ? "我的关注" : "重点事项"}</span></div><div class="approvedui-task-grid"><section class="approvedui-task-block"><h4>为什么需要处理</h4><p>${t(why)}</p></section><section class="approvedui-task-block"><h4>AI分析</h4><div class="approvedui-task-list"><span>业务对象：${t(e.object)}</span><span>当前环节：${t(e.current)}</span><span>时限判断：${t(e.deadline)}｜${t(e.remain)}</span></div><em class="approvedui-ai">已核验业务状态、时限和上下游影响</em></section><section class="approvedui-task-block"><h4>建议操作</h4><p>${t(e.advice)}</p><em class="approvedui-ai">建议结合当前权限和流程影响生成</em></section></div><div class="approvedui-task-stage">${stages.map((x,i)=>`<span class="${i < currentStage ? "done" : i === currentStage ? "current" : ""}">${t(x)}</span>`).join("")}</div>${"function" == typeof window.execModesBlock ? window.execModesBlock(e) : ""}<div class="approvedui-task-actions"><button data-homebrief-action="detail">查看处理过程</button>${/工单/.test(e.cat) ? "" : '<button data-homebrief-action="remind">立即催办</button>'}${!/工单/.test(e.cat) && "general" !== state.homebriefBrief.root && "follow" !== state.homebriefBrief.root ? '<button class="warn" data-homebrief-action="escalate">升级督办</button>' : ""}<button class="primary" data-homebrief-action="dialog">去办理</button></div></article></div>`;
                        })()
                      : $();
          }),
          (window.briefdrillBriefMarkup = function (t = !1, e) {
            const a = "closed" !== state.briefnavHome.level,
              n = `normal-brief-card livebrief-brief-card briefnav-brief briefdrill-brief agentcatalog-brief homebrief-brief ${t ? "livebrief-intro" : "livebrief-docked"} ${(void 0 === e ? !t && !a : !!e) ? "collapsed" : ""} ${a ? "livebrief-filter-open" : ""}`,
              s = l(),
              r = o() && !state.sensingstateSenseAcknowledged,
              i =
                t && "closed" === state.briefnavHome.level
                  ? `<div class="briefnav-panel">${f()}</div>`
                  : briefnavPanelMarkup();
            return `<section class="${n}" id="normalBriefCard"><div class="normal-brief-head"><div class="normal-brief-bot" data-briefnav-title>${icons("i-bot")}</div><div class="normal-brief-title" data-briefnav-title><strong>今日简报</strong><span>${s.focus + s.general}项业务事项 · ${s.focus}项重点 · ${s.follow}项关注</span></div><button type="button" class="livebrief-brief-status briefdrill-sense-btn ${r ? "sensingstate-new-task" : ""}" id="livebriefBriefStatus" data-sensingstate-sense><i></i><span>${o() ? "发现1项新任务" : "智能体持续感知中"}</span></button><div class="normal-brief-mini">${u("new", "新增任务", s.new, "homebrief-new " + (r ? "unread" : ""))}${u("focus", "重点事项", s.focus, "urgent")}${u("general", "一般事项", s.general)}${u("follow", "我的关注", s.follow)}</div><button class="normal-brief-chevron" data-briefnav-title aria-label="展开或收起今日简报">${icons("i-down")}</button></div><div class="normal-brief-body">${i}</div></section>`;
          }),
          (window.briefnavBriefMarkup = briefdrillBriefMarkup),
          (window.workbriefBriefMarkup = briefdrillBriefMarkup),
          (window.briefshellBriefMarkup = briefdrillBriefMarkup),
          (window.livebriefBriefMarkup = briefdrillBriefMarkup),
          (window.notificationsNormalBriefMarkup = () => briefdrillBriefMarkup(!1, !0)),
          (window.briefbootUpdateBriefInPlace = function () {
            const t = document.getElementById("normalBriefCard");
            if (!t) return;
            const e = l(),
              a = t.querySelector(".normal-brief-title span");
            a &&
              (a.textContent = `${e.focus + e.general}项业务事项 · ${e.focus}项重点 · ${e.follow}项关注`);
            const n = t.querySelector("#livebriefBriefStatus");
            if (n) {
              const t = o() && !state.sensingstateSenseAcknowledged;
              n.classList.toggle("sensingstate-new-task", t);
              const e = n.querySelector("span");
              e && (e.textContent = o() ? "发现1项新任务" : "智能体持续感知中");
            }
            [
              ["new", e.new],
              ["focus", e.focus],
              ["general", e.general],
              ["follow", e.follow],
            ].forEach(([e, a]) => {
              const n = t.querySelector(`[data-homebrief-root="${e}"] b`);
              n && (n.textContent = String(a));
            });
            const s = t.querySelector('[data-homebrief-root="new"]');
            if (
              (s &&
                s.classList.toggle(
                  "unread",
                  o() && !state.sensingstateSenseAcknowledged,
                ),
              "closed" !== state.briefnavHome.level)
            ) {
              const e = t.querySelector(".normal-brief-body");
              e && (e.innerHTML = briefnavPanelMarkup());
            }
          }),
          document.addEventListener(
            "click",
            (t) => {
              const e = t.target.closest("[data-homebrief-root]");
              if (e) {
                (t.preventDefault(), t.stopImmediatePropagation());
                const a = e.dataset.homebriefRoot;
                return (
                  (state.homebriefBrief.root = a),
                  (state.homebriefBrief.filter = "all"),
                  (state.homebriefBrief.category = ""),
                  (state.homebriefBrief.task = ""),
                  "new" === a && !("function" == typeof window.__v94FocusAdd && window.__v94FocusAdd(who()))
                    ? ((state.sensingstateSenseAcknowledged = !0),
                      (state.briefnavHome.level = "homebrief-new"))
                    : (state.briefnavHome.level = "homebrief-root"),
                  (state.briefnavHome.root = a),
                  void refreshHomeBrief()
                );
              }
              const a = t.target.closest("[data-homebrief-filter]");
              if (a)
                return (
                  t.preventDefault(),
                  t.stopImmediatePropagation(),
                  (state.homebriefBrief.filter = a.dataset.homebriefFilter),
                  (state.homebriefBrief.category = ""),
                  (state.homebriefBrief.task = ""),
                  (state.briefnavHome.level = "homebrief-root"),
                  void refreshHomeBrief()
                );
              const n = t.target.closest("[data-homebrief-category]");
              if (n) {
                (t.preventDefault(),
                  t.stopImmediatePropagation(),
                  (state.homebriefBrief.category = n.dataset.homebriefCategory));
                const e = d(state.homebriefBrief.root).filter(
                  (t) => t.cat === state.homebriefBrief.category,
                );
                return (
                  1 === e.length
                    ? ((state.homebriefBrief.task = e[0].id),
                      (state.briefnavHome.level = "homebrief-task"))
                    : (state.briefnavHome.level = "homebrief-list"),
                  void refreshHomeBrief()
                );
              }
              const s = t.target.closest("[data-homebrief-task]");
              if (s) {
                (t.preventDefault(),
                  t.stopImmediatePropagation(),
                  (state.homebriefBrief.task = s.dataset.homebriefTask));
                const e = m(state.homebriefBrief.task);
                return (
                  e && (state.homebriefBrief.category = e.cat),
                  (state.briefnavHome.level = "homebrief-task"),
                  void refreshHomeBrief()
                );
              }
              const r = t.target.closest("[data-homebrief-back]");
              if (r) {
                (t.preventDefault(), t.stopImmediatePropagation());
                const e = r.dataset.homebriefBack;
                if ("summary" === e)
                  ((state.homebriefBrief.root = "summary"),
                    (state.briefnavHome.level = "summary"));
                else if ("root" === e)
                  state.briefnavHome.level =
                    "new" === state.homebriefBrief.root ? "homebrief-new" : "homebrief-root";
                else if ("new" === e) state.briefnavHome.level = "homebrief-new";
                else if ("list" === e) {
                  const t = d(state.homebriefBrief.root).filter(
                    (t) => t.cat === state.homebriefBrief.category,
                  ).length;
                  state.briefnavHome.level = t > 1 ? "homebrief-list" : "homebrief-root";
                }
                return void refreshHomeBrief();
              }
              const o = t.target.closest("[data-homebrief-action]");
              if (o) {
                (t.preventDefault(), t.stopImmediatePropagation());
                const e = m(state.homebriefBrief.task);
                if (!e) return;
                const a = o.dataset.homebriefAction;
                if ("remind" === a)
                  showToast(`已向“${e.title}”当前责任方发送智能催办`);
                else if ("escalate" === a)
                  showToast(`“${e.title}”已升级督办并同步发起人`);
                else if ("detail" === a)
                  showToast(`已定位“${e.current}”流程环节`);
                else if ("dialog" === a) {
                  if ("function" == typeof window.execThreadOpen && window.execThreadOpen(e.id)) return;
                  ((state.briefnavHome.level = "closed"), refreshHomeBrief());
                  const t = document.getElementById("chatInput");
                  t && ((t.value = `分析并推进：${e.title}`), sendChat());
                }
                return;
              }
            },
            !0,
          ),
          document.addEventListener(
            "four-analysis-lifecycle-change",
            () => {
              syncFourAnalysisHomeFollow();
              refreshHomeBrief();
            },
          ),
          k(),
          new MutationObserver(k).observe(document.body, {
            childList: !0,
            subtree: !0,
          }));
        ((document.title = "供应链智慧工作台"),
          requestAnimationFrame(() => {
            (k(),
              "chat" === state.view &&
                "function" == typeof briefbootRenderConversation &&
                briefbootRenderConversation(!0));
          }));
      })();
