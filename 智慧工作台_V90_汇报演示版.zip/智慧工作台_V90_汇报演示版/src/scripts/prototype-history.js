/* Source runtime block 3 */
let assistantbriefButlerMode = !0,
        assistantbriefQuestionSeq = 0,
        assistantbriefQuestions = [],
        assistantbriefActiveQuestion = 0,
        assistantbriefButlerFilter = "all";
      const assistantbriefButlerTasks = [
        {
          id: "T1",
          title: "忠县滑坡应急物资保障",
          type: "应急物资",
          code: "YJ202508105396-01",
          status: "紧急",
          statusClass: "urgent",
          reason:
            "二次确认后仍有1类物资存在缺口，需要确认是否启用在建资源备选方案。",
          deadline: "今天10:30",
          remain: "剩余42分钟",
          remainClass: "urgent",
          expanded: !1,
          selected: !1,
          why: "现有来源二次确认数量发生变化，继续执行会产生0.4千米光缆缺口，已超出经办人员自动调整权限。",
          analysis: [
            "已匹配长寿供电分公司在建资源0.4千米",
            "启用后23条物资可完整覆盖",
            "最晚到货预计由14:00延后至16:00",
          ],
          suggest: "接受在建资源补足方案，暂不启动应急采购。",
          progress: [
            "需求确认",
            "资源寻源",
            "二次确认",
            "方案调整",
            "执行回写",
          ],
          progressDone: 3,
          progressCurrent: 3,
        },
        {
          id: "T2",
          title: "年度投资计划调整审批",
          type: "投资管理",
          code: "INV-2026-0723-018",
          status: "高风险",
          statusClass: "risk",
          reason:
            "调整金额较大且超出授权范围，需要管理层完成综合效益与风险确认。",
          deadline: "今天18:00",
          remain: "剩余8小时",
          remainClass: "soon",
          expanded: !1,
          selected: !1,
          why: "本次计划调整涉及3个项目、预算增加10.8%，需要在风险可控的前提下确认最终方案。",
          analysis: [
            "调整后投资回报率预计提升8.7%",
            "符合年度预算调整框架",
            "主要风险为市场波动与供应链不确定性",
          ],
          suggest: "接受调整方案，并要求项目组补充月度风险跟踪。",
          progress: [
            "材料核验",
            "财务复核",
            "专业会签",
            "管理审批",
            "计划下达",
          ],
          progressDone: 3,
          progressCurrent: 3,
        },
        {
          id: "T3",
          title: "供应商合同到期续签审核",
          type: "合同管理",
          code: "PUR-2026-0723-097",
          status: "待确认",
          statusClass: "confirm",
          reason:
            "核心供应商合同即将到期，智能体已完成履约评价并生成续签建议。",
          deadline: "明天12:00",
          remain: "剩余1天2小时",
          remainClass: "soon",
          expanded: !1,
          selected: !1,
          why: "该供应商承担两类关键物资，合同中断会影响后续框架采购执行。",
          analysis: [
            "近12个月履约率96.8%",
            "质量问题闭环率100%",
            "建议续签1年并增加交付时效约束",
          ],
          suggest: "同意续签，并采用智能体推荐的补充条款。",
          progress: [
            "履约分析",
            "风险核验",
            "条款生成",
            "续签确认",
            "合同归档",
          ],
          progressDone: 2,
          progressCurrent: 2,
        },
        {
          id: "T4",
          title: "费用报销异常单据复核",
          type: "财务管理",
          code: "FIN-2026-0723-142",
          status: "处理中",
          statusClass: "running",
          reason:
            "检测到3笔异常报销记录，智能体已完成凭证比对，等待人工复核结论。",
          deadline: "后天17:00",
          remain: "剩余2天7小时",
          remainClass: "",
          expanded: !1,
          selected: !1,
          why: "单据金额与合同付款节点存在差异，自动规则无法直接判定是否属于合理补充费用。",
          analysis: [
            "3笔单据合计18.6万元",
            "2笔可由补充材料解释",
            "1笔建议退回重新核验",
          ],
          suggest: "先核验金额最大的单据，其余两笔补充附件后放行。",
          progress: [
            "异常识别",
            "凭证比对",
            "规则校验",
            "人工复核",
            "结果回写",
          ],
          progressDone: 3,
          progressCurrent: 3,
        },
        {
          id: "T5",
          title: "信息化系统升级评估",
          type: "信息化管理",
          code: "IT-2026-0723-021",
          status: "等待外部",
          statusClass: "waiting",
          reason:
            "厂商兼容性测试报告尚未返回，当前无需您介入，智能体会持续跟踪。",
          deadline: "本周五",
          remain: "等待厂商报告",
          remainClass: "",
          expanded: !1,
          selected: !1,
          why: "系统升级涉及统一权限与供应链接口，需要外部厂商确认兼容性后才能形成最终结论。",
          analysis: [
            "已完成内部环境影响评估",
            "兼容性测试已发起",
            "预计厂商今日16:00前返回",
          ],
          suggest: "继续等待外部报告，超时后由智能体自动催办。",
          progress: [
            "范围确认",
            "内部评估",
            "厂商测试",
            "升级决策",
            "计划执行",
          ],
          progressDone: 2,
          progressCurrent: 2,
        },
        {
          id: "T6",
          title: "应急需求定时扫描异常",
          type: "平台运行",
          code: "RUN-2026-0723-009",
          status: "需接管",
          statusClass: "risk",
          reason:
            "业务接口连续调用失败2次，已进入自动重试，若再次失败需平台运营人员处理。",
          deadline: "5分钟内",
          remain: "第3次重试中",
          remainClass: "urgent",
          expanded: !1,
          selected: !1,
          why: "应急需求扫描接口连续返回网关超时，可能影响新应急任务自动接收。",
          analysis: [
            "已完成2次退避重试",
            "异常已通知平台运营人员",
            "备用接口可在主接口再次失败后切换",
          ],
          suggest: "授权失败后自动切换备用接口，并保留原链路追踪。",
          progress: [
            "定时触发",
            "接口扫描",
            "自动重试",
            "备用切换",
            "恢复确认",
          ],
          progressDone: 2,
          progressCurrent: 2,
        },
      ];
      function assistantbriefEsc(t) {
        return String(t ?? "").replace(
          /[&<>\"]/g,
          (t) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[t],
        );
      }
      function assistantbriefTaskCard(t) {
        const e = t.progress
          .map(
            (e, s) =>
              `<div class="butler-progress-step ${s < t.progressDone ? "done" : s === t.progressCurrent ? "current" : ""}">${assistantbriefEsc(e)}</div>`,
          )
          .join("");
        return `<article class="butler-task-card ${t.expanded ? "expanded" : ""} ${t.selected ? "selected" : ""} ${t.resolved ? "resolved" : ""}" data-butler-card="${t.id}">\n  <div class="butler-task-main" data-butler-toggle="${t.id}">\n   <input class="butler-check" type="checkbox" ${t.selected ? "checked" : ""} data-butler-select="${t.id}" aria-label="选择${assistantbriefEsc(t.title)}"/>\n   <div class="butler-task-copy"><div class="butler-task-titleline"><span class="butler-task-title">${assistantbriefEsc(t.title)}</span><span class="butler-status ${t.statusClass}">${assistantbriefEsc(t.status)}</span></div><div class="butler-task-code">${assistantbriefEsc(t.type)} · ${assistantbriefEsc(t.code)}</div><div class="butler-task-reason">${assistantbriefEsc(t.reason)}</div></div>\n   <div class="butler-task-deadline"><strong class="${t.remainClass}">${assistantbriefEsc(t.remain)}</strong><span>${assistantbriefEsc(t.deadline)}</span></div>\n   <button class="butler-chevron" data-butler-toggle="${t.id}" aria-label="展开或收起">${icons("i-down")}</button>\n  </div>\n  <div class="butler-task-expand">\n   <div class="butler-detail-grid">\n    <section class="butler-detail-cell"><h4>为什么需要您处理</h4><p>${assistantbriefEsc(t.why)}</p></section>\n    <section class="butler-detail-cell"><h4>AI分析</h4><div class="butler-detail-list">${t.analysis.map((t) => `<span><i></i>${assistantbriefEsc(t)}</span>`).join("")}</div><span class="butler-ai-tag">AI分析可信度 92%</span></section>\n    <section class="butler-detail-cell"><h4>建议操作</h4><p>${assistantbriefEsc(t.suggest)}</p><span class="butler-ai-tag">建议已结合权限与业务影响</span></section>\n   </div>\n   <div class="butler-progress">${e}</div>\n   <div class="butler-card-actions"><button class="btn primary sm" data-butler-action="accept" data-task-id="${t.id}">接受AI建议</button><button class="btn sm" data-butler-action="detail" data-task-id="${t.id}">查看业务详情</button><button class="btn sm" data-butler-action="adjust" data-task-id="${t.id}">调整处理方案</button></div>\n  </div>\n </article>`;
      }
      function assistantbriefRenderTaskList() {
        const t = $("#assistantbriefTaskList");
        if (!t) return;
        const e =
          "manual" === assistantbriefButlerFilter
            ? assistantbriefButlerTasks.filter((t) =>
                ["urgent", "risk", "confirm"].includes(t.statusClass),
              )
            : assistantbriefButlerTasks;
        t.innerHTML = e.map(assistantbriefTaskCard).join("");
        const s = assistantbriefButlerTasks.filter((t) => t.selected),
          a = $("#assistantbriefSelectBar");
        a &&
          (a.classList.toggle("show", s.length > 0),
          (a.querySelector("[data-selected-count]").textContent = s.length));
        const i = $("#assistantbriefVisibleCount");
        i && (i.textContent = `当前展示 ${e.length} 项`);
      }
      function assistantbriefRenderButlerHome() {
        ((assistantbriefButlerMode = !0),
          (assistantbriefQuestions = []),
          (assistantbriefQuestionSeq = 0),
          (assistantbriefActiveQuestion = 0),
          setView("chat"));
        ($("#view-chat").classList.add("butler-active"),
          $("#emergencyHomeBanner")?.classList.add("hidden"),
          hideEmergencyHomeNotice());
        const t = $("#chatThread");
        ((t.innerHTML = `<div class="butler-home">\n  <div class="butler-intro"><div class="butler-avatar">${icons("i-bot")}</div><div class="butler-brief"><div class="butler-brief-head"><div><h2>今日简报</h2><p>早上好，张伟。我已汇总并分析您权限范围内的跨专业工单、应急任务和风险预警。当前有3项需要您优先决策。</p></div><span class="butler-brief-time">今日 09:32</span></div>\n   <div class="butler-summary"><div class="butler-summary-item"><div class="butler-summary-icon alert">${icons("i-alert")}</div><div class="butler-summary-copy"><span>需要立即处理</span><b>3</b><small>项</small></div></div><div class="butler-summary-item"><div class="butler-summary-icon warn">${icons("i-clock")}</div><div class="butler-summary-copy"><span>建议今日处理</span><b>7</b><small>项</small></div></div><div class="butler-summary-item"><div class="butler-summary-icon neutral">${icons("i-refresh")}</div><div class="butler-summary-copy"><span>等待外部响应</span><b>8</b><small>项</small></div></div><div class="butler-summary-item"><div class="butler-summary-icon">${icons("i-bot")}</div><div class="butler-summary-copy"><span>智能体自动处理中</span><b>24</b><small>项</small></div></div></div>\n   <div class="butler-overview-note"><b>AI总体判断：</b>忠县滑坡应急任务和年度投资计划调整会阻塞后续流程，建议优先处理；其余事项可按截止时间依次推进。每张卡片可独立展开、收起和选择。</div></div></div>\n  <div class="butler-followup"><button data-butler-prompt="只看必须由我处理的任务">只看必须由我处理</button><button data-butler-prompt="比较当前最紧急的三个任务">比较最紧急的三个</button><button data-butler-prompt="汇总我选中的任务并给出处理顺序">分析已选择任务</button></div>\n  <div class="butler-selectbar" id="assistantbriefSelectBar"><span>已选择 <b data-selected-count>0</b> 项，可继续在对话中比较、排序或生成处理建议。</span><div class="butler-selectbar-actions"><button class="btn sm" data-butler-batch="analyze">批量分析</button><button class="btn sm" data-butler-batch="today">加入今日清单</button><button class="btn sm" data-butler-batch="clear">取消选择</button></div></div>\n  <div class="butler-task-list" id="assistantbriefTaskList"></div>\n </div>`),
          assistantbriefRenderTaskList(),
          ($("#crumb").innerHTML = "<b>智慧工作台</b> / 今日简报"));
        const e = $('#recentList [data-recent="0"]');
        (e && e.classList.add("active"),
          assistantbriefRenderQuestionRail(),
          (t.scrollTop = 0));
      }
      function assistantbriefRenderNormalHome() {
        ((assistantbriefButlerMode = !1),
          (assistantbriefQuestions = []),
          (assistantbriefQuestionSeq = 0),
          (assistantbriefActiveQuestion = 0),
          setView("chat"));
        ($("#view-chat").classList.remove("butler-active"),
          $("#emergencyHomeBanner")?.classList.remove("hidden"),
          ($("#chatThread").innerHTML =
            '<div class="chat-empty" id="chatEmpty"><div class="workspace-mark">智</div><div class="hello">有什么可以帮你？</div><div class="hello-sub">使用工具、技能和智能体完成复杂工作</div></div>'),
          ($("#crumb").innerHTML = "<b>智慧工作台</b> / 对话"),
          renderRecent(),
          assistantbriefRenderQuestionRail(),
          $$("[data-suggest]").forEach(
            (t) =>
              (t.onclick = () => {
                (($("#chatInput").value = t.dataset.suggest), sendChat());
              }),
          ),
          $$("#chatThread [data-view]").forEach(
            (t) => (t.onclick = () => setView(t.dataset.view)),
          ));
      }
      function assistantbriefEnsureRail() {
        let t = $("#assistantbriefQuestionRail");
        return (
          t ||
          ((t = document.createElement("aside")),
          (t.id = "assistantbriefQuestionRail"),
          (t.className = "question-rail"),
          (t.innerHTML =
            '<div class="question-rail-track" id="assistantbriefQuestionRailTrack"></div>'),
          $("#view-chat").appendChild(t),
          t)
        );
      }
      function assistantbriefRenderQuestionRail() {
        const t = assistantbriefEnsureRail(),
          e = $("#assistantbriefQuestionRailTrack");
        (t.classList.toggle("has-items", assistantbriefQuestions.length > 0),
          (e.innerHTML = assistantbriefQuestions
            .map(
              (t, e) =>
                `<button class="question-rail-mark ${e === assistantbriefActiveQuestion ? "active" : ""}" data-question-jump="${t.id}" aria-label="跳转到第${e + 1}问"><span class="question-rail-tip"><b>第${e + 1}问</b>${assistantbriefEsc(t.text.length > 42 ? t.text.slice(0, 42) + "…" : t.text)}</span></button>`,
            )
            .join("")));
      }
      function assistantbriefAddQuestion(t, e) {
        const s = "assistantbrief-question-" + ++assistantbriefQuestionSeq;
        return (
          (e.id = s),
          (e.dataset.questionAnchor = "true"),
          assistantbriefQuestions.push({ id: s, text: t }),
          (assistantbriefActiveQuestion = assistantbriefQuestions.length - 1),
          assistantbriefRenderQuestionRail(),
          s
        );
      }
      function assistantbriefUpdateActiveQuestion() {
        if (!assistantbriefQuestions.length) return;
        const t = $("#chatThread");
        let e = 0,
          s = 1 / 0;
        (assistantbriefQuestions.forEach((a, i) => {
          const n = document.getElementById(a.id);
          if (!n) return;
          const r = Math.abs(n.offsetTop - t.scrollTop - 120);
          r < s && ((s = r), (e = i));
        }),
          e !== assistantbriefActiveQuestion &&
            ((assistantbriefActiveQuestion = e), assistantbriefRenderQuestionRail()));
      }
      function assistantbriefReplyFor(t) {
        const e = assistantbriefButlerTasks.filter((t) => t.selected);
        let s =
          "我已结合当前任务状态、截止时间、业务影响和您的权限范围继续分析。";
        if (t.includes("只看") || t.includes("必须由我"))
          ((assistantbriefButlerFilter = "manual"),
            assistantbriefRenderTaskList(),
            (s =
              "已筛选出需要您本人决策或确认的事项。当前重点是应急资源补足、投资计划调整和合同续签审核。"));
        else if (t.includes("比较") || t.includes("优先级"))
          s =
            "综合业务阻塞程度、截止时间和影响范围，建议处理顺序为：①忠县滑坡应急物资保障；②应急需求定时扫描异常；③年度投资计划调整审批。";
        else if (t.includes("选中") || t.includes("选择"))
          s = e.length
            ? `您已选择${e.length}项：${e.map((t) => t.title).join("、")}。建议先处理其中会阻塞后续流程且剩余时间最短的事项。`
            : "当前尚未选择任务卡片。可勾选一项或多项后，让我进行对比、排序或批量分析。";
        else if (t.includes("展开")) {
          const e =
            assistantbriefButlerTasks.find((e) => t.includes(e.title.slice(0, 4))) ||
            assistantbriefButlerTasks[0];
          ((e.expanded = !0),
            assistantbriefRenderTaskList(),
            (s = `已展开“${e.title}”。卡片中已展示需要您处理的原因、AI分析、建议操作和当前业务进度。`));
        }
        return `<div class="message"><div class="avatar">智</div><div class="bubble assistant-copy"><div class="thinking"><span class="live-dot"></span>中枢智能体已完成分析</div>${assistantbriefEsc(s)}<div class="tool-call"><b>处理依据：</b>任务优先级、业务阻塞关系、截止时间、用户权限及当前处置状态。</div></div></div>`;
      }
      const assistantbriefOriginalStartChat = window.startChat;
      window.startChat = function (t) {
        const e = $("#chatThread"),
          s = assistantbriefEsc(t);
        if (assistantbriefButlerMode) {
          const a = document.createElement("div");
          return (
            (a.className = "message user"),
            (a.innerHTML = `<div class="avatar">我</div><div class="bubble">${s}</div>`),
            e.appendChild(a),
            assistantbriefAddQuestion(t, a),
            e.insertAdjacentHTML("beforeend", assistantbriefReplyFor(t)),
            void (e.scrollTop = e.scrollHeight)
          );
        }
        $("#chatEmpty") && $("#chatEmpty").classList.add("hidden");
        const a = document.createElement("div");
        ((a.className = "message user"),
          (a.innerHTML = `<div class="avatar">我</div><div class="bubble">${s}</div>`),
          e.appendChild(a),
          assistantbriefAddQuestion(t, a),
          e.insertAdjacentHTML(
            "beforeend",
            '<div class="message"><div class="avatar">智</div><div class="bubble assistant-copy"><div class="thinking"><span class="live-dot"></span>正在使用工具与技能</div>我已理解您的请求。当前为智慧工作台通用对话区，可调用工具、技能和专业智能体。涉及持续执行的复杂任务，可进入对应业务中心继续处理。<div class="tool-call"><b>路由判断：</b>普通问答留在当前对话；复杂业务按需调用专业智能体。</div></div></div>',
          ),
          (e.scrollTop = e.scrollHeight));
      };
      const assistantbriefOriginalShowEmergencyHomeNotice = window.showEmergencyHomeNotice;
      function assistantbriefInit() {
        (state.conversations.some((t) => t.assistantbriefButler) ||
          state.conversations.unshift({
            title: "今日简报",
            type: "智能管家",
            time: "08:55",
            messages: 1,
            live: !0,
            assistantbriefButler: !0,
          }),
          renderRecent(),
          renderChatTable(),
          assistantbriefEnsureRail(),
          assistantbriefRenderButlerHome(),
          $("#chatThread").addEventListener("scroll", assistantbriefUpdateActiveQuestion, {
            passive: !0,
          }),
          document.addEventListener(
            "click",
            (t) => {
              if (
                t.target.closest(
                  '.new-chat,#view-chats .btn.primary[data-view="chat"]',
                )
              )
                return (
                  t.preventDefault(),
                  t.stopImmediatePropagation(),
                  void assistantbriefRenderNormalHome()
                );
              const e = t.target.closest("[data-recent]");
              if (e) {
                const s = state.conversations[+e.dataset.recent];
                if (s?.assistantbriefButler)
                  return (
                    t.preventDefault(),
                    t.stopImmediatePropagation(),
                    void assistantbriefRenderButlerHome()
                  );
              }
              const s = t.target.closest("[data-question-jump]");
              if (s) {
                const t = document.getElementById(s.dataset.questionJump),
                  e = $("#chatThread"),
                  a = $("#view-chat");
                if (!t || !e || !e.contains(t) || !a?.classList.contains("active"))
                  return;
                const i =
                  t.getBoundingClientRect().top -
                  e.getBoundingClientRect().top +
                  e.scrollTop -
                  24;
                return (
                  e.scrollTo({ top: Math.max(0, i), behavior: "smooth" }),
                  t.classList.remove("question-anchor-flash"),
                  t.offsetWidth,
                  t.classList.add("question-anchor-flash"),
                  void 0
                );
              }
              const a = t.target.closest("[data-butler-prompt]");
              if (a)
                return (
                  ($("#chatInput").value = a.dataset.butlerPrompt),
                  void sendChat()
                );
              const i = t.target.closest("[data-butler-select]");
              if (i) {
                t.stopPropagation();
                const e = assistantbriefButlerTasks.find(
                  (t) => t.id === i.dataset.butlerSelect,
                );
                return void (
                  e && ((e.selected = i.checked), assistantbriefRenderTaskList())
                );
              }
              const n = t.target.closest("[data-butler-toggle]");
              if (n && !t.target.closest("button[data-butler-action]")) {
                const t = assistantbriefButlerTasks.find(
                  (t) => t.id === n.dataset.butlerToggle,
                );
                return void (
                  t && ((t.expanded = !t.expanded), assistantbriefRenderTaskList())
                );
              }
              const r = t.target.closest("[data-butler-action]");
              if (r) {
                const t = assistantbriefButlerTasks.find((t) => t.id === r.dataset.taskId);
                if (!t) return;
                const e = r.dataset.butlerAction;
                return void ("accept" === e
                  ? ((t.status = "已处理"),
                    (t.statusClass = "done"),
                    (t.resolved = !0),
                    (t.expanded = !1),
                    showToast(`已接受“${t.title}”的AI建议，操作已留痕`),
                    assistantbriefRenderTaskList())
                  : "detail" === e
                    ? "T1" === t.id
                      ? setView("emergency")
                      : showToast(`已打开“${t.title}”业务详情`)
                    : showToast(`已进入“${t.title}”方案调整`));
              }
              const o = t.target.closest("[data-butler-batch]");
              if (o) {
                const t = assistantbriefButlerTasks.filter((t) => t.selected);
                return "clear" === o.dataset.butlerBatch
                  ? (t.forEach((t) => (t.selected = !1)),
                    void assistantbriefRenderTaskList())
                  : void showToast(
                      "today" === o.dataset.butlerBatch
                        ? `已将${t.length}项加入今日处理清单`
                        : `已生成${t.length}项任务的对比分析`,
                    );
              }
              return t.target.closest("#assistantbriefCollapseAll")
                ? (assistantbriefButlerTasks.forEach((t) => (t.expanded = !1)),
                  void assistantbriefRenderTaskList())
                : t.target.closest("#assistantbriefFilterManual")
                  ? ((assistantbriefButlerFilter =
                      "manual" === assistantbriefButlerFilter ? "all" : "manual"),
                    (t.target.closest("#assistantbriefFilterManual").textContent =
                      "manual" === assistantbriefButlerFilter
                        ? "显示全部任务"
                        : "只看待我处理"),
                    void assistantbriefRenderTaskList())
                  : void 0;
            },
            !0,
          ));
      }
      ((window.showEmergencyHomeNotice = function (t = !1) {
        if (!assistantbriefButlerMode || t)
          return assistantbriefOriginalShowEmergencyHomeNotice
            ? assistantbriefOriginalShowEmergencyHomeNotice(t)
            : void 0;
      }),
        setTimeout(assistantbriefInit, 0));
      let briefcategoryButlerSummaryFilter = "";
      const briefcategoryCategoryMap = {
          immediate: ["T1", "T2", "T6"],
          today: ["T1", "T2", "T3", "T4"],
          external: ["T3", "T5"],
          auto: ["T4", "T5", "T6"],
        },
        briefcategoryCategoryMeta = {
          immediate: { title: "需要立即处理", note: "" },
          today: {
            title: "建议今日处理",
            note: "展示建议今天完成或推进的事项",
          },
          external: {
            title: "等待外部响应",
            note: "展示正在等待单位、供应商或厂商反馈的事项",
          },
          auto: {
            title: "智能体自动处理中",
            note: "展示当前由智能体持续执行、暂不需要您介入的事项",
          },
        };
      function briefcategorySummaryButton(t, e, s, a, i = "") {
        return `<button class="butler-summary-item ${briefcategoryButlerSummaryFilter === t ? "active" : ""}" data-butler-summary="${t}" aria-pressed="${briefcategoryButlerSummaryFilter === t}"><div class="butler-summary-icon ${i}">${icons(a)}</div><div class="butler-summary-copy"><span>${e}</span><b>${s}</b><small>项</small></div></button>`;
      }
      function assistantbriefRenderTaskList() {
        const t = $("#assistantbriefTaskList"),
          e = $("#briefcategoryTaskResults");
        if (!t || !e) return;
        if (!briefcategoryButlerSummaryFilter)
          return (e.classList.remove("show"), void (t.innerHTML = ""));
        e.classList.add("show");
        const s = briefcategoryCategoryMap[briefcategoryButlerSummaryFilter] || [],
          a = assistantbriefButlerTasks.filter((t) => s.includes(t.id));
        t.innerHTML = a.length
          ? a.map(assistantbriefTaskCard).join("")
          : '<div class="butler-empty-filter">当前分类暂无需要展示的事项。</div>';
        const i = briefcategoryCategoryMeta[briefcategoryButlerSummaryFilter],
          n = $("#briefcategoryFilterTitle"),
          r = $("#briefcategoryFilterNote");
        (n && (n.textContent = i?.title || "筛选结果"),
          r &&
            (r.textContent = `${i?.note || ""} · 当前展示 ${a.length} 个代表事项`));
        const o = assistantbriefButlerTasks.filter((t) => t.selected),
          l = $("#assistantbriefSelectBar");
        (l &&
          (l.classList.toggle("show", o.length > 0),
          (l.querySelector("[data-selected-count]").textContent = o.length)),
          $$(".butler-summary-item[data-butler-summary]").forEach((t) =>
            t.classList.toggle(
              "active",
              t.dataset.butlerSummary === briefcategoryButlerSummaryFilter,
            ),
          ));
      }
      function assistantbriefRenderButlerHome() {
        ((assistantbriefButlerMode = !0),
          (assistantbriefQuestions = []),
          (assistantbriefQuestionSeq = 0),
          (assistantbriefActiveQuestion = 0),
          (briefcategoryButlerSummaryFilter = ""),
          assistantbriefButlerTasks.forEach((t) => (t.expanded = !1)),
          setView("chat"));
        ($("#view-chat").classList.add("butler-active"),
          $("#emergencyHomeBanner")?.classList.add("hidden"),
          hideEmergencyHomeNotice());
        const t = $("#chatThread");
        ((t.innerHTML = `<div class="butler-home">\n  <div class="butler-intro"><div class="butler-avatar">${icons("i-bot")}</div><div class="butler-brief"><div class="butler-brief-head"><div><h2>今日简报</h2><p>早上好，张伟。我已汇总您权限范围内的跨专业任务与工单。点击数字即可查看对应事项。</p></div><span class="butler-brief-time">今日 09:32</span></div>\n   <div class="butler-summary">${briefcategorySummaryButton("immediate", "需要立即处理", 3, "i-alert", "alert")}${briefcategorySummaryButton("today", "建议今日处理", 7, "i-clock", "warn")}${briefcategorySummaryButton("external", "等待外部响应", 8, "i-refresh", "neutral")}${briefcategorySummaryButton("auto", "智能体自动处理中", 24, "i-bot")}</div>\n   <div class="butler-overview-note"><b>AI简要建议：</b>优先处理会阻塞后续流程的3项事项；其余任务由智能体持续跟踪，出现状态变化时再提醒您。</div></div></div>\n  <section class="butler-result-shell" id="briefcategoryTaskResults">\n   <div class="butler-selectbar" id="assistantbriefSelectBar"><span>已选择 <b data-selected-count>0</b> 项，可继续在对话中比较、排序或生成处理建议。</span><div class="butler-selectbar-actions"><button class="btn sm" data-butler-batch="analyze">批量分析</button><button class="btn sm" data-butler-batch="today">加入今日清单</button><button class="btn sm" data-butler-batch="clear">取消选择</button></div></div>\n   <div class="butler-task-list" id="assistantbriefTaskList"></div>\n  </section>\n </div>`),
          assistantbriefRenderTaskList(),
          ($("#crumb").innerHTML = "<b>智慧工作台</b> / 今日简报"));
        const e = $('#recentList [data-recent="0"]');
        (e && e.classList.add("active"),
          assistantbriefRenderQuestionRail(),
          (t.scrollTop = 0));
      }
      function assistantbriefRenderQuestionRail() {
        const t = assistantbriefEnsureRail(),
          e = $("#assistantbriefQuestionRailTrack");
        (t.classList.toggle("has-items", assistantbriefQuestions.length > 0),
          (e.innerHTML = assistantbriefQuestions
            .map(
              (t, e) =>
                `<button class="question-rail-mark ${e === assistantbriefActiveQuestion ? "active" : ""}" data-question-jump="${t.id}" aria-label="跳转到第${e + 1}次提问"><span class="question-rail-tip"><b>第${e + 1}次提问</b>${assistantbriefEsc(t.text)}<small>点击跳转到该次提问</small></span></button>`,
            )
            .join("")));
      }
      function assistantbriefRenderQuestionRail() {
        const t = assistantbriefEnsureRail(),
          e = $("#assistantbriefQuestionRailTrack");
        const s = "chat" === state.view && assistantbriefQuestions.length > 0;
        (t.toggleAttribute("hidden", !s),
          t.classList.toggle("has-items", s));
        if (!s) return void (e.innerHTML = "");
        e.innerHTML = assistantbriefQuestions
            .map(
              (t, e) =>
                `<button class="question-rail-mark ${e === assistantbriefActiveQuestion ? "active" : ""}" data-question-jump="${t.id}" aria-label="${assistantbriefEsc(t.text)}" title="${assistantbriefEsc(t.text)}"><span class="question-rail-text">${assistantbriefEsc(t.text)}</span></button>`,
            )
            .join("");
      }
      document.addEventListener(
        "click",
        (t) => {
          const e = t.target.closest("[data-butler-summary]");
          if (e) {
            (t.preventDefault(), t.stopImmediatePropagation());
            const s = e.dataset.butlerSummary;
            return (
              (briefcategoryButlerSummaryFilter = briefcategoryButlerSummaryFilter === s ? "" : s),
              assistantbriefButlerTasks.forEach((t) => (t.expanded = !1)),
              assistantbriefRenderTaskList(),
              void (
                briefcategoryButlerSummaryFilter &&
                setTimeout(
                  () =>
                    $("#briefcategoryTaskResults")?.scrollIntoView({
                      behavior: "smooth",
                      block: "nearest",
                    }),
                  20,
                )
              )
            );
          }
          if (t.target.closest("#briefcategoryCloseFilter"))
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (briefcategoryButlerSummaryFilter = ""),
              assistantbriefRenderTaskList(),
              void $("#chatThread").scrollTo({ top: 0, behavior: "smooth" })
            );
        },
        !0,
      );
      let notificationsNormalBriefCollapsed = !0;
      function notificationsNormalBriefMetric(t, e, s, a = !1) {
        return `<button class="${a ? "urgent " : ""}${briefcategoryButlerSummaryFilter === t ? "active" : ""}" data-newbrief-filter="${t}" aria-pressed="${briefcategoryButlerSummaryFilter === t}"><b>${s}</b>${e}</button>`;
      }
      function notificationsNormalBriefMarkup() {
        return `<section class="normal-brief-card ${notificationsNormalBriefCollapsed ? "collapsed" : ""}" id="normalBriefCard"><div class="normal-brief-head"><div class="normal-brief-bot" data-normal-brief-toggle>${icons("i-bot")}</div><div class="normal-brief-title" data-normal-brief-toggle><strong>今日简报</strong><span>点击数字即可在当前对话中筛选任务，任务默认收起。</span></div><div class="normal-brief-mini">${notificationsNormalBriefMetric("immediate", "立即处理", 3, !0)}${notificationsNormalBriefMetric("today", "今日处理", 7)}${notificationsNormalBriefMetric("external", "等待响应", 8)}${notificationsNormalBriefMetric("auto", "自动处理", 24)}</div><button class="normal-brief-chevron" data-normal-brief-toggle aria-label="展开或收起今日简报">${icons("i-down")}</button></div><div class="normal-brief-body"><section class="butler-result-shell" id="briefcategoryTaskResults"><div class="butler-selectbar" id="assistantbriefSelectBar"><span>已选择 <b data-selected-count>0</b> 项，可继续在对话中比较、排序或生成处理建议。</span><div class="butler-selectbar-actions"><button class="btn sm" data-butler-batch="analyze">批量分析</button><button class="btn sm" data-butler-batch="today">加入今日清单</button><button class="btn sm" data-butler-batch="clear">取消选择</button></div></div><div class="butler-task-list" id="assistantbriefTaskList"></div></section></div></section>`;
      }
      function notificationsApplyNormalBriefFilter(t = "") {
        const e = $("#normalBriefCard");
        e &&
          ((briefcategoryButlerSummaryFilter = briefcategoryButlerSummaryFilter === t ? "" : t),
          assistantbriefButlerTasks.forEach((t) => (t.expanded = !1)),
          briefcategoryButlerSummaryFilter
            ? ((notificationsNormalBriefCollapsed = !1), e.classList.remove("collapsed"))
            : ((notificationsNormalBriefCollapsed = !0), e.classList.add("collapsed")),
          assistantbriefRenderTaskList(),
          $$("#normalBriefCard [data-newbrief-filter]").forEach((t) => {
            const e = t.dataset.newbriefFilter === briefcategoryButlerSummaryFilter;
            (t.classList.toggle("active", e),
              t.setAttribute("aria-pressed", String(e)));
          }));
      }
      function notificationsRenderNotificationCenter() {
        const t = $("#notificationPanel");
        t &&
          (t.innerHTML = `<div class="notification-panel-head"><div class="notification-panel-head-main"><strong>任务消息</strong><span>按总部、省公司、部门范围聚合 · 4条未读</span></div><button class="notification-settings-btn" data-notice-settings>${icons("i-settings")}提醒设置</button></div><div class="notification-list"><button class="notification-item unread" data-notice-target="workbench"><span class="notification-item-icon alert">${icons("i-alert")}</span><span class="notification-item-copy"><strong><i class="notice-scope-tag province">省公司级</i>应急方案待确认</strong><p>忠县滑坡应急任务最终资源组合已生成，需要您确认后回写原系统。</p></span><time>刚刚</time></button><button class="notification-item unread" data-notice-target="agents"><span class="notification-item-icon">${icons("i-activity")}</span><span class="notification-item-copy"><strong><i class="notice-scope-tag hq">总部级</i>攻坚任务运行异常</strong><p>供应链工单智能化任务有1个工具节点重试后仍未恢复。</p></span><time>2分钟前</time></button><button class="notification-item unread" data-notice-target="scheduled"><span class="notification-item-icon">${icons("i-clock")}</span><span class="notification-item-copy"><strong><i class="notice-scope-tag dept">部门级</i>审批工单即将超时</strong><p>年度投资计划调整审批剩余2小时15分钟，需要管理人员确认。</p></span><time>6分钟前</time></button><button class="notification-item unread" data-notice-target="emergency"><span class="notification-item-icon">${icons("i-refresh")}</span><span class="notification-item-copy"><strong><i class="notice-scope-tag province">省公司级</i>自动催办已执行</strong><p>智能体已对2个未响应对象完成越级催办，等待最新反馈。</p></span><time>8分钟前</time></button></div><div class="notification-panel-foot"><button data-notice-target="chat">查看全部任务消息</button><button data-notice-settings>自定义提醒范围</button></div>`);
      }
      function notificationsConfigurePopup() {
        const t = $("#emergencyNotifyCard");
        t &&
          (t.innerHTML = `<div class="emergency-notice-accent"></div><div class="emergency-notice-head"><div class="emergency-notice-heading"><span class="live-dot"></span>智能任务提醒 <span class="platform-notice-scope">省公司级</span></div><span class="emergency-notice-time">09:32</span><button class="emergency-notice-close" id="notificationsNoticeClose" aria-label="关闭提醒">${icons("i-x")}</button></div><div class="emergency-notice-body"><div class="emergency-notice-kicker">需要您决策</div><div class="emergency-notice-title">国网重庆忠县公司110kV石拔南线#22滑坡应急</div><div class="emergency-notice-sub">中枢智能体已聚合关联工单和寻源结果，当前最终资源组合需要您确认。</div><div class="emergency-notice-meta"><div><span>所属层级</span><strong>省公司级</strong></div><div><span>业务专业</span><strong>物资应急保障</strong></div><div><span>处理时限</span><strong>今日 10:30 前</strong></div><div><span>来源</span><strong>应急任务智能体</strong></div></div><div class="emergency-notice-progress"><span class="spinner"></span><div><strong>AI已完成前置处理</strong><p>23条物资已形成最终组合，二次确认已完成，等待您确认并进入执行衔接。</p></div></div></div><div class="emergency-notice-actions"><button class="btn primary" id="notificationsNoticeEnter">立即处理</button><button class="btn" id="notificationsNoticeLater">稍后处理</button><div class="platform-notice-links"><button id="notificationsNoticeAll">查看全部消息</button><button id="notificationsNoticeSettings">提醒设置</button></div></div>`);
      }
      function notificationsOpenNoticeSettings() {
        (openOverlay("notificationSettingsModal"),
          $("#notificationPanel")?.classList.remove("show"),
          $("#notificationBtn")?.classList.remove("open"));
      }
      function notificationsInit() {
        ($("#emergencyHomeBanner")?.remove(),
          notificationsRenderNotificationCenter(),
          notificationsConfigurePopup());
        const t = $("#notificationCount");
        (t && (t.textContent = "4"),
          setTimeout(() => showEmergencyHomeNotice(!0), 320),
          document.addEventListener(
            "click",
            (t) => {
              const e = t.target.closest("[data-newbrief-filter]");
              if (e)
                return (
                  t.preventDefault(),
                  t.stopImmediatePropagation(),
                  void notificationsApplyNormalBriefFilter(e.dataset.newbriefFilter)
                );
              if (t.target.closest("[data-normal-brief-toggle]")) {
                t.preventDefault();
                const e = $("#normalBriefCard");
                return (
                  (notificationsNormalBriefCollapsed =
                    !e?.classList.contains("collapsed")),
                  void e?.classList.toggle("collapsed")
                );
              }
              if (t.target.closest("[data-notice-settings],#notificationsNoticeSettings"))
                return (
                  t.preventDefault(),
                  t.stopImmediatePropagation(),
                  void notificationsOpenNoticeSettings()
                );
              if (t.target.closest("#notificationsNoticeClose,#notificationsNoticeLater"))
                return void $("#emergencyNotifyCard")?.classList.remove("show");
              if (t.target.closest("#notificationsNoticeEnter"))
                return (
                  $("#emergencyNotifyCard")?.classList.remove("show"),
                  $("#view-chat")?.classList.contains("hidden") &&
                    livebriefRenderConversation(!1),
                  void requestAnimationFrame(() => livebriefApplyFilter("immediate"))
                );
              if (t.target.closest("#notificationsNoticeAll"))
                return (
                  $("#emergencyNotifyCard")?.classList.remove("show"),
                  $("#notificationPanel")?.classList.add("show"),
                  void $("#notificationBtn")?.classList.add("open")
                );
              const s = t.target.closest("[data-notify-mode]");
              if (s)
                return (
                  t.preventDefault(),
                  void $$("#notifyUrgencyMode button").forEach((t) =>
                    t.classList.toggle("active", t === s),
                  )
                );
              if (t.target.closest("#saveNotificationSettings")) {
                const t = $$('input[name="notifyScope"]:checked').map(
                    (t) => t.value,
                  ),
                  e = $$('input[name="notifyType"]:checked').map(
                    (t) => t.value,
                  );
                return (
                  closeOverlay("notificationSettingsModal"),
                  void showToast(
                    `提醒设置已保存：${t.join("、")} · ${e.length}类任务`,
                  )
                );
              }
            },
            !0,
          ));
      }
      ((assistantbriefRenderNormalHome = function () {
        ((assistantbriefButlerMode = !1),
          (assistantbriefQuestions = []),
          (assistantbriefQuestionSeq = 0),
          (assistantbriefActiveQuestion = 0),
          (briefcategoryButlerSummaryFilter = ""),
          (notificationsNormalBriefCollapsed = !0),
          assistantbriefButlerTasks.forEach((t) => {
            ((t.expanded = !1), (t.selected = !1));
          }),
          setView("chat"));
        ($("#view-chat").classList.remove("butler-active"),
          $("#emergencyHomeBanner")?.classList.add("hidden"),
          ($("#chatThread").innerHTML =
            `${notificationsNormalBriefMarkup()}<div class="chat-empty" id="chatEmpty"><div class="workspace-mark">智</div><div class="hello">有什么可以帮你？</div><div class="hello-sub">使用工具、技能和智能体完成复杂工作</div></div>`),
          ($("#crumb").innerHTML = "<b>智慧工作台</b> / 对话"),
          renderRecent(),
          assistantbriefRenderQuestionRail(),
          assistantbriefRenderTaskList(),
          $$("[data-suggest]").forEach(
            (t) =>
              (t.onclick = () => {
                (($("#chatInput").value = t.dataset.suggest), sendChat());
              }),
          ),
          $$("#chatThread [data-view]").forEach(
            (t) => (t.onclick = () => setView(t.dataset.view)),
          ));
      }),
        (showEmergencyHomeNotice = function (t = !1) {
          const e = $("#emergencyNotifyCard");
          if (!e) return;
          let s = !1;
          try {
            s = !!sessionStorage.getItem("notifications-task-popup-seen");
          } catch (t) {}
          if (t || !s) {
            e.classList.add("show");
            try {
              sessionStorage.setItem("notifications-task-popup-seen", "1");
            } catch (t) {}
          }
        }),
        setTimeout(notificationsInit, 40));

/* Source runtime block 4 */
let livebriefIntroTimer = null,
        livebriefRefreshTimer = null,
        livebriefFirstEntryActive = !1,
        livebriefUpdateInjected = !1;
      const livebriefCounts = { immediate: 3, today: 7, external: 8, auto: 24 };
      function livebriefMetric(e, t, a = !1) {
        return `<button class="${a ? "urgent " : ""}${briefcategoryButlerSummaryFilter === e ? "active" : ""}" data-newbrief-filter="${e}" data-livebrief-metric="${e}" aria-pressed="${briefcategoryButlerSummaryFilter === e}"><b>${livebriefCounts[e]}</b>${t}</button>`;
      }
      function livebriefEmptyMarkup(e = !1) {
        return `<div class="chat-empty livebrief-chat-empty ${e ? "livebrief-awaiting" : ""}" id="chatEmpty"><div class="workspace-mark">智</div><div class="hello">有什么可以帮你？</div><div class="hello-sub">使用工具、技能和智能体完成复杂工作</div></div>`;
      }
      function livebriefBriefMarkup(e = !1) {
        return `<section class="${"normal-brief-card livebrief-brief-card " + (e ? "livebrief-intro" : "livebrief-docked collapsed")}" id="normalBriefCard"><div class="normal-brief-head"><div class="normal-brief-bot" data-normal-brief-toggle>${icons("i-bot")}</div><div class="normal-brief-title" data-normal-brief-toggle><strong>今日简报</strong><span>${e ? "早上好，张伟。我已完成您权限范围内跨专业任务、工单和风险预警的汇总分析。点击数字即可在当前页面查看对应事项。" : "点击数字即可在当前对话中筛选任务，任务默认收起。"}</span></div><span class="livebrief-brief-status" id="livebriefBriefStatus"><i></i><span>${e ? "已完成今日分析" : "智能体持续感知中"}</span></span><div class="normal-brief-mini">${livebriefMetric("immediate", "立即处理", !0)}${livebriefMetric("today", "今日处理")}${livebriefMetric("external", "等待响应")}${livebriefMetric("auto", "自动处理")}</div><button class="normal-brief-chevron" data-normal-brief-toggle aria-label="展开或收起今日简报">${icons("i-down")}</button></div><div class="normal-brief-body"><div class="livebrief-new-task-note" id="livebriefNewTaskNote">检测到1项新的省公司级应急任务，已纳入“立即处理”和“自动处理”统计。</div><section class="butler-result-shell" id="briefcategoryTaskResults"><div class="butler-selectbar" id="assistantbriefSelectBar"><span>已选择 <b data-selected-count>0</b> 项，可继续在对话中比较、排序或生成处理建议。</span><div class="butler-selectbar-actions"><button class="btn sm" data-butler-batch="analyze">批量分析</button><button class="btn sm" data-butler-batch="today">加入今日清单</button><button class="btn sm" data-butler-batch="clear">取消选择</button></div></div><div class="butler-task-list" id="assistantbriefTaskList"></div></section></div></section>`;
      }
      function livebriefBindSuggestions() {
        ($$("[data-suggest]").forEach(
          (e) =>
            (e.onclick = () => {
              (($("#chatInput").value = e.dataset.suggest), sendChat());
            }),
        ),
          $$("#chatThread [data-view]").forEach(
            (e) => (e.onclick = () => setView(e.dataset.view)),
          ));
      }
      function livebriefScheduleRefresh() {
        (clearTimeout(livebriefRefreshTimer),
          (livebriefRefreshTimer = setTimeout(livebriefInjectNewTask, 12e3)));
      }
      function livebriefRenderConversation(e = !1) {
        (clearTimeout(livebriefIntroTimer),
          clearTimeout(livebriefRefreshTimer),
          (assistantbriefButlerMode = !1),
          (assistantbriefQuestions = []),
          (assistantbriefQuestionSeq = 0),
          (assistantbriefActiveQuestion = 0),
          (briefcategoryButlerSummaryFilter = ""),
          (notificationsNormalBriefCollapsed = !e),
          (livebriefFirstEntryActive = e),
          assistantbriefButlerTasks.forEach((e) => {
            ((e.expanded = !1), (e.selected = !1));
          }),
          setView("chat"));
        const t = $("#view-chat");
        (t.classList.remove("butler-active"),
          t.classList.add("livebrief-conversation"),
          $("#emergencyHomeBanner")?.classList.add("hidden"));
        const a = $("#chatThread");
        ((a.innerHTML = `${livebriefBriefMarkup(e)}${livebriefEmptyMarkup(e)}`),
          ($("#crumb").innerHTML = e
            ? "<b>智慧工作台</b> / 今日简报"
            : "<b>智慧工作台</b> / 对话"),
          renderRecent(),
          assistantbriefRenderQuestionRail(),
          assistantbriefRenderTaskList(),
          livebriefBindSuggestions(),
          (a.scrollTop = 0),
          e
            ? (livebriefIntroTimer = setTimeout(() => livebriefDockBrief(!1), 5200))
            : requestAnimationFrame(() =>
                $("#chatEmpty")?.classList.remove("livebrief-awaiting"),
              ),
          livebriefScheduleRefresh());
      }
      function livebriefDockBrief(e = !1) {
        const t = $("#normalBriefCard"),
          a = $("#chatEmpty");
        t &&
          t.classList.contains("livebrief-intro") &&
          (clearTimeout(livebriefIntroTimer),
          (livebriefFirstEntryActive = !1),
          t.classList.add("livebrief-docking"),
          requestAnimationFrame(() =>
            requestAnimationFrame(() => {
              (t.classList.remove("livebrief-intro", "livebrief-docking"),
                t.classList.add("livebrief-docked"));
              const r = t.querySelector(".normal-brief-title span");
              r &&
                (r.textContent =
                  "点击数字即可在当前对话中筛选任务，任务默认收起。");
              const s = t.querySelector("#livebriefBriefStatus span");
              (s && (s.textContent = "智能体持续感知中"),
                e && briefcategoryButlerSummaryFilter
                  ? (t.classList.remove("collapsed"),
                    t.classList.add("livebrief-filter-open"),
                    (notificationsNormalBriefCollapsed = !1))
                  : (t.classList.add("collapsed"),
                    t.classList.remove("livebrief-filter-open"),
                    (notificationsNormalBriefCollapsed = !0)),
                a?.classList.remove("livebrief-awaiting"),
                ($("#crumb").innerHTML = "<b>智慧工作台</b> / 对话"));
            }),
          ));
      }
      function livebriefSyncMetrics() {
        $$("#normalBriefCard [data-livebrief-metric]").forEach((e) => {
          const t = e.dataset.livebriefMetric,
            a = e.querySelector("b");
          a && (a.textContent = livebriefCounts[t]);
          const r = t === briefcategoryButlerSummaryFilter;
          (e.classList.toggle("active", r),
            e.setAttribute("aria-pressed", String(r)));
        });
      }
      function livebriefApplyFilter(e = "") {
        const t = $("#normalBriefCard");
        t &&
          ((briefcategoryButlerSummaryFilter = briefcategoryButlerSummaryFilter === e ? "" : e),
          assistantbriefButlerTasks.forEach((e) => (e.expanded = !1)),
          t.classList.contains("livebrief-intro") &&
            livebriefDockBrief(!!briefcategoryButlerSummaryFilter),
          briefcategoryButlerSummaryFilter
            ? (t.classList.remove("collapsed"),
              t.classList.add("livebrief-filter-open"),
              (notificationsNormalBriefCollapsed = !1))
            : (t.classList.add("collapsed"),
              t.classList.remove("livebrief-filter-open"),
              (notificationsNormalBriefCollapsed = !0)),
          assistantbriefRenderTaskList(),
          livebriefSyncMetrics());
      }
      function livebriefInjectNewTask() {
        if (livebriefUpdateInjected) return;
        ((livebriefUpdateInjected = !0),
          (livebriefCounts.immediate = 4),
          (livebriefCounts.today = 8),
          (livebriefCounts.auto = 25),
          assistantbriefButlerTasks.some((e) => "T7" === e.id) ||
            (assistantbriefButlerTasks.unshift({
              id: "T7",
              title: "省公司应急资源协同任务",
              type: "应急协同",
              code: "YJ-2026-0726-031",
              status: "新任务",
              statusClass: "urgent",
              reason:
                "省公司新下发应急资源协同任务，需要确认跨单位资源协调优先级。",
              deadline: "今天21:30",
              remain: "刚刚进入",
              remainClass: "urgent",
              expanded: !1,
              selected: !1,
              why: "任务涉及3个地市单位的应急资源协同，需由当前岗位确认优先级后启动自动调度。",
              analysis: [
                "已完成需求清单结构化",
                "发现2类物资存在跨区域竞争",
                "已生成省内优先与交期优先两套方案",
              ],
              suggest: "采用省内资源优先方案，并同步启动外部供应商备选寻源。",
              progress: [
                "任务接收",
                "需求解析",
                "资源匹配",
                "方案确认",
                "协同执行",
              ],
              progressDone: 2,
              progressCurrent: 2,
            }),
            briefcategoryCategoryMap.immediate.unshift("T7"),
            briefcategoryCategoryMap.today.unshift("T7"),
            briefcategoryCategoryMap.auto.unshift("T7")));
        const e = $("#normalBriefCard");
        if (!e) return;
        (livebriefSyncMetrics(), e.classList.add("livebrief-updated"));
        const t = e.querySelector("#livebriefBriefStatus span");
        (t && (t.textContent = "刚刚更新 · 1项新任务"),
          ["immediate", "today", "auto"].forEach((t) => {
            const a = e.querySelector(`[data-livebrief-metric="${t}"]`);
            (a?.classList.add("livebrief-count-bump"),
              setTimeout(() => a?.classList.remove("livebrief-count-bump"), 760));
          }),
          briefcategoryButlerSummaryFilter && assistantbriefRenderTaskList(),
          setTimeout(() => e.classList.remove("livebrief-updated"), 4200));
      }
      ((notificationsApplyNormalBriefFilter = livebriefApplyFilter),
        (assistantbriefRenderButlerHome = function () {
          livebriefRenderConversation(!0);
        }),
        (assistantbriefRenderNormalHome = function () {
          livebriefRenderConversation(!1);
        }),
        (notificationsNormalBriefMarkup = function () {
          return livebriefBriefMarkup(!1);
        }),
        ["focusin", "wheel", "touchstart"].forEach((e) =>
          document.addEventListener(
            e,
            (t) => {
              livebriefFirstEntryActive &&
                (("focusin" === e && "chatInput" !== t.target?.id) ||
                  (("wheel" !== e || t.target.closest?.("#chatThread")) &&
                    livebriefDockBrief(!1)));
            },
            { passive: !0 },
          ),
        ),
        document.addEventListener(
          "click",
          (e) => {
            const t = e.target.closest("[data-newbrief-filter]");
            if (t)
              return (
                e.preventDefault(),
                e.stopImmediatePropagation(),
                void livebriefApplyFilter(t.dataset.newbriefFilter)
              );
            return e.target.closest("[data-normal-brief-toggle]") &&
              $("#normalBriefCard")?.classList.contains("livebrief-intro")
              ? (e.preventDefault(),
                e.stopImmediatePropagation(),
                void livebriefDockBrief(!1))
              : void 0;
          },
          !0,
        ),
        setTimeout(() => {
          document.title = "供应链智慧工作台";
        }, 0));

/* Source runtime block 8 */
function renderTaskOverview() {
        const s = !!state.overviewDecisionConfirmed,
          n = "E001" === state.selectedEmergency,
          i = state.task.materials?.length || 0,
          v = s ? "执行与到货跟踪" : "正式需求确认与差异处理",
          a = s
            ? 88
            : n
              ? 78
              : Math.max(36, Math.min(72, 24 * (state.task.stageIndex || 2))),
          c = [
            ["灾损预测与需求预估", "预估清单已生成"],
            ["资源预享与预保障", "四渠道寻源已完成"],
            ["正式需求确认与差异处理", s ? "已完成确认" : "当前需要人工决策"],
            ["执行与到货跟踪", s ? "智能体正在执行" : "确认后自动启动"],
          ]
            .map((n, i) => {
              const v = i + 1,
                a = s ? v <= 3 : v <= 2;
              return `<div class="incidentcockpit-stage ${a ? "done" : ""} ${(s ? 4 === v : 3 === v) ? "current" : ""}"><div class="incidentcockpit-stage-node">${a ? "✓" : v}</div><strong>${n[0]}</strong><small>${n[1]}</small></div>`;
            })
            .join(""),
          d = state.overviewEvidence
            ? '<div class="incidentcockpit-evidence"><b>判断依据：</b>最终方案已完成二次确认；20条物资形成可执行来源，3条缺口需要在“启用在建资源、启动应急采购、接受延后到货”之间进行业务选择。该操作涉及资源释放和采购启动权限，需要业务人员确认。</div>'
            : "";
        return s
          ? `<div class="incidentcockpit-cockpit">\n   <section class="incidentcockpit-cockpit-hero"><div><div class="incidentcockpit-hero-kicker"><span class="incidentcockpit-live-signal"></span>中枢智能体持续感知任务状态</div><h3>任务已进入执行与到货跟踪</h3><p>最终保障方案已经确认。智能体正在完成原系统回写、执行指令生成和通知下发，并持续跟踪调拨出库、供应商发运与到货异常。</p><div class="incidentcockpit-hero-metrics"><span>${i}条物资需求</span><span>20条进入执行</span><span>3条兜底处置</span><span>最近更新：刚刚</span></div></div><div class="incidentcockpit-progress-orb" style="background:conic-gradient(#65e5be 0 ${a}%,rgba(255,255,255,.14) ${a}% 100%)"><div class="incidentcockpit-progress-copy"><strong>${a}%</strong><span>任务总体进度</span></div></div></section>\n   <section class="incidentcockpit-process confirmed">${c}</section>\n   <div class="incidentcockpit-confirmed-banner"><div><strong>您的确认已生效，智能体已接续执行</strong><span>当前正在回写原系统并生成调拨、采购和运输跟踪任务，后续异常将主动提醒。</span></div><button class="btn primary" id="incidentcockpitOpenExecution">查看执行与到货跟踪</button></div>\n   <section class="incidentcockpit-cockpit-grid">\n    <div class="incidentcockpit-status-card incidentcockpit-card-done"><h4><span class="incidentcockpit-card-icon">✓</span>智能体已经完成</h4><div class="incidentcockpit-check-list"><div class="incidentcockpit-check-item"><b>✓</b><span>灾损预测与${i}条物资需求解析</span></div><div class="incidentcockpit-check-item"><b>✓</b><span>跨单位、供应商、在途在建资源寻源</span></div><div class="incidentcockpit-check-item"><b>✓</b><span>二次确认与最终方案收敛</span></div><div class="incidentcockpit-check-item"><b>✓</b><span>人工确认及风险接受留痕</span></div></div></div>\n    <div class="incidentcockpit-status-card incidentcockpit-card-running"><h4><span class="incidentcockpit-card-icon">↻</span>智能体当前正在做</h4><div class="incidentcockpit-running-line"><i class="incidentcockpit-running-dot"></i><div><strong>回写智慧供应链原系统</strong><span>正在校验任务、物资、来源和缺口处置字段</span></div></div><div class="incidentcockpit-running-line"><i class="incidentcockpit-running-dot"></i><div><strong>生成并下发执行指令</strong><span>调拨、应急采购及运输任务将按确认方案启动</span></div></div><div class="incidentcockpit-running-line"><i class="incidentcockpit-running-dot"></i><div><strong>建立到货跟踪节点</strong><span>持续监测出库、发运、在途、签收和异常状态</span></div></div></div>\n   </section></div>`
          : `<div class="incidentcockpit-cockpit">\n  <section class="incidentcockpit-cockpit-hero"><div><div class="incidentcockpit-hero-kicker"><span class="incidentcockpit-live-signal"></span>中枢智能体正在持续运行</div><h3>当前处于：${v}</h3><p>灾损预测、需求解析、四渠道资源寻源和二次确认已经完成。最终保障方案已形成，当前需要您对方案及3条缺口处置作出确认。</p><div class="incidentcockpit-hero-metrics"><span>${i}条物资需求</span><span>206条资源记录已核验</span><span>20条形成执行来源</span><span>3条需要兜底处置</span></div></div><div class="incidentcockpit-progress-orb"><div class="incidentcockpit-progress-copy"><strong>${a}%</strong><span>任务总体进度</span></div></div></section>\n  <section class="incidentcockpit-process">${c}</section>\n  <section class="incidentcockpit-cockpit-grid">\n   <div class="incidentcockpit-status-card incidentcockpit-card-done"><h4><span class="incidentcockpit-card-icon">✓</span>智能体已经完成</h4><div class="incidentcockpit-check-list"><div class="incidentcockpit-check-item"><b>✓</b><span>根据灾害信息生成预估物资清单</span></div><div class="incidentcockpit-check-item"><b>✓</b><span>完成${i}条正式需求标准化解析</span></div><div class="incidentcockpit-check-item"><b>✓</b><span>完成四渠道寻源和资源优先级排序</span></div><div class="incidentcockpit-check-item"><b>✓</b><span>完成二次确认并生成最终保障方案</span></div></div></div>\n   <div class="incidentcockpit-status-card incidentcockpit-card-running"><h4><span class="incidentcockpit-card-icon">↻</span>智能体当前正在做</h4><div class="incidentcockpit-running-line"><i class="incidentcockpit-running-dot"></i><div><strong>核验3条缺口的兜底处置条件</strong><span>校验在建资源可释放性、应急采购条件和到货风险</span></div></div><div class="incidentcockpit-running-line"><i class="incidentcockpit-running-dot"></i><div><strong>预生成原系统回写数据</strong><span>提前完成字段映射和执行指令草稿，等待您的确认</span></div></div><div class="incidentcockpit-running-line"><i class="incidentcockpit-running-dot"></i><div><strong>持续监听资源状态变化</strong><span>如来源数量或交付时间变化，将立即重新计算方案</span></div></div></div>\n   <div class="incidentcockpit-status-card incidentcockpit-card-decision"><h4><span class="incidentcockpit-card-icon">!</span>当前需要您判断</h4><div class="incidentcockpit-decision-title">确认最终保障方案及3条缺口处置方式</div><div class="incidentcockpit-decision-copy">AI建议采用当前最终方案：20条物资直接进入执行；2条启用已核验的在建资源；1条启动应急采购兜底。</div><div class="incidentcockpit-decision-reason">需要您确认的原因：该操作将释放跨单位资源并触发正式调拨、采购和原系统回写。</div>${d}<div class="incidentcockpit-card-actions"><button class="btn primary" id="incidentcockpitConfirmDecision">确认并继续</button><button class="btn" id="incidentcockpitAdjustPlan">调整方案</button><button class="btn" id="incidentcockpitViewEvidence">${state.overviewEvidence ? "收起依据" : "查看判断依据"}</button></div></div>\n   <div class="incidentcockpit-status-card incidentcockpit-card-next"><h4><span class="incidentcockpit-card-icon">→</span>确认后下一步</h4><div class="incidentcockpit-next-flow"><div class="incidentcockpit-next-step"><b>01 回写原系统</b><span>校验并写入最终来源与缺口处置</span></div><div class="incidentcockpit-next-arrow">›</div><div class="incidentcockpit-next-step"><b>02 启动执行</b><span>生成调拨、采购和通知任务</span></div><div class="incidentcockpit-next-arrow">›</div><div class="incidentcockpit-next-step"><b>03 跟踪到货</b><span>持续监测出库、发运、在途和签收</span></div></div><div class="incidentcockpit-card-actions"><button class="btn" id="incidentcockpitOpenPlan">查看完整方案</button><button class="btn" id="incidentcockpitRefreshOverview">刷新任务状态</button></div></div>\n  </section></div>`;
      }

/* Source runtime block 9 */
const collaborationOriginalSetView = setView;
      function collaborationEscape(t) {
        return String(t ?? "").replace(
          /[&<>'"]/g,
          (t) =>
            ({
              "&": "&amp;",
              "<": "&lt;",
              ">": "&gt;",
              "'": "&#39;",
              '"': "&quot;",
            })[t],
        );
      }
      function collaborationSelectedEmergency() {
        return (
          (state.emergencies || []).find((t) => t.id === state.collaborationTask) ||
          state.emergencies?.[0] ||
          {}
        );
      }
      function collaborationDecisionCounts() {
        const t = Object.values(state.collaborationDecisions || {});
        return {
          ai: t.filter((t) => "ai" === t).length,
          original: t.filter((t) => "original" === t).length,
          adjust: t.filter((t) => "adjust" === t).length,
          pending: t.filter((t) => "pending" === t).length,
          total: t.length,
        };
      }
      function collaborationTaskCounts() {
        const t = state.emergencies || [];
        return {
          all: t.length,
          attention: t.filter((t) => t.attention).length,
          running: t.filter(
            (t) =>
              "running" === t.statusClass ||
              "waiting" === t.statusClass ||
              "attention" === t.statusClass,
          ).length,
          done: t.filter((t) => "done" === t.statusClass).length,
        };
      }
      function collaborationMaterials() {
        return state.task?.materials || [];
      }
      function collaborationGap(t) {
        return Math.max(0, +((t.need || 0) - (t.filled || 0)).toFixed(2));
      }
      function collaborationStatusTone(t) {
        return "done" === t.statusClass
          ? "done"
          : t.attention
            ? "attention"
            : "waiting" === t.statusClass
              ? "waiting"
              : "running";
      }
      function collaborationAddMessage(t, e) {
        (state.collaborationMessages.push({ role: t, text: e }),
          state.collaborationMessages.length > 10 &&
            (state.collaborationMessages = state.collaborationMessages.slice(-10)));
      }
      function collaborationMountEmergency() {
        const t = $("#view-emergency");
        t &&
          ($("#collaborationEmergencyWorkspace") ||
            ((t.innerHTML =
              '<div class="collaboration-workspace" id="collaborationEmergencyWorkspace"></div>'),
            t.addEventListener("click", collaborationClickHandler),
            t.addEventListener("keydown", (t) => {
              "Enter" !== t.key ||
                t.shiftKey ||
                "collaborationPrompt" !== t.target?.id ||
                (t.preventDefault(), collaborationSendPrompt());
            })),
          renderEmergencyCollaboration());
      }
      function collaborationTaskPane() {
        const t = collaborationTaskCounts(),
          e = state.collaborationTaskFilter;
        let a = (state.emergencies || []).filter(
          (t) =>
            "all" === e ||
            ("attention" === e && t.attention) ||
            ("running" === e &&
              ("running" === t.statusClass ||
                "waiting" === t.statusClass ||
                "attention" === t.statusClass)) ||
            ("done" === e && "done" === t.statusClass),
        );
        return `<aside class="collaboration-task-pane">\n  <div class="collaboration-pane-head"><div><b>应急任务</b><span>智能寻源任务列表</span></div><button class="collaboration-icon-btn" title="新建演练任务">＋</button></div>\n  <label class="collaboration-search">${icons("i-search")}<input id="collaborationTaskSearch" placeholder="搜索任务名称或编号"></label>\n  <div class="collaboration-filter-row">\n   <button class="${"all" === e ? "on" : ""}" data-collaboration-filter="all">全部 ${t.all}</button>\n   <button class="${"attention" === e ? "on" : ""}" data-collaboration-filter="attention">待确认 ${t.attention}</button>\n   <button class="${"running" === e ? "on" : ""}" data-collaboration-filter="running">寻源中 ${t.running}</button>\n   <button class="${"done" === e ? "on" : ""}" data-collaboration-filter="done">已完成 ${t.done}</button>\n  </div>\n  <div class="collaboration-task-list">${a.map((t, e) => `<button class="collaboration-task-card ${t.id === state.collaborationTask ? "selected" : ""}" data-collaboration-task="${t.id}">\n   <div class="collaboration-task-card-top"><span class="collaboration-status ${collaborationStatusTone(t)}">${t.attention ? "待确认" : t.status}</span><time>${t.received}</time></div>\n   <strong>${collaborationEscape(t.title)}</strong>\n   <small>${t.code} · ${t.materials}</small>\n   <div class="collaboration-task-card-foot"><span>${t.summary}</span><b>${t.progress}%</b></div>\n   <i style="width:${t.progress}%"></i>\n  </button>`).join("") || '<div class="collaboration-empty">暂无符合条件的任务</div>'}</div>\n </aside>`;
      }
      function collaborationCollabPane() {
        const t = collaborationSelectedEmergency(),
          e = collaborationDecisionCounts(),
          a = [
            ["需求确认", "已完成"],
            ["四渠道寻源", "已完成"],
            ["响应汇聚", "已完成"],
            ["方案差异确认", e.pending ? `待确认${e.pending}项` : "已完成"],
          ];
        return `<section class="collaboration-collab-pane">\n  <div class="collaboration-collab-head"><div><strong>${collaborationEscape(t.title || "应急寻源任务")}</strong><span>${t.materials || "10条"} · 18条有效响应 · ${e.pending}项待确认</span></div><span class="collaboration-agent-live"><i></i>智能体运行中</span></div>\n  <div class="collaboration-collab-scroll">\n   <article class="collaboration-ai-summary"><div class="collaboration-ai-mark">AI</div><div><h3>智能体总结</h3><p>四渠道寻源已完成。AI方案在原系统基础上新增4个可用来源，补足2项物资缺口，最晚到货预计提前4小时；当前仍有${e.pending}项差异需要确认。</p><div class="collaboration-summary-chips"><span>+4 可用来源</span><span>+2 补足缺口</span><span>-4h 最晚到货</span></div></div></article>\n   <div class="collaboration-block-title"><span>运行过程</span><button data-collaboration-tab="events">查看记录</button></div>\n   <div class="collaboration-run-steps">${a.map((t, a) => `<button data-collaboration-step="${a}" class="${a < 3 || !e.pending ? "done" : "current"}"><i>${a < 3 || !e.pending ? "✓" : a + 1}</i><span><b>${t[0]}</b><small>${t[1]}</small></span><em>${a < 3 ? "已完成" : e.pending ? "进行中" : "已完成"}</em></button>`).join("")}</div>\n   <article class="collaboration-todo-card ${e.pending ? "" : "done"}"><div><span>${e.pending ? "当前需要您处理" : "方案差异已处理"}</span><strong>${e.pending ? `确认${e.pending}项方案差异` : "最终寻源方案已形成"}</strong><p>${e.pending ? "2项建议采用AI新增资源，1项建议启动应急采购。" : "已完成方案取舍，智能体正在准备结果回写。"}</p></div><button data-collaboration-tab="plans">${e.pending ? "在右侧处理" : "查看最终方案"}</button></article>\n   <div class="collaboration-block-title"><span>协同对话</span><small>右侧工作区将随指令联动</small></div>\n   <div class="collaboration-chat-log">${state.collaborationMessages.map((t) => `<div class="collaboration-msg ${t.role}"><span>${"user" === t.role ? "我" : "智"}</span><p>${collaborationEscape(t.text)}</p></div>`).join("")}</div>\n  </div>\n  <div class="collaboration-compose"><textarea id="collaborationPrompt" placeholder="例如：只看有缺口的物资，或对比原系统与AI方案"></textarea><div><span>支持自然语言筛选、定位和决策</span><button id="collaborationSend">↑</button></div></div>\n </section>`;
      }
      function collaborationAppHeader() {
        return `<div class="collaboration-app-head"><div><strong>应急寻源工作区</strong><span><i></i>MCP App · 数据已更新</span></div><div class="collaboration-app-actions"><button title="刷新">↻</button><button title="全屏">⛶</button><button title="更多">···</button></div></div><nav class="collaboration-tabs">${[
          ["overview", "任务总览"],
          ["materials", "物资清单"],
          ["responses", "响应情况"],
          ["plans", "方案与决策"],
          ["events", "事件记录"],
        ]
          .map(
            (t) =>
              `<button class="${state.collaborationTab === t[0] ? "on" : ""}" data-collaboration-tab="${t[0]}">${t[1]}${"plans" === t[0] && collaborationDecisionCounts().pending ? `<em>${collaborationDecisionCounts().pending}</em>` : ""}</button>`,
          )
          .join("")}</nav>`;
      }
      function collaborationOverview() {
        const t = collaborationMaterials(),
          e = collaborationDecisionCounts(),
          a = t.length || 10;
        return `<div class="collaboration-app-page collaboration-overview">\n  <section class="collaboration-flow"><div class="done"><i>✓</i><b>需求确认</b><span>${a}条需求已校验</span></div><div class="done"><i>✓</i><b>四渠道寻源</b><span>4类渠道已完成</span></div><div class="done"><i>✓</i><b>响应汇聚</b><span>18条有效响应</span></div><div class="current"><i>4</i><b>方案确认</b><span>${e.pending ? `待确认${e.pending}项` : "已完成"}</span></div></section>\n  <section class="collaboration-metrics"><button data-collaboration-tab="materials"><strong>${a}</strong><span>需求物资</span></button><button data-collaboration-tab="responses"><strong>4</strong><span>寻源渠道</span></button><button data-collaboration-tab="responses"><strong>18</strong><span>有效响应</span></button><button data-collaboration-tab="plans" class="attention"><strong>${e.pending}</strong><span>待确认差异</span></button></section>\n  <div class="collaboration-overview-grid">\n   <article class="collaboration-decision-panel"><div class="collaboration-eyebrow">当前需要您确认</div><h2>${e.pending ? `确认最终寻源组合及${e.pending}项差异处置` : "最终寻源方案已确认"}</h2><p>${e.pending ? "AI建议采用新增资源补足2项缺口，并对1项启动应急采购。推荐组合满足总体到货要求。" : "差异事项已全部处理，最终方案已形成。"}</p><div class="collaboration-decision-kpis"><span><b>20</b>已形成来源</span><span><b>2</b>AI补足缺口</span><span><b>1</b>应急采购</span></div><div class="collaboration-actions"><button class="primary" data-collaboration-tab="plans">${e.pending ? "处理方案差异" : "查看最终方案"}</button><button data-collaboration-tab="materials">查看物资</button></div></article>\n   <div class="collaboration-side-stack"><article><h3>智能体已完成</h3><ul><li>需求校验与标准化</li><li>四渠道并行寻源</li><li>有效响应汇总与冲突校验</li><li>原系统与AI方案对比</li></ul></article><article class="running"><h3><i></i>智能体当前状态</h3><p>${e.pending ? "持续监听未回复单位及供应商；如资源状态变化，将重新计算推荐组合。" : "正在生成最终寻源结果并准备回写原系统。"}</p><small>最近更新：1分钟前</small></article></div>\n  </div>\n  <div class="collaboration-next-line"><b>确认后：</b>智能体将锁定推荐来源，形成最终寻源结果，并将结果回写原系统。</div>\n </div>`;
      }
      function collaborationMaterialRows() {
        let t = collaborationMaterials();
        const e = state.collaborationMaterialFilter;
        return (
          "satisfied" === e && (t = t.filter((t) => 0 === collaborationGap(t))),
          "gap" === e && (t = t.filter((t) => collaborationGap(t) > 0)),
          "decision" === e &&
            (t = t.filter((t) => "pending" === state.collaborationDecisions[t.id])),
          t
        );
      }
      function collaborationMaterialsPage() {
        const t = collaborationMaterials(),
          e = collaborationMaterialRows(),
          a = t.filter((t) => collaborationGap(t) > 0).length,
          s = Object.values(state.collaborationDecisions).filter(
            (t) => "pending" === t,
          ).length;
        return `<div class="collaboration-app-page"><div class="collaboration-page-toolbar"><div class="collaboration-pill-tabs"><button class="${"all" === state.collaborationMaterialFilter ? "on" : ""}" data-collaboration-mfilter="all">全部 ${t.length}</button><button class="${"satisfied" === state.collaborationMaterialFilter ? "on" : ""}" data-collaboration-mfilter="satisfied">已满足 ${t.length - a}</button><button class="${"gap" === state.collaborationMaterialFilter ? "on" : ""}" data-collaboration-mfilter="gap">有缺口 ${a}</button><button class="${"decision" === state.collaborationMaterialFilter ? "on" : ""}" data-collaboration-mfilter="decision">待确认 ${s}</button></div><div><button class="collaboration-light-btn">筛选</button><button class="collaboration-light-btn">导出</button></div></div>\n <div class="collaboration-table-wrap"><table class="collaboration-table"><thead><tr><th>物资</th><th>需求数量</th><th>已匹配</th><th>缺口</th><th>推荐来源</th><th>状态</th></tr></thead><tbody>${e
          .map((t) => {
            const e = collaborationGap(t);
            return `<tr data-collaboration-material="${t.id}"><td><strong>${collaborationEscape(t.name)}</strong><small>${collaborationEscape(t.spec)}</small></td><td>${t.need}${t.unit}</td><td>${t.filled}${t.unit}</td><td class="${e ? "red" : ""}">${e ? e + t.unit : "0"}</td><td>${collaborationEscape(t.method || "智能推荐组合")}</td><td><span class="collaboration-row-status ${e ? "attention" : "done"}">${e ? "有缺口" : "已满足"}</span></td></tr>`;
          })
          .join(
            "",
          )}</tbody></table></div>${state.collaborationSelectedMaterial ? collaborationMaterialDetail() : ""}</div>`;
      }
      function collaborationMaterialDetail() {
        const t = collaborationMaterials().find(
          (t) => t.id === state.collaborationSelectedMaterial,
        );
        if (!t) return "";
        const e = collaborationGap(t),
          a = (t.sources || []).filter((t) => !1 !== t.requested).slice(0, 4);
        return `<aside class="collaboration-detail-drawer"><div class="collaboration-detail-head"><div><span>物资详情</span><strong>${collaborationEscape(t.name)}</strong></div><button data-collaboration-close-detail>×</button></div><dl><dt>需求数量</dt><dd>${t.need}${t.unit}</dd><dt>已匹配</dt><dd>${t.filled}${t.unit}</dd><dt>当前缺口</dt><dd class="${e ? "red" : ""}">${e}${t.unit}</dd><dt>推荐方式</dt><dd>${collaborationEscape(t.method)}</dd></dl><h4>推荐来源组合</h4>${a.map((t) => `<div class="collaboration-source-item"><div><b>${collaborationEscape(t.name)}</b><span>${collaborationEscape(t.type || "资源来源")}</span></div><em>${collaborationEscape(t.qty || "待确认")}</em></div>`).join("")}<div class="collaboration-risk-note">AI已综合数量覆盖、交期和来源冲突进行校验。</div><button class="collaboration-drawer-action" data-collaboration-tab="plans">查看方案差异</button></aside>`;
      }
      function collaborationResponseRecords() {
        const t = [];
        return (
          collaborationMaterials().forEach((e) =>
            (e.sources || []).forEach((a) => {
              !1 !== a.requested &&
                t.push({
                  m: e,
                  s: a,
                  key:
                    a.channelKey ||
                    (/供应商|协议/.test(a.type)
                      ? "rush"
                      : /在途|在建/.test(a.type)
                        ? "transit"
                        : /采购/.test(a.type)
                          ? "purchase"
                          : "unit"),
                });
            }),
          ),
          t
        );
      }
      function collaborationResponsesPage() {
        const t = {
          unit: ["跨单位调拨", "14", "12", "2"],
          rush: ["应急抢单", "4", "3", "1"],
          transit: ["在途／在建", "2", "2", "0"],
          purchase: ["应急采购", "1", "1", "0"],
        };
        let e = collaborationResponseRecords();
        return (
          "all" !== state.collaborationResponseChannel &&
            (e = e.filter((t) => t.key === state.collaborationResponseChannel)),
          `<div class="collaboration-app-page"><section class="collaboration-channel-grid">${Object.entries(
            t,
          )
            .map(
              ([t, e]) =>
                `<button class="${state.collaborationResponseChannel === t ? "on" : ""}" data-collaboration-channel="${t}"><span>${e[0]}</span><b>${e[2]}/${e[1]}</b><small>已回复／请求 · 未回复${e[3]}</small></button>`,
            )
            .join(
              "",
            )}</section><div class="collaboration-page-toolbar"><div><strong>${"all" === state.collaborationResponseChannel ? "全部渠道响应" : t[state.collaborationResponseChannel][0] + "响应"}</strong><span>智能体持续自动催办并校验可用性</span></div><button class="collaboration-light-btn" data-collaboration-channel="all">全部渠道</button></div><div class="collaboration-response-list">${e
            .slice(0, 10)
            .map(
              ({ m: e, s: a, key: s }) =>
                `<article><span class="collaboration-channel-tag ${s}">${t[s]?.[0] || "资源渠道"}</span><div><strong>${collaborationEscape(a.name)}</strong><small>${collaborationEscape(e.name)} · 可供 ${collaborationEscape(a.qty || "待回复")}</small></div><div><b>${collaborationEscape(a.status)}</b><small>${collaborationEscape(a.eta || "—")}</small></div><button>详情</button></article>`,
            )
            .join("")}</div></div>`
        );
      }
      function collaborationPlansPage() {
        const t = collaborationDecisionCounts();
        return `<div class="collaboration-app-page collaboration-plan-page"><section class="collaboration-plan-summary"><div class="collaboration-ai-mark">AI</div><div><h3>方案对比结论</h3><p>AI方案在保留原系统有效来源的基础上，新增4个可用来源，优化5项物资来源组合，补足2项缺口，预计最晚到货提前4小时。</p></div><div class="collaboration-plan-changes"><span>+4 来源</span><span>+2 补缺</span><span>-4h 到货</span></div></section>\n <section class="collaboration-plan-cards"><article><span>基线</span><h3>原系统方案</h3><div><b>8 / 10</b><small>满足物资</small></div><dl><dt>可用来源</dt><dd>8个</dd><dt>剩余缺口</dt><dd>3项</dd><dt>最晚到货</dt><dd>18:00</dd></dl></article><article class="recommended"><span>AI推荐</span><h3>AI推荐方案</h3><div><b>10 / 10</b><small>满足物资</small></div><dl><dt>可用来源</dt><dd>12个</dd><dt>剩余缺口</dt><dd>1项</dd><dt>最晚到货</dt><dd>14:00</dd></dl></article><article class="final"><span>${t.pending ? "待确认" : "已形成"}</span><h3>最终确认方案</h3><div><b>${t.total - t.pending} / ${t.total}</b><small>差异已处理</small></div><dl><dt>采用AI</dt><dd>${t.ai}项</dd><dt>保留原方案</dt><dd>${t.original}项</dd><dt>人工调整</dt><dd>${t.adjust}项</dd></dl></article></section>\n <section class="collaboration-compare-table"><div class="collaboration-section-head"><div><h3>核心指标对比</h3><span>点击差异事项完成最终方案决策</span></div></div><table class="collaboration-table"><thead><tr><th>指标</th><th>原系统方案</th><th>AI推荐方案</th><th>变化</th></tr></thead><tbody><tr><td>满足物资</td><td>8 / 10</td><td><b>10 / 10</b></td><td class="green">+2项</td></tr><tr><td>可用来源</td><td>8个</td><td><b>12个</b></td><td class="green">+4个</td></tr><tr><td>寻源渠道</td><td>2类</td><td><b>4类</b></td><td class="green">+2类</td></tr><tr><td>剩余缺口</td><td>3项</td><td><b>1项</b></td><td class="green">-2项</td></tr><tr><td>最晚到货</td><td>18:00</td><td><b>14:00</b></td><td class="green">提前4小时</td></tr></tbody></table></section>\n <section class="collaboration-diff-list"><div class="collaboration-section-head"><div><h3>差异事项</h3><span>仅展示原系统与AI方案存在差异的物资</span></div><b>剩余 ${t.pending} 项待确认</b></div>${[
          {
            id: "M01",
            name: "光缆",
            need: "2.74千米",
            original: "两家单位拼单，最晚02:10",
            ai: "单一来源＋在建资源，最晚01:30",
            reason: "减少协调对象，交付提前40分钟",
          },
          {
            id: "M03",
            name: "通信电源",
            need: "5套",
            original: "无可用来源，保留缺口",
            ai: "本地供应商现货5套，06:00交付",
            reason: "新增应急采购来源，补足缺口",
          },
          {
            id: "M04",
            name: "电力电缆",
            need: "2.5千米",
            original: "库存＋协议1.5千米，缺1千米",
            ai: "增加跨单位资源1千米，完整满足",
            reason: "新增1个可调来源，补足缺口",
          },
        ]
          .map((t) => {
            const e = state.collaborationDecisions[t.id] || "pending";
            return `<article class="${"pending" !== e ? "decided" : ""}"><div class="collaboration-diff-name"><strong>${t.name}</strong><small>需求 ${t.need}</small></div><div><span>原系统方案</span><p>${t.original}</p></div><div><span>AI推荐方案</span><p>${t.ai}</p><small>${t.reason}</small></div><div class="collaboration-choice-actions">${"pending" === e ? `<button class="primary" data-collaboration-decision="${t.id}|ai">采用AI方案</button><button data-collaboration-decision="${t.id}|original">保留原方案</button><button data-collaboration-decision="${t.id}|adjust">调整</button>` : `<strong>${"ai" === e ? "已采用AI方案" : "original" === e ? "已保留原方案" : "已人工调整"}</strong><button data-collaboration-decision="${t.id}|pending">重新选择</button>`}</div></article>`;
          })
          .join(
            "",
          )}</section>\n <div class="collaboration-plan-footer"><span>${t.total - t.pending}项已确认，剩余${t.pending}项</span><button ${t.pending ? "disabled" : ""} id="collaborationFinalize">确认并形成最终方案</button></div></div>`;
      }
      function collaborationEventsPage() {
        return `<div class="collaboration-app-page"><div class="collaboration-page-toolbar"><div><strong>关键业务事件</strong><span>支持按时间回溯任务处理过程</span></div><div class="collaboration-pill-tabs"><button class="on">全部事件</button><button>系统动作</button><button>人工动作</button><button>方案节点</button></div></div><div class="collaboration-timeline">${[
          ["09:48", "接收应急任务", "系统自动接收并创建独立寻源任务", "done"],
          ["09:52", "完成需求校验", "完成物资编码、数量和到货要求校验", "done"],
          [
            "09:55",
            "发起四渠道寻源",
            "跨单位、应急抢单、在途在建、应急采购并行启动",
            "done",
          ],
          [
            "10:12",
            "收到首批有效响应",
            "已汇聚18条有效响应并完成可用性核验",
            "done",
          ],
          [
            "10:28",
            "生成AI推荐方案",
            "完成原系统与AI方案对比，识别3项差异",
            "done",
          ],
          ["10:32", "等待用户确认", "请处理最终来源组合和差异事项", "current"],
        ]
          .map(
            (t) =>
              `<article class="${t[3]}"><time>${t[0]}</time><i>${"done" === t[3] ? "✓" : "●"}</i><div><strong>${t[1]}</strong><p>${t[2]}</p></div><span>${"done" === t[3] ? "完成" : "进行中"}</span></article>`,
          )
          .join("")}</div></div>`;
      }
      function collaborationAppPane() {
        let t =
          "overview" === state.collaborationTab
            ? collaborationOverview()
            : "materials" === state.collaborationTab
              ? collaborationMaterialsPage()
              : "responses" === state.collaborationTab
                ? collaborationResponsesPage()
                : "plans" === state.collaborationTab
                  ? collaborationPlansPage()
                  : collaborationEventsPage();
        return `<section class="collaboration-app-pane">${collaborationAppHeader()}<div class="collaboration-app-body">${t}</div></section>`;
      }
      function renderEmergencyCollaboration() {
        const t = $("#collaborationEmergencyWorkspace");
        t &&
          ((t.innerHTML = collaborationTaskPane() + collaborationCollabPane() + collaborationAppPane()),
          setTimeout(() => {
            const t = $(".collaboration-chat-log");
            t && (t.scrollTop = t.scrollHeight);
          }, 0));
      }
      function collaborationSendPrompt() {
        const t = $("#collaborationPrompt"),
          e = (t?.value || "").trim();
        if (!e) return;
        collaborationAddMessage("user", e);
        let a = "已理解并同步更新右侧工作区。";
        (/缺口|未满足/.test(e)
          ? ((state.collaborationTab = "materials"),
            (state.collaborationMaterialFilter = "gap"),
            (a = "已切换到物资清单，并筛选存在缺口的物资。"))
          : /方案|对比|原系统|AI/.test(e)
            ? ((state.collaborationTab = "plans"),
              (a =
                "已打开方案与决策，右侧展示原系统方案、AI推荐方案和最终确认方案。"))
            : /响应|供应商|单位/.test(e)
              ? ((state.collaborationTab = "responses"),
                (a = "已打开响应情况，可按四类渠道查看单位和供应商反馈。"))
              : /事件|记录|过程/.test(e)
                ? ((state.collaborationTab = "events"),
                  (a = "已打开事件记录，展示本次应急寻源关键业务节点。"))
                : /总览|进度/.test(e)
                  ? ((state.collaborationTab = "overview"),
                    (a = "已返回任务总览，当前处于方案确认阶段。"))
                  : /接受全部|采用全部/.test(e) &&
                    (Object.keys(state.collaborationDecisions).forEach(
                      (t) => (state.collaborationDecisions[t] = "ai"),
                    ),
                    (state.collaborationTab = "plans"),
                    (a = "已采用全部AI推荐差异项，最终方案已具备确认条件。")),
          collaborationAddMessage("assistant", a),
          renderEmergencyCollaboration());
      }
      function collaborationClickHandler(t) {
        const e = t.target.closest("[data-collaboration-task]");
        if (e)
          return (
            (state.collaborationTask = e.dataset.collaborationTask),
            (state.selectedEmergency = state.collaborationTask),
            (state.collaborationTab = "overview"),
            void renderEmergencyCollaboration()
          );
        const a = t.target.closest("[data-collaboration-filter]");
        if (a)
          return (
            (state.collaborationTaskFilter = a.dataset.collaborationFilter),
            void renderEmergencyCollaboration()
          );
        const s = t.target.closest("[data-collaboration-tab]");
        if (s)
          return (
            (state.collaborationTab = s.dataset.collaborationTab),
            (state.collaborationSelectedMaterial = null),
            void renderEmergencyCollaboration()
          );
        const n = t.target.closest("[data-collaboration-mfilter]");
        if (n)
          return (
            (state.collaborationMaterialFilter = n.dataset.collaborationMfilter),
            void renderEmergencyCollaboration()
          );
        const i = t.target.closest("[data-collaboration-material]");
        if (i)
          return (
            (state.collaborationSelectedMaterial = i.dataset.collaborationMaterial),
            void renderEmergencyCollaboration()
          );
        if (t.target.closest("[data-collaboration-close-detail]"))
          return (
            (state.collaborationSelectedMaterial = null),
            void renderEmergencyCollaboration()
          );
        const d = t.target.closest("[data-collaboration-channel]");
        if (d)
          return (
            (state.collaborationResponseChannel = d.dataset.collaborationChannel),
            void renderEmergencyCollaboration()
          );
        const l = t.target.closest("[data-collaboration-decision]");
        if (l) {
          const [t, e] = l.dataset.collaborationDecision.split("|");
          state.collaborationDecisions[t] = e;
          const a = { M01: "光缆", M03: "通信电源", M04: "电力电缆" }[t] || t;
          return (
            collaborationAddMessage(
              "assistant",
              "pending" === e
                ? `已将“${a}”恢复为待确认。`
                : `“${a}”差异已处理，${"ai" === e ? "采用AI推荐方案" : "original" === e ? "保留原系统方案" : "进入人工调整"}。`,
            ),
            void renderEmergencyCollaboration()
          );
        }
        if (t.target.closest("#collaborationFinalize"))
          return collaborationDecisionCounts().pending
            ? void showToast("请先处理全部差异事项")
            : (collaborationAddMessage(
                "assistant",
                "最终寻源方案已形成，智能体正在准备结果回写原系统。",
              ),
              showToast("最终寻源方案已形成"),
              (state.collaborationTab = "overview"),
              void renderEmergencyCollaboration());
        t.target.closest("#collaborationSend") && collaborationSendPrompt();
      }
      ((state.collaborationTask = state.collaborationTask || state.selectedEmergency || "E001"),
        (state.collaborationTab = state.collaborationTab || "overview"),
        (state.collaborationTaskFilter = state.collaborationTaskFilter || "all"),
        (state.collaborationMaterialFilter = state.collaborationMaterialFilter || "all"),
        (state.collaborationResponseChannel = state.collaborationResponseChannel || "all"),
        (state.collaborationSelectedMaterial = state.collaborationSelectedMaterial || null),
        (state.collaborationDecisions = state.collaborationDecisions || {
          M01: "pending",
          M03: "pending",
          M04: "pending",
        }),
        (state.collaborationMessages = state.collaborationMessages || [
          {
            role: "assistant",
            text: "四渠道寻源已完成。当前方案比原系统新增4个可用来源，补足2项缺口，预计最晚到货时间提前4小时。",
          },
          {
            role: "assistant",
            text: "目前有3项方案差异需要确认，建议优先处理关键物资来源组合。",
          },
        ]),
        (setView = function (t) {
          if (("workbench" === t && (t = "emergency"), "emergency" !== t))
            return collaborationOriginalSetView(t);
          ((state.view = "emergency"),
            $$(".view").forEach((t) => t.classList.remove("active")),
            $("#view-emergency")?.classList.add("active"),
            $$("[data-view]").forEach((t) =>
              t.classList.toggle("active", "emergency" === t.dataset.view),
            ),
            $$(".mobile-bottom [data-view]").forEach((t) =>
              t.classList.toggle("active", "emergency" === t.dataset.view),
            ),
            ($("#crumb").innerHTML = "<b>智慧工作台</b> / 应急任务中心"),
            innerWidth < 821 && $("#sidebar")?.classList.remove("mobile-open"),
            collaborationMountEmergency());
        }),
        (openPriorityEmergency = function () {
          (hideEmergencyHomeNotice(),
            (state.collaborationTask = "E001"),
            (state.collaborationTab = "overview"),
            setView("emergency"),
            showToast("已进入应急任务中心"));
        }),
        init(),
        setTimeout(() => {
          ((document.title = "供应链智慧工作台"),
            collaborationMountEmergency());
        }, 0));

/* Source runtime block 10 */
const emergencyPreviousSetView = setView,
        emergencyTaskMeta = {
          E001: {
            title: "国网重庆忠县公司110kV石拔南线#22滑坡应急",
            status: "待确认方案",
            detail: "3项待处理 · 刚刚",
            tone: "waiting",
            subtitle: "23条物资 · 18条有效响应 · 3项待确认",
          },
          E003: {
            title: "万州暴雨抢修物资保障",
            status: "寻源中",
            detail: "18条物资 · 2分钟前更新",
            tone: "running",
            subtitle: "18条物资 · 12条有效响应 · 寻源中",
          },
          E002: {
            title: "永川山火变电站应急保障",
            status: "等待确认",
            detail: "1项待确认 · 9分钟前",
            tone: "waiting",
            subtitle: "8条物资 · 7条已满足 · 1项待确认",
          },
          E004: {
            title: "黔江山火线路抢修物资调拨",
            status: "已完成",
            detail: "5条物资 · 昨日完成",
            tone: "done",
            subtitle: "5条物资 · 已完成并回写",
          },
          E005: {
            title: "綦江暴雨内涝应急保供",
            status: "已完成",
            detail: "16条物资 · 昨日完成",
            tone: "done",
            subtitle: "16条物资 · 复盘报告已生成",
          },
        };
      function emergencyEsc(t) {
        return String(t ?? "").replace(
          /[&<>'"]/g,
          (t) =>
            ({
              "&": "&amp;",
              "<": "&lt;",
              ">": "&gt;",
              "'": "&#39;",
              '"': "&quot;",
            })[t],
        );
      }
      function emergencyMeta(t) {
        return (
          emergencyTaskMeta[t] || {
            title: "应急寻源任务",
            status: "处理中",
            detail: "刚刚更新",
            tone: "running",
            subtitle: "智能体持续处理中",
          }
        );
      }
      function emergencyThreadMessages(t) {
        if (state.emergencyThreads[t]) return state.emergencyThreads[t];
        if ("center" === t)
          return (state.emergencyThreads[t] = [
            {
              role: "assistant",
              kind: "center",
              text: "当前共有5项应急寻源任务，其中2项等待确认、1项正在寻源。忠县滑坡应急任务已生成推荐方案，建议优先处理。",
            },
          ]);
        const a = emergencyMeta(t);
        return (state.emergencyThreads[t] = [
          {
            role: "assistant",
            kind: "summary",
            text: `${a.title}已完成需求校验和四渠道寻源。当前已汇总有效响应并形成AI推荐方案，仍有3项差异需要确认。`,
          },
          { role: "assistant", kind: "tools", text: "四渠道寻源已完成" },
          { role: "assistant", kind: "decision", text: "需要确认3项方案差异" },
        ]);
      }
      function emergencyPush(t, a, e = "bubble") {
        emergencyThreadMessages(state.emergencyThread).push({ role: t, text: a, kind: e });
      }
      function emergencySaveCanvas() {
        state.emergencyCanvasMemory[state.emergencyThread] = {
          open: state.emergencyCanvasOpen,
          full: state.emergencyCanvasFull,
          tab: state.emergencyCanvasTab,
          materialFilter: state.collaborationMaterialFilter,
          responseChannel: state.collaborationResponseChannel,
        };
      }
      function emergencyLoadCanvas(t) {
        const a = state.emergencyCanvasMemory[t];
        ((state.emergencyCanvasOpen = a?.open || !1),
          (state.emergencyCanvasFull = !1),
          (state.emergencyCanvasTab = a?.tab || "overview"),
          (state.collaborationTab = state.emergencyCanvasTab),
          (state.collaborationMaterialFilter = a?.materialFilter || "all"),
          (state.collaborationResponseChannel = a?.responseChannel || "all"));
      }
      function emergencySwitchThread(t) {
        (emergencySaveCanvas(),
          (state.emergencyThread = t),
          (state.collaborationTask = "center" === t ? "E001" : t),
          (state.selectedEmergency = state.collaborationTask),
          emergencyLoadCanvas(t),
          renderRecent(),
          emergencyRender());
      }
      function emergencyOpenCanvas(t = "overview") {
        ((state.emergencyCanvasTab = t),
          (state.collaborationTab = t),
          (state.emergencyCanvasOpen = !0),
          (state.emergencyCanvasFull = !1),
          emergencyRender());
      }
      function emergencyCloseCanvas() {
        ((state.emergencyCanvasOpen = !1), (state.emergencyCanvasFull = !1), emergencyRender());
      }
      function emergencyRenderRecent() {
        const t = $("#recentList");
        if (!t) return;
        const a = (state.conversations || [])
          .filter((t) => "应急任务" !== t.type)
          .slice(0, 5);
        t.innerHTML = `<div class="emergency-recent-group">${[
          "E001",
          "E003",
          "E002",
          "E004",
        ]
          .map((t) => {
            const a = emergencyMeta(t);
            return `<button class="recent-item emergency-emergency-conversation ${a.tone} ${"emergency" === state.view && state.emergencyThread === t ? "active" : ""}" data-emergency-thread="${t}">${emergencyEsc(a.title)}<span class="recent-meta"><span class="emergency-recent-status">${emergencyEsc(a.status)}</span> · ${emergencyEsc(a.detail)}</span></button>`;
          })
          .join(
            "",
          )}</div>${a.map((t, a) => `<button class="recent-item" data-recent="${state.conversations.indexOf(t)}">${emergencyEsc(t.title)}<span class="recent-meta"><span class="mini-dot ${t.live ? "live" : ""}"></span>${emergencyEsc(t.time)} · ${emergencyEsc(t.type)}</span></button>`).join("")}`;
      }
      function emergencyCenterMessage() {
        return '<article class="emergency-center-card"><div class="emergency-card-head"><div><div class="emergency-card-kicker">应急任务中心</div><h3>当前应急任务概况</h3><p>当前共有5项应急寻源任务，其中2项等待确认、1项正在寻源。您可以直接提问，也可以从左侧历史记录进入某个任务会话。</p></div><span class="emergency-card-status">智能体持续感知中</span></div><div class="emergency-card-body"><div class="emergency-kpi-row"><button data-emergency-center-canvas><b>5</b><span>应急任务</span></button><button data-emergency-center-task="E001" class="attention"><b>2</b><span>等待确认</span></button><button data-emergency-center-task="E003"><b>1</b><span>正在寻源</span></button><button data-emergency-center-canvas><b>2</b><span>已完成</span></button></div><div class="emergency-task-highlight"><div><strong>建议优先处理：忠县石拔南线#22滑坡应急</strong><span>AI推荐方案已生成，3项差异等待确认。</span></div><button data-emergency-center-task="E001">进入任务对话</button></div></div></article>';
      }
      function emergencySummaryCard(t) {
        const a = emergencyMeta(state.emergencyThread);
        return `<article class="emergency-ai-summary-card"><div class="emergency-card-head"><div><div class="emergency-card-kicker">AI任务总结</div><h3>${emergencyEsc(a.title)}</h3><p>${emergencyEsc(t.text)}</p></div><span class="emergency-card-status">${emergencyEsc(a.status)}</span></div><div class="emergency-card-body"><div class="emergency-kpi-row"><button data-emergency-open-canvas="materials"><b>23</b><span>需求物资</span></button><button data-emergency-open-canvas="responses"><b>4</b><span>寻源渠道</span></button><button data-emergency-open-canvas="responses"><b>18</b><span>有效响应</span></button><button class="attention" data-emergency-open-canvas="plans"><b>${collaborationDecisionCounts().pending}</b><span>待确认差异</span></button></div><div class="emergency-card-actions"><button data-emergency-open-canvas="overview">查看任务总览</button><button class="secondary" data-emergency-open-canvas="plans">打开方案对比</button></div></div></article>`;
      }
      function emergencyToolsCard() {
        return '<article class="emergency-tool-card"><div class="emergency-card-head"><div><div class="emergency-card-kicker">智能体执行结果</div><h3>四渠道寻源已完成</h3><p>智能体已汇聚并核验跨单位、应急抢单、在途／在建和应急采购结果。</p></div><span class="emergency-card-status">已完成</span></div><div class="emergency-tool-steps"><div class="emergency-tool-step"><i>✓</i><span><b>需求确认</b><small>完成23条需求标准化校验</small></span><em>已完成</em></div><div class="emergency-tool-step"><i>✓</i><span><b>四渠道寻源</b><small>跨单位、抢单、在途在建、应急采购</small></span><em>已完成</em></div><div class="emergency-tool-step"><i>✓</i><span><b>响应汇聚</b><small>收到18条有效响应并完成冲突校验</small></span><em>已完成</em></div><div class="emergency-tool-step current"><i>4</i><span><b>方案确认</b><small>等待确认3项差异</small></span><em>进行中</em></div></div><div class="emergency-tool-foot"><button data-emergency-open-canvas="overview">在画布中查看</button></div></article>';
      }
      function emergencyDecisionCard() {
        const t = collaborationDecisionCounts();
        return `<article class="emergency-decision-card"><div class="emergency-card-head"><div><div class="emergency-card-kicker">当前需要您处理</div><h3>${t.pending ? `确认${t.pending}项方案差异` : "最终方案已形成"}</h3><p>${t.pending ? "2项建议采用AI新增资源，1项建议启动应急采购。" : "差异已全部处理，智能体正在准备结果回写。"}</p></div><span class="emergency-card-status">${t.pending ? "待确认" : "已完成"}</span></div><div class="emergency-card-body"><div class="emergency-decision-grid"><div><b>2</b><span>建议采用AI资源</span></div><div><b>1</b><span>建议应急采购</span></div><div><b>${t.pending}</b><span>剩余待确认</span></div></div><div class="emergency-card-actions"><button data-emergency-open-canvas="plans">${t.pending ? "开始处理" : "查看最终方案"}</button><button class="secondary" data-emergency-open-canvas="events">查看事件记录</button></div></div></article>`;
      }
      function emergencyBubble(t) {
        return `<div class="emergency-message ${"user" === t.role ? "user" : ""}"><div class="emergency-avatar">${"user" === t.role ? "我" : "智"}</div><div class="emergency-message-body"><div class="emergency-bubble">${emergencyEsc(t.text)}</div></div></div>`;
      }
      function emergencyRenderMessage(t) {
        return "center" === t.kind
          ? emergencyCenterMessage()
          : "summary" === t.kind
            ? emergencySummaryCard(t)
            : "tools" === t.kind
              ? emergencyToolsCard()
              : "decision" === t.kind
                ? emergencyDecisionCard()
                : emergencyBubble(t);
      }
      function emergencyChatPane() {
        const t = "center" === state.emergencyThread,
          a = t ? null : emergencyMeta(state.emergencyThread),
          e = emergencyThreadMessages(state.emergencyThread);
        return `<section class="emergency-chat-column"><header class="emergency-thread-head"><div class="emergency-thread-title"><strong>${t ? "应急任务中心" : emergencyEsc(a.title)}</strong><span>${t ? "所有应急任务都作为独立会话保存在左侧历史记录中" : emergencyEsc(a.subtitle)}</span></div><div class="emergency-thread-actions">${t ? "" : `<button data-emergency-open-canvas="overview">${icons("i-grid")} 任务画布</button>`}<button title="更多">···</button></div></header><div class="emergency-thread-body"><div class="emergency-chat-stream">${t ? '<div class="emergency-center-welcome"><h2>应急寻源智能体</h2><p>我会持续感知新任务、汇总进展并提示需要您判断的事项。每个应急任务都是一条独立对话，点击左侧历史记录即可继续处理。</p></div>' : ""}${e.map(emergencyRenderMessage).join("")}<div class="emergency-suggestions">${t ? '<button data-emergency-suggest="查看等待我确认的任务">查看等待我确认的任务</button><button data-emergency-suggest="汇总当前寻源进展">汇总当前寻源进展</button><button data-emergency-suggest="查看今日新增任务">查看今日新增任务</button>' : '<button data-emergency-suggest="只看有缺口的物资">只看有缺口的物资</button><button data-emergency-suggest="对比原系统方案和AI方案">对比原系统与AI方案</button><button data-emergency-suggest="查看当前任务进度">查看当前任务进度</button>'}</div></div></div><div class="emergency-composer-dock"><div class="emergency-composer-shell"><textarea id="emergencyPrompt" placeholder="${t ? "向应急寻源智能体发送消息……" : "继续处理当前应急任务……"}"></textarea><div class="emergency-composer-bottom"><div class="emergency-composer-tools"><button>＋ 附件</button><button>⌘ 工具</button><button>◇ 技能</button></div><button class="emergency-send" id="emergencySend">↑</button></div></div><div class="emergency-composer-hint">Shift + Enter 换行，Enter 发送</div></div></section>`;
      }
      function emergencyCenterCanvas() {
        return '<div class="emergency-center-canvas"><article><span>任务总数</span><b>5</b><p>当前权限范围内应急任务</p></article><article><span>待本人确认</span><b>2</b><p>方案差异与关键资源决策</p></article><article><span>正在寻源</span><b>1</b><p>智能体持续汇聚资源响应</p></article><article><span>已完成</span><b>2</b><p>结果已回写并形成事件记录</p></article><article class="wide"><span>优先事项</span><div class="emergency-center-canvas-list"><button data-emergency-center-task="E001"><div><strong>忠县石拔南线#22滑坡应急</strong><small>3项方案差异等待确认</small></div><em>立即处理</em></button><button data-emergency-center-task="E002"><div><strong>永川山火变电站应急保障</strong><small>1项关键附件到货时间待确认</small></div><em>待确认</em></button><button data-emergency-center-task="E003"><div><strong>万州暴雨抢修物资保障</strong><small>四渠道寻源进行中</small></div><em>寻源中</em></button></div></article></div>';
      }
      function emergencyCanvasTabs() {
        const t = collaborationDecisionCounts();
        return `<nav class="emergency-canvas-tabs">${[
          ["overview", "任务总览"],
          ["materials", "物资清单"],
          ["responses", "响应情况"],
          ["plans", "方案与决策"],
          ["events", "事件记录"],
        ]
          .map(
            ([a, e]) =>
              `<button class="${state.emergencyCanvasTab === a ? "on" : ""}" data-emergency-canvas-tab="${a}">${e}${"plans" === a && t.pending ? `<em>${t.pending}</em>` : ""}</button>`,
          )
          .join("")}</nav>`;
      }
      function emergencyCanvasContent() {
        return "center" === state.emergencyThread
          ? emergencyCenterCanvas()
          : ((state.collaborationTab = state.emergencyCanvasTab),
            "overview" === state.emergencyCanvasTab
              ? collaborationOverview()
              : "materials" === state.emergencyCanvasTab
                ? collaborationMaterialsPage()
                : "responses" === state.emergencyCanvasTab
                  ? collaborationResponsesPage()
                  : "plans" === state.emergencyCanvasTab
                    ? collaborationPlansPage()
                    : collaborationEventsPage());
      }
      function emergencyCanvasPane() {
        const t = collaborationDecisionCounts();
        if (!state.emergencyCanvasOpen)
          return `<aside class="emergency-canvas-column"><button class="emergency-canvas-rail" data-emergency-expand-canvas title="展开业务画布"><span class="rail-icon">▣</span><b>${"center" === state.emergencyThread ? "任务态势" : "应急寻源画布"}</b>${"center" === state.emergencyThread ? "" : `<em>${t.pending}</em>`}</button></aside>`;
        return `<aside class="emergency-canvas-column"><div class="emergency-canvas-shell"><header class="emergency-canvas-head"><div class="emergency-canvas-title"><strong>${emergencyEsc("center" === state.emergencyThread ? "应急任务态势" : emergencyMeta(state.emergencyThread).title)}</strong><span><i></i>MCP App · 数据已更新</span></div><div class="emergency-canvas-actions"><button title="刷新" data-emergency-refresh>↻</button><button title="${state.emergencyCanvasFull ? "退出全屏" : "全屏"}" data-emergency-fullscreen>⛶</button><button title="收起" data-emergency-collapse-canvas>‹</button><button title="关闭" data-emergency-close-canvas>×</button></div></header>${"center" === state.emergencyThread ? "" : emergencyCanvasTabs()}<div class="emergency-canvas-body">${emergencyCanvasContent()}</div></div></aside>`;
      }
      function emergencyRender() {
        const t = $("#emergencyEmergencyWorkspace");
        if (!t) return;
        ((t.className = `emergency-agentos ${state.emergencyCanvasOpen ? "canvas-open" : ""} ${state.emergencyCanvasFull ? "canvas-full" : ""}`),
          (t.innerHTML = emergencyChatPane() + emergencyCanvasPane()),
          setTimeout(() => {
            const t = $(".emergency-thread-body");
            t && (t.scrollTop = t.scrollHeight);
          }, 0),
          renderRecent());
        const a = $('[data-view="emergency"] .side-text');
        (a && (a.textContent = "应急任务中心"),
          $("#emergencyBadge") && ($("#emergencyBadge").textContent = "3"));
      }
      function emergencyMountEmergency() {
        const t = $("#view-emergency");
        t &&
          ((t.innerHTML =
            '<div class="emergency-agentos" id="emergencyEmergencyWorkspace"></div>'),
          t.dataset.emergencyBound ||
            ((t.dataset.emergencyBound = "1"),
            t.addEventListener("click", emergencyClick, !0),
            t.addEventListener(
              "keydown",
              (t) => {
                "Enter" !== t.key ||
                  t.shiftKey ||
                  "emergencyPrompt" !== t.target?.id ||
                  (t.preventDefault(), t.stopPropagation(), emergencySendPrompt());
              },
              !0,
            )),
          emergencyRender());
      }
      function emergencySendPrompt(t) {
        const a = $("#emergencyPrompt"),
          e = (t ?? a?.value ?? "").trim();
        if (!e) return;
        (a && (a.value = ""), emergencyPush("user", e));
        let s = "已理解，我会继续在当前对话中处理。";
        ("center" === state.emergencyThread
          ? /等待|确认|优先/.test(e)
            ? (s =
                "当前有2项任务等待确认，优先级最高的是忠县滑坡应急任务，已生成方案并有3项差异待处理。")
            : /进展|汇总/.test(e)
              ? (s =
                  "当前5项任务中，1项正在寻源、2项等待确认、2项已完成。所有任务均在左侧历史记录中持续更新。")
              : /新增/.test(e) &&
                (s =
                  "今日新增1项万州暴雨抢修物资保障任务，智能体已自动完成需求解析并启动四渠道寻源。")
          : /缺口|未满足/.test(e)
            ? ((state.emergencyCanvasTab = "materials"),
              (state.collaborationMaterialFilter = "gap"),
              (state.emergencyCanvasOpen = !0),
              (s = "已在右侧画布打开物资清单，并筛选存在缺口的物资。"))
            : /方案|对比|原系统|AI/.test(e)
              ? ((state.emergencyCanvasTab = "plans"),
                (state.emergencyCanvasOpen = !0),
                (s =
                  "已打开方案与决策画布，可对比原系统方案、AI推荐方案和最终确认方案。"))
              : /响应|供应商|单位/.test(e)
                ? ((state.emergencyCanvasTab = "responses"),
                  (state.emergencyCanvasOpen = !0),
                  (s =
                    "已打开响应情况画布，可查看四类渠道的单位和供应商反馈。"))
                : /事件|记录|过程/.test(e)
                  ? ((state.emergencyCanvasTab = "events"),
                    (state.emergencyCanvasOpen = !0),
                    (s =
                      "已打开事件记录画布，展示本次应急寻源的关键业务节点。"))
                  : /总览|进度/.test(e)
                    ? ((state.emergencyCanvasTab = "overview"),
                      (state.emergencyCanvasOpen = !0),
                      (s = "已打开任务总览画布，当前处于方案确认阶段。"))
                    : /接受全部|采用全部/.test(e) &&
                      (Object.keys(state.collaborationDecisions).forEach(
                        (t) => (state.collaborationDecisions[t] = "ai"),
                      ),
                      (state.emergencyCanvasTab = "plans"),
                      (state.emergencyCanvasOpen = !0),
                      (s = "已采用全部AI推荐差异项，最终方案已具备确认条件。")),
          emergencyPush("assistant", s),
          emergencyRender());
      }
      function emergencyClick(t) {
        const a = t.target,
          e = a.closest("[data-emergency-thread]");
        if (e)
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            void emergencySwitchThread(e.dataset.emergencyThread)
          );
        const s = a.closest("[data-emergency-center-task]");
        if (s)
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            void emergencySwitchThread(s.dataset.emergencyCenterTask)
          );
        const n = a.closest("[data-emergency-suggest]");
        if (n)
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            void emergencySendPrompt(n.dataset.emergencySuggest)
          );
        const v = a.closest("[data-emergency-open-canvas]");
        if (v)
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            void emergencyOpenCanvas(v.dataset.emergencyOpenCanvas)
          );
        if (a.closest("[data-emergency-center-canvas]"))
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            (state.emergencyCanvasOpen = !0),
            void emergencyRender()
          );
        if (a.closest("[data-emergency-expand-canvas]"))
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            (state.emergencyCanvasOpen = !0),
            void emergencyRender()
          );
        if (a.closest("[data-emergency-collapse-canvas]"))
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            (state.emergencyCanvasOpen = !1),
            (state.emergencyCanvasFull = !1),
            void emergencyRender()
          );
        if (a.closest("[data-emergency-close-canvas]"))
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            void emergencyCloseCanvas()
          );
        if (a.closest("[data-emergency-fullscreen]"))
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            (state.emergencyCanvasOpen = !0),
            (state.emergencyCanvasFull = !state.emergencyCanvasFull),
            void emergencyRender()
          );
        if (a.closest("[data-emergency-refresh]"))
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            showToast("画布数据已刷新"),
            void emergencyRender()
          );
        const i = a.closest("[data-emergency-canvas-tab],[data-collaboration-tab]");
        if (i) {
          (t.preventDefault(), t.stopImmediatePropagation());
          const a = i.dataset.emergencyCanvasTab || i.dataset.collaborationTab;
          return (
            (state.emergencyCanvasTab = a),
            (state.collaborationTab = a),
            (state.collaborationSelectedMaterial = null),
            (state.emergencyCanvasOpen = !0),
            void emergencyRender()
          );
        }
        const o = a.closest("[data-collaboration-mfilter]");
        if (o)
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            (state.collaborationMaterialFilter = o.dataset.collaborationMfilter),
            void emergencyRender()
          );
        const r = a.closest("[data-collaboration-material]");
        if (r)
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            (state.collaborationSelectedMaterial = r.dataset.collaborationMaterial),
            void emergencyRender()
          );
        if (a.closest("[data-collaboration-close-detail]"))
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            (state.collaborationSelectedMaterial = null),
            void emergencyRender()
          );
        const d = a.closest("[data-collaboration-channel]");
        if (d)
          return (
            t.preventDefault(),
            t.stopImmediatePropagation(),
            (state.collaborationResponseChannel = d.dataset.collaborationChannel),
            void emergencyRender()
          );
        const c = a.closest("[data-collaboration-decision]");
        if (c) {
          (t.preventDefault(), t.stopImmediatePropagation());
          const [a, e] = c.dataset.collaborationDecision.split("|");
          state.collaborationDecisions[a] = e;
          const s = { M01: "光缆", M03: "通信电源", M04: "电力电缆" }[a] || a;
          return (
            emergencyPush(
              "assistant",
              "pending" === e
                ? `已将“${s}”恢复为待确认。`
                : `“${s}”差异已处理，${"ai" === e ? "采用AI推荐方案" : "original" === e ? "保留原系统方案" : "进入人工调整"}。`,
            ),
            void emergencyRender()
          );
        }
        return a.closest("#collaborationFinalize")
          ? (t.preventDefault(),
            t.stopImmediatePropagation(),
            collaborationDecisionCounts().pending
              ? void showToast("请先处理全部差异事项")
              : (emergencyPush(
                  "assistant",
                  "最终寻源方案已形成，智能体正在准备结果回写原系统。",
                ),
                showToast("最终寻源方案已形成"),
                (state.emergencyCanvasTab = "overview"),
                void emergencyRender()))
          : a.closest("#emergencySend")
            ? (t.preventDefault(),
              t.stopImmediatePropagation(),
              void emergencySendPrompt())
            : void 0;
      }
      ((state.emergencyThread = state.emergencyThread || "center"),
        (state.emergencyCanvasOpen = !1),
        (state.emergencyCanvasFull = !1),
        (state.emergencyCanvasTab = state.emergencyCanvasTab || "overview"),
        (state.emergencyCanvasMemory = state.emergencyCanvasMemory || {}),
        (state.emergencyThreads = state.emergencyThreads || {}),
        (renderRecent = emergencyRenderRecent),
        document.addEventListener(
          "click",
          (t) => {
            const a = t.target.closest("[data-emergency-thread]");
            a &&
              "emergency" !== state.view &&
              (t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.emergencyThread = a.dataset.emergencyThread),
              (state.collaborationTask = state.emergencyThread),
              emergencyLoadCanvas(state.emergencyThread),
              setView("emergency"));
          },
          !0,
        ),
        (setView = function (t) {
          if (("workbench" === t && (t = "emergency"), "emergency" !== t))
            return emergencyPreviousSetView(t);
          ((state.view = "emergency"),
            $$(".view").forEach((t) => t.classList.remove("active")),
            $("#view-emergency")?.classList.add("active"),
            $$("[data-view]").forEach((t) =>
              t.classList.toggle("active", "emergency" === t.dataset.view),
            ),
            $$(".mobile-bottom [data-view]").forEach((t) =>
              t.classList.toggle("active", "emergency" === t.dataset.view),
            ),
            ($("#crumb").innerHTML =
              `<b>智慧工作台</b> / ${"center" === state.emergencyThread ? "应急任务中心" : emergencyEsc(emergencyMeta(state.emergencyThread).title)}`),
            innerWidth < 821 && $("#sidebar")?.classList.remove("mobile-open"),
            emergencyMountEmergency());
        }),
        (openPriorityEmergency = function () {
          (hideEmergencyHomeNotice(),
            (state.emergencyThread = "E001"),
            (state.collaborationTask = "E001"),
            emergencyLoadCanvas("E001"),
            setView("emergency"),
            showToast("已进入应急任务对话"));
        }),
        setTimeout(() => {
          document.title = "供应链智慧工作台";
          const t = $('[data-view="emergency"] .side-text');
          (t && (t.textContent = "应急任务中心"), renderRecent());
        }, 0));

/* Source runtime block 11 */
function timelineEmergencyThreadsMarkup() {
        return ["E001", "E003", "E002"]
          .map((t) => {
            const e = emergencyMeta(t);
            return `<button class="timeline-emergency-thread ${e.tone} ${"emergency" === state.view && state.emergencyThread === t ? "active" : ""}" data-emergency-thread="${t}"><strong>${emergencyEsc(e.title)}</strong><span><i></i>${emergencyEsc(e.status)} · ${emergencyEsc(e.detail)}</span></button>`;
          })
          .join("");
      }
      function timelineEnsureSidebarTasks() {
        const t = document.querySelector('.nav-btn[data-view="emergency"]');
        if (!t) return;
        const e = t.querySelector(".side-text");
        e && (e.textContent = "应急任务中心");
        const a = t.querySelector("#emergencyBadge");
        a && (a.textContent = "3");
        let s = t.querySelector(".timeline-nav-chevron");
        (s ||
          ((s = document.createElement("span")),
          (s.className = "timeline-nav-chevron"),
          (s.dataset.timelineToggleGroup = "1"),
          (s.title = "展开或收起应急任务会话"),
          (s.innerHTML = '<svg class="icon"><use href="#i-down"></use></svg>'),
          t.appendChild(s)),
          s.classList.toggle("collapsed", state.timelineEmergencyCollapsed));
        let n = document.getElementById("timelineSidebarEmergencyThreads");
        (n ||
          ((n = document.createElement("div")),
          (n.id = "timelineSidebarEmergencyThreads"),
          (n.className = "timeline-sidebar-emergency-threads"),
          t.insertAdjacentElement("afterend", n)),
          n.classList.toggle("collapsed", state.timelineEmergencyCollapsed),
          (n.innerHTML = timelineEmergencyThreadsMarkup()));
      }
      function timelineRenderRecent() {
        const t = $("#recentList");
        if (!t) return;
        const e = (state.conversations || [])
          .filter((t) => "应急任务" !== t.type)
          .slice(0, 7);
        ((t.innerHTML = e
          .map(
            (t) =>
              `<button class="recent-item" data-recent="${state.conversations.indexOf(t)}">${emergencyEsc(t.title)}<span class="recent-meta"><span class="mini-dot ${t.live ? "live" : ""}"></span>${emergencyEsc(t.time)} · ${emergencyEsc(t.type)}</span></button>`,
          )
          .join("")),
          timelineEnsureSidebarTasks());
      }
      function timelineTaskProgress(t) {
        const e = "E003" === t ? 1 : "E004" === t || "E005" === t ? 4 : 3;
        return [
          ["需求确认", "完成需求校验", "materials"],
          ["四渠道寻源", "跨单位、抢单、在途在建、应急采购", "responses"],
          ["响应汇聚", "汇总有效响应并校验冲突", "responses"],
          ["方案确认", "确认来源组合与差异处置", "plans"],
        ].map((t, a) => ({
          key: ["demand", "source", "response", "plan"][a],
          title: t[0],
          desc: t[1],
          tab: t[2],
          state: a < e ? "done" : a === e ? "current" : "future",
        }));
      }
      function timelineDetailedSteps(t) {
        timelineTaskProgress(t).findIndex((t) => "current" === t.state);
        const e = [
          [
            "接收并解析应急需求",
            "识别任务范围、需求单位与要求到货时间",
            "09:48",
            "materials",
          ],
          [
            "校验物资需求清单",
            "完成物料编码、数量、单位和交期校验，共23条有效需求",
            "09:50",
            "materials",
          ],
          [
            "查询跨单位可调库存",
            "检索省内可调库存并评估原单位保供影响",
            "09:52",
            "responses",
          ],
          [
            "发起应急抢单",
            "向协议供应商发起快速响应并设置自动催办",
            "09:54",
            "responses",
          ],
          [
            "核验在途／在建资源",
            "识别3项可协调资源并校验原项目影响",
            "09:57",
            "responses",
          ],
          [
            "汇总18条有效响应",
            "完成数量覆盖、交期和重复来源冲突校验",
            "10:16",
            "responses",
          ],
          [
            "生成AI推荐方案",
            "比较原系统方案与四渠道组合方案，识别3项差异",
            "10:22",
            "plans",
          ],
          [
            "等待用户确认",
            "确认最终来源组合及3项差异处置方式",
            "现在",
            "plans",
          ],
        ];
        let a = "E003" === t ? 3 : "E004" === t || "E005" === t ? e.length : 7;
        return e.map((t, e) => ({
          title: t[0],
          desc: t[1],
          time: t[2],
          tab: t[3],
          state: e < a ? "done" : e === a ? "current" : "future",
        }));
      }
      function timelineHorizontalProgress(t) {
        return `<div class="timeline-stage-strip">${timelineTaskProgress(t)
          .map(
            (t, e) =>
              `<button class="timeline-stage ${t.state}" data-timeline-stage="${t.key}" data-timeline-canvas-tab="${t.tab}"><span class="timeline-stage-node">${"done" === t.state ? "✓" : e + 1}</span><strong>${t.title}</strong><small>${"done" === t.state ? "已完成" : "current" === t.state ? "当前阶段" : "待开始"}</small></button>`,
          )
          .join("")}</div>`;
      }
      function timelineVerticalTimeline(t) {
        const e = timelineDetailedSteps(t),
          a = state.timelineActiveStep[t] || "";
        return `<div class="timeline-timeline-shell"><div class="timeline-timeline-top"><div><strong>智能体执行过程</strong><span>展示业务动作、结果与当前等待事项</span></div><button class="timeline-overview-toggle secondary" data-timeline-toggle-timeline>收起执行过程</button></div><div class="timeline-timeline">${e.map((t, e) => `<button class="timeline-timeline-item ${t.state} ${a === String(e) ? "selected" : ""}" data-timeline-detail-step="${e}" data-timeline-canvas-tab="${t.tab}"><span class="timeline-timeline-icon">${"done" === t.state ? "✓" : "current" === t.state ? "●" : "○"}</span><span class="timeline-timeline-copy"><strong>${t.title}</strong><p>${t.desc}</p><small class="timeline-timeline-more">查看相关业务明细 →</small></span><time class="timeline-timeline-time">${t.time}</time></button>`).join("")}</div><div class="timeline-timeline-foot"><button class="timeline-overview-toggle secondary" data-timeline-open-events>查看完整事件记录</button></div></div>`;
      }
      function timelineTaskOverviewCard(t) {
        const e = state.emergencyThread,
          a = emergencyMeta(e),
          s = !!state.timelineTimelineExpanded[e],
          n = collaborationDecisionCounts(),
          v = s ? timelineVerticalTimeline(e) : timelineHorizontalProgress(e);
        return `<article class="timeline-task-overview"><div class="timeline-overview-head"><div><div class="eyebrow">任务总览</div><h3>${emergencyEsc(a.title)}</h3><p>${emergencyEsc(t.text)}</p></div><span class="timeline-overview-status">${emergencyEsc(a.status)}</span></div><div class="timeline-overview-body">${v}${s ? "" : `<div class="timeline-overview-metrics"><button data-emergency-open-canvas="materials"><b>23</b><span>需求物资</span></button><button data-timeline-stage="source" data-timeline-canvas-tab="responses"><b>4</b><span>寻源渠道</span></button><button data-emergency-open-canvas="responses"><b>18</b><span>有效响应</span></button><button class="attention" data-emergency-open-canvas="plans"><b>${n.pending}</b><span>待确认差异</span></button></div><div class="timeline-current-action"><div><strong>${n.pending ? "当前需要您确认最终来源组合及差异处置" : "最终寻源方案已形成"}</strong><span>${n.pending ? "2项建议采用AI新增资源，1项建议启动应急采购。" : "智能体正在准备生成结果并回写原系统。"}</span></div><div class="actions"><button class="secondary" data-timeline-toggle-timeline>查看执行过程</button><button data-emergency-open-canvas="plans">${n.pending ? "处理方案差异" : "查看最终方案"}</button></div></div>`}</div></article>`;
      }
      function timelineCenterDetail() {
        return '<div class="timeline-center-detail"><article><h3>忠县石拔南线#22滑坡应急</h3><p>AI推荐方案已生成，3项方案差异等待确认。</p><button data-emergency-center-task="E001">进入任务对话</button></article><article><h3>万州暴雨抢修物资保障</h3><p>四渠道寻源进行中，已收到12条有效响应。</p><button data-emergency-center-task="E003">进入任务对话</button></article><article><h3>永川山火变电站应急保障</h3><p>1项关键附件到货时间等待确认。</p><button data-emergency-center-task="E002">进入任务对话</button></article></div>';
      }
      ((state.timelineEmergencyCollapsed = state.timelineEmergencyCollapsed ?? !1),
        (state.timelineTimelineExpanded = state.timelineTimelineExpanded || {}),
        (state.timelineActiveStep = state.timelineActiveStep || {}),
        (renderRecent = timelineRenderRecent),
        (emergencyThreadMessages = function (t) {
          if (state.emergencyThreads[t]) return state.emergencyThreads[t];
          if ("center" === t)
            return (state.emergencyThreads[t] = [
              {
                role: "assistant",
                kind: "center",
                text: "当前共有3项进行中的应急寻源任务，其中2项等待确认、1项正在寻源。忠县滑坡应急任务已生成推荐方案，建议优先处理。",
              },
            ]);
          const e = emergencyMeta(t),
            a =
              "E003" === t
                ? `${e.title}已完成需求确认，四渠道寻源正在并行执行。当前已收到12条有效响应，智能体仍在持续催办和校验资源可用性。`
                : `${e.title}已完成需求校验、四渠道寻源和响应汇聚。23条物资中20条已形成完整来源组合，当前有3项方案差异需要确认。`;
          return (state.emergencyThreads[t] = [
            { role: "assistant", kind: "timelineoverview", text: a },
          ]);
        }),
        (emergencyRenderMessage = function (t) {
          return "center" === t.kind
            ? emergencyCenterMessage()
            : "timelineoverview" === t.kind || "summary" === t.kind
              ? timelineTaskOverviewCard(t)
              : emergencyBubble(t);
        }),
        (emergencyCenterMessage = function () {
          return '<article class="emergency-center-card"><div class="emergency-card-head"><div><div class="emergency-card-kicker">应急任务中心</div><h3>当前应急任务概况</h3><p>当前共有3项进行中的应急寻源任务，其中2项等待确认、1项正在寻源。每个任务都是一条独立会话，可从左侧“应急任务中心”下方继续处理。</p></div><span class="emergency-card-status">智能体持续感知中</span></div><div class="emergency-card-body"><div class="emergency-kpi-row"><button data-emergency-center-task="E001"><b>3</b><span>进行中任务</span></button><button data-emergency-center-task="E001" class="attention"><b>2</b><span>等待确认</span></button><button data-emergency-center-task="E003"><b>1</b><span>正在寻源</span></button><button data-emergency-center-task="E001"><b>3</b><span>新增待处理</span></button></div><div class="emergency-task-highlight"><div><strong>建议优先处理：忠县石拔南线#22滑坡应急</strong><span>AI推荐方案已生成，3项差异等待确认。</span></div><button data-emergency-center-task="E001">进入任务对话</button></div></div></article>';
        }),
        (emergencyCanvasTabs = function () {
          const t = collaborationDecisionCounts();
          return `<nav class="emergency-canvas-tabs">${[
            ["materials", "物资清单"],
            ["responses", "响应情况"],
            ["plans", "方案与决策"],
            ["events", "事件记录"],
          ]
            .map(
              ([e, a]) =>
                `<button class="${state.emergencyCanvasTab === e ? "on" : ""}" data-emergency-canvas-tab="${e}">${a}${"plans" === e && t.pending ? `<em>${t.pending}</em>` : ""}</button>`,
            )
            .join("")}</nav>`;
        }),
        (emergencyCanvasContent = function () {
          if ("center" === state.emergencyThread) return timelineCenterDetail();
          let t = state.emergencyCanvasTab;
          return (
            "overview" === t && (t = "plans"),
            (state.emergencyCanvasTab = t),
            (state.collaborationTab = t),
            "materials" === t
              ? collaborationMaterialsPage()
              : "responses" === t
                ? collaborationResponsesPage()
                : "plans" === t
                  ? collaborationPlansPage()
                  : collaborationEventsPage()
          );
        }),
        (emergencyOpenCanvas = function (t = "plans") {
          ("overview" === t && (t = "plans"),
            (state.emergencyCanvasTab = t),
            (state.collaborationTab = t),
            (state.emergencyCanvasOpen = !0),
            (state.emergencyCanvasFull = !1),
            emergencyRender());
        }));
      const timelineOldLoadCanvas = emergencyLoadCanvas;
      ((emergencyLoadCanvas = function (t) {
        (timelineOldLoadCanvas(t),
          "overview" === state.emergencyCanvasTab &&
            (state.emergencyCanvasTab = "E003" === t ? "responses" : "plans"),
          (state.collaborationTab = state.emergencyCanvasTab),
          (state.emergencyCanvasOpen = !1),
          (state.emergencyCanvasFull = !1));
      }),
        (emergencyChatPane = function () {
          const t = "center" === state.emergencyThread,
            e = t ? null : emergencyMeta(state.emergencyThread),
            a = emergencyThreadMessages(state.emergencyThread);
          return `<section class="emergency-chat-column"><header class="emergency-thread-head"><div class="emergency-thread-title"><strong>${t ? "应急任务中心" : emergencyEsc(e.title)}</strong><span>${t ? "任务会话持续保存在左侧历史记录中" : emergencyEsc(e.subtitle)}</span></div><div class="emergency-thread-actions">${t ? "" : `<button data-emergency-open-canvas="${"overview" === state.emergencyCanvasTab ? "plans" : state.emergencyCanvasTab}">${icons("i-grid")} 业务画布</button>`}<button title="更多">···</button></div></header><div class="emergency-thread-body"><div class="emergency-chat-stream">${t ? '<div class="emergency-center-welcome"><h2>应急寻源智能体</h2><p>我会持续感知新任务、汇总进展并提示需要您判断的事项。选择左侧任务会话后，中间展示任务总览和执行过程，右侧画布按需显示业务明细。</p></div>' : ""}${a.map(emergencyRenderMessage).join("")}<div class="emergency-suggestions">${t ? '<button data-emergency-suggest="查看等待我确认的任务">查看等待我确认的任务</button><button data-emergency-suggest="汇总当前寻源进展">汇总当前寻源进展</button><button data-emergency-suggest="查看今日新增任务">查看今日新增任务</button>' : '<button data-emergency-suggest="展开当前任务执行过程">展开执行过程</button><button data-emergency-suggest="只看有缺口的物资">只看有缺口的物资</button><button data-emergency-suggest="对比原系统方案和AI方案">对比原系统与AI方案</button>'}</div></div></div><div class="emergency-composer-dock"><div class="emergency-composer-shell"><textarea id="emergencyPrompt" placeholder="${t ? "向应急寻源智能体发送消息……" : "继续处理当前应急任务……"}"></textarea><div class="emergency-composer-bottom"><div class="emergency-composer-tools"><button>＋ 附件</button><button>⌘ 工具</button><button>◇ 技能</button></div><button class="emergency-send" id="emergencySend">↑</button></div></div><div class="emergency-composer-hint">Shift + Enter 换行，Enter 发送</div></div></section>`;
        }),
        (emergencyCanvasPane = function () {
          const t = collaborationDecisionCounts();
          if (!state.emergencyCanvasOpen)
            return `<aside class="emergency-canvas-column"><button class="emergency-canvas-rail" data-emergency-expand-canvas title="展开业务画布"><span class="rail-icon">▣</span><b>${"center" === state.emergencyThread ? "任务明细" : "业务画布"}</b>${"center" === state.emergencyThread ? "" : `<em>${t.pending}</em>`}</button></aside>`;
          const e =
            "center" === state.emergencyThread
              ? "应急任务明细"
              : emergencyMeta(state.emergencyThread).title;
          return `<aside class="emergency-canvas-column"><div class="emergency-canvas-shell"><header class="emergency-canvas-head"><div class="emergency-canvas-title"><strong>应急寻源业务画布</strong><span><i></i>${emergencyEsc(e)} · 数据已更新</span></div><div class="emergency-canvas-actions"><button title="刷新" data-emergency-refresh>↻</button><button title="${state.emergencyCanvasFull ? "退出全屏" : "全屏"}" data-emergency-fullscreen>⛶</button><button title="收起" data-emergency-collapse-canvas>‹</button><button title="关闭" data-emergency-close-canvas>×</button></div></header>${"center" === state.emergencyThread ? "" : emergencyCanvasTabs()}<div class="emergency-canvas-body">${emergencyCanvasContent()}</div></div></aside>`;
        }),
        (emergencySendPrompt = function (t) {
          const e = $("#emergencyPrompt"),
            a = (t ?? e?.value ?? "").trim();
          if (!a) return;
          (e && (e.value = ""), emergencyPush("user", a));
          let s = "已理解，我会继续在当前任务会话中处理。";
          ("center" === state.emergencyThread
            ? /等待|确认|优先/.test(a)
              ? (s =
                  "当前有2项任务等待确认，优先级最高的是忠县滑坡应急任务，已生成方案并有3项差异待处理。")
              : /进展|汇总/.test(a)
                ? (s =
                    "当前3项任务中，1项正在寻源、2项等待确认。所有任务均在左侧“应急任务中心”下持续更新。")
                : /新增/.test(a) &&
                  (s =
                    "今日新增万州暴雨抢修物资保障任务，智能体已自动完成需求解析并启动四渠道寻源。")
            : /执行|进度|过程|总览/.test(a)
              ? ((state.timelineTimelineExpanded[state.emergencyThread] = !0),
                (s =
                  "已将横向任务总览展开为详细执行过程，可点击任一步骤在右侧查看对应业务明细。"))
              : /缺口|未满足/.test(a)
                ? ((state.emergencyCanvasTab = "materials"),
                  (state.collaborationMaterialFilter = "gap"),
                  (state.emergencyCanvasOpen = !0),
                  (s = "已在右侧画布打开物资清单，并筛选存在缺口的物资。"))
                : /方案|对比|原系统|AI/.test(a)
                  ? ((state.emergencyCanvasTab = "plans"),
                    (state.emergencyCanvasOpen = !0),
                    (s =
                      "已打开方案与决策画布，可对比原系统方案、AI推荐方案和最终确认方案。"))
                  : /响应|供应商|单位/.test(a)
                    ? ((state.emergencyCanvasTab = "responses"),
                      (state.emergencyCanvasOpen = !0),
                      (s =
                        "已打开响应情况画布，可查看四类渠道的单位和供应商反馈。"))
                    : /事件|记录/.test(a)
                      ? ((state.emergencyCanvasTab = "events"),
                        (state.emergencyCanvasOpen = !0),
                        (s =
                          "已打开事件记录画布，展示本次应急寻源的关键业务节点。"))
                      : /接受全部|采用全部/.test(a) &&
                        (Object.keys(state.collaborationDecisions).forEach(
                          (t) => (state.collaborationDecisions[t] = "ai"),
                        ),
                        (state.emergencyCanvasTab = "plans"),
                        (state.emergencyCanvasOpen = !0),
                        (s =
                          "已采用全部AI推荐差异项，最终方案已具备确认条件。")),
            emergencyPush("assistant", s),
            emergencyRender());
        }),
        (emergencyClick = function (t) {
          const e = t.target,
            a = e.closest("[data-timeline-stage]");
          if (a)
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.timelineTimelineExpanded[state.emergencyThread] = !0),
              (state.timelineActiveStep[state.emergencyThread] = a.dataset.timelineStage || ""),
              (state.emergencyCanvasTab = a.dataset.timelineCanvasTab || "plans"),
              (state.collaborationTab = state.emergencyCanvasTab),
              (state.emergencyCanvasOpen = !0),
              void emergencyRender()
            );
          if (e.closest("[data-timeline-toggle-timeline]"))
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.timelineTimelineExpanded[state.emergencyThread] =
                !state.timelineTimelineExpanded[state.emergencyThread]),
              void emergencyRender()
            );
          const s = e.closest("[data-timeline-detail-step]");
          if (s)
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.timelineActiveStep[state.emergencyThread] = s.dataset.timelineDetailStep),
              (state.emergencyCanvasTab = s.dataset.timelineCanvasTab || "events"),
              (state.collaborationTab = state.emergencyCanvasTab),
              (state.emergencyCanvasOpen = !0),
              void emergencyRender()
            );
          if (e.closest("[data-timeline-open-events]"))
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.emergencyCanvasTab = "events"),
              (state.collaborationTab = "events"),
              (state.emergencyCanvasOpen = !0),
              void emergencyRender()
            );
          const n = e.closest("[data-emergency-thread]");
          if (n)
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              void emergencySwitchThread(n.dataset.emergencyThread)
            );
          const v = e.closest("[data-emergency-center-task]");
          if (v)
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              void emergencySwitchThread(v.dataset.emergencyCenterTask)
            );
          const o = e.closest("[data-emergency-suggest]");
          if (o)
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              void emergencySendPrompt(o.dataset.emergencySuggest)
            );
          const r = e.closest("[data-emergency-open-canvas]");
          if (r)
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              void emergencyOpenCanvas(r.dataset.emergencyOpenCanvas)
            );
          if (e.closest("[data-emergency-center-canvas]"))
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.emergencyCanvasOpen = !0),
              void emergencyRender()
            );
          if (e.closest("[data-emergency-expand-canvas]"))
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.emergencyCanvasOpen = !0),
              "overview" === state.emergencyCanvasTab &&
                (state.emergencyCanvasTab =
                  "E003" === state.emergencyThread ? "responses" : "plans"),
              void emergencyRender()
            );
          if (e.closest("[data-emergency-collapse-canvas]"))
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.emergencyCanvasOpen = !1),
              (state.emergencyCanvasFull = !1),
              void emergencyRender()
            );
          if (e.closest("[data-emergency-close-canvas]"))
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              void emergencyCloseCanvas()
            );
          if (e.closest("[data-emergency-fullscreen]"))
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.emergencyCanvasOpen = !0),
              (state.emergencyCanvasFull = !state.emergencyCanvasFull),
              void emergencyRender()
            );
          if (e.closest("[data-emergency-refresh]"))
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              showToast("画布数据已刷新"),
              void emergencyRender()
            );
          const i = e.closest("[data-emergency-canvas-tab],[data-collaboration-tab]");
          if (i) {
            (t.preventDefault(), t.stopImmediatePropagation());
            let e = i.dataset.emergencyCanvasTab || i.dataset.collaborationTab;
            return (
              "overview" === e && (e = "plans"),
              (state.emergencyCanvasTab = e),
              (state.collaborationTab = e),
              (state.collaborationSelectedMaterial = null),
              (state.emergencyCanvasOpen = !0),
              void emergencyRender()
            );
          }
          const d = e.closest("[data-collaboration-mfilter]");
          if (d)
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.collaborationMaterialFilter = d.dataset.collaborationMfilter),
              void emergencyRender()
            );
          const c = e.closest("[data-collaboration-material]");
          if (c)
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.collaborationSelectedMaterial = c.dataset.collaborationMaterial),
              void emergencyRender()
            );
          if (e.closest("[data-collaboration-close-detail]"))
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.collaborationSelectedMaterial = null),
              void emergencyRender()
            );
          const l = e.closest("[data-collaboration-channel]");
          if (l)
            return (
              t.preventDefault(),
              t.stopImmediatePropagation(),
              (state.collaborationResponseChannel = l.dataset.collaborationChannel),
              void emergencyRender()
            );
          const p = e.closest("[data-collaboration-decision]");
          if (p) {
            (t.preventDefault(), t.stopImmediatePropagation());
            const [e, a] = p.dataset.collaborationDecision.split("|");
            state.collaborationDecisions[e] = a;
            const s = { M01: "光缆", M03: "通信电源", M04: "电力电缆" }[e] || e;
            return (
              emergencyPush(
                "assistant",
                "pending" === a
                  ? `已将“${s}”恢复为待确认。`
                  : `“${s}”差异已处理，${"ai" === a ? "采用AI推荐方案" : "original" === a ? "保留原系统方案" : "进入人工调整"}。`,
              ),
              void emergencyRender()
            );
          }
          return e.closest("#collaborationFinalize")
            ? (t.preventDefault(),
              t.stopImmediatePropagation(),
              collaborationDecisionCounts().pending
                ? void showToast("请先处理全部差异事项")
                : (emergencyPush(
                    "assistant",
                    "最终寻源方案已形成，智能体正在准备结果回写原系统。",
                  ),
                  showToast("最终寻源方案已形成"),
                  (state.emergencyCanvasTab = "events"),
                  void emergencyRender()))
            : e.closest("#emergencySend")
              ? (t.preventDefault(),
                t.stopImmediatePropagation(),
                void emergencySendPrompt())
              : void 0;
        }));
      const timelineOldRender = emergencyRender;
      ((emergencyRender = function () {
        const t = $("#emergencyEmergencyWorkspace");
        if (!t) return;
        ((t.className = `emergency-agentos ${state.emergencyCanvasOpen ? "canvas-open" : ""} ${state.emergencyCanvasFull ? "canvas-full" : ""}`),
          (t.innerHTML = emergencyChatPane() + emergencyCanvasPane()),
          setTimeout(() => {
            const t = $(".emergency-thread-body");
            t && (t.scrollTop = 0);
          }, 0),
          timelineRenderRecent(),
          timelineEnsureSidebarTasks());
        const e = $('[data-view="emergency"] .side-text');
        (e && (e.textContent = "应急任务中心"),
          $("#emergencyBadge") && ($("#emergencyBadge").textContent = "3"));
      }),
        document.addEventListener(
          "click",
          (t) => {
            if (t.target.closest("[data-timeline-toggle-group]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.timelineEmergencyCollapsed = !state.timelineEmergencyCollapsed),
                void timelineEnsureSidebarTasks()
              );
            const e = t.target.closest("[data-emergency-thread]");
            if (e && !t.target.closest("#view-emergency")) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const a = e.dataset.emergencyThread;
              return void ("emergency" === state.view
                ? emergencySwitchThread(a)
                : ((state.emergencyThread = a),
                  (state.collaborationTask = a),
                  emergencyLoadCanvas(a),
                  setView("emergency")));
            }
          },
          !0,
        ),
        setTimeout(() => {
          ((document.title = "供应链智慧工作台"),
            timelineRenderRecent(),
            timelineEnsureSidebarTasks());
        }, 0));

/* Source runtime block 12 */
((state.taskcenterCenterFilter = state.taskcenterCenterFilter || "all"),
        (state.taskcenterCenterDetailTask = state.taskcenterCenterDetailTask || "E001"),
        (state.taskcenterNewTriggered = state.taskcenterNewTriggered || !1));
      const taskcenterTaskRuntime = {
        E001: {
          trigger: "应急事件常驻感知任务",
          triggerAt: "今日 09:48",
          summary: "四渠道寻源已完成，AI推荐方案已生成，3项方案差异等待确认。",
          isNew: !1,
        },
        E003: {
          trigger: "气象与工单联合监测",
          triggerAt: "今日 10:32",
          summary:
            "四渠道寻源正在执行，已收到12条有效响应，仍等待2家单位回复。",
          isNew: !0,
        },
        E002: {
          trigger: "设备故障应急工单监测",
          triggerAt: "今日 09:08",
          summary: "已形成初步来源组合，1项关键附件到货时间等待确认。",
          isNew: !1,
        },
        E006: {
          trigger: "应急事件常驻感知任务",
          triggerAt: "刚刚",
          summary: "新事件已完成识别，智能体正在解析需求并创建四渠道寻源计划。",
          isNew: !0,
        },
      };
      function taskcenterTaskIds() {
        return ["E001", "E003", "E002"].concat(
          state.taskcenterNewTriggered ? ["E006"] : [],
        );
      }
      function taskcenterTaskClass(e) {
        return emergencyMeta(e).tone || "running";
      }
      function taskcenterTaskCounts() {
        const e = taskcenterTaskIds();
        return {
          all: e.length,
          waiting: e.filter((e) => "waiting" === taskcenterTaskClass(e)).length,
          running: e.filter((e) => "running" === taskcenterTaskClass(e)).length,
          new: e.filter((e) => taskcenterTaskRuntime[e]?.isNew).length,
        };
      }
      function taskcenterFilteredTaskIds() {
        const e = taskcenterTaskIds(),
          t = state.taskcenterCenterFilter;
        return "all" === t
          ? e
          : "waiting" === t
            ? e.filter((e) => "waiting" === taskcenterTaskClass(e))
            : "running" === t
              ? e.filter((e) => "running" === taskcenterTaskClass(e))
              : e.filter((e) => taskcenterTaskRuntime[e]?.isNew);
      }
      function taskcenterTaskCard(e) {
        const t = emergencyMeta(e),
          a = taskcenterTaskRuntime[e] || {};
        return `<article class="taskcenter-task-card ${taskcenterTaskClass(e)}" data-taskcenter-open-task="${e}"><div><div class="taskcenter-task-titleline"><strong>${emergencyEsc(t.title)}</strong><span class="taskcenter-task-status">${emergencyEsc(t.status)}</span></div><div class="taskcenter-task-summary">${emergencyEsc(a.summary || t.subtitle)}</div><div class="taskcenter-task-source">${icons("i-clock")}<span>由 <b>${emergencyEsc(a.trigger || "定时任务中心")}</b> 于 ${emergencyEsc(a.triggerAt || "刚刚")} 触发并新建对话</span></div></div><div class="taskcenter-task-actions"><button data-taskcenter-task-detail="${e}">触发详情</button><button class="primary" data-taskcenter-open-task="${e}">进入任务</button></div></article>`;
      }
      ((emergencyTaskMeta.E001.subtitle = "23条物资 · 3项待确认"),
        (emergencyTaskMeta.E003.subtitle = "18条物资 · 寻源中"),
        (emergencyTaskMeta.E002.subtitle = "8条物资 · 1项待确认"),
        (emergencyCenterMessage = function () {
          const e = taskcenterTaskCounts(),
            t = taskcenterFilteredTaskIds();
          return `<article class="taskcenter-center-brief"><div class="taskcenter-brief-head"><div class="taskcenter-brief-head-main"><span class="taskcenter-brief-icon">${icons("i-alert")}</span><div><h3>应急任务简报</h3><p>当前共有<b>${e.all}项应急物资保障任务</b>正在推进。忠县滑坡任务已完成四渠道寻源，23条物资中20条已形成来源组合，<b>3项方案差异等待确认</b>，为当前首要处置事项；万州暴雨任务已取得12条有效响应，仍有2家单位待回复；永川山火任务已形成初步来源组合，1项关键附件到货时间待确认。建议优先完成忠县方案确认，尽快衔接后续调拨与采购执行。</p></div></div><span class="taskcenter-trigger-badge"><i></i>定时任务联动运行中</span></div><div class="taskcenter-brief-body"><div class="taskcenter-brief-kpis"><button class="${"all" === state.taskcenterCenterFilter ? "active" : ""}" data-taskcenter-center-filter="all"><b>${e.all}</b><span>当前任务</span></button><button class="attention ${"waiting" === state.taskcenterCenterFilter ? "active" : ""}" data-taskcenter-center-filter="waiting"><b>${e.waiting}</b><span>等待确认</span></button><button class="${"running" === state.taskcenterCenterFilter ? "active" : ""}" data-taskcenter-center-filter="running"><b>${e.running}</b><span>正在寻源</span></button><button class="${"new" === state.taskcenterCenterFilter ? "active" : ""}" data-taskcenter-center-filter="new"><b>${e.new}</b><span>今日新增</span></button></div><div class="taskcenter-trigger-flow"><div class="taskcenter-trigger-flow-main"><b>定时监测规则</b><span class="taskcenter-flow-arrow">→</span><span>识别应急事件</span><span class="taskcenter-flow-arrow">→</span><span>创建任务实例和独立对话</span><span class="taskcenter-flow-arrow">→</span><span>智能体持续执行</span></div><button data-taskcenter-open-schedule>查看定时任务来源</button></div><div class="taskcenter-task-list">${t.length ? t.map(taskcenterTaskCard).join("") : '<div class="taskcenter-task-list-empty">当前筛选条件下暂无应急任务。</div>'}</div></div></article>`;
        }),
        (timelineEmergencyThreadsMarkup = function () {
          return taskcenterTaskIds()
            .map((e) => {
              const t = emergencyMeta(e),
                a = taskcenterTaskRuntime[e] || {};
              return `<button class="timeline-emergency-thread ${t.tone} ${"emergency" === state.view && state.emergencyThread === e ? "active" : ""}" data-emergency-thread="${e}"><strong>${emergencyEsc(t.title)}</strong><span><i></i>${emergencyEsc(t.status)} · ${emergencyEsc(a.isNew ? "新任务" : t.detail)}</span></button>`;
            })
            .join("");
        }));
      const taskcenterOldEnsureSidebar = timelineEnsureSidebarTasks;
      function taskcenterCenterDetailMarkup() {
        const e = state.taskcenterCenterDetailTask || taskcenterTaskIds()[0],
          t = emergencyMeta(e),
          a = taskcenterTaskRuntime[e] || {};
        return `<div class="taskcenter-center-detail"><article class="taskcenter-detail-hero"><h3>${emergencyEsc(t.title)}</h3><p>${emergencyEsc(a.summary || t.subtitle)}</p><div class="taskcenter-detail-grid"><div><span>触发规则</span><b>${emergencyEsc(a.trigger || "应急事件常驻感知任务")}</b></div><div><span>触发时间</span><b>${emergencyEsc(a.triggerAt || "刚刚")}</b></div><div><span>创建方式</span><b>自动创建任务实例与独立对话</b></div><div><span>当前状态</span><b>${emergencyEsc(t.status)}</b></div></div><div class="taskcenter-detail-actions"><button class="primary" data-taskcenter-open-task="${e}">进入任务对话</button><button data-taskcenter-open-schedule>查看触发规则</button></div></article></div>`;
      }
      timelineEnsureSidebarTasks = function () {
        taskcenterOldEnsureSidebar();
        const e = taskcenterTaskIds().length,
          t = document.querySelector(
            '.nav-btn[data-view="emergency"] #emergencyBadge',
          );
        t && (t.textContent = String(e));
        const a = document.getElementById("timelineSidebarEmergencyThreads");
        a && (a.innerHTML = timelineEmergencyThreadsMarkup());
      };
      const taskcenterOldCanvasContent = emergencyCanvasContent;
      emergencyCanvasContent = function () {
        return "center" === state.emergencyThread
          ? taskcenterCenterDetailMarkup()
          : taskcenterOldCanvasContent();
      };
      const taskcenterOldChatPane = emergencyChatPane;
      function taskcenterMatchTask(e) {
        return /忠县|石拔南线|滑坡/.test(e)
          ? "E001"
          : /万州|暴雨|抢修/.test(e)
            ? "E003"
            : /永川|山火|变电站/.test(e)
              ? "E002"
              : /江津|设备故障|新任务/.test(e) && state.taskcenterNewTriggered
                ? "E006"
                : "";
      }
      function taskcenterDecorateSchedule() {
        const e = $("#scheduleDetail");
        if (!e) return;
        if (
          (e.querySelector(".taskcenter-schedule-triggered")?.remove(),
          1 !== +state.selectedSchedule)
        )
          return;
        const t = e.querySelector(".schedule-detail-body");
        if (!t) return;
        const a = taskcenterTaskIds();
        t.insertAdjacentHTML(
          "beforeend",
          `<section class="schedule-section taskcenter-schedule-triggered"><div class="taskcenter-schedule-triggered-head"><h3>已触发应急任务会话</h3><span>${a.length}条 · 任务状态与对话实时同步</span></div><div class="taskcenter-schedule-task-list">${a
            .map((e) => {
              const t = emergencyMeta(e),
                a = taskcenterTaskRuntime[e] || {};
              return `<button class="taskcenter-schedule-task" data-taskcenter-schedule-task="${e}"><div><strong>${emergencyEsc(t.title)}</strong><small>${emergencyEsc(a.triggerAt || "刚刚")} 创建对话 · ${emergencyEsc(t.status)}</small></div><em>进入任务 →</em></button>`;
            })
            .join("")}</div></section>`,
        );
      }
      ((emergencyChatPane = function () {
        const e = taskcenterOldChatPane();
        return "center" !== state.emergencyThread
          ? e
          : e
              .replace(
                "任务会话持续保存在左侧历史记录中",
                "定时任务触发后自动创建独立应急任务对话",
              )
              .replace(
                "我会持续感知新任务、汇总进展并提示需要您判断的事项。选择左侧任务会话后，中间展示任务总览和执行过程，右侧画布按需显示业务明细。",
                "定时任务中心负责持续监测和触发；每次识别到新应急事件，系统会自动创建一条独立任务对话。您可以从简报筛选任务，也可以直接输入任务名称进入处理。",
              );
      }),
        (emergencySendPrompt = function (e) {
          const t = $("#emergencyPrompt"),
            a = (e ?? t?.value ?? "").trim();
          if (!a) return;
          if ((t && (t.value = ""), "center" === state.emergencyThread)) {
            const e = taskcenterMatchTask(a);
            if (e)
              return (
                emergencyThreadMessages("center").push(
                  { role: "user", kind: "bubble", text: a },
                  {
                    role: "assistant",
                    kind: "bubble",
                    text: `已找到“${emergencyMeta(e).title}”，正在切换到该任务对话。`,
                  },
                ),
                emergencySwitchThread(e),
                emergencyThreadMessages(e).push(
                  { role: "user", kind: "bubble", text: a },
                  {
                    role: "assistant",
                    kind: "bubble",
                    text: "已进入本任务。上方为任务总览，可展开执行过程；点击具体数字或节点可在右侧画布查看业务明细。",
                  },
                ),
                void emergencyRender()
              );
            emergencyThreadMessages("center").push({
              role: "user",
              kind: "bubble",
              text: a,
            });
            let t = "已根据您的问题更新应急任务简报。";
            return (
              /等待|确认|优先/.test(a)
                ? ((state.taskcenterCenterFilter = "waiting"),
                  (t =
                    "已筛选等待确认的任务。忠县滑坡应急任务优先级最高，AI方案已生成并有3项差异待处理。"))
                : /寻源|进行中/.test(a)
                  ? ((state.taskcenterCenterFilter = "running"),
                    (t =
                      "已筛选正在寻源的任务。万州暴雨抢修任务当前已收到12条有效响应。"))
                  : /新增|刚刚/.test(a)
                    ? ((state.taskcenterCenterFilter = "new"),
                      (t =
                        "已筛选今日新增任务。每个新任务均由定时监测规则触发并自动创建独立对话。"))
                    : /全部|汇总|进展/.test(a) &&
                      ((state.taskcenterCenterFilter = "all"),
                      (t =
                        "当前所有应急任务已汇总展示，可点击任一任务进入其独立对话。")),
              emergencyThreadMessages("center").push({
                role: "assistant",
                kind: "bubble",
                text: t,
              }),
              void emergencyRender()
            );
          }
          emergencyPush("user", a);
          let s = "已理解，我会继续在当前任务会话中处理。";
          (/执行|进度|过程|总览/.test(a)
            ? ((state.timelineTimelineExpanded[state.emergencyThread] = !0),
              (s =
                "已将横向任务总览展开为详细执行过程，可点击任一步骤在右侧查看对应业务明细。"))
            : /缺口|未满足/.test(a)
              ? ((state.emergencyCanvasTab = "materials"),
                (state.collaborationMaterialFilter = "gap"),
                (state.emergencyCanvasOpen = !0),
                (s = "已在右侧画布打开物资清单，并筛选存在缺口的物资。"))
              : /方案|对比|原系统|AI/.test(a)
                ? ((state.emergencyCanvasTab = "plans"),
                  (state.emergencyCanvasOpen = !0),
                  (s =
                    "已打开方案与决策画布，可对比原系统方案、AI推荐方案和最终确认方案。"))
                : /响应|供应商|单位/.test(a)
                  ? ((state.emergencyCanvasTab = "responses"),
                    (state.emergencyCanvasOpen = !0),
                    (s =
                      "已打开响应情况画布，可查看四类渠道的单位和供应商反馈。"))
                  : /事件|记录/.test(a)
                    ? ((state.emergencyCanvasTab = "events"),
                      (state.emergencyCanvasOpen = !0),
                      (s =
                        "已打开事件记录画布，展示本次应急寻源的关键业务节点。"))
                    : /接受全部|采用全部/.test(a) &&
                      (Object.keys(state.collaborationDecisions).forEach(
                        (e) => (state.collaborationDecisions[e] = "ai"),
                      ),
                      (state.emergencyCanvasTab = "plans"),
                      (state.emergencyCanvasOpen = !0),
                      (s = "已采用全部AI推荐差异项，最终方案已具备确认条件。")),
            emergencyPush("assistant", s),
            emergencyRender());
        }));
      const taskcenterOldRenderSchedules = renderSchedules;
      function taskcenterSimulateScheduleTrigger() {
        if (state.taskcenterNewTriggered) showToast("本次扫描未发现新的独立应急事件");
        else {
          ((state.taskcenterNewTriggered = !0),
            (emergencyTaskMeta.E006 = {
              title: "江津设备故障应急物资保障",
              status: "需求解析中",
              detail: "刚刚自动创建",
              tone: "running",
              subtitle: "由“应急事件常驻感知任务”自动创建 · 正在解析需求",
            }),
            (state.emergencyThreads.E006 = [
              {
                role: "assistant",
                kind: "timelineoverview",
                text: "定时监测发现江津设备故障应急工单，已自动创建本任务对话。智能体正在解析需求清单并准备启动四渠道寻源。",
              },
            ]));
          const e = state.scheduled.find((e) => 1 === e.id);
          (e &&
            ((e.last = "刚刚 · 发现1个新增任务并创建对话"),
            (e.runsToday = (e.runsToday || 6) + 1)),
            showToast("已触发新应急事件，并自动创建任务对话"));
        }
        (renderSchedules(),
          timelineEnsureSidebarTasks(),
          "emergency" === state.view &&
            "center" === state.emergencyThread &&
            emergencyRender());
      }
      function taskcenterEnhanceHomeBrief() {
        const e = $("#normalBriefCard .normal-brief-mini");
        e &&
          !e.querySelector(".taskcenter-home-emergency") &&
          e.insertAdjacentHTML(
            "beforeend",
            `<button class="taskcenter-home-emergency" data-taskcenter-home-emergency><b>${taskcenterTaskIds().length}</b>应急任务</button>`,
          );
        const t = $('[data-butler-action="detail"][data-task-id="T1"]');
        t && (t.textContent = "进入应急任务对话");
        const a = $('[data-butler-action="detail"][data-task-id="T7"]');
        a && (a.textContent = "进入应急任务中心");
      }
      renderSchedules = function () {
        (taskcenterOldRenderSchedules(), setTimeout(taskcenterDecorateSchedule, 0));
      };
      const taskcenterOldRenderTaskList = assistantbriefRenderTaskList;
      assistantbriefRenderTaskList = function () {
        (taskcenterOldRenderTaskList(), setTimeout(taskcenterEnhanceHomeBrief, 0));
      };
      const taskcenterOldRenderConversation = livebriefRenderConversation;
      function taskcenterOpenTask(e) {
        ((state.emergencyThread = e),
          (state.collaborationTask = e),
          (state.selectedEmergency = e),
          emergencyLoadCanvas(e),
          (state.emergencyCanvasOpen = !1),
          setView("emergency"));
      }
      ((livebriefRenderConversation = function (e = !1) {
        const t = taskcenterOldRenderConversation(e);
        return (setTimeout(taskcenterEnhanceHomeBrief, 0), t);
      }),
        document.addEventListener(
          "click",
          (e) => {
            if (
              e.target.closest('.nav-btn[data-view="emergency"]') &&
              !e.target.closest("[data-timeline-toggle-group]")
            )
              return (
                e.preventDefault(),
                e.stopImmediatePropagation(),
                (state.emergencyThread = "center"),
                (state.emergencyCanvasOpen = !1),
                (state.emergencyCanvasFull = !1),
                (state.taskcenterCenterFilter = "all"),
                void setView("emergency")
              );
            const t = e.target.closest("[data-taskcenter-center-filter]");
            if (t)
              return (
                e.preventDefault(),
                e.stopImmediatePropagation(),
                (state.taskcenterCenterFilter = t.dataset.taskcenterCenterFilter),
                void emergencyRender()
              );
            const a = e.target.closest("[data-taskcenter-task-detail]");
            if (a)
              return (
                e.preventDefault(),
                e.stopImmediatePropagation(),
                (state.taskcenterCenterDetailTask = a.dataset.taskcenterTaskDetail),
                (state.emergencyCanvasOpen = !0),
                (state.emergencyCanvasFull = !1),
                void emergencyRender()
              );
            const s = e.target.closest("[data-taskcenter-open-task]");
            if (s)
              return (
                e.preventDefault(),
                e.stopImmediatePropagation(),
                void emergencySwitchThread(s.dataset.taskcenterOpenTask)
              );
            if (e.target.closest("[data-taskcenter-open-schedule]"))
              return (
                e.preventDefault(),
                e.stopImmediatePropagation(),
                (state.selectedSchedule = 1),
                setView("scheduled"),
                void setTimeout(() => {
                  (renderSchedules(),
                    document
                      .querySelector("#scheduleDetail")
                      ?.scrollIntoView({ block: "start" }));
                }, 40)
              );
            const n = e.target.closest("[data-taskcenter-schedule-task]");
            if (n)
              return (
                e.preventDefault(),
                e.stopImmediatePropagation(),
                void taskcenterOpenTask(n.dataset.taskcenterScheduleTask)
              );
            if (
              e.target.closest("#runSchedule") &&
              1 === +state.selectedSchedule
            )
              return (
                e.preventDefault(),
                e.stopImmediatePropagation(),
                void taskcenterSimulateScheduleTrigger()
              );
            if (e.target.closest("[data-taskcenter-home-emergency]"))
              return (
                e.preventDefault(),
                e.stopImmediatePropagation(),
                (state.emergencyThread = "center"),
                (state.taskcenterCenterFilter = "all"),
                (state.emergencyCanvasOpen = !1),
                void setView("emergency")
              );
            const r = e.target.closest('[data-butler-action="detail"]');
            return "T1" === r?.dataset.taskId
              ? (e.preventDefault(),
                e.stopImmediatePropagation(),
                void taskcenterOpenTask("E001"))
              : "T7" === r?.dataset.taskId
                ? (e.preventDefault(),
                  e.stopImmediatePropagation(),
                  (state.emergencyThread = "center"),
                  (state.taskcenterCenterFilter = "new"),
                  void setView("emergency"))
                : e.target.closest("#notificationsNoticeEnter")
                  ? (e.preventDefault(),
                    e.stopImmediatePropagation(),
                    $("#emergencyNotifyCard")?.classList.remove("show"),
                    void taskcenterOpenTask("E001"))
                  : void 0;
          },
          !0,
        ));
      const taskcenterOldRender = emergencyRender;
      ((emergencyRender = function () {
        (taskcenterOldRender(), timelineEnsureSidebarTasks());
        const e = $("#emergencyBadge");
        (e && (e.textContent = String(taskcenterTaskIds().length)),
          setTimeout(taskcenterEnhanceHomeBrief, 0));
      }),
        setTimeout(() => {
          ((document.title = "供应链智慧工作台"),
            timelineEnsureSidebarTasks(),
            taskcenterEnhanceHomeBrief(),
            "scheduled" === state.view && renderSchedules());
        }, 0));

/* Source runtime block 13 */
((state.plancomparePlanFilter = state.plancomparePlanFilter || "all"),
        (state.plancomparePlanDetail = state.plancomparePlanDetail || ""),
        (state.plancomparePlanView = state.plancomparePlanView || ""),
        (state.plancompareAdjusting = state.plancompareAdjusting || ""),
        (state.plancompareReviewDetail = state.plancompareReviewDetail || "summary"));
      const plancompareDiffs = [
        {
          id: "M01",
          name: "光缆",
          need: "2.74千米",
          original: "两家单位拼单，最晚02:10",
          ai: "单一来源＋在建资源，最晚01:30",
          reason: "减少协调对象，交付提前40分钟",
          tags: ["source", "eta"],
          risk: "需长寿单位在30分钟内确认释放在建资源。",
          originalSources: "忠县库存1.8千米＋两家单位拼单0.94千米",
          aiSources: "忠县库存1.8千米＋长寿在建资源0.94千米",
        },
        {
          id: "M03",
          name: "通信电源",
          need: "5套",
          original: "无可用来源，保留缺口",
          ai: "本地供应商现货5套，06:00交付",
          reason: "新增应急采购来源，补足缺口",
          tags: ["gap", "source", "eta"],
          risk: "需核验供应商现货锁定和紧急运输能力。",
          originalSources: "无可用来源",
          aiSources: "重庆本地应急供应商现货5套",
        },
        {
          id: "M04",
          name: "电力电缆",
          need: "2.5千米",
          original: "库存＋协议1.5千米，缺1千米",
          ai: "增加跨单位资源1千米，完整满足",
          reason: "新增1个可调来源，补足缺口",
          tags: ["gap", "source"],
          risk: "跨单位调拨不会影响原单位保供红线。",
          originalSources: "本单位库存0.8千米＋协议供应0.7千米",
          aiSources: "原系统组合1.5千米＋江北单位可调库存1千米",
        },
      ];
      function plancompareDecisionLabel(t) {
        return "ai" === t
          ? "已采用AI方案"
          : "original" === t
            ? "已保留原方案"
            : "adjust" === t
              ? "已人工调整"
              : "待确认";
      }
      function plancompareFilteredDiffs() {
        const t = state.plancomparePlanFilter || "all";
        return plancompareDiffs.filter(
          (e) =>
            "all" === t ||
            ("pending" === t && "pending" === state.collaborationDecisions[e.id]) ||
            e.tags.includes(t),
        );
      }
      function plancomparePlanDetailMarkup() {
        const t = state.plancomparePlanDetail || state.plancompareAdjusting;
        if (!t) return "";
        const e = plancompareDiffs.find((e) => e.id === t);
        if (!e) return "";
        const a = state.plancompareAdjusting === t;
        return `<aside class="plancompare-detail-drawer"><div class="plancompare-detail-head"><div><span>${a ? "人工调整" : "方案差异详情"}</span><strong>${collaborationEscape(e.name)}</strong></div><button data-plancompare-close-detail>×</button></div><div class="plancompare-detail-body">${a ? `<div class="plancompare-adjust-form"><label>来源组合<select id="plancompareAdjustSource"><option>采用AI推荐来源组合</option><option>保留原系统并补充外部来源</option><option>人工指定跨单位资源</option></select></label><label>确认数量<input id="plancompareAdjustQty" value="${collaborationEscape(e.need)}"></label><label>要求到货时间<input id="plancompareAdjustEta" value="今日 14:00"></label><label>调整说明<input id="plancompareAdjustNote" value="结合现场实际情况调整"></label></div>` : `<section class="plancompare-detail-section"><h4>需求与当前决策</h4><dl class="plancompare-detail-kv"><dt>需求数量</dt><dd>${collaborationEscape(e.need)}</dd><dt>当前状态</dt><dd>${plancompareDecisionLabel(state.collaborationDecisions[e.id] || "pending")}</dd><dt>AI调整价值</dt><dd>${collaborationEscape(e.reason)}</dd></dl></section><section class="plancompare-detail-section"><h4>原系统方案</h4><p>${collaborationEscape(e.originalSources)}。${collaborationEscape(e.original)}</p></section><section class="plancompare-detail-section"><h4>AI推荐方案</h4><p>${collaborationEscape(e.aiSources)}。${collaborationEscape(e.ai)}</p></section><section class="plancompare-detail-section"><h4>风险与前置条件</h4><p>${collaborationEscape(e.risk)}</p></section>`}</div><div class="plancompare-detail-actions">${a ? `<button data-plancompare-close-detail>取消</button><button class="primary" data-plancompare-save-adjust="${e.id}">保存调整</button>` : `<button data-plancompare-decision="${e.id}|original">保留原方案</button><button class="primary" data-plancompare-decision="${e.id}|ai">采用AI方案</button>`}</div></aside>`;
      }
      function plancomparePlanViewDrawer() {
        const t = state.plancomparePlanView;
        if (!t) return "";
        const e = {
          original: [
            "原系统方案",
            "按原系统规则形成基线方案，以库存及协议供应商为主。",
            "满足8/10项物资，8个可用来源，3项缺口，最晚18:00到货。",
          ],
          ai: [
            "AI推荐方案",
            "在保留有效来源的基础上，融合跨单位、在途在建和应急采购资源。",
            "满足10/10项物资，12个可用来源，1项缺口，最晚14:00到货。",
          ],
          final: [
            "最终确认方案",
            "根据用户逐项选择动态形成，可随差异处理实时刷新。",
            `已处理${collaborationDecisionCounts().total - collaborationDecisionCounts().pending}/${collaborationDecisionCounts().total}项差异，剩余${collaborationDecisionCounts().pending}项。`,
          ],
        }[t];
        return `<aside class="plancompare-detail-drawer"><div class="plancompare-detail-head"><div><span>方案摘要</span><strong>${e[0]}</strong></div><button data-plancompare-close-detail>×</button></div><div class="plancompare-detail-body"><section class="plancompare-detail-section"><h4>方案说明</h4><p>${e[1]}</p></section><section class="plancompare-detail-section"><h4>核心结果</h4><p>${e[2]}</p></section><section class="plancompare-detail-section"><h4>查看建议</h4><p>点击下方差异事项可进入物资级方案对比，并完成采用、保留或人工调整。</p></section></div><div class="plancompare-detail-actions"><button data-plancompare-close-detail>返回</button><button class="primary" data-plancompare-plan-filter="pending">查看待确认差异</button></div></aside>`;
      }
      function plancomparePlansPage() {
        const t = collaborationDecisionCounts(),
          e = plancompareFilteredDiffs();
        return `<div class="collaboration-app-page plancompare-plan-page"><section class="plancompare-plan-hero"><div><h3>方案对比结论</h3><p>AI方案保留原系统有效来源，并新增4个可用来源，补足2项缺口，预计最晚到货提前4小时。所有方案卡片、指标与差异事项均可点击查看。</p></div><div class="plancompare-plan-hero-tags"><button class="${"all" === state.plancomparePlanFilter ? "on" : ""}" data-plancompare-plan-filter="all">全部差异 3</button><button class="${"pending" === state.plancomparePlanFilter ? "on" : ""}" data-plancompare-plan-filter="pending">待确认 ${t.pending}</button><button class="${"gap" === state.plancomparePlanFilter ? "on" : ""}" data-plancompare-plan-filter="gap">缺口改善 2</button></div></section>\n <section class="plancompare-plan-cards"><button class="plancompare-plan-card ${"original" === state.plancomparePlanView ? "active" : ""}" data-plancompare-plan-view="original"><span>基线</span><h4>原系统方案</h4><strong>8 / 10</strong><small>满足物资</small><dl><dt>可用来源</dt><dd>8个</dd><dt>剩余缺口</dt><dd>3项</dd><dt>最晚到货</dt><dd>18:00</dd></dl></button><button class="plancompare-plan-card ai ${"ai" === state.plancomparePlanView ? "active" : ""}" data-plancompare-plan-view="ai"><span>AI推荐</span><h4>AI推荐方案</h4><strong>10 / 10</strong><small>满足物资</small><dl><dt>可用来源</dt><dd>12个</dd><dt>剩余缺口</dt><dd>1项</dd><dt>最晚到货</dt><dd>14:00</dd></dl></button><button class="plancompare-plan-card final ${"final" === state.plancomparePlanView ? "active" : ""}" data-plancompare-plan-view="final"><span>${t.pending ? "待确认" : "已形成"}</span><h4>最终确认方案</h4><strong>${t.total - t.pending} / ${t.total}</strong><small>差异已处理</small><dl><dt>采用AI</dt><dd>${t.ai}项</dd><dt>保留原方案</dt><dd>${t.original}项</dd><dt>人工调整</dt><dd>${t.adjust}项</dd></dl></button></section>\n <section class="plancompare-metric-grid"><button class="plancompare-metric ${"gap" === state.plancomparePlanFilter ? "on" : ""}" data-plancompare-plan-filter="gap"><span>满足物资</span><b>8 → 10</b><em>增加2项</em></button><button class="plancompare-metric ${"source" === state.plancomparePlanFilter ? "on" : ""}" data-plancompare-plan-filter="source"><span>可用来源</span><b>8 → 12</b><em>增加4个</em></button><button class="plancompare-metric" data-plancompare-plan-filter="source"><span>寻源渠道</span><b>2 → 4</b><em>增加2类</em></button><button class="plancompare-metric ${"gap" === state.plancomparePlanFilter ? "on" : ""}" data-plancompare-plan-filter="gap"><span>剩余缺口</span><b>3 → 1</b><em>减少2项</em></button><button class="plancompare-metric ${"eta" === state.plancomparePlanFilter ? "on" : ""}" data-plancompare-plan-filter="eta"><span>最晚到货</span><b>18:00 → 14:00</b><em>提前4小时</em></button></section>\n <div class="plancompare-diff-toolbar"><div><strong>差异事项</strong><span>点击整行查看方案依据，或直接完成决策</span></div><span>当前展示 ${e.length} 项 · 剩余 ${t.pending} 项待确认</span></div><section class="plancompare-diff-list">${
          e
            .map((t) => {
              const e = state.collaborationDecisions[t.id] || "pending";
              return `<article class="plancompare-diff-item ${"pending" !== e ? "decided" : ""} ${state.plancomparePlanDetail === t.id ? "selected" : ""}" data-plancompare-plan-detail="${t.id}"><div class="plancompare-diff-name"><strong>${collaborationEscape(t.name)}</strong><small>需求 ${collaborationEscape(t.need)}</small></div><div class="plancompare-diff-col"><span>原系统方案</span><p>${collaborationEscape(t.original)}</p></div><div class="plancompare-diff-col"><span>AI推荐方案</span><p>${collaborationEscape(t.ai)}</p><small>${collaborationEscape(t.reason)}</small></div><div class="plancompare-choice">${"pending" === e ? `<button class="primary" data-plancompare-decision="${t.id}|ai">采用AI方案</button><button data-plancompare-decision="${t.id}|original">保留原方案</button><button data-plancompare-adjust="${t.id}">调整</button>` : `<strong>${plancompareDecisionLabel(e)}</strong><button data-plancompare-decision="${t.id}|pending">重新选择</button>`}</div></article>`;
            })
            .join("") ||
          '<div class="taskcenter-task-list-empty">当前筛选条件下暂无差异事项。</div>'
        }</section>\n <div class="plancompare-plan-footer"><span>${t.total - t.pending}项已确认，剩余${t.pending}项待处理</span><button ${t.pending ? "disabled" : ""} id="plancompareFinalize">确认并形成最终方案</button></div>${plancomparePlanDetailMarkup()}${plancomparePlanViewDrawer()}</div>`;
      }
      function plancompareReviewPage() {
        const t = collaborationDecisionCounts(),
          e = {
            summary: [
              "任务闭环摘要",
              "本任务由定时监测触发，智能体完成需求校验、四渠道寻源、响应汇聚和方案生成。当前重点是完成差异确认并形成最终寻源结果。",
            ],
            trigger: [
              "触发与响应",
              "09:48由“应急事件常驻感知任务”识别并创建独立任务对话，3分钟内完成需求解析并启动四渠道寻源。",
            ],
            source: [
              "寻源成效",
              "共核验23条需求，汇聚18条有效响应，AI新增4个资源来源，补足2项缺口。",
            ],
            decision: [
              "方案决策",
              "原系统与AI方案共有3项差异，当前已处理" +
                (t.total - t.pending) +
                "项，剩余" +
                t.pending +
                "项待确认。",
            ],
            agent: [
              "智能体贡献",
              "自动完成需求标准化、渠道并行查询、响应冲突校验、方案比较和动态更新，减少多系统切换与人工汇总。",
            ],
            learning: [
              "经验沉淀",
              "本次可沉淀为滑坡抢修物资寻源案例，更新在建资源协调规则和应急采购供应商优先级。",
            ],
          },
          a = e[state.plancompareReviewDetail] || e.summary;
        return `<div class="collaboration-app-page plancompare-review-page"><section class="plancompare-review-hero"><h3>事件复盘</h3><p>从触发、寻源、决策和智能体贡献四个维度回顾任务全过程，关键数字和模块可点击查看对应明细。</p></section><section class="plancompare-review-kpis"><button data-plancompare-review-open="source"><b>23</b><span>需求物资</span></button><button data-plancompare-review-open="source"><b>18</b><span>有效响应</span></button><button data-plancompare-review-open="decision"><b>3</b><span>方案差异</span></button><button data-plancompare-review-open="agent"><b>4h</b><span>预计交期改善</span></button></section><section class="plancompare-review-grid"><button class="plancompare-review-card ${"trigger" === state.plancompareReviewDetail ? "active" : ""}" data-plancompare-review-open="trigger"><h4>触发与响应</h4><p>查看定时任务如何识别事件、创建会话并启动智能体。</p><span>查看触发链路 →</span></button><button class="plancompare-review-card ${"source" === state.plancompareReviewDetail ? "active" : ""}" data-plancompare-review-open="source"><h4>寻源结果</h4><p>查看四渠道资源覆盖、响应效率和缺口改善。</p><span>查看寻源明细 →</span></button><button class="plancompare-review-card ${"decision" === state.plancompareReviewDetail ? "active" : ""}" data-plancompare-review-open="decision"><h4>方案决策</h4><p>查看原系统、AI推荐与最终方案的取舍记录。</p><span>查看决策明细 →</span></button><button class="plancompare-review-card ${"agent" === state.plancompareReviewDetail ? "active" : ""}" data-plancompare-review-open="agent"><h4>智能体贡献</h4><p>查看自动完成事项、人工接管节点与效率提升。</p><span>查看贡献明细 →</span></button><button class="plancompare-review-card ${"learning" === state.plancompareReviewDetail ? "active" : ""}" data-plancompare-review-open="learning"><h4>经验沉淀</h4><p>形成案例、知识条目和技能优化建议。</p><span>查看沉淀建议 →</span></button><button class="plancompare-review-card ${"summary" === state.plancompareReviewDetail ? "active" : ""}" data-plancompare-review-open="summary"><h4>复盘结论</h4><p>汇总任务成效、风险和后续建议。</p><span>查看总结 →</span></button></section><section class="plancompare-review-result"><h4>${a[0]}</h4><ul><li>${a[1]}</li><li>所有关键业务事件均已留痕，可从事件记录定位原始时间点。</li><li>用户确认结果会同步回写任务对话、最终方案和定时任务运行记录。</li></ul><div class="plancompare-review-actions"><button data-emergency-canvas-tab="events">查看事件记录</button><button data-emergency-canvas-tab="plans">查看方案决策</button><button class="primary" data-plancompare-review-report>生成复盘报告</button></div></section></div>`;
      }
      emergencyCanvasTabs = function () {
        const t = collaborationDecisionCounts();
        return `<nav class="emergency-canvas-tabs">${[
          ["materials", "物资清单"],
          ["responses", "响应情况"],
          ["plans", "方案与决策"],
          ["events", "事件记录"],
          ["review", "事件复盘"],
        ]
          .map(
            ([e, a]) =>
              `<button class="${state.emergencyCanvasTab === e ? "on" : ""}" data-emergency-canvas-tab="${e}">${a}${"plans" === e && t.pending ? `<em>${t.pending}</em>` : ""}</button>`,
          )
          .join("")}</nav>`;
      };
      const plancompareCenterCanvasContent = emergencyCanvasContent;
      function plancompareSetDecision(t, e) {
        ((state.collaborationDecisions[t] = e),
          (state.plancompareAdjusting = ""),
          (state.plancomparePlanDetail = t));
        const a = (plancompareDiffs.find((e) => e.id === t) || {}).name || t;
        (emergencyPush(
          "assistant",
          "pending" === e
            ? `已将“${a}”恢复为待确认。`
            : `“${a}”差异已处理，${"ai" === e ? "采用AI推荐方案" : "original" === e ? "保留原系统方案" : "已保存人工调整方案"}。`,
        ),
          emergencyRender());
      }
      ((emergencyCanvasContent = function () {
        if ("center" === state.emergencyThread) return taskcenterCenterDetailMarkup();
        const t =
          "overview" === state.emergencyCanvasTab ? "plans" : state.emergencyCanvasTab;
        return (
          (state.collaborationTab = t),
          "materials" === t
            ? collaborationMaterialsPage()
            : "responses" === t
              ? collaborationResponsesPage()
              : "plans" === t
                ? plancomparePlansPage()
                : "events" === t
                  ? collaborationEventsPage()
                  : plancompareReviewPage()
        );
      }),
        document.addEventListener(
          "click",
          (t) => {
            const e = t.target.closest("[data-plancompare-plan-filter]");
            if (e)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.plancomparePlanFilter = e.dataset.plancomparePlanFilter),
                (state.plancomparePlanView = ""),
                (state.plancomparePlanDetail = ""),
                (state.plancompareAdjusting = ""),
                void emergencyRender()
              );
            const a = t.target.closest("[data-plancompare-plan-view]");
            if (a)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.plancomparePlanView = a.dataset.plancomparePlanView),
                (state.plancomparePlanDetail = ""),
                (state.plancompareAdjusting = ""),
                void emergencyRender()
              );
            const n = t.target.closest("[data-plancompare-decision]");
            if (n) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const [e, a] = n.dataset.plancompareDecision.split("|");
              return void plancompareSetDecision(e, a);
            }
            const s = t.target.closest("[data-plancompare-adjust]");
            if (s)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.plancompareAdjusting = s.dataset.plancompareAdjust),
                (state.plancomparePlanDetail = ""),
                (state.plancomparePlanView = ""),
                void emergencyRender()
              );
            const i = t.target.closest("[data-plancompare-save-adjust]");
            if (i)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                plancompareSetDecision(i.dataset.plancompareSaveAdjust, "adjust"),
                void showToast("人工调整方案已保存并重新校验")
              );
            const o = t.target.closest("[data-plancompare-plan-detail]");
            if (o && !t.target.closest("button"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.plancomparePlanDetail = o.dataset.plancomparePlanDetail),
                (state.plancomparePlanView = ""),
                (state.plancompareAdjusting = ""),
                void emergencyRender()
              );
            if (t.target.closest("[data-plancompare-close-detail]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.plancomparePlanDetail = ""),
                (state.plancomparePlanView = ""),
                (state.plancompareAdjusting = ""),
                void emergencyRender()
              );
            if (t.target.closest("#plancompareFinalize"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                collaborationDecisionCounts().pending
                  ? void showToast("请先处理全部差异事项")
                  : (emergencyPush(
                      "assistant",
                      "最终寻源方案已形成，已同步生成事件复盘并准备回写原系统。",
                    ),
                    (state.emergencyCanvasTab = "review"),
                    showToast("最终寻源方案已形成"),
                    void emergencyRender())
              );
            const v = t.target.closest("[data-plancompare-review-open]");
            return v
              ? (t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.plancompareReviewDetail = v.dataset.plancompareReviewOpen),
                void emergencyRender())
              : t.target.closest("[data-plancompare-review-report]")
                ? (t.preventDefault(),
                  t.stopImmediatePropagation(),
                  emergencyPush(
                    "assistant",
                    "事件复盘报告已生成，包含触发链路、寻源成效、方案决策、智能体贡献和经验沉淀。",
                  ),
                  showToast("事件复盘报告已生成"),
                  void emergencyRender())
                : void 0;
          },
          !0,
        ));
      const plancompareOldSendPrompt = emergencySendPrompt;
      function plancomparePositionQuestionRail() {
        const t = document.querySelector(".sidebar"),
          e = t ? Math.round(t.getBoundingClientRect().width) : 0;
        document.documentElement.style.setProperty(
          "--plancompare-question-rail-left",
          e + 4 + "px",
        );
      }
      ((emergencySendPrompt = function (t) {
        const e = $("#emergencyPrompt"),
          a = (t ?? e?.value ?? "").trim();
        return "center" !== state.emergencyThread && /复盘|总结经验|沉淀/.test(a)
          ? (e && (e.value = ""),
            emergencyPush("user", a),
            (state.emergencyCanvasTab = "review"),
            (state.emergencyCanvasOpen = !0),
            emergencyPush(
              "assistant",
              "已打开事件复盘，汇总本次任务的触发、寻源、决策、智能体贡献和经验沉淀。",
            ),
            void emergencyRender())
          : plancompareOldSendPrompt(t);
      }),
        window.addEventListener("resize", plancomparePositionQuestionRail),
        document.addEventListener(
          "click",
          () => setTimeout(plancomparePositionQuestionRail, 40),
          !0,
        ));
      const plancompareObserver = new MutationObserver(() => plancomparePositionQuestionRail());
      setTimeout(() => {
        const t = document.querySelector(".sidebar");
        (t &&
          plancompareObserver.observe(t, {
            attributes: !0,
            attributeFilter: ["class", "style"],
          }),
          plancomparePositionQuestionRail(),
          (document.title = "供应链智慧工作台"));
      }, 0);

/* Source runtime block 14 */
function planreviewChangeLabel(t) {
        return t.tags.includes("gap")
          ? "缺口已补足"
          : t.tags.includes("eta")
            ? "交期提前"
            : t.tags.includes("source")
              ? "新增来源"
              : "组合优化";
      }
      function planreviewPlanDiffs() {
        const t = state.planreviewPlanFilter || "all";
        return plancompareDiffs.filter(
          (e) =>
            "all" === t ||
            ("pending" === t &&
              "pending" === (state.collaborationDecisions[e.id] || "pending")) ||
            e.tags.includes(t),
        );
      }
      function planreviewPlanPage() {
        const t = collaborationDecisionCounts(),
          e = planreviewPlanDiffs(),
          a =
            plancompareDiffs.find((t) => t.id === state.planreviewPlanDetail) ||
            e[0] ||
            plancompareDiffs[0],
          s = (a && state.collaborationDecisions[a.id]) || "pending";
        return `<div class="planreview-page planreview-plan-page">\n  <section class="planreview-summary">\n   <div><strong>AI方案补足2项缺口，最晚到货提前4小时</strong><span>当前还有${t.pending}项差异待确认</span></div>\n   <div class="planreview-summary-metrics">\n    <button class="${"all" === state.planreviewPlanFilter ? "on" : ""}" data-planreview-plan-filter="all"><b>3</b>全部</button>\n    <button class="${"pending" === state.planreviewPlanFilter ? "on" : ""}" data-planreview-plan-filter="pending"><b>${t.pending}</b>待确认</button>\n    <button class="${"gap" === state.planreviewPlanFilter ? "on" : ""}" data-planreview-plan-filter="gap"><b>2</b>补足缺口</button>\n    <button class="${"eta" === state.planreviewPlanFilter ? "on" : ""}" data-planreview-plan-filter="eta"><b>1</b>交期变化</button>\n   </div>\n  </section>\n  <section class="planreview-section">\n   <div class="planreview-compare-head"><div>物资</div><div>原系统方案</div><div>变化</div><div>AI方案</div><div>决策</div></div>\n   <div>${
          e
            .map((t) => {
              const e = state.collaborationDecisions[t.id] || "pending";
              return `<article class="planreview-compare-row ${state.planreviewPlanDetail === t.id ? "selected" : ""}" data-planreview-plan-row="${t.id}">\n    <div class="planreview-item-name"><strong>${collaborationEscape(t.name)}</strong><small>需求 ${collaborationEscape(t.need)}</small></div>\n    <div class="planreview-scheme-cell"><span>基线</span><p>${collaborationEscape(t.original)}</p></div>\n    <div class="planreview-change-cell"><b>${planreviewChangeLabel(t)}</b></div>\n    <div class="planreview-scheme-cell ai"><span>推荐</span><p>${collaborationEscape(t.ai)}</p></div>\n    <div class="planreview-decision-cell">${"pending" === e ? `<button class="primary" data-planreview-decision="${t.id}|ai">采用AI</button><button data-planreview-decision="${t.id}|original">保留原方案</button>` : `<span class="planreview-decision-state">${plancompareDecisionLabel(e)}</span><button data-planreview-decision="${t.id}|pending">重新选择</button>`}</div>\n   </article>`;
            })
            .join("") ||
          '<div class="taskcenter-task-list-empty">当前筛选条件下暂无差异事项。</div>'
        }</div>\n   <div class="planreview-plan-foot"><span>已确认${t.total - t.pending}项，剩余${t.pending}项</span><button id="planreviewFinalize" ${t.pending ? "disabled" : ""}>形成最终方案</button></div>\n  </section>\n  ${a ? `<section class="planreview-detail-bar">\n   <div class="planreview-detail-main"><div><strong>${collaborationEscape(a.name)} · ${plancompareDecisionLabel(s)}</strong><p>AI方案：${collaborationEscape(a.ai)}</p></div><div class="planreview-detail-actions"><button data-planreview-ask="为什么推荐${collaborationEscape(a.name)}的AI方案？">问AI原因</button><button data-planreview-adjust="${a.id}">调整</button><button data-planreview-decision="${a.id}|original">保留原方案</button><button class="primary" data-planreview-decision="${a.id}|ai">采用AI方案</button></div></div>\n   ${state.planreviewAdjusting === a.id ? `<div class="planreview-adjust-inline"><label>来源组合<select id="planreviewAdjustSource"><option>采用AI推荐组合</option><option>保留原方案并补充来源</option><option>人工指定资源</option></select></label><label>确认数量<input id="planreviewAdjustQty" value="${collaborationEscape(a.need)}"></label><label>到货时间<input id="planreviewAdjustEta" value="今日 14:00"></label><button data-planreview-save-adjust="${a.id}">保存调整</button></div>` : ""}\n  </section>` : ""}\n </div>`;
      }
      function planreviewResponseRecords() {
        return collaborationResponseRecords().map((t, e) => ({
          key: `${t.m.id}-${e}`,
          materialId: t.m.id,
          material: t.m.name,
          channel: t.key,
          name: t.s.name || "响应对象",
          qty: t.s.qty || "待确认",
          status: t.s.status || (e % 5 == 0 ? "待回复" : "已确认"),
          eta: t.s.eta || (e % 3 == 0 ? "今日 12:00" : "今日 14:00"),
          condition:
            "unit" === t.key
              ? "不影响原单位保供红线"
              : "rush" === t.key
                ? "按应急订单优先排产"
                : "transit" === t.key
                  ? "需协调原项目释放资源"
                  : "现货锁定后安排紧急运输",
        }));
      }
      function planreviewResponsesPage() {
        const t = {
          unit: ["跨单位调拨", "12/14"],
          rush: ["应急抢单", "3/4"],
          transit: ["在途／在建", "2/2"],
          purchase: ["应急采购", "1/1"],
        };
        let e = planreviewResponseRecords(),
          a =
            "all" === state.planreviewResponseChannel
              ? e
              : e.filter((t) => t.channel === state.planreviewResponseChannel);
        (state.planreviewResponseKey &&
          a.some((t) => t.key === state.planreviewResponseKey)) ||
          (state.planreviewResponseKey = a[0]?.key || "");
        const s = e.find((t) => t.key === state.planreviewResponseKey) || a[0];
        return `<div class="planreview-page planreview-response-page">\n  <section class="planreview-summary"><div><strong>已收到18条有效响应</strong><span>2个对象待回复，智能体持续催办</span></div><div class="planreview-summary-metrics"><button class="${"all" === state.planreviewResponseChannel ? "on" : ""}" data-planreview-channel="all">全部</button></div></section>\n  <section class="planreview-channel-strip">${Object.entries(
          t,
        )
          .map(
            ([t, e]) =>
              `<button class="${state.planreviewResponseChannel === t ? "on" : ""}" data-planreview-channel="${t}"><span>${e[0]}</span><b>${e[1]}</b></button>`,
          )
          .join(
            "",
          )}</section>\n  <section class="planreview-section planreview-response-grid">\n   <div class="planreview-response-list">${a
          .slice(0, 12)
          .map(
            (t) =>
              `<button class="planreview-response-row ${state.planreviewResponseKey === t.key ? "active" : ""}" data-planreview-response="${t.key}"><div><strong>${collaborationEscape(t.name)}</strong><small>${collaborationEscape(t.material)} · ${collaborationEscape(t.qty)}</small></div><em>${collaborationEscape(t.status)}</em></button>`,
          )
          .join(
            "",
          )}</div>\n   ${s ? `<div class="planreview-response-detail">\n    <div class="planreview-response-detail-head"><div><strong>${collaborationEscape(s.name)}</strong><span>${collaborationEscape(s.material)}</span></div><i class="planreview-response-status">${collaborationEscape(s.status)}</i></div>\n    <div class="planreview-response-kv"><div><span>可提供数量</span><b>${collaborationEscape(s.qty)}</b></div><div><span>预计到达</span><b>${collaborationEscape(s.eta)}</b></div><div><span>响应渠道</span><b>${collaborationEscape(t[s.channel]?.[0] || "资源渠道")}</b></div><div><span>当前结论</span><b>${"待回复" === s.status ? "继续催办" : "可纳入方案"}</b></div></div>\n    <div class="planreview-response-note">${collaborationEscape(s.condition)}</div>\n    <div class="planreview-response-actions"><button data-planreview-response-material="${s.materialId}">查看对应物资</button><button data-planreview-response-plan="${s.materialId}">查看方案影响</button><button class="primary" data-planreview-ask="${collaborationEscape(s.name)}具体回复了什么？">问AI详情</button></div>\n   </div>` : '<div class="taskcenter-task-list-empty">暂无响应记录。</div>'}\n  </section>\n </div>`;
      }
      function planreviewReviewPage() {
        const t = collaborationDecisionCounts(),
          e = {
            result: [
              "任务结果",
              "20/23",
              "20条形成完整来源，3项进入人工确认。",
            ],
            source: ["寻源成效", "18条", "四渠道汇聚18条有效响应。"],
            decision: [
              "方案决策",
              t.total - t.pending + "/3",
              `${t.pending}项差异仍待确认。`,
            ],
            learning: ["经验沉淀", "3项", "形成案例、规则和技能优化建议。"],
          },
          a = e[state.planreviewReviewKey] || e.result;
        return `<div class="planreview-page planreview-review-page">\n  <section class="planreview-summary"><div><strong>事件复盘</strong><span>结果、决策与经验沉淀</span></div><div class="planreview-summary-metrics"><button data-emergency-canvas-tab="events">查看事件记录</button></div></section>\n  <section class="planreview-review-grid">${Object.entries(
          e,
        )
          .map(
            ([t, e]) =>
              `<button class="planreview-review-card ${state.planreviewReviewKey === t ? "active" : ""}" data-planreview-review="${t}"><span>${e[0]}</span><b>${e[1]}</b><small>${e[2]}</small></button>`,
          )
          .join(
            "",
          )}</section>\n  <section class="planreview-review-result"><div><strong>${a[0]}</strong><span>${a[2]}</span></div><button data-planreview-ask="请总结本次应急任务复盘结论">向AI追问</button></section>\n </div>`;
      }
      function planreviewSetDecision(t, e) {
        ((state.planreviewPlanDetail = t),
          (state.planreviewAdjusting = ""),
          (state.collaborationDecisions[t] = e));
        const a = (plancompareDiffs.find((e) => e.id === t) || {}).name || t;
        (emergencyPush(
          "assistant",
          "pending" === e
            ? `已将“${a}”恢复为待确认。`
            : `“${a}”已${"ai" === e ? "采用AI方案" : "original" === e ? "保留原系统方案" : "保存人工调整"}。`,
        ),
          emergencyRender());
      }
      ((state.planreviewPlanFilter = state.planreviewPlanFilter || "all"),
        (state.planreviewPlanDetail = state.planreviewPlanDetail || "M01"),
        (state.planreviewAdjusting = state.planreviewAdjusting || ""),
        (state.planreviewResponseChannel = state.planreviewResponseChannel || "all"),
        (state.planreviewResponseKey = state.planreviewResponseKey || ""),
        (state.planreviewReviewKey = state.planreviewReviewKey || "result"),
        (collaborationMaterialDetail = function () {
          const t = collaborationMaterials().find(
            (t) => t.id === state.collaborationSelectedMaterial,
          );
          if (!t) return "";
          const e = collaborationGap(t),
            a = (t.sources || []).filter((t) => !1 !== t.requested).slice(0, 3);
          return `<aside class="collaboration-detail-drawer"><div class="collaboration-detail-head"><div><span>物资详情</span><strong>${collaborationEscape(t.name)}</strong></div><button data-collaboration-close-detail>×</button></div><dl><dt>需求</dt><dd>${t.need}${t.unit}</dd><dt>已匹配</dt><dd>${t.filled}${t.unit}</dd><dt>缺口</dt><dd class="${e ? "red" : ""}">${e}${t.unit}</dd></dl><h4>来源组合</h4>${a.map((t) => `<div class="collaboration-source-item"><div><b>${collaborationEscape(t.name)}</b><span>${collaborationEscape(t.type || "资源来源")}</span></div><em>${collaborationEscape(t.qty || "待确认")}</em></div>`).join("")}<button class="collaboration-drawer-action" data-planreview-ask="请说明${collaborationEscape(t.name)}当前来源组合和风险">问AI详情</button></aside>`;
        }),
        (emergencyCanvasTabs = function () {
          const t = collaborationDecisionCounts();
          return `<nav class="emergency-canvas-tabs">${[
            ["materials", "物资清单"],
            ["responses", "响应情况"],
            ["plans", "方案对比"],
            ["events", "事件记录"],
            ["review", "事件复盘"],
          ]
            .map(
              ([e, a]) =>
                `<button class="${state.emergencyCanvasTab === e ? "on" : ""}" data-emergency-canvas-tab="${e}">${a}${"plans" === e && t.pending ? `<em>${t.pending}</em>` : ""}</button>`,
            )
            .join("")}</nav>`;
        }),
        (emergencyCanvasContent = function () {
          if ("center" === state.emergencyThread) return taskcenterCenterDetailMarkup();
          const t =
            "overview" === state.emergencyCanvasTab ? "plans" : state.emergencyCanvasTab;
          return (
            (state.collaborationTab = t),
            "materials" === t
              ? collaborationMaterialsPage()
              : "responses" === t
                ? planreviewResponsesPage()
                : "plans" === t
                  ? planreviewPlanPage()
                  : "events" === t
                    ? collaborationEventsPage()
                    : planreviewReviewPage()
          );
        }),
        document.addEventListener(
          "click",
          (t) => {
            const e = t.target.closest("[data-planreview-plan-filter]");
            if (e) {
              (t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.planreviewPlanFilter = e.dataset.planreviewPlanFilter));
              const a = planreviewPlanDiffs();
              return (
                (state.planreviewPlanDetail = a[0]?.id || ""),
                (state.planreviewAdjusting = ""),
                void emergencyRender()
              );
            }
            const a = t.target.closest("[data-planreview-plan-row]");
            if (a && !t.target.closest("button"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.planreviewPlanDetail = a.dataset.planreviewPlanRow),
                (state.planreviewAdjusting = ""),
                void emergencyRender()
              );
            const s = t.target.closest("[data-planreview-decision]");
            if (s) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const [e, a] = s.dataset.planreviewDecision.split("|");
              return void planreviewSetDecision(e, a);
            }
            const n = t.target.closest("[data-planreview-adjust]");
            if (n)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.planreviewPlanDetail = n.dataset.planreviewAdjust),
                (state.planreviewAdjusting = n.dataset.planreviewAdjust),
                void emergencyRender()
              );
            const i = t.target.closest("[data-planreview-save-adjust]");
            if (i)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                planreviewSetDecision(i.dataset.planreviewSaveAdjust, "adjust"),
                void showToast("调整方案已保存")
              );
            if (t.target.closest("#planreviewFinalize"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                collaborationDecisionCounts().pending
                  ? void showToast("请先处理全部差异事项")
                  : (emergencyPush(
                      "assistant",
                      "最终寻源方案已形成，事件复盘同步更新。",
                    ),
                    (state.emergencyCanvasTab = "review"),
                    void emergencyRender())
              );
            const v = t.target.closest("[data-planreview-channel]");
            if (v)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.planreviewResponseChannel = v.dataset.planreviewChannel),
                (state.planreviewResponseKey = ""),
                void emergencyRender()
              );
            const o = t.target.closest("[data-planreview-response]");
            if (o)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.planreviewResponseKey = o.dataset.planreviewResponse),
                void emergencyRender()
              );
            const d = t.target.closest("[data-planreview-response-material]");
            if (d)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.emergencyCanvasTab = "materials"),
                (state.collaborationSelectedMaterial = d.dataset.planreviewResponseMaterial),
                void emergencyRender()
              );
            const l = t.target.closest("[data-planreview-response-plan]");
            if (l) {
              (t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.emergencyCanvasTab = "plans"));
              const e =
                plancompareDiffs.find((t) => t.id === l.dataset.planreviewResponsePlan) ||
                plancompareDiffs[0];
              return (
                (state.planreviewPlanDetail = e?.id || ""),
                (state.planreviewPlanFilter = "all"),
                void emergencyRender()
              );
            }
            const r = t.target.closest("[data-planreview-review]");
            if (r)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.planreviewReviewKey = r.dataset.planreviewReview),
                void emergencyRender()
              );
            const c = t.target.closest("[data-planreview-ask]");
            if (c) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const e = document.querySelector("#emergencyPrompt");
              return (
                e && ((e.value = c.dataset.planreviewAsk || ""), e.focus()),
                void showToast("问题已放入对话框")
              );
            }
          },
          !0,
        ),
        setTimeout(() => {
          ((document.title = "供应链智慧工作台"),
            "emergency" === state.view && emergencyRender());
        }, 0));

/* Source runtime block 16 */
((state.workbriefHome = state.workbriefHome || {
        priority: "focus",
        progress: "pending",
        business: "procurement",
        selectedImportant: "",
        selectedTask: "",
        selectedFollow: "",
        recap: !1,
        escalated: !1,
      }),
        (state.workbriefOrchestrationStep = state.workbriefOrchestrationStep || {}));
      const workbriefBusinessGroups = {
          procurement: {
            name: "采购流标处理",
            count: 8,
            risk: "2项时间风险",
            tasks: [
              {
                id: "P1",
                title: "迎峰度夏重点项目采购流标",
                type: "采购流标处理",
                object: "迎峰度夏配网工程 / 批次2026-08",
                current: "流标后采购方式确认",
                before: "流标结果确认",
                after: "采购文件编制",
                remain: "剩余18天",
                risk: "预计延期5天",
                status: "重点",
                advice: "今日确认加急采购方式，并同步发起人。",
              },
              {
                id: "P2",
                title: "柱上断路器采购包流标处置",
                type: "采购流标处理",
                object: "城口配网改造 / 批次2026-09",
                current: "需求重组",
                before: "流标分析",
                after: "二次采购",
                remain: "剩余26天",
                risk: "仍有补救窗口",
                status: "一般",
                advice: "今日完成需求拆分，暂不升级督办。",
              },
            ],
          },
          contract: {
            name: "合同履约异常",
            count: 6,
            risk: "1项已超期",
            tasks: [
              {
                id: "C1",
                title: "主变压器订单发货确认超期",
                type: "合同履约异常",
                object: "北碚220千伏输变电工程 / 订单CQ-260718",
                current: "供应商发货确认",
                before: "排产完成",
                after: "到货验收",
                remain: "已超期3天",
                risk: "投运节点受影响",
                status: "重点",
                advice: "立即升级督办并同步项目发起人。",
              },
              {
                id: "C2",
                title: "组合电器交期变更确认",
                type: "合同履约异常",
                object: "万州变电站扩建 / 订单CQ-260633",
                current: "交期确认",
                before: "生产排程",
                after: "运输计划",
                remain: "剩余4天",
                risk: "中等风险",
                status: "一般",
                advice: "今日确认调整交期并评估运输衔接。",
              },
            ],
          },
          arrival: {
            name: "到货信息维护",
            count: 5,
            risk: "2项应到未到",
            tasks: [
              {
                id: "A1",
                title: "主变压器应到未到核查",
                type: "到货信息维护",
                object: "忠县变电站工程 / 订单CQ-260525",
                current: "到货状态核验",
                before: "供应商发货",
                after: "现场验收",
                remain: "延迟1天",
                risk: "剩余3天缓冲",
                status: "重点",
                advice: "今日16:00前确认实际到货时间。",
              },
              {
                id: "A2",
                title: "电缆附件到货信息补录",
                type: "到货信息维护",
                object: "江津线路改造 / 订单CQ-260701",
                current: "信息维护",
                before: "实物签收",
                after: "验收归档",
                remain: "剩余1天",
                risk: "低风险",
                status: "一般",
                advice: "由智能体校验后自动补录。",
              },
            ],
          },
          collaboration: {
            name: "跨单位协同",
            count: 4,
            risk: "1项待外部响应",
            tasks: [
              {
                id: "X1",
                title: "跨单位库存调拨确认",
                type: "跨单位协同",
                object: "忠县滑坡应急 / 调拨单DB-260729",
                current: "资源释放确认",
                before: "库存匹配",
                after: "调拨执行",
                remain: "剩余2小时",
                risk: "临近最晚确认时间",
                status: "重点",
                advice: "立即催办长寿公司，30分钟后未回复则升级。",
              },
              {
                id: "X2",
                title: "项目单位到货地点确认",
                type: "跨单位协同",
                object: "酉阳配网工程 / 订单CQ-260688",
                current: "地点确认",
                before: "订单确认",
                after: "发货安排",
                remain: "剩余6小时",
                risk: "可能顺延1天",
                status: "一般",
                advice: "发送普通提醒，持续跟踪。",
              },
            ],
          },
          quality: {
            name: "质量问题处理",
            count: 2,
            risk: "1项红线风险",
            tasks: [
              {
                id: "Q1",
                title: "疑似虚假收货异常核查",
                type: "质量问题处理",
                object: "渝北仓储项目 / 验收单YS-260412",
                current: "异常核验",
                before: "收货登记",
                after: "质量处置",
                remain: "今日完成",
                risk: "合规红线风险",
                status: "重点",
                advice: "暂停后续结算并通知监督人员。",
              },
              {
                id: "Q2",
                title: "电缆抽检不合格处置",
                type: "质量问题处理",
                object: "南岸配网项目 / 检测单JC-260122",
                current: "复检安排",
                before: "抽样检测",
                after: "退换货处理",
                remain: "剩余2天",
                risk: "影响施工备料",
                status: "一般",
                advice: "今日确认复检计划。",
              },
            ],
          },
        },
        workbriefFollowItems = [
          {
            id: "summer",
            title: "迎峰度夏项目物资保障",
            desc: "当前完成率82%，仍有3项物资存在交期风险。",
            tag: "用户关注",
          },
          {
            id: "batch",
            title: "采购批次2026-08",
            desc: "需求审查已完成，预计明日进入采购文件确认。",
            tag: "节点跟踪",
          },
          {
            id: "agent",
            title: "主变压器订单跟踪",
            desc: "智能体正在持续核验供应商发货和到货状态。",
            tag: "自动执行",
          },
        ];
      function workbriefEsc(t) {
        return "function" == typeof emergencyEsc
          ? emergencyEsc(String(t ?? ""))
          : String(t ?? "");
      }
      function workbriefCounts() {
        return {
          focus: 5,
          general: 20,
          pending: 8,
          running: 6,
          external: 7,
          done: 4,
        };
      }
      function workbriefBusinessMarkup() {
        return Object.entries(workbriefBusinessGroups)
          .map(
            ([t, e]) =>
              `<button class="workbrief-business-btn ${state.workbriefHome.business === t ? "active" : ""}" data-workbrief-business="${t}"><b>${e.count}</b><strong>${workbriefEsc(e.name)}</strong><small>${workbriefEsc(e.risk)}</small></button>`,
          )
          .join("");
      }
      function workbriefTaskMarkup(t) {
        const e = "重点" === t.status;
        return `<article class="workbrief-task-card"><div class="workbrief-task-title"><strong>${workbriefEsc(t.title)}</strong><span class="${e ? "" : "normal"}">${workbriefEsc(t.status)}事项</span></div><div class="workbrief-task-meta"><div><span>业务类型</span><b>${workbriefEsc(t.type)}</b></div><div><span>当前 / 前后环节</span><b>${workbriefEsc(t.before)} → ${workbriefEsc(t.current)} → ${workbriefEsc(t.after)}</b></div><div><span>剩余时间</span><b>${workbriefEsc(t.remain)}</b></div><div><span>风险判断</span><b>${workbriefEsc(t.risk)}</b></div></div><div class="workbrief-task-advice"><b>AI建议</b><span>${workbriefEsc(t.advice)}</span></div><div class="workbrief-task-actions"><button data-workbrief-task="${t.id}" data-workbrief-action="process">查看流程</button><button data-workbrief-task="${t.id}" data-workbrief-action="remind">立即催办</button>${e ? `<button class="danger" data-workbrief-task="${t.id}" data-workbrief-action="escalate">${state.workbriefHome.escalated && "C1" === t.id ? "已升级督办" : "升级督办"}</button>` : ""}<button class="primary" data-workbrief-task="${t.id}" data-workbrief-action="dialog">进入事项对话</button></div>${state.workbriefHome.selectedTask === t.id ? `<div class="workbrief-inline-detail"><div class="workbrief-inline-detail-head"><strong>流程影响摘要</strong><button data-workbrief-close-detail>收起</button></div><p>当前卡点位于“${workbriefEsc(t.current)}”。上游“${workbriefEsc(t.before)}”已完成，下游“${workbriefEsc(t.after)}”将受当前处理时点影响。${workbriefEsc(t.advice)}</p></div>` : ""}</article>`;
      }
      function workbriefImportantMarkup() {
        return `<div class="workbrief-important-grid"><article class="workbrief-important-card ${"flow" === state.workbriefHome.selectedImportant ? "active" : ""}" data-workbrief-important="flow"><div class="workbrief-important-top"><strong>① 重点项目采购流标</strong><span>保障相关 · 时间紧迫</span></div><p>迎峰度夏重点项目采购流标，距要求到货仅剩18天，常规采购预计晚5天。</p><div class="workbrief-facts"><div class="workbrief-fact"><span>后续影响</span><b>合同、生产、安装</b></div><div class="workbrief-fact"><span>建议动作</span><b>今日确认加急方式</b></div><div class="workbrief-fact"><span>推动建议</span><b>通知发起人并督办</b></div></div><div class="workbrief-important-actions"><button data-workbrief-important-action="flow" data-action="detail">查看事项</button><button class="warn" data-workbrief-important-action="flow" data-action="notify">通知发起人</button><button class="primary" data-workbrief-important-action="flow" data-action="handle">立即处理</button></div></article><article class="workbrief-important-card ${"overdue" === state.workbriefHome.selectedImportant ? "active" : ""}" data-workbrief-important="overdue"><div class="workbrief-important-top"><strong>② 主变压器订单超期3天</strong><span>时间超期 · 履约异常</span></div><p>供应商尚未确认发货，下游验收与项目投运节点可能受到影响，当前仅剩2天缓冲。</p><div class="workbrief-facts"><div class="workbrief-fact"><span>后续影响</span><b>验收、投运节点</b></div><div class="workbrief-fact"><span>建议动作</span><b>确认实际交期</b></div><div class="workbrief-fact"><span>推动建议</span><b>升级督办并同步</b></div></div><div class="workbrief-important-actions"><button data-workbrief-important-action="overdue" data-action="detail">查看事项</button><button class="warn" data-workbrief-important-action="overdue" data-action="notify">同步相关人员</button><button class="primary" data-workbrief-important-action="overdue" data-action="escalate">升级督办</button></div></article></div>`;
      }
      function workbriefBriefMarkup(t = !1, e) {
        const a = workbriefCounts(),
          s = void 0 === e ? !t : !!e,
          n =
            workbriefBusinessGroups[state.workbriefHome.business] ||
            workbriefBusinessGroups.procurement;
        return `<section class="normal-brief-card livebrief-brief-card workbrief-brief ${t ? "livebrief-intro" : "livebrief-docked"} ${s ? "collapsed" : ""}" id="normalBriefCard"><div class="normal-brief-head"><div class="normal-brief-title" data-workbrief-toggle><strong>重要事项</strong><span>AI已完成今日业务研判：共涉及5类、25条任务、工单和邮件，其中2项需优先关注。</span></div><span class="workbrief-brief-state"><i></i>智能体持续分析中</span><button class="workbrief-brief-toggle" data-workbrief-toggle aria-label="展开或收起">⌄</button></div><div class="normal-brief-body"><div class="workbrief-focus-summary"><div><h3>重点事项</h3><p>先看结论，再按优先级、处理进程和业务类型下钻。</p></div><div class="workbrief-summary-actions"><button class="workbrief-ghost-btn" data-workbrief-business="collaboration">查看应急协同</button><button class="workbrief-primary-btn" data-workbrief-open-emergency>进入应急任务中心</button></div></div>${workbriefImportantMarkup()}<div class="workbrief-layer-shell"><section class="workbrief-layer"><div class="workbrief-layer-head"><strong>重点优先级</strong><span>点击筛选</span></div><div class="workbrief-chip-row"><button class="workbrief-filter-chip attention ${"focus" === state.workbriefHome.priority ? "active" : ""}" data-workbrief-priority="focus"><b>${a.focus}</b>重点事项</button><button class="workbrief-filter-chip ${"general" === state.workbriefHome.priority ? "active" : ""}" data-workbrief-priority="general"><b>${a.general}</b>一般事项</button></div></section><section class="workbrief-layer"><div class="workbrief-layer-head"><strong>处理进程</strong><span>点击下钻</span></div><div class="workbrief-chip-row"><button class="workbrief-filter-chip ${"pending" === state.workbriefHome.progress ? "active" : ""}" data-workbrief-progress="pending"><b>${a.pending}</b>待处理</button><button class="workbrief-filter-chip ${"running" === state.workbriefHome.progress ? "active" : ""}" data-workbrief-progress="running"><b>${a.running}</b>处理中</button><button class="workbrief-filter-chip ${"external" === state.workbriefHome.progress ? "active" : ""}" data-workbrief-progress="external"><b>${a.external}</b>待外部响应</button><button class="workbrief-filter-chip ${"done" === state.workbriefHome.progress ? "active" : ""}" data-workbrief-progress="done"><b>${a.done}</b>已完成</button></div></section></div><section class="workbrief-section"><div class="workbrief-section-head"><div><h4>业务事项归并</h4><p>共涉及5类业务、25条任务、工单和邮件</p></div><span>${workbriefEsc(n.name)} · ${n.count}条</span></div><div class="workbrief-business-grid">${workbriefBusinessMarkup()}</div><div class="workbrief-task-list">${n.tasks.map(workbriefTaskMarkup).join("")}</div></section><section class="workbrief-section"><div class="workbrief-section-head"><div><h4>我关注的事项</h4><p>用户关注、定时任务与智能体自动执行</p></div><span>3项</span></div><div class="workbrief-follow-grid">${workbriefFollowItems.map((t) => `<button class="workbrief-follow-card ${state.workbriefHome.selectedFollow === t.id ? "active" : ""}" data-workbrief-follow="${t.id}"><strong>${workbriefEsc(t.title)}</strong><p>${workbriefEsc(t.desc)}</p><span>${workbriefEsc(t.tag)}</span></button>`).join("")}</div>${state.workbriefHome.selectedFollow ? `<div class="workbrief-inline-detail"><div class="workbrief-inline-detail-head"><strong>${workbriefEsc((workbriefFollowItems.find((t) => t.id === state.workbriefHome.selectedFollow) || {}).title || "关注事项")}</strong><button data-workbrief-close-follow>收起</button></div><p>已定位到该关注事项。可继续在下方对话中询问进展、风险、时间判断或要求智能体持续跟踪。</p></div>` : ""}</section><section class="workbrief-section"><div class="workbrief-recap"><div class="workbrief-recap-copy"><strong>17:00 今日复盘</strong><p>自动总结重点事项、完成情况、未闭环风险和次日提醒。</p></div><button class="workbrief-ghost-btn" data-workbrief-recap>${state.workbriefHome.recap ? "收起预览" : "预览今日复盘"}</button></div>${state.workbriefHome.recap ? '<div class="workbrief-recap-preview"><b>今日复盘：</b>已完成12项业务事项，其中智能体自动完成5项；采购流标加急方式已确认，仍有2项重点事项等待外部响应，1项建议明日上午升级督办。今天的重要事项已基本推进到位，辛苦啦～ (ง •̀_•́)ง</div>' : ""}</section></div></section>`;
      }
      function workbriefRerenderHome() {
        const t = document.getElementById("normalBriefCard");
        if (!t) return;
        const e = t.classList.contains("livebrief-intro"),
          a = t.classList.contains("collapsed");
        t.outerHTML = workbriefBriefMarkup(e, a);
      }
      function workbriefFindTask(t) {
        for (const e of Object.values(workbriefBusinessGroups)) {
          const a = e.tasks.find((e) => e.id === t);
          if (a) return a;
        }
        return null;
      }
      function workbriefOrchSteps(t) {
        const e = "E003" === t ? 1 : "E002" === t ? 5 : 4;
        return [
          [
            "demand",
            "需求确认",
            "materials",
            "23条需求完成编码、数量与交期校验。",
            "23条有效需求",
            "0条异常",
          ],
          [
            "source",
            "四渠道寻源",
            "responses",
            "跨单位、应急抢单、在途在建和应急采购并行执行。",
            "4类渠道",
            "12个来源",
          ],
          [
            "response",
            "响应汇聚",
            "responses",
            "有效响应完成去重、数量覆盖和交期冲突校验。",
            "18条响应",
            "20条已满足",
          ],
          [
            "compare",
            "方案比对",
            "plans",
            "原系统方案与AI组合方案完成逐物资对齐比较。",
            "补足2项缺口",
            "交期优化4小时",
          ],
          [
            "confirm",
            "人工确认",
            "plans",
            "3项差异需要用户确认来源组合和风险取舍。",
            "3项待确认",
            "当前环节",
          ],
          [
            "writeback",
            "结果回写",
            "events",
            "最终方案确认后自动回写原业务系统并留痕。",
            "待执行",
            "需先完成确认",
          ],
          [
            "review",
            "事件复盘",
            "review",
            "任务闭环后形成结果、决策和经验沉淀。",
            "待执行",
            "自动生成",
          ],
        ].map((t, a) => ({
          key: t[0],
          title: t[1],
          tab: t[2],
          summary: t[3],
          m1: t[4],
          m2: t[5],
          state: a < e ? "done" : a === e ? "current" : "future",
        }));
      }
      function workbriefSelectedOrch(t) {
        const e = workbriefOrchSteps(t);
        let a = state.workbriefOrchestrationStep[t];
        return (
          e.some((t) => t.key === a) ||
            (a = (e.find((t) => "current" === t.state) || e[0]).key),
          a
        );
      }
      function workbriefHorizontalProgress(t) {
        const e = workbriefOrchSteps(t),
          a = workbriefSelectedOrch(t),
          s = e.find((t) => t.key === a) || e[0];
        return `<div class="workbrief-orch-wrap"><div class="workbrief-orch-strip">${e.map((t, e) => `<button class="workbrief-orch-step ${t.state} ${a === t.key ? "selected" : ""}" data-workbrief-orch-step="${t.key}"><span class="workbrief-orch-node">${"done" === t.state ? "✓" : e + 1}</span><strong>${t.title}</strong><small>${"done" === t.state ? "已完成" : "current" === t.state ? "当前阶段" : "待执行"}</small></button>`).join("")}</div><div class="workbrief-orch-result"><div><div class="eyebrow">${s.title} · ${"done" === s.state ? "已完成" : "current" === s.state ? "当前执行" : "待执行"}</div><strong>${s.summary}</strong><p>${"future" === s.state ? "将在前置步骤完成后自动启动。" : "点击“查看明细”可在右侧业务画布查看对应结构化结果。"}</p><div class="workbrief-orch-result-meta"><span>${s.m1}</span><span>${s.m2}</span></div></div><div class="workbrief-orch-result-actions"><button data-timeline-toggle-timeline>展开执行轨迹</button><button class="primary" data-workbrief-orch-detail="${s.tab}">查看明细</button></div></div></div>`;
      }
      ((briefshellBriefMarkup = workbriefBriefMarkup),
        (livebriefBriefMarkup = workbriefBriefMarkup),
        (notificationsNormalBriefMarkup = function () {
          return workbriefBriefMarkup(!1);
        }),
        (timelineHorizontalProgress = workbriefHorizontalProgress),
        (timelineDetailedSteps = function (t) {
          const e = "E003" === t ? 4 : "E002" === t ? 9 : 8;
          return [
            [
              "定时任务识别应急事件",
              "监测规则触发并自动创建独立任务对话",
              "09:48",
              "events",
            ],
            [
              "接收并解析应急需求",
              "识别任务范围、需求单位与要求到货时间",
              "09:48",
              "materials",
            ],
            [
              "校验物资需求清单",
              "完成物料编码、数量、单位和交期校验，共23条有效需求",
              "09:50",
              "materials",
            ],
            [
              "查询跨单位可调库存",
              "检索省内可调库存并评估原单位保供影响",
              "09:52",
              "responses",
            ],
            [
              "发起应急抢单",
              "向协议供应商发起快速响应并设置自动催办",
              "09:54",
              "responses",
            ],
            [
              "核验在途／在建资源",
              "识别3项可协调资源并校验原项目影响",
              "09:57",
              "responses",
            ],
            [
              "汇总18条有效响应",
              "完成数量覆盖、交期和重复来源冲突校验",
              "10:16",
              "responses",
            ],
            [
              "生成AI推荐方案",
              "比较原系统方案与四渠道组合方案，识别3项差异",
              "10:22",
              "plans",
            ],
            [
              "等待用户确认",
              "确认最终来源组合及3项差异处置方式",
              "现在",
              "plans",
            ],
            [
              "回写最终结果",
              "确认后写回原业务系统并生成事件复盘",
              "待执行",
              "review",
            ],
          ].map((t, a) => ({
            title: t[0],
            desc: t[1],
            time: t[2],
            tab: t[3],
            state: a < e ? "done" : a === e ? "current" : "future",
          }));
        }),
        (timelineTaskOverviewCard = function (t) {
          const e = state.emergencyThread,
            a = emergencyMeta(e),
            s = !!state.timelineTimelineExpanded[e],
            n = collaborationDecisionCounts();
          return `<article class="timeline-task-overview"><div class="timeline-overview-head"><div><div class="eyebrow">智能体编排过程</div><h3>${emergencyEsc(a.title)}</h3><p>${emergencyEsc(t.text)}</p></div><span class="timeline-overview-status">${emergencyEsc(a.status)}</span></div><div class="timeline-overview-body">${s ? timelineVerticalTimeline(e) : workbriefHorizontalProgress(e)}${s ? "" : `<div class="timeline-overview-metrics"><button data-emergency-open-canvas="materials"><b>23</b><span>需求物资</span></button><button data-emergency-open-canvas="responses"><b>18</b><span>有效响应</span></button><button data-emergency-open-canvas="plans"><b>2</b><span>补足缺口</span></button><button class="attention" data-emergency-open-canvas="plans"><b>${n.pending}</b><span>待确认差异</span></button></div><div class="workbrief-overview-actions"><span>每一步均可点击查看状态和阶段结果。</span><div><button data-timeline-toggle-timeline>查看完整轨迹</button><button class="primary" data-emergency-open-canvas="plans">${n.pending ? "处理方案差异" : "查看最终方案"}</button></div></div>`}</div></article>`;
        }));
      const workbriefOldRenderConversation = livebriefRenderConversation;
      ((livebriefRenderConversation = function (t = !1) {
        const e = workbriefOldRenderConversation(t);
        return (
          setTimeout(() => {
            const e = document.getElementById("normalBriefCard");
            e &&
              !e.classList.contains("workbrief-brief") &&
              (e.outerHTML = workbriefBriefMarkup(!!t, !1));
          }, 40),
          e
        );
      }),
        document.addEventListener(
          "click",
          (t) => {
            if (t.target.closest("[data-workbrief-toggle]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                void document
                  .getElementById("normalBriefCard")
                  ?.classList.toggle("collapsed")
              );
            const e = t.target.closest("[data-workbrief-priority]");
            if (e)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.workbriefHome.priority = e.dataset.workbriefPriority),
                document
                  .getElementById("normalBriefCard")
                  ?.classList.remove("collapsed"),
                workbriefRerenderHome(),
                void showToast(
                  "已筛选" +
                    ("focus" === e.dataset.workbriefPriority
                      ? "重点事项"
                      : "一般事项"),
                )
              );
            const a = t.target.closest("[data-workbrief-progress]");
            if (a) {
              (t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.workbriefHome.progress = a.dataset.workbriefProgress),
                document
                  .getElementById("normalBriefCard")
                  ?.classList.remove("collapsed"),
                workbriefRerenderHome());
              return void showToast(
                `已下钻到“${{ pending: "待处理", running: "处理中", external: "待外部响应", done: "已完成" }[a.dataset.workbriefProgress]}”事项`,
              );
            }
            const s = t.target.closest("[data-workbrief-business]");
            if (s)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.workbriefHome.business = s.dataset.workbriefBusiness),
                document
                  .getElementById("normalBriefCard")
                  ?.classList.remove("collapsed"),
                void workbriefRerenderHome()
              );
            const n = t.target.closest("[data-workbrief-important]");
            if (n && !t.target.closest("button"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.workbriefHome.selectedImportant = n.dataset.workbriefImportant),
                void workbriefRerenderHome()
              );
            const o = t.target.closest("[data-workbrief-important-action]");
            if (o) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const e = o.dataset.workbriefImportantAction,
                a = o.dataset.action;
              return (
                (state.workbriefHome.selectedImportant = e),
                "handle" === a
                  ? ((state.workbriefHome.business = "procurement"),
                    showToast("已进入采购流标处理事项"))
                  : "escalate" === a
                    ? ((state.workbriefHome.escalated = !0),
                      showToast("已升级督办并同步发起人"))
                    : "notify" === a
                      ? showToast("已通知相关发起人和责任人员")
                      : showToast("已展开重点事项"),
                void workbriefRerenderHome()
              );
            }
            const r = t.target.closest("[data-workbrief-action]");
            if (r) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const e = workbriefFindTask(r.dataset.workbriefTask),
                a = r.dataset.workbriefAction;
              if (!e) return;
              return void ("process" === a
                ? ((state.workbriefHome.selectedTask =
                    state.workbriefHome.selectedTask === e.id ? "" : e.id),
                  workbriefRerenderHome())
                : "remind" === a
                  ? showToast(`已向“${e.title}”当前责任方发送智能催办`)
                  : "escalate" === a
                    ? ((state.workbriefHome.escalated = !0),
                      showToast(`“${e.title}”已升级督办`),
                      workbriefRerenderHome())
                    : "dialog" === a &&
                      ("X1" === e.id
                        ? ((state.emergencyThread = "E001"), setView("emergency"))
                        : showToast(`已创建“${e.title}”事项对话`)));
            }
            if (t.target.closest("[data-workbrief-close-detail]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.workbriefHome.selectedTask = ""),
                void workbriefRerenderHome()
              );
            const i = t.target.closest("[data-workbrief-follow]");
            if (i)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.workbriefHome.selectedFollow = i.dataset.workbriefFollow),
                void workbriefRerenderHome()
              );
            if (t.target.closest("[data-workbrief-close-follow]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.workbriefHome.selectedFollow = ""),
                void workbriefRerenderHome()
              );
            if (t.target.closest("[data-workbrief-recap]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.workbriefHome.recap = !state.workbriefHome.recap),
                void workbriefRerenderHome()
              );
            if (t.target.closest("[data-workbrief-open-emergency]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.emergencyThread = "center"),
                void setView("emergency")
              );
            const v = t.target.closest("[data-workbrief-orch-step]");
            if (v)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.workbriefOrchestrationStep[state.emergencyThread] =
                  v.dataset.workbriefOrchStep),
                (state.timelineTimelineExpanded[state.emergencyThread] = !1),
                void emergencyRender()
              );
            const c = t.target.closest("[data-workbrief-orch-detail]");
            return c
              ? (t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.emergencyCanvasTab = c.dataset.workbriefOrchDetail || "plans"),
                (state.collaborationTab = state.emergencyCanvasTab),
                (state.emergencyCanvasOpen = !0),
                void emergencyRender())
              : void 0;
          },
          !0,
        ));

/* Source runtime block 17 */
state.briefnavHome = state.briefnavHome || {
        level: "closed",
        root: "summary",
        priority: "focus",
        progress: "pending",
        business: "procurement",
        task: "",
        follow: "",
      };
      const briefnavPriorityCounts = {
          focus: { pending: 2, running: 1, external: 1, done: 0 },
          general: { pending: 6, running: 5, external: 5, done: 4 },
        },
        briefnavBreakdown = {
          "focus:pending": { procurement: 1, quality: 1 },
          "focus:running": { collaboration: 1 },
          "focus:external": { contract: 1 },
          "general:pending": {
            procurement: 3,
            contract: 1,
            arrival: 1,
            quality: 1,
          },
          "general:running": { procurement: 2, arrival: 2, collaboration: 1 },
          "general:external": { contract: 3, arrival: 1, collaboration: 1 },
          "general:done": { procurement: 2, contract: 1, arrival: 1 },
        };
      function briefnavEsc(t) {
        return "function" == typeof workbriefEsc ? workbriefEsc(t) : String(t ?? "");
      }
      function briefnavMetric(t, e, s, a = !1) {
        return `<button class="${a ? "urgent " : ""}${state.briefnavHome.root === t && "closed" !== state.briefnavHome.level ? "active" : ""}" data-briefnav-root="${t}"><b>${s}</b>${e}</button>`;
      }
      function briefnavBriefMarkup(t = !1, e) {
        const s = "closed" !== state.briefnavHome.level,
          a = t
            ? "今日共有5类、25条事项。AI识别2项需优先关注：1项采购流标存在交期风险，1项订单超期可能影响投运节点。"
            : "AI已完成今日业务研判，按优先级、处理进程和业务类型逐层查看。";
        return `<section class="${`normal-brief-card livebrief-brief-card briefnav-brief ${t ? "livebrief-intro" : "livebrief-docked"} ${(void 0 === e ? !t && !s : !!e) ? "collapsed" : ""} ${s ? "livebrief-filter-open" : ""}`}" id="normalBriefCard"><div class="normal-brief-head"><div class="normal-brief-bot" data-briefnav-title>${icons("i-bot")}</div><div class="normal-brief-title" data-briefnav-title><strong>今日简报</strong><span>${a}</span></div><span class="livebrief-brief-status" id="livebriefBriefStatus"><i></i><span>${t ? "已完成今日分析" : "智能体持续感知中"}</span></span><div class="normal-brief-mini">${briefnavMetric("immediate", "立即处理", 2, !0)}${briefnavMetric("focus", "重点事项", 4)}${briefnavMetric("general", "一般事项", 20)}${briefnavMetric("follow", "我的关注", 3)}</div><button class="normal-brief-chevron" data-briefnav-title aria-label="展开或收起今日简报">${icons("i-down")}</button></div><div class="normal-brief-body">${briefnavPanelMarkup()}</div></section>`;
      }
      function briefnavPath(t) {
        return `<div class="briefnav-path"><button data-briefnav-back="summary">重点事项</button>${t.map((e, s) => "<i>›</i>" + (s === t.length - 1 ? `<strong>${briefnavEsc(e.label)}</strong>` : `<button data-briefnav-back="${e.to}">${briefnavEsc(e.label)}</button>`)).join("")}</div>`;
      }
      function briefnavHead(t = []) {
        return `<div class="briefnav-panel-head">${briefnavPath(t)}<button class="briefnav-close" data-briefnav-close>收起</button></div>`;
      }
      function briefnavImportantRows() {
        const rows = [
          {id:"P1",title:"迎峰度夏重点项目采购流标",tags:["计划退回","时间紧迫"],copy:"常规采购周期将挤压要求到货窗口，当前需要尽快确认加急采购方式。",foot:"今日确认采购方式并启动最近可执行批次",type:"time"},
          {id:"X1",title:"忠县滑坡应急资源组合确认",tags:["应急保障","待人工确认"],copy:"多源寻源与方案比对已完成，当前3项资源组合差异需要人工确认。",foot:"确认推荐资源组合后自动进入结果回写",type:"risk"},
          {id:"C1",title:"主变压器订单发货确认超期",tags:["履约异常","已超期3天"],copy:"供应商仍未确认发货，继续延迟将影响到货验收和项目投运节点。",foot:"建议升级督办并同步项目发起人",type:"risk"},
          {id:"Q1",title:"质量异常事项处置核查",tags:["质量风险","需复核"],copy:"异常核验尚未闭环，需结合证据和处置规则判断是否暂停后续业务。",foot:"完成核验后明确冻结、复检或责任处置",type:"time"}
        ];
        return `<div class="briefnav-important-list">${rows.map(t=>`<button class="briefnav-important-row" data-briefnav-task="${t.id}"><div class="briefnav-row-top"><strong>${briefnavEsc(t.title)}</strong><div class="briefnav-tags">${t.tags.map((e,s)=>`<span class="briefnav-tag ${1===s?t.type:""}">${briefnavEsc(e)}</span>`).join("")}</div></div><p>${briefnavEsc(t.copy)}</p><div class="briefnav-row-foot"><span>${briefnavEsc(t.foot)}</span><b>›</b></div></button>`).join("")}</div>`;
      }
      function briefnavSummaryMarkup() {
        return `${briefnavHead()}<div class="briefnav-ai-summary"><div><strong>重点事项</strong><p>当前风险主要集中在采购流标后的时间窗口和订单履约超期。优先看4项关键事项，其余事项可按优先级继续下钻。</p></div><span>4项重点事项</span></div>${briefnavImportantRows()}<div class="briefnav-hint">点击上方“重点事项 / 一般事项”可继续查看处理进程；详细原因和依据可在下方对话中追问AI。</div>`;
      }
      function briefnavPriorityMarkup() {
        const t = state.briefnavHome.priority,
          e = briefnavPriorityCounts[t],
          s = "focus" === t ? "重点事项" : "一般事项",
          a = {
            pending: "需要本人或智能体启动处理",
            running: "本人或智能体正在执行",
            external: "当前环节已完成，等待外部反馈",
            done: "仅展示当日完成摘要",
          };
        return `${briefnavHead([{ label: s, to: "priority" }])}<div class="briefnav-ai-summary"><div><strong>${s}</strong><p>${"focus" === t ? "因保障、时间、风险、应急或用户关注被AI判定为重点。" : "当前未触发重点规则，按时限和业务节奏正常推进。"}</p></div><span>${"focus" === t ? 4 : 20}项</span></div><div class="briefnav-next-grid">${Object.entries(
          e,
        )
          .map(
            ([t, e]) =>
              `<button class="briefnav-next-btn" data-briefnav-progress="${t}"><b>${e}</b><strong>${{ pending: "待处理", running: "处理中", external: "待外部响应", done: "已完成" }[t]}</strong><small>${a[t]}</small></button>`,
          )
          .join("")}</div>`;
      }
      function briefnavProgressMarkup() {
        const t = state.briefnavHome.priority,
          e = state.briefnavHome.progress,
          s = "focus" === t ? "重点事项" : "一般事项",
          a = {
            pending: "待处理",
            running: "处理中",
            external: "待外部响应",
            done: "已完成",
          }[e];
        if ("done" === e)
          return `${briefnavHead([
            { label: s, to: "priority" },
            { label: a, to: "progress" },
          ])}<div class="briefnav-complete-summary"><strong>今日已完成4项</strong><p>采购方式确认2项、履约异常闭环1项、到货信息维护1项。已完成事项不在首页铺开历史明细，可在今日复盘中查看处理摘要。</p></div>`;
        const n = briefnavBreakdown[`${t}:${e}`] || {};
        return `${briefnavHead([
          { label: s, to: "priority" },
          { label: a, to: "progress" },
        ])}<div class="briefnav-ai-summary"><div><strong>${s} · ${a}</strong><p>先按业务类型归并，再查看具体业务事项。</p></div><span>${briefnavPriorityCounts[t][e]}项</span></div><div class="briefnav-business-grid">${Object.entries(
          n,
        )
          .map(([t, e]) => {
            const s = workbriefBusinessGroups[t];
            return `<button class="briefnav-business-btn" data-briefnav-business="${t}"><b>${e}</b><strong>${briefnavEsc(s.name)}</strong><small>${briefnavEsc(s.risk)}</small></button>`;
          })
          .join("")}</div>`;
      }
      function briefnavBusinessMarkup() {
        const t =
            workbriefBusinessGroups[state.briefnavHome.business] ||
            workbriefBusinessGroups.procurement,
          e = state.briefnavHome.priority;
        let s = t.tasks.filter((t) =>
          "focus" === e ? "重点" === t.status : "重点" !== t.status,
        );
        s.length || (s = t.tasks.slice(0, 1));
        const a =
          { pending: "待处理", running: "处理中", external: "待外部响应" }[
            state.briefnavHome.progress
          ] || "事项";
        return `${briefnavHead([
          { label: "focus" === e ? "重点事项" : "一般事项", to: "priority" },
          { label: a, to: "progress" },
          { label: t.name, to: "business" },
        ])}<div class="briefnav-ai-summary"><div><strong>${briefnavEsc(t.name)}</strong><p>当前展示该类型下最需关注的业务事项，点击后查看时间、流程影响和AI建议。</p></div><span>${t.count}条</span></div><div class="briefnav-task-list">${s.map((t) => `<button class="briefnav-task-row" data-briefnav-task="${t.id}"><div class="briefnav-row-top"><strong>${briefnavEsc(t.title)}</strong><div class="briefnav-tags"><span class="briefnav-tag ${"重点" === t.status ? "risk" : ""}">${briefnavEsc(t.status)}事项</span></div></div><p>${briefnavEsc(t.object)}</p><div class="briefnav-task-meta"><span>当前：${briefnavEsc(t.current)}</span><span>时间：${briefnavEsc(t.remain)}</span><span>风险：${briefnavEsc(t.risk)}</span></div><div class="briefnav-row-foot"><span>${briefnavEsc(t.advice)}</span><b>查看事项 ›</b></div></button>`).join("")}</div>`;
      }
      function briefnavTaskDetailMarkup() {
        const t = workbriefFindTask(state.briefnavHome.task) || workbriefFindTask("P1"),
          e = "重点" === t.status,
          s =
            "P1" === t.id
              ? "涉及迎峰度夏重点工程关键物资，采购窗口已明显压缩。"
              : "C1" === t.id
                ? "订单履约已超期，并开始挤压验收和投运准备时间。"
                : t.risk,
          a =
            "C1" === t.id
              ? "升级督办，并同步项目发起人和供应商负责人。"
              : "P1" === t.id
                ? "今日确认加急采购方式，并通知发起人启动后续流程。"
                : t.advice;
        return `${briefnavHead([
          { label: t.type, to: "business" },
          { label: t.title, to: "task" },
        ])}<article class="briefnav-detail"><div class="briefnav-detail-title"><strong>${briefnavEsc(t.title)}</strong><span>${e ? "重点事项" : "一般事项"}</span></div><div class="briefnav-detail-grid"><div class="briefnav-detail-cell"><span>发生了什么</span><b>${briefnavEsc(t.current)}｜${briefnavEsc(t.object)}</b></div><div class="briefnav-detail-cell"><span>为什么重要</span><b>${briefnavEsc(s)}</b></div><div class="briefnav-detail-cell"><span>时间判断</span><b>${briefnavEsc(t.remain)}｜${briefnavEsc(t.risk)}</b></div><div class="briefnav-detail-cell"><span>后续影响</span><b>${briefnavEsc(t.current)}未完成将影响${briefnavEsc(t.after)}</b></div><div class="briefnav-detail-cell"><span>AI建议</span><b>${briefnavEsc(t.advice)}</b></div><div class="briefnav-detail-cell"><span>推动方式</span><b>${briefnavEsc(a)}</b></div></div><div class="briefnav-detail-actions"><button data-briefnav-action="remind">立即催办</button>${e ? '<button class="warn" data-briefnav-action="escalate">升级督办</button>' : ""}<button class="primary" data-briefnav-action="dialog">进入事项对话</button></div></article>`;
      }
      function briefnavFollowMarkup() {
        return `${briefnavHead([{ label: "我的关注", to: "follow" }])}<div class="briefnav-ai-summary"><div><strong>我关注的事项</strong><p>用户主动关注、定时任务和智能体持续执行的事项。</p></div><span>3项</span></div><div class="briefnav-follow-list">${workbriefFollowItems.map((t) => `<button class="briefnav-follow-row" data-briefnav-follow="${t.id}"><div class="briefnav-row-top"><strong>${briefnavEsc(t.title)}</strong><span>${briefnavEsc(t.tag)}</span></div><p>${briefnavEsc(t.desc)}</p><div class="briefnav-row-foot"><span>持续跟踪中</span><b>查看进展 ›</b></div></button>`).join("")}</div>`;
      }
      function briefnavPanelMarkup() {
        switch (state.briefnavHome.level) {
          case "summary":
          case "immediate":
            return `<div class="briefnav-panel">${briefnavSummaryMarkup()}</div>`;
          case "priority":
            return `<div class="briefnav-panel">${briefnavPriorityMarkup()}</div>`;
          case "progress":
            return `<div class="briefnav-panel">${briefnavProgressMarkup()}</div>`;
          case "business":
            return `<div class="briefnav-panel">${briefnavBusinessMarkup()}</div>`;
          case "task":
            return `<div class="briefnav-panel">${briefnavTaskDetailMarkup()}</div>`;
          case "follow":
            return `<div class="briefnav-panel">${briefnavFollowMarkup()}</div>`;
          default:
            return "";
        }
      }
      function briefnavRerender() {
        const t = document.getElementById("normalBriefCard");
        if (!t) return;
        const e = t.classList.contains("livebrief-intro");
        t.outerHTML = briefnavBriefMarkup(e, "closed" === state.briefnavHome.level);
      }
      function briefnavOpenLevel(t, e) {
        const s = document.getElementById("normalBriefCard"),
          a = () => {
            ((state.briefnavHome.level = t),
              (state.briefnavHome.root = e || t),
              briefnavRerender());
          };
        s?.classList.contains("livebrief-intro")
          ? (livebriefDockBrief(!1), setTimeout(a, 110))
          : a();
      }
      function briefnavClose() {
        ((state.briefnavHome.level = "closed"),
          (state.briefnavHome.task = ""),
          briefnavRerender());
      }
      ((workbriefBriefMarkup = briefnavBriefMarkup),
        (briefshellBriefMarkup = briefnavBriefMarkup),
        (livebriefBriefMarkup = briefnavBriefMarkup),
        (notificationsNormalBriefMarkup = function () {
          return briefnavBriefMarkup(!1, !0);
        }));
      const briefnavBaseDock = livebriefDockBrief;
      function briefnavEnsureRecap() {
        const t = document.getElementById("view-chat");
        if (!t) return;
        let e = document.getElementById("briefnavRecapNudge");
        e ||
          ((e = document.createElement("div")),
          (e.id = "briefnavRecapNudge"),
          (e.className = "briefnav-recap-nudge"),
          (e.innerHTML =
            '<div class="briefnav-recap-card"><div class="briefnav-recap-line"><span class="briefnav-recap-dot"></span><div class="briefnav-recap-copy"><strong>17:00 今日复盘已生成</strong><span>完成12项，2项明日继续关注。今天的重要事项已基本推进到位，辛苦啦～ (ง •̀_•́)ง</span></div><button data-briefnav-recap-toggle>查看</button><button class="primary" data-briefnav-recap-chat>进入复盘对话</button></div><div class="briefnav-recap-detail"><div class="briefnav-recap-metrics"><div><b>12</b><span>今日完成</span></div><div><b>2</b><span>待外部响应</span></div><div><b>1</b><span>建议明日升级</span></div></div><p>采购流标加急方式已确认；主变压器订单仍待供应商反馈，建议明日上午继续催办并视情况升级。</p></div></div>'),
          t.appendChild(e));
      }
      livebriefDockBrief = function (t = !1) {
        (briefnavBaseDock(t),
          setTimeout(() => {
            const t = document.getElementById("normalBriefCard");
            if (!t) return;
            const e = t.querySelector(".normal-brief-title span");
            e &&
              (e.textContent =
                "AI已完成今日业务研判，按优先级、处理进程和业务类型逐层查看。");
          }, 100));
      };
      const briefnavBaseRenderConversation = livebriefRenderConversation;
      ((livebriefRenderConversation = function (t = !1) {
        state.briefnavHome.level = "closed";
        const e = briefnavBaseRenderConversation(t);
        return (
          setTimeout(() => {
            const e = document.getElementById("normalBriefCard");
            (e &&
              !e.classList.contains("briefnav-brief") &&
              (e.outerHTML = briefnavBriefMarkup(!!t, !0)),
              briefnavEnsureRecap());
          }, 80),
          e
        );
      }),
        document.addEventListener(
          "click",
          (t) => {
            if (t.target.closest("[data-briefnav-title]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                void ("closed" === state.briefnavHome.level
                  ? briefnavOpenLevel("summary", "summary")
                  : briefnavClose())
              );
            const e = t.target.closest("[data-briefnav-root]");
            if (e) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const s = e.dataset.briefnavRoot;
              return void ("immediate" === s
                ? briefnavOpenLevel("immediate", "immediate")
                : "follow" === s
                  ? briefnavOpenLevel("follow", "follow")
                  : ((state.briefnavHome.priority = s),
                    briefnavOpenLevel("priority", s)));
            }
            if (t.target.closest("[data-briefnav-close]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                void briefnavClose()
              );
            const s = t.target.closest("[data-briefnav-back]");
            if (s) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const e = s.dataset.briefnavBack;
              return void ("summary" === e
                ? briefnavOpenLevel("summary", "summary")
                : "priority" === e
                  ? briefnavOpenLevel("priority", state.briefnavHome.priority)
                  : "progress" === e
                    ? briefnavOpenLevel("progress", state.briefnavHome.priority)
                    : "business" === e
                      ? briefnavOpenLevel("business", state.briefnavHome.priority)
                      : "follow" === e && briefnavOpenLevel("follow", "follow"));
            }
            const a = t.target.closest("[data-briefnav-progress]");
            if (a)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.briefnavHome.progress = a.dataset.briefnavProgress),
                void briefnavOpenLevel("progress", state.briefnavHome.priority)
              );
            const n = t.target.closest("[data-briefnav-business]");
            if (n)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.briefnavHome.business = n.dataset.briefnavBusiness),
                void briefnavOpenLevel("business", state.briefnavHome.priority)
              );
            const o = t.target.closest("[data-briefnav-task]");
            if (o) {
              (t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.briefnavHome.task = o.dataset.briefnavTask));
              const e = workbriefFindTask(state.briefnavHome.task);
              return (
                e &&
                  ((state.briefnavHome.business =
                    Object.keys(workbriefBusinessGroups).find((t) =>
                      workbriefBusinessGroups[t].tasks.some((t) => t.id === e.id),
                    ) || state.briefnavHome.business),
                  (state.briefnavHome.priority =
                    "重点" === e.status ? "focus" : "general")),
                void briefnavOpenLevel("task", state.briefnavHome.root)
              );
            }
            const i = t.target.closest("[data-briefnav-action]");
            if (i) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const e = workbriefFindTask(state.briefnavHome.task);
              if (!e) return;
              const s = i.dataset.briefnavAction;
              if ("remind" === s)
                showToast(`已向“${e.title}”当前责任方发送智能催办`);
              else if ("escalate" === s)
                showToast(`“${e.title}”已升级督办并同步发起人`);
              else if ("dialog" === s) {
                briefnavClose();
                const t = document.getElementById("chatInput");
                t && ((t.value = `分析并推进：${e.title}`), sendChat());
              }
              return;
            }
            const r = t.target.closest("[data-briefnav-follow]");
            if (r) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const e = workbriefFollowItems.find(
                (t) => t.id === r.dataset.briefnavFollow,
              );
              return void showToast(
                `已定位“${e?.title || "关注事项"}”，可在对话中继续询问进展`,
              );
            }
            if (t.target.closest("[data-briefnav-recap-toggle]")) {
              t.preventDefault();
              const e = document.querySelector(".briefnav-recap-card");
              e?.classList.toggle("open");
              const s = t.target.closest("button");
              return void (
                s &&
                (s.textContent = e?.classList.contains("open")
                  ? "收起"
                  : "查看")
              );
            }
            if (t.target.closest("[data-briefnav-recap-chat]")) {
              t.preventDefault();
              const e = document.getElementById("chatInput");
              return void (
                e && ((e.value = "查看今天17点生成的工作复盘"), sendChat())
              );
            }
          },
          !0,
        ));

/* Source runtime block 18 */
function processreviewHomeProcessSteps(t) {
        const e = "P1" === t.id || "C1" === t.id ? 3 : 2;
        return [
          ["接收事项", "系统汇聚工单、邮件和订单信息", "已完成"],
          ["业务对象核验", "关联项目、订单及上下游节点", "已完成"],
          [
            "时间风险分析",
            "计算剩余窗口和最晚处理时间",
            e >= 2 ? "已完成" : "处理中",
          ],
          [
            "影响研判",
            "判断对后续环节和里程碑的影响",
            e >= 3 ? "当前环节" : "待执行",
          ],
          ["推动执行", "提醒、催办或升级督办", "待执行"],
          ["结果闭环", "记录处置结果并持续跟踪", "待执行"],
        ].map((t, a) => ({
          key: ["receive", "verify", "time", "impact", "push", "close"][a],
          title: t[0],
          desc: t[1],
          state: a < e ? "done" : a === e ? "current" : "future",
        }));
      }
      function processreviewTaskProcessMarkup() {
        const t = workbriefFindTask(state.briefnavHome.task) || workbriefFindTask("P1"),
          e = processreviewHomeProcessSteps(t);
        let a = state.processreviewHomeProcessStep;
        e.some((t) => t.key === a) ||
          (a = (e.find((t) => "current" === t.state) || e[0]).key);
        const s = e.find((t) => t.key === a) || e[0],
          n = {
            receive: `已汇聚“${t.type}”相关工单、邮件及业务对象。`,
            verify: `已定位${t.object}，确认当前处于“${t.current}”环节。`,
            time: `${t.remain}，智能体判断为“${t.risk}”。`,
            impact: `若当前环节未及时完成，将影响“${t.after}”及后续计划。`,
            push: `建议执行：${t.advice}`,
            close: "处置结果完成后，将自动更新首页简报和今日复盘。",
          };
        return `${briefnavHead([
          { label: t.type, to: "business" },
          { label: t.title, to: "task" },
          { label: "处理过程", to: "taskprocess" },
        ])}<article class="processreview-task-process"><div class="processreview-process-summary"><div><strong>${briefnavEsc(t.title)} · 处理过程</strong><p>按业务环节查看智能体完成内容、当前判断和下一步推动动作。</p></div><span>${"重点" === t.status ? "重点事项" : "一般事项"}</span></div><div class="processreview-process-line">${e.map((t, e) => `<button class="processreview-process-node ${t.state} ${t.key === a ? "active" : ""}" data-processreview-home-step="${t.key}"><i>${"done" === t.state ? "✓" : e + 1}</i><strong>${t.title}</strong><small>${"done" === t.state ? "已完成" : "current" === t.state ? "当前环节" : "待执行"}</small></button>`).join("")}</div><div class="processreview-process-detail"><div><span>这一步做什么</span><b>${briefnavEsc(s.desc)}</b></div><div><span>AI已经完成</span><b>${briefnavEsc(n[s.key])}</b></div><div><span>下一步</span><b>${"future" === s.state ? "等待前置环节完成后自动启动" : "push" === s.key ? "执行提醒、催办或升级督办" : t.advice}</b></div></div><div class="processreview-process-actions"><button data-briefnav-back="task">返回事项概览</button><button data-briefnav-action="remind">发送催办</button><button class="primary" data-briefnav-action="dialog">进入事项对话</button></div></article>`;
      }
      ((document.title = "供应链智慧工作台"),
        (state.processreviewHomeProcessStep = state.processreviewHomeProcessStep || "current"),
        (state.processreviewAtomicSelection = state.processreviewAtomicSelection || {}),
        (state.processreviewVerticalOpenStep = state.processreviewVerticalOpenStep || {}),
        (state.processreviewPlanFilter = state.processreviewPlanFilter || "all"),
        (state.processreviewPlanOpenItem = state.processreviewPlanOpenItem || "M01"),
        (state.processreviewPlanOpenSource = state.processreviewPlanOpenSource || ""),
        (state.processreviewPlanManual = state.processreviewPlanManual || ""),
        (state.processreviewPlanChoices = state.processreviewPlanChoices || {
          M01: "ai",
          M03: "ai",
          M04: "ai",
        }),
        (state.processreviewPlanConfirmed = state.processreviewPlanConfirmed || {
          M01: !1,
          M03: !1,
          M04: !1,
        }),
        (state.processreviewSameExpanded = state.processreviewSameExpanded || !1));
      const processreviewBaseTaskDetail = briefnavTaskDetailMarkup;
      briefnavTaskDetailMarkup = function () {
        const t = workbriefFindTask(state.briefnavHome.task) || workbriefFindTask("P1"),
          e = "重点" === t.status,
          a =
            "P1" === t.id
              ? "涉及迎峰度夏重点工程关键物资，采购窗口已明显压缩。"
              : "C1" === t.id
                ? "订单履约已超期，并开始挤压验收和投运准备时间。"
                : t.risk,
          s =
            "C1" === t.id
              ? "升级督办，并同步项目发起人和供应商负责人。"
              : "P1" === t.id
                ? "今日确认加急采购方式，并通知发起人启动后续流程。"
                : t.advice;
        return `${briefnavHead([
          { label: t.type, to: "business" },
          { label: t.title, to: "task" },
        ])}<article class="briefnav-detail"><div class="briefnav-detail-title"><strong>${briefnavEsc(t.title)}</strong><span>${e ? "重点事项" : "一般事项"}</span></div><div class="briefnav-detail-grid"><div class="briefnav-detail-cell"><span>任务要做什么</span><b>${briefnavEsc(t.current)}｜完成${briefnavEsc(t.object)}当前处置</b></div><div class="briefnav-detail-cell"><span>AI已经完成</span><b>已核验业务对象、时间窗口、上下游环节及历史催办记录</b></div><div class="briefnav-detail-cell"><span>为什么重要</span><b>${briefnavEsc(a)}</b></div><div class="briefnav-detail-cell"><span>当前状态</span><b>${briefnavEsc(t.remain)}｜${briefnavEsc(t.risk)}</b></div><div class="briefnav-detail-cell"><span>下一步动作</span><b>${briefnavEsc(t.advice)}</b></div><div class="briefnav-detail-cell"><span>推动方式</span><b>${briefnavEsc(s)}</b></div></div><div class="briefnav-detail-actions"><button data-briefnav-action="remind">立即催办</button>${e ? '<button class="warn" data-briefnav-action="escalate">升级督办</button>' : ""}<button data-processreview-open-home-process>查看处理过程</button><button class="primary" data-briefnav-action="dialog">进入事项对话</button></div></article>`;
      };
      const processreviewBasePanel = briefnavPanelMarkup;
      briefnavPanelMarkup = function () {
        return "taskprocess" === state.briefnavHome.level
          ? `<div class="briefnav-panel">${processreviewTaskProcessMarkup()}</div>`
          : processreviewBasePanel();
      };
      const processreviewOrchBlueprint = {
        demand: {
          goal: "确认需求边界并形成可执行物资清单",
          judgement:
            "优先校验物资编码、数量和要求到货时间，异常项先澄清再进入寻源。",
          result: "23条需求全部通过校验，0条异常。",
          atoms: [
            [
              "字段解析",
              "识别项目、单位、物资和时限",
              "形成23条结构化需求",
              "materials",
            ],
            [
              "物资编码校验",
              "匹配标准物料编码和计量单位",
              "23条编码全部有效",
              "materials",
            ],
            [
              "到货时限校验",
              "核对现场需求时间和缓冲窗口",
              "识别3条紧迫物资",
              "materials",
            ],
          ],
        },
        source: {
          goal: "通过四个渠道并行寻找可执行资源",
          judgement:
            "先使用内部可调资源，再补充协议供应和应急采购，兼顾到货时间与保供影响。",
          result: "发现12个可用来源，获得18条有效响应。",
          atoms: [
            [
              "跨单位库存查询",
              "查询省内可调库存并校验保供占用",
              "8个来源，6个可直接调拨",
              "responses",
            ],
            [
              "应急抢单",
              "向协议供应商发起快速响应",
              "5家供应商有效回复",
              "responses",
            ],
            [
              "在途／在建核验",
              "识别可协调资源并评估原项目影响",
              "3项资源可协调",
              "responses",
            ],
            [
              "应急采购寻源",
              "匹配本地现货和紧急运输能力",
              "2个备选来源",
              "responses",
            ],
          ],
        },
        response: {
          goal: "汇总响应并形成可比较的资源结果",
          judgement:
            "剔除重复来源，优先保留数量可覆盖、交期可满足且风险可控的响应。",
          result: "20条物资已满足，3条进入方案差异处理。",
          atoms: [
            [
              "响应去重",
              "合并同单位、同物资的重复回复",
              "18条有效响应",
              "responses",
            ],
            ["数量覆盖校验", "核对需求量与响应量", "20条完整覆盖", "materials"],
            [
              "交期冲突校验",
              "比较预计到达与要求到货",
              "识别1项交期风险",
              "responses",
            ],
          ],
        },
        compare: {
          goal: "逐项比较原系统方案与AI组合方案",
          judgement:
            "保留两套方案一致项，只把来源、数量、缺口或交期发生变化的物资交给用户确认。",
          result: "3项存在差异，AI建议补足2项缺口并优化1项交期。",
          atoms: [
            [
              "读取原系统方案",
              "读取原系统生成的来源组合",
              "形成方案基线",
              "plans",
            ],
            ["AI组合生成", "融合四渠道有效响应", "形成23项AI建议", "plans"],
            [
              "差异识别",
              "按物资比较来源、数量、缺口和交期",
              "识别3项差异",
              "plans",
            ],
          ],
        },
        confirm: {
          goal: "由用户逐项确认最终来源组合",
          judgement: "AI建议默认预选，用户可保留原系统方案或进行手动调整。",
          result: "当前仍有3项差异待人工确认。",
          atoms: [
            [
              "风险摘要生成",
              "汇总来源条件、交期和保供影响",
              "生成3条决策提示",
              "plans",
            ],
            [
              "用户决策留痕",
              "记录采用AI、原系统或人工调整",
              "等待用户操作",
              "plans",
            ],
          ],
        },
        writeback: {
          goal: "将最终方案回写原业务系统",
          judgement:
            "回写前校验物资、来源、数量和到货时间，确保与用户最终选择一致。",
          result: "待方案确认后执行。",
          atoms: [
            ["字段映射", "映射原系统回写字段", "映射规则已准备", "events"],
            ["结果校验", "校验最终方案完整性", "待执行", "events"],
          ],
        },
        review: {
          goal: "形成任务闭环复盘与经验沉淀",
          judgement: "提炼业务结果、人工决策和可复用经验，不展示底层技术日志。",
          result: "将在任务闭环后自动生成。",
          atoms: [
            ["事件汇总", "汇总关键业务动作和结果", "待执行", "review"],
            ["经验沉淀", "形成案例和技能优化建议", "待执行", "review"],
          ],
        },
      };
      function processreviewAtomKey(t, e) {
        return `${t}:${e}`;
      }
      function processreviewOrchDetail(t, e) {
        const a = processreviewOrchBlueprint[e.key] || processreviewOrchBlueprint.demand,
          s = processreviewAtomKey(t, e.key),
          n = state.processreviewAtomicSelection[s] || "",
          i = a.atoms.find((t) => t[0] === n);
        return `<div class="processreview-orch-detail"><div class="processreview-orch-three"><div><span>本步骤目标</span><b>${emergencyEsc(a.goal)}</b></div><div><span>业务判断</span><b>${emergencyEsc(a.judgement)}</b></div><div><span>阶段结果</span><b>${emergencyEsc(a.result)}</b></div></div><div class="processreview-atom-list"><strong>原子能力执行</strong><div class="processreview-atom-grid">${a.atoms.map((t) => `<button class="processreview-atom ${n === t[0] ? "active" : ""}" data-processreview-atom="${e.key}|${emergencyEsc(t[0])}"><strong>${emergencyEsc(t[0])}</strong><span>${emergencyEsc(t[2])}</span></button>`).join("")}</div>${i ? `<div class="processreview-atom-output"><div><strong>${emergencyEsc(i[0])} · 产出结果</strong><p>${emergencyEsc(i[1])}；${emergencyEsc(i[2])}。</p></div><button data-processreview-atom-detail="${i[3]}">查看业务结果</button></div>` : ""}</div></div>`;
      }
      function processreviewVerticalTimeline(t) {
        const e = workbriefOrchSteps(t);
        let a = state.processreviewVerticalOpenStep[t];
        return (
          a || (a = (e.find((t) => "current" === t.state) || e[0]).key),
          `<div class="timeline-timeline-shell"><div class="timeline-timeline-top"><div><strong>智能体执行过程</strong><span>点击阶段和原子能力，查看业务执行与产出结果</span></div><button class="timeline-overview-toggle secondary" data-timeline-toggle-timeline>收起全部</button></div><div class="processreview-vtimeline">${e
            .map((e, s) => {
              const n = processreviewOrchBlueprint[e.key] || processreviewOrchBlueprint.demand,
                i = a === e.key,
                v = processreviewAtomKey(t, e.key),
                o = state.processreviewAtomicSelection[v] || "";
              return `<article class="processreview-vstage ${e.state} ${i ? "open" : ""}"><button class="processreview-vstage-head" data-processreview-vstep="${e.key}"><span class="processreview-vicon">${"done" === e.state ? "✓" : "current" === e.state ? "●" : "○"}</span><span class="processreview-vcopy"><strong>${e.title}</strong><p>${emergencyEsc(n.result)}</p></span><time class="processreview-vtime">${"done" === e.state ? "已完成" : "current" === e.state ? "当前执行" : "待执行"}</time></button><div class="processreview-vbody"><div class="processreview-orch-three"><div><span>目标</span><b>${emergencyEsc(n.goal)}</b></div><div><span>业务判断</span><b>${emergencyEsc(n.judgement)}</b></div><div><span>结果</span><b>${emergencyEsc(n.result)}</b></div></div><div class="processreview-atom-list"><strong>原子能力</strong><div class="processreview-atom-grid">${n.atoms.map((t) => `<button class="processreview-atom ${o === t[0] ? "active" : ""}" data-processreview-atom="${e.key}|${emergencyEsc(t[0])}"><strong>${emergencyEsc(t[0])}</strong><span>${emergencyEsc(t[2])}</span></button>`).join("")}</div>${
                o
                  ? (() => {
                      const t = n.atoms.find((t) => t[0] === o);
                      return t
                        ? `<div class="processreview-atom-output"><div><strong>${emergencyEsc(t[0])} · 产出结果</strong><p>${emergencyEsc(t[1])}；${emergencyEsc(t[2])}。</p></div><button data-processreview-atom-detail="${t[3]}">查看业务结果</button></div>`
                        : "";
                    })()
                  : ""
              }</div></div></article>`;
            })
            .join(
              "",
            )}</div><div class="timeline-timeline-foot"><button class="timeline-overview-toggle secondary" data-timeline-open-events>查看完整事件记录</button></div></div>`
        );
      }
      ((workbriefHorizontalProgress = function (t) {
        const e = workbriefOrchSteps(t),
          a = workbriefSelectedOrch(t),
          s = e.find((t) => t.key === a) || e[0];
        return `<div class="workbrief-orch-wrap"><div class="workbrief-orch-strip">${e.map((t, e) => `<button class="workbrief-orch-step ${t.state} ${a === t.key ? "selected" : ""}" data-workbrief-orch-step="${t.key}"><span class="workbrief-orch-node">${"done" === t.state ? "✓" : e + 1}</span><strong>${t.title}</strong><small>${"done" === t.state ? "已完成" : "current" === t.state ? "当前阶段" : "待执行"}</small></button>`).join("")}</div>${processreviewOrchDetail(t, s)}</div>`;
      }),
        (timelineHorizontalProgress = workbriefHorizontalProgress),
        (timelineVerticalTimeline = processreviewVerticalTimeline),
        (timelineTaskOverviewCard = function (t) {
          const e = state.emergencyThread,
            a = emergencyMeta(e),
            s = !!state.timelineTimelineExpanded[e],
            n = collaborationDecisionCounts();
          return `<article class="timeline-task-overview"><div class="timeline-overview-head"><div><div class="eyebrow">智能体编排过程</div><h3>${emergencyEsc(a.title)}</h3><p>${emergencyEsc(t.text)}</p></div><span class="timeline-overview-status">${emergencyEsc(a.status)}</span></div><div class="timeline-overview-body">${s ? timelineVerticalTimeline(e) : workbriefHorizontalProgress(e)}${s ? "" : `<div class="timeline-overview-metrics"><button data-emergency-open-canvas="materials"><b>23</b><span>需求物资</span></button><button data-emergency-open-canvas="responses"><b>18</b><span>有效响应</span></button><button data-emergency-open-canvas="plans"><b>2</b><span>补足缺口</span></button><button class="attention" data-emergency-open-canvas="plans"><b>${n.pending}</b><span>待确认差异</span></button></div><div class="workbrief-overview-actions"><span>点击每一步查看业务判断、原子能力与产出结果。</span><div><button data-timeline-toggle-timeline>展开全部</button><button class="primary" data-emergency-open-canvas="plans">${n.pending ? "处理方案差异" : "查看最终方案"}</button></div></div>`}</div></article>`;
        }));
      const processreviewSameMaterials = [
          [
            "M05",
            "复合绝缘子",
            "FXBW-110/100",
            "30支",
            "忠县仓库",
            "30支",
            "10:30",
          ],
          [
            "M06",
            "氧化锌避雷器",
            "HY5WZ-51/134",
            "12只",
            "万州仓库",
            "12只",
            "11:10",
          ],
          [
            "M07",
            "耐张线夹",
            "NY-240/30",
            "24套",
            "本单位库存",
            "24套",
            "09:50",
          ],
          ["M08", "悬垂线夹", "CGU-5", "20套", "本单位库存", "20套", "09:50"],
          ["M09", "防震锤", "FD-5", "48只", "长寿公司", "48只", "12:20"],
          ["M10", "接续管", "JYD-240/30", "18根", "江津公司", "18根", "13:00"],
          [
            "M11",
            "OPGW光缆",
            "OPGW-24B1",
            "1.8千米",
            "忠县库存",
            "1.8千米",
            "10:00",
          ],
          [
            "M12",
            "光纤配线架",
            "ODF-48芯",
            "2套",
            "协议供应商A",
            "2套",
            "14:00",
          ],
          ["M13", "蓄电池组", "48V/200Ah", "2组", "本地供应商", "2组", "15:00"],
          ["M14", "逆变电源", "5kVA", "3台", "本单位库存", "3台", "10:20"],
          [
            "M15",
            "控制电缆",
            "KVVP2-22",
            "1.2千米",
            "涪陵公司",
            "1.2千米",
            "13:20",
          ],
          [
            "M16",
            "低压电缆",
            "YJV22-0.6/1kV",
            "0.8千米",
            "协议供应商B",
            "0.8千米",
            "14:30",
          ],
          ["M17", "接地线", "50mm²", "600米", "本单位库存", "600米", "09:40"],
          [
            "M18",
            "角钢塔材",
            "Q420",
            "4.5吨",
            "在建项目资源",
            "4.5吨",
            "15:30",
          ],
          ["M19", "钢绞线", "GJ-80", "1.0千米", "垫江公司", "1.0千米", "13:40"],
          ["M20", "熔断器", "RW12-12", "15组", "本单位库存", "15组", "10:10"],
          ["M21", "隔离开关", "GW9-12", "6组", "协议供应商C", "6组", "16:00"],
          [
            "M22",
            "配电变压器",
            "S13-400kVA",
            "1台",
            "应急储备库",
            "1台",
            "14:20",
          ],
          ["M23", "开关柜", "KYN28A-12", "2面", "在途订单资源", "2面", "16:30"],
          [
            "M24",
            "应急照明设备",
            "移动式",
            "8套",
            "本单位库存",
            "8套",
            "09:30",
          ],
        ].map((t) => ({
          id: t[0],
          name: t[1],
          spec: t[2],
          need: t[3],
          same: !0,
          due: "今日18:00前",
          original: [{ name: t[4], type: "可用来源", qty: t[5], eta: t[6] }],
          ai: [{ name: t[4], type: "可用来源", qty: t[5], eta: t[6] }],
          note: "原系统与AI方案来源、数量和交期一致，自动纳入最终方案。",
        })),
        processreviewDiffMaterials = [
          {
            id: "M01",
            name: "光缆",
            spec: "GYTA-24B1",
            need: "2.74千米",
            due: "今日02:30前",
            same: !1,
            original: [
              {
                name: "忠县库存",
                type: "本单位库存",
                qty: "1.8千米",
                eta: "00:40",
              },
              {
                name: "两家单位拼单",
                type: "跨单位调拨",
                qty: "0.94千米",
                eta: "02:10",
              },
            ],
            ai: [
              {
                name: "忠县库存",
                type: "本单位库存",
                qty: "1.8千米",
                eta: "00:40",
              },
              {
                name: "长寿公司",
                type: "在建资源",
                qty: "0.94千米",
                eta: "01:30",
              },
            ],
            note: "AI建议减少协调对象，并将最晚到达时间提前40分钟。",
          },
          {
            id: "M03",
            name: "通信电源",
            spec: "48V/100A",
            need: "5套",
            due: "今日06:30前",
            same: !1,
            original: [],
            ai: [
              {
                name: "重庆本地供应商",
                type: "应急采购现货",
                qty: "5套",
                eta: "06:00",
              },
            ],
            note: "原系统保留缺口；AI新增本地现货来源，可完整满足需求。",
          },
          {
            id: "M04",
            name: "电力电缆",
            spec: "YJV22-10kV",
            need: "2.5千米",
            due: "今日16:00前",
            same: !1,
            original: [
              {
                name: "本单位库存",
                type: "库存",
                qty: "0.8千米",
                eta: "10:00",
              },
              {
                name: "协议供应商",
                type: "协议供货",
                qty: "0.7千米",
                eta: "14:00",
              },
            ],
            ai: [
              {
                name: "本单位库存",
                type: "库存",
                qty: "0.8千米",
                eta: "10:00",
              },
              {
                name: "协议供应商",
                type: "协议供货",
                qty: "0.7千米",
                eta: "14:00",
              },
              {
                name: "江北公司",
                type: "跨单位可调库存",
                qty: "1.0千米",
                eta: "15:00",
              },
            ],
            note: "AI新增跨单位资源1.0千米，补足原系统方案缺口。",
          },
        ];
      function processreviewAllPlanItems() {
        return [...processreviewDiffMaterials, ...processreviewSameMaterials];
      }
      function processreviewPlanStats() {
        const t = processreviewDiffMaterials.map((t) => t.id),
          e = t.filter((t) => !state.processreviewPlanConfirmed[t]).length;
        return {
          total: 3,
          pending: e,
          ai: t.filter(
            (t) =>
              state.processreviewPlanConfirmed[t] && "ai" === state.processreviewPlanChoices[t],
          ).length,
          original: t.filter(
            (t) =>
              state.processreviewPlanConfirmed[t] &&
              "original" === state.processreviewPlanChoices[t],
          ).length,
          adjust: t.filter(
            (t) =>
              state.processreviewPlanConfirmed[t] && "adjust" === state.processreviewPlanChoices[t],
          ).length,
          confirmed: 3 - e,
        };
      }
      function processreviewSourceMarkup(t, e) {
        const a = t[e];
        return a.length
          ? `<div class="processreview-scheme-line">${a.map((a, s) => `<button class="processreview-source-chip" data-processreview-source="${t.id}|${e}|${s}"><span><b>${collaborationEscape(a.name)}</b><small>${collaborationEscape(a.type)} · ${collaborationEscape(a.eta)}到达</small></span><em>${collaborationEscape(a.qty)}</em></button>`).join("")}</div>`
          : `<div class="processreview-scheme-empty">暂无可用来源，保留缺口 ${collaborationEscape(t.need)}</div>`;
      }
      function processreviewChoiceMarkup(t) {
        if (t.same)
          return '<div class="processreview-choice"><button class="on">方案一致</button><span class="done">已自动纳入</span></div>';
        const e = state.processreviewPlanChoices[t.id] || "ai",
          a = !!state.processreviewPlanConfirmed[t.id];
        return `<div class="processreview-choice"><button class="${"ai" === e ? "on" : ""}" data-processreview-plan-choice="${t.id}|ai">采用AI建议</button><button class="${"original" === e ? "on" : ""}" data-processreview-plan-choice="${t.id}|original">采用原系统</button><button class="${"adjust" === e ? "on" : ""}" data-processreview-plan-manual="${t.id}">手动调整</button><span class="${a ? "done" : ""}">${a ? "已确认" : "AI建议已预选 · 待确认"}</span></div>`;
      }
      function processreviewPlanExpand(t) {
        const e = state.processreviewPlanOpenSource.split("|"),
          a = e[0] === t.id ? t[e[1]]?.[Number(e[2])] : null;
        return `<div class="processreview-plan-expand">${a ? `<div class="processreview-source-detail"><div><span>响应单位</span><b>${collaborationEscape(a.name)}</b></div><div><span>资源类型</span><b>${collaborationEscape(a.type)}</b></div><div><span>响应数量</span><b>${collaborationEscape(a.qty)}</b></div><div><span>预计到达</span><b>${collaborationEscape(a.eta)}</b></div></div>` : ""}<div class="processreview-plan-note">${collaborationEscape(t.note)} 点击来源可查看对应响应；更多依据可在中间对话中继续询问AI。</div>${state.processreviewPlanManual === t.id ? `<div class="processreview-manual"><label>来源组合<select id="processreviewManualSource"><option>采用AI组合并调整数量</option><option>保留原系统并补充来源</option><option>人工指定其他来源</option></select></label><label>确认数量<input id="processreviewManualQty" value="${collaborationEscape(t.need)}"></label><label>最晚到达<input id="processreviewManualEta" value="今日 15:30"></label><button data-processreview-save-manual="${t.id}">保存调整</button></div>` : ""}</div>`;
      }
      function processreviewPlanItem(t) {
        return `<article class="processreview-plan-item ${state.processreviewPlanOpenItem === t.id ? "open" : ""}" data-processreview-plan-item="${t.id}"><div class="processreview-plan-row-main"><div class="processreview-material"><strong>${collaborationEscape(t.name)}</strong><small>${collaborationEscape(t.spec)} · 需求${collaborationEscape(t.need)}</small><small>要求到货：${collaborationEscape(t.due)}</small><em class="${t.same ? "same" : ""}">${t.same ? "方案一致" : "方案差异"}</em></div><div>${processreviewSourceMarkup(t, "original")}</div><div>${processreviewSourceMarkup(t, "ai")}</div><div>${processreviewChoiceMarkup(t)}</div></div>${processreviewPlanExpand(t)}</article>`;
      }
      function processreviewPlanPage() {
        const t = processreviewPlanStats();
        let e = processreviewDiffMaterials;
        ("pending" === state.processreviewPlanFilter &&
          (e = e.filter((t) => !state.processreviewPlanConfirmed[t.id])),
          "same" === state.processreviewPlanFilter && (e = []));
        const a =
          "same" === state.processreviewPlanFilter ||
          ("all" === state.processreviewPlanFilter && state.processreviewSameExpanded);
        return `<div class="processreview-plan-page"><section class="processreview-plan-hero"><div><strong>应急寻源完整方案</strong><p>共23项物资。3项存在差异，AI建议已预选；20项方案一致，默认纳入最终方案。</p></div><div class="processreview-plan-kpis"><button class="${"all" === state.processreviewPlanFilter ? "on" : ""}" data-processreview-plan-filter="all"><b>23</b>全部</button><button class="${"diff" === state.processreviewPlanFilter ? "on" : ""}" data-processreview-plan-filter="diff"><b>3</b>差异项</button><button class="${"pending" === state.processreviewPlanFilter ? "on" : ""}" data-processreview-plan-filter="pending"><b>${t.pending}</b>待确认</button><button class="${"same" === state.processreviewPlanFilter ? "on" : ""}" data-processreview-plan-filter="same"><b>20</b>一致项</button></div></section><div class="processreview-plan-toolbar"><span>已确认${t.confirmed}/3 · 采用AI ${t.ai} · 原系统 ${t.original} · 手动调整 ${t.adjust}</span><div><button data-processreview-plan-filter="pending">仅看待确认</button><button class="primary" data-processreview-accept-all>采用全部AI建议</button></div></div><section class="processreview-plan-sheet"><div class="processreview-plan-section-head"><strong>需确认差异 · ${e.length}项</strong><span>逐项选择最终采用方案</span></div><div class="processreview-plan-columns"><div>物资</div><div>原系统方案</div><div>AI建议方案</div><div>最终选择</div></div>${e.map(processreviewPlanItem).join("") || '<div style="padding:16px;text-align:center;color:#7e918d;font-size:8px">当前没有待确认差异。</div>'}<div class="processreview-plan-section-head"><strong>方案一致 · 20项</strong><button data-processreview-toggle-same>${a ? "收起" : "展开查看"}</button></div>${a ? `<div class="processreview-plan-columns"><div>物资</div><div>原系统方案</div><div>AI建议方案</div><div>最终选择</div></div>${processreviewSameMaterials.map(processreviewPlanItem).join("")}` : ""}</section><div class="processreview-plan-footer"><span>${t.pending ? `仍有${t.pending}项差异待确认，完成后可形成最终方案。` : "全部差异已确认，可形成并回写最终方案。"}</span><button id="processreviewFinalize" ${t.pending ? "disabled" : ""}>形成最终方案</button></div></div>`;
      }
      function processreviewEnsureRecapUI() {
        const t = document.getElementById("view-chat") || document.body;
        if (!document.getElementById("processreviewRecapAnchor")) {
          const e = document.createElement("div");
          ((e.id = "processreviewRecapAnchor"),
            (e.className = "processreview-recap-anchor"),
            (e.innerHTML =
              '<div class="processreview-recap-anchor-card"><div class="processreview-recap-anchor-icon">✓</div><div class="processreview-recap-anchor-copy"><strong>今日复盘已生成</strong><span>完成12项，2项明日继续关注。今天辛苦啦～</span></div><button data-processreview-open-recap>再次查看</button></div>'),
            t.appendChild(e));
        }
        if (!document.getElementById("processreviewRecapOverlay")) {
          const t = document.createElement("div");
          ((t.id = "processreviewRecapOverlay"),
            (t.className = "processreview-recap-overlay"),
            (t.innerHTML =
              '<section class="processreview-recap-modal" role="dialog" aria-modal="true" aria-label="今日工作完成总结"><div class="processreview-recap-top"><span>17:00 · 智能体自动生成</span><h2>今日工作完成啦</h2><p>今天的重要事项推进得很扎实，智能体已经为您完成今日复盘。</p></div><div class="processreview-recap-body"><div class="processreview-recap-metrics"><div class="processreview-recap-metric"><b>12</b><span>今日完成事项</span></div><div class="processreview-recap-metric"><b>5</b><span>智能体自动完成</span></div><div class="processreview-recap-metric"><b>2</b><span>明日继续关注</span></div></div><div class="processreview-recap-list"><div class="processreview-recap-item"><i>✓</i><div><strong>重点事项已推进</strong><p>采购流标加急方式已确认，预计缩短4天采购周期。</p></div></div><div class="processreview-recap-item"><i>!</i><div><strong>明日提醒</strong><p>主变压器订单仍待供应商反馈，建议明日上午继续催办，必要时升级督办。</p></div></div><div class="processreview-recap-item"><i>→</i><div><strong>工作已留痕</strong><p>今日决策、催办和智能体执行结果均已记录，可随时回看。</p></div></div></div><div class="processreview-recap-cheer">今天该推进的都推进到位了，放心下班吧～ ✨ (ง •̀_•́)ง</div><div class="processreview-recap-actions"><button data-processreview-recap-chat>查看完整复盘</button><button class="primary" data-processreview-close-recap>知道了，准备下班</button></div></div></section>'),
            document.body.appendChild(t));
        }
      }
      function processreviewOpenRecap() {
        (processreviewEnsureRecapUI(),
          document.getElementById("processreviewRecapOverlay")?.classList.add("open"));
      }
      function processreviewCloseRecap() {
        (document.getElementById("processreviewRecapOverlay")?.classList.remove("open"),
          document.getElementById("processreviewRecapAnchor")?.classList.add("show"));
      }
      ((collaborationDecisionCounts = function () {
        return processreviewPlanStats();
      }),
        (planreviewPlanPage = processreviewPlanPage),
        (briefnavEnsureRecap = function () {}),
        processreviewEnsureRecapUI(),
        clearTimeout(window.__processreviewRecapTimer),
        (window.__processreviewRecapTimer = setTimeout(processreviewOpenRecap, 6e4)),
        document.addEventListener(
          "click",
          (t) => {
            if (t.target.closest("[data-processreview-open-home-process]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.briefnavHome.level = "taskprocess"),
                void briefnavRerender()
              );
            const e = t.target.closest("[data-processreview-home-step]");
            if (e)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.processreviewHomeProcessStep = e.dataset.processreviewHomeStep),
                void briefnavRerender()
              );
            const a = t.target.closest("[data-processreview-atom]");
            if (a) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const [e, s] = a.dataset.processreviewAtom.split("|");
              return (
                (state.processreviewAtomicSelection[processreviewAtomKey(state.emergencyThread, e)] = s),
                (state.processreviewVerticalOpenStep[state.emergencyThread] = e),
                void emergencyRender()
              );
            }
            const s = t.target.closest("[data-processreview-vstep]");
            if (s) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const e = s.dataset.processreviewVstep;
              return (
                (state.processreviewVerticalOpenStep[state.emergencyThread] =
                  state.processreviewVerticalOpenStep[state.emergencyThread] === e ? "" : e),
                void emergencyRender()
              );
            }
            const n = t.target.closest("[data-processreview-atom-detail]");
            if (n)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.emergencyCanvasTab = n.dataset.processreviewAtomDetail),
                (state.collaborationTab = state.emergencyCanvasTab),
                (state.emergencyCanvasOpen = !0),
                void emergencyRender()
              );
            const i = t.target.closest("[data-processreview-plan-filter]");
            if (i)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.processreviewPlanFilter = i.dataset.processreviewPlanFilter),
                void emergencyRender()
              );
            const v = t.target.closest("[data-processreview-plan-item]");
            if (v && !t.target.closest("button,input,select"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.processreviewPlanOpenItem =
                  state.processreviewPlanOpenItem === v.dataset.processreviewPlanItem
                    ? ""
                    : v.dataset.processreviewPlanItem),
                (state.processreviewPlanOpenSource = ""),
                void emergencyRender()
              );
            const o = t.target.closest("[data-processreview-source]");
            if (o) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const e = o.dataset.processreviewSource.split("|")[0];
              return (
                (state.processreviewPlanOpenItem = e),
                (state.processreviewPlanOpenSource = o.dataset.processreviewSource),
                void emergencyRender()
              );
            }
            const l = t.target.closest("[data-processreview-plan-choice]");
            if (l) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const [e, a] = l.dataset.processreviewPlanChoice.split("|");
              return (
                (state.processreviewPlanChoices[e] = a),
                (state.processreviewPlanConfirmed[e] = !0),
                (state.collaborationDecisions[e] = a),
                (state.processreviewPlanOpenItem = e),
                emergencyPush(
                  "assistant",
                  `“${(processreviewDiffMaterials.find((t) => t.id === e) || {}).name || e}”已${"ai" === a ? "采用AI建议方案" : "采用原系统方案"}。`,
                ),
                void emergencyRender()
              );
            }
            const d = t.target.closest("[data-processreview-plan-manual]");
            if (d)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.processreviewPlanOpenItem = d.dataset.processreviewPlanManual),
                (state.processreviewPlanManual = d.dataset.processreviewPlanManual),
                (state.processreviewPlanChoices[d.dataset.processreviewPlanManual] = "adjust"),
                void emergencyRender()
              );
            const c = t.target.closest("[data-processreview-save-manual]");
            if (c) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const e = c.dataset.processreviewSaveManual;
              return (
                (state.processreviewPlanChoices[e] = "adjust"),
                (state.processreviewPlanConfirmed[e] = !0),
                (state.collaborationDecisions[e] = "adjust"),
                (state.processreviewPlanManual = ""),
                emergencyPush(
                  "assistant",
                  `“${(processreviewDiffMaterials.find((t) => t.id === e) || {}).name || e}”已保存人工调整方案。`,
                ),
                void emergencyRender()
              );
            }
            if (t.target.closest("[data-processreview-toggle-same]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.processreviewSameExpanded = !state.processreviewSameExpanded),
                (state.processreviewPlanFilter = "all"),
                void emergencyRender()
              );
            if (t.target.closest("[data-processreview-accept-all]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                processreviewDiffMaterials.forEach((t) => {
                  ((state.processreviewPlanChoices[t.id] = "ai"),
                    (state.processreviewPlanConfirmed[t.id] = !0),
                    (state.collaborationDecisions[t.id] = "ai"));
                }),
                emergencyPush("assistant", "已采用全部AI建议，3项方案差异均已确认。"),
                void emergencyRender()
              );
            if (t.target.closest("#processreviewFinalize")) {
              if (
                (t.preventDefault(),
                t.stopImmediatePropagation(),
                processreviewPlanStats().pending)
              )
                return;
              return (
                (state.task.finalSolutionGenerated = !0),
                emergencyPush(
                  "assistant",
                  "最终寻源方案已形成：23项物资全部完成来源确认，正在准备回写原业务系统。",
                ),
                showToast("最终方案已形成"),
                void emergencyRender()
              );
            }
            return t.target.closest("[data-processreview-open-recap]")
              ? (t.preventDefault(), void processreviewOpenRecap())
              : t.target.closest("[data-processreview-close-recap]")
                ? (t.preventDefault(), void processreviewCloseRecap())
                : t.target.closest("[data-processreview-recap-chat]")
                  ? (t.preventDefault(),
                    processreviewCloseRecap(),
                    setView("chat"),
                    void setTimeout(() => {
                      const t = document.getElementById("chatInput");
                      t &&
                        ((t.value = "查看今天17点生成的完整工作复盘"),
                        sendChat());
                    }, 120))
                  : void 0;
          },
          !0,
        ));

/* Source runtime block 19 */
function sensingSummaryCounts() {
        return state.sensingSense.detected
          ? {
              total: 26,
              categories: 6,
              priority: 3,
              pending: 8,
              running: 6,
              external: 8,
              done: 4,
            }
          : {
              total: 25,
              categories: 5,
              priority: 2,
              pending: 7,
              running: 6,
              external: 8,
              done: 4,
            };
      }
      function sensingSenseMarkup() {
        const t = state.sensingSense;
        return `<div class="sensing-sense-bar"><div class="sensing-sense-main"><span class="sensing-sense-pulse"></span><div class="sensing-sense-copy"><strong>智能体持续感知中</strong><span>${t.detected ? "刚刚发现1项新的履约预警任务，简报、分类和历史对话已同步更新。" : "持续读取工单、任务、邮件和业务系统变化，最近一次扫描：" + t.lastScan}</span></div></div>${t.detected ? '<button class="hot" data-sensing-new-task>查看新增任务</button>' : "<button data-sensing-scan-now>立即扫描</button>"}</div>`;
      }
      ((document.title = "供应链智慧工作台"),
        (state.sensingSense = state.sensingSense || {
          detected: !1,
          total: 25,
          categories: 5,
          priority: 2,
          lastScan: "刚刚",
          newTaskAdded: !1,
        }),
        (state.sensingAllProgress = state.sensingAllProgress || "pending"));
      const sensingPrevBriefMarkup = briefnavBriefMarkup;
      function sensingAllProgressMarkup() {
        const t = state.sensingAllProgress,
          e = sensingSummaryCounts(),
          s = {
            pending: "待处理",
            running: "处理中",
            external: "待外部响应",
            done: "今日完成",
          };
        if ("done" === t)
          return `${briefnavHead([{ label: "今日完成", to: "allprogress" }])}${sensingSenseMarkup()}<div class="briefnav-complete-summary"><strong>今日已完成${e.done}项</strong><p>采购方式确认2项、履约异常闭环1项、到货信息维护1项。点击“查看完整复盘”可回看今日决策、催办和智能体执行记录。</p></div>`;
        const a =
          {
            pending: {
              procurement: 3,
              contract: state.sensingSense.detected ? 2 : 1,
              arrival: 1,
              quality: 1,
            },
            running: { procurement: 2, arrival: 2, collaboration: 2 },
            external: { contract: 3, arrival: 2, collaboration: 2, quality: 1 },
          }[t] || {};
        return `${briefnavHead([{ label: s[t], to: "allprogress" }])}${sensingSenseMarkup()}<div class="sensing-progress-summary"><div><strong>${s[t]} · ${e[t]}项</strong><p>${{ pending: "需要用户或智能体启动处理", running: "本人或智能体正在执行", external: "当前环节已完成，正在等待外部反馈", done: "仅展示当日完成摘要" }[t]}。先按业务场景归并，再进入单个任务。</p></div><span>点击业务类型继续下钻</span></div><div class="briefnav-business-grid" style="margin-top:8px">${Object.entries(
          a,
        )
          .map(([t, e]) => {
            const s = workbriefBusinessGroups[t];
            return `<button class="briefnav-business-btn" data-sensing-all-business="${t}"><b>${e}</b><strong>${briefnavEsc(s.name)}</strong><small>${briefnavEsc(s.risk)}</small></button>`;
          })
          .join("")}</div>`;
      }
      function sensingRiskMarkup() {
        const t = state.sensingRisk || "时间紧迫";
        return `${briefnavHead([{ label: t, to: "risk" }])}${sensingSenseMarkup()}<div class="sensing-progress-summary"><div><strong>${briefnavEsc(t)} · ${"保障相关" === t ? 3 : state.sensingSense.detected ? 6 : 5}项</strong><p>AI根据项目等级、剩余时间、流程里程碑和异常规则筛选出的关注事项。</p></div><span>按业务场景查看</span></div><div class="briefnav-business-grid" style="margin-top:8px"><button class="briefnav-business-btn" data-sensing-all-business="procurement"><b>2</b><strong>采购流标处理</strong><small>采购窗口压缩</small></button><button class="briefnav-business-btn" data-sensing-all-business="contract"><b>${state.sensingSense.detected ? 2 : 1}</b><strong>合同履约异常</strong><small>发货与交期异常</small></button><button class="briefnav-business-btn" data-sensing-all-business="arrival"><b>2</b><strong>到货信息维护</strong><small>应到未到</small></button></div>`;
      }
      function sensingNewTaskMarkup() {
        return `${briefnavHead([{ label: "新增任务", to: "newtask" }])}${sensingSenseMarkup()}<article class="sensing-new-task"><span class="flag">持续感知自动发现</span><h3>主变压器订单发货确认</h3><p>合同履约监测定时任务发现计划发货时间已过，系统仍未收到供应商发货确认。智能体已关联订单、合同、项目里程碑和历史催办记录，并将事项归入“合同履约异常”。</p><div class="sensing-new-task-grid"><div><span>当前环节</span><b>供应商发货确认</b></div><div><span>时间判断</span><b>已超计划2小时</b></div><div><span>后续影响</span><b>可能压缩到货验收窗口</b></div></div><div class="sensing-new-task-actions"><button data-sensing-back-summary>返回总体分析</button><button data-sensing-remind-new>立即催办</button><button class="primary" data-sensing-enter-new-task>进入任务对话</button></div></article>`;
      }
      ((briefnavBriefMarkup = function (t = !1, e) {
        const s = sensingSummaryCounts(),
          a = "closed" !== state.briefnavHome.level,
          n = `normal-brief-card livebrief-brief-card briefnav-brief sensing-brief ${t ? "livebrief-intro" : "livebrief-docked"} ${(void 0 === e ? !t && !a : !!e) ? "collapsed" : ""} ${a ? "livebrief-filter-open" : ""}`,
          r = `今日共感知${s.categories}类、${s.total}条事项，${s.priority}项需优先关注；点击后按概要、筛选、业务场景和单项任务逐层查看。`;
        return `<section class="${n}" id="normalBriefCard"><div class="normal-brief-head"><div class="normal-brief-bot" data-briefnav-title>${icons("i-bot")}</div><div class="normal-brief-title" data-briefnav-title><strong>今日简报</strong><span>${r}</span></div><span class="livebrief-brief-status" id="livebriefBriefStatus"><i></i><span>${state.sensingSense.detected ? "发现1项新任务" : "智能体持续感知中"}</span></span><div class="normal-brief-mini">${briefnavMetric("immediate", "立即处理", state.sensingSense.detected ? 3 : 2, !0)}${briefnavMetric("focus", "重点事项", state.sensingSense.detected ? 6 : 5)}${briefnavMetric("general", "一般事项", 20)}${briefnavMetric("follow", "我的关注", 3)}</div><button class="normal-brief-chevron" data-briefnav-title aria-label="展开或收起今日简报">${icons("i-down")}</button></div><div class="normal-brief-body">${briefnavPanelMarkup()}</div></section>`;
      }),
        (workbriefBriefMarkup = briefnavBriefMarkup),
        (briefshellBriefMarkup = briefnavBriefMarkup),
        (livebriefBriefMarkup = briefnavBriefMarkup),
        (notificationsNormalBriefMarkup = function () {
          return briefnavBriefMarkup(!1, !0);
        }),
        (briefnavSummaryMarkup = function () {
          const t = sensingSummaryCounts(),
            e = state.sensingSense.detected
              ? '<button class="sensing-key-card" data-sensing-new-task><div class="top"><strong>主变压器订单发货确认</strong><em>新增任务</em></div><p>计划发货时间已过，尚未收到供应商确认；已自动归入合同履约异常。</p><small>建议今日16:00前催办并判断是否升级督办 ›</small></button>'
              : "";
          return `${briefnavHead()}${sensingSenseMarkup()}<div class="sensing-summary-hero"><div><h3>今日总体概要与重点分析</h3><p>AI已对工单、任务、邮件、定时任务和关注事项完成归并分析。当前风险主要集中在重点项目采购流标、订单履约超期${state.sensingSense.detected ? "以及新增发货确认预警" : ""}。建议优先处理时间窗口已经收窄、可能影响下游里程碑的事项。</p></div><div class="sensing-summary-total"><div><b>${t.categories}</b><span>业务类型</span></div><div><b>${t.total}</b><span>业务事项</span></div><div><b>${t.priority}</b><span>优先关注</span></div></div></div><div class="sensing-key-list"><button class="sensing-key-card" data-briefnav-task="P1"><div class="top"><strong>重点项目采购流标</strong><em>时间紧迫</em></div><p>距要求到货仅剩18天，按常规采购周期预计晚5天，并将压缩合同签订和生产交付时间。</p><small>建议今日确认加急采购方式并同步发起人 ›</small></button><button class="sensing-key-card" data-briefnav-task="C1"><div class="top"><strong>主变压器订单超期3天</strong><em>风险异常</em></div><p>供应商未确认发货，下游到货验收和项目投运仅剩2天缓冲，已具备升级督办条件。</p><small>建议升级督办并同步项目负责人 ›</small></button>${e}</div><div class="sensing-filter-shell"><div class="sensing-filter-title"><strong>按优先级和处理进程继续查看</strong><span>每个入口均可逐层下钻</span></div><div class="sensing-filter-grid"><button data-briefnav-root="focus"><b>${state.sensingSense.detected ? 6 : 5}</b><span>重点事项</span><small>保障、时间、风险、应急</small></button><button data-briefnav-root="general"><b>20</b><span>一般事项</span><small>按业务节奏推进</small></button><button data-sensing-all-progress="pending"><b>${t.pending}</b><span>待处理</span><small>尚未启动执行</small></button><button data-sensing-all-progress="running"><b>${t.running}</b><span>处理中</span><small>本人或智能体执行中</small></button><button data-sensing-all-progress="external"><b>${t.external}</b><span>待外部响应</span><small>等待单位、供应商或审批</small></button><button data-sensing-all-progress="done"><b>${t.done}</b><span>今日完成</span><small>查看当日完成摘要</small></button><button data-sensing-risk="保障相关"><b>3</b><span>保障相关</span><small>重点工程和保供任务</small></button><button data-sensing-risk="时间紧迫"><b>${state.sensingSense.detected ? 6 : 5}</b><span>时间紧迫</span><small>临近超期和里程碑冲突</small></button></div></div>`;
        }));
      const sensingPrevPanelMarkup = briefnavPanelMarkup;
      briefnavPanelMarkup = function () {
        return "allprogress" === state.briefnavHome.level
          ? `<div class="briefnav-panel">${sensingAllProgressMarkup()}</div>`
          : "risk" === state.briefnavHome.level
            ? `<div class="briefnav-panel">${sensingRiskMarkup()}</div>`
            : "newtask" === state.briefnavHome.level
              ? `<div class="briefnav-panel">${sensingNewTaskMarkup()}</div>`
              : sensingPrevPanelMarkup();
      };
      const sensingOrchBlueprint = {
        demand: {
          goal: "确认需求边界并形成可执行物资清单",
          judgement: "校验物资、数量和到货要求，异常项先澄清再进入寻源。",
          result: "23条需求全部通过校验，0条异常。",
          atoms: [
            {
              name: "需求清单解析",
              task: "读取应急需求清单并识别项目、单位和物资",
              exec: "已将原始清单转换为结构化需求",
              result: "形成23条有效需求",
              tab: "materials",
            },
            {
              name: "物料编码匹配",
              task: "将需求描述匹配到标准物料编码和计量单位",
              exec: "已完成标准物料映射",
              result: "23条编码全部有效",
              tab: "materials",
            },
            {
              name: "需求完整性校验",
              task: "校验数量、单位、规格和必要字段",
              exec: "已检查必填字段及重复需求",
              result: "0条缺失，0条重复",
              tab: "materials",
            },
            {
              name: "到货要求识别",
              task: "识别要求到货时间和现场时间窗口",
              exec: "已结合任务时限完成优先级判断",
              result: "识别3条紧迫物资",
              tab: "materials",
            },
          ],
        },
        source: {
          goal: "通过四个渠道并行寻找可执行资源",
          judgement:
            "内部可调资源优先，协议供应和应急采购并行补充，兼顾交期与保供影响。",
          result: "发现12个可用来源，获得18条有效响应。",
          atoms: [
            {
              name: "跨单位调拨查询",
              task: "查询省内其他单位可调库存和可释放资源",
              exec: "综合校验可用数量、保供占用和预计到达时间",
              result: "8个有效来源，6个可直接调拨",
              tab: "responses",
            },
            {
              name: "应急抢单查询",
              task: "向协议供应商发起应急快速响应",
              exec: "已读取供应商回复并校验数量与交期",
              result: "5家供应商有效回复",
              tab: "responses",
            },
            {
              name: "在途／在建资源查询",
              task: "识别在途订单和在建项目中可协调资源",
              exec: "已评估原项目影响和可释放时间",
              result: "3项资源可协调",
              tab: "responses",
            },
            {
              name: "应急采购寻源",
              task: "针对剩余缺口匹配本地现货和紧急供应能力",
              exec: "已完成候选供应商、交期和风险筛选",
              result: "形成2个备选采购来源",
              tab: "responses",
            },
          ],
        },
        response: {
          goal: "汇总响应并形成可比较的资源结果",
          judgement: "合并多渠道响应，按需求量、到货时间和风险形成有效匹配。",
          result: "20条物资已满足，3条进入方案差异处理。",
          atoms: [
            {
              name: "多渠道响应汇总",
              task: "汇总四渠道单位和供应商响应",
              exec: "已合并重复回复并标准化单位、数量和交期",
              result: "形成18条有效响应",
              tab: "responses",
            },
            {
              name: "需求资源匹配",
              task: "逐项匹配需求物资与有效来源",
              exec: "已按数量覆盖和到货要求完成匹配",
              result: "20条需求完整满足",
              tab: "materials",
            },
            {
              name: "剩余缺口计算",
              task: "计算未满足数量和时间缺口",
              exec: "已识别无法被现有响应覆盖的差额",
              result: "3条进入方案优化",
              tab: "materials",
            },
          ],
        },
        compare: {
          goal: "逐项比较原系统方案与AI组合方案",
          judgement:
            "一致项自动纳入，只将来源、数量、缺口和交期不同的物资交给用户确认。",
          result: "3项存在差异，AI建议补足2项缺口并优化1项交期。",
          atoms: [
            {
              name: "原系统方案读取",
              task: "读取原系统生成的物资来源组合",
              exec: "已提取来源、数量、缺口和交期",
              result: "形成23项方案基线",
              tab: "plans",
            },
            {
              name: "AI方案生成",
              task: "基于四渠道有效响应生成AI组合方案",
              exec: "已综合交期、数量、协调对象和风险",
              result: "形成23项AI建议方案",
              tab: "plans",
            },
            {
              name: "方案差异比对",
              task: "逐物资对齐原系统与AI方案",
              exec: "已比较来源组合、数量、缺口和最晚到达时间",
              result: "识别3项关键差异",
              tab: "plans",
            },
            {
              name: "方案风险评估",
              task: "评估差异项对保供、交期和执行可行性的影响",
              exec: "已生成逐项决策摘要",
              result: "2项建议采用AI，1项建议人工确认",
              tab: "plans",
            },
          ],
        },
        confirm: {
          goal: "由用户逐项确认最终来源组合",
          judgement: "AI建议默认预选，用户可保留原系统方案或手动调整。",
          result: "当前仍有3项差异待人工确认。",
          atoms: [
            {
              name: "差异事项确认",
              task: "呈现差异物资和AI建议供用户逐项选择",
              exec: "已将差异项置顶并默认预选AI建议",
              result: "3项待用户确认",
              tab: "plans",
            },
            {
              name: "方案手动调整",
              task: "允许用户修改来源组合、数量和到货时间",
              exec: "已准备行内编辑和方案校验",
              result: "支持逐项人工调整",
              tab: "plans",
            },
            {
              name: "最终方案校验",
              task: "校验用户选择后的完整性和可执行性",
              exec: "将在全部差异确认后自动执行",
              result: "待执行",
              tab: "plans",
            },
          ],
        },
        writeback: {
          goal: "将最终方案回写原业务系统",
          judgement:
            "回写前校验物资、来源、数量和到货时间，确保与用户最终选择一致。",
          result: "待方案确认后执行。",
          atoms: [
            {
              name: "最终方案生成",
              task: "汇总一致项和用户确认后的差异项",
              exec: "将在全部差异确认后生成正式方案",
              result: "待执行",
              tab: "plans",
            },
            {
              name: "原系统结果回写",
              task: "将最终方案写入原业务系统并校验回写结果",
              exec: "已准备字段映射和回写接口",
              result: "待执行",
              tab: "events",
            },
          ],
        },
        review: {
          goal: "形成任务闭环复盘与经验沉淀",
          judgement: "提炼业务结果、人工决策和可复用经验，不展示底层技术日志。",
          result: "将在任务闭环后自动生成。",
          atoms: [
            {
              name: "任务结果复盘",
              task: "汇总需求满足、响应、方案和执行结果",
              exec: "将在任务闭环后自动形成",
              result: "待执行",
              tab: "review",
            },
            {
              name: "经验规则沉淀",
              task: "提炼人工调整和有效处置经验",
              exec: "形成可审核的知识和技能优化建议",
              result: "待执行",
              tab: "review",
            },
          ],
        },
      };
      function sensingBlueprint(t) {
        return sensingOrchBlueprint[t] || sensingOrchBlueprint.demand;
      }
      function sensingAtomOutput(t) {
        return `<div class="sensing-atom-output"><div class="sensing-atom-output-grid"><div><span>本次任务</span><b>${emergencyEsc(t.task)}</b></div><div><span>执行情况</span><b>${emergencyEsc(t.exec)}</b></div><div><span>产出结果</span><b>${emergencyEsc(t.result)}</b></div></div><div class="sensing-atom-output-actions"><button data-processreview-atom-detail="${t.tab}">查看业务结果</button></div></div>`;
      }
      function sensingShowLiveToast() {
        let t = document.getElementById("sensingLiveToast");
        (t ||
          ((t = document.createElement("div")),
          (t.id = "sensingLiveToast"),
          (t.className = "sensing-live-toast"),
          (t.innerHTML =
            '<div class="sensing-live-toast-card"><div class="head"><strong>智能体发现1项新任务</strong><span>刚刚</span></div><p>主变压器订单计划发货时间已过，尚未收到供应商确认。今日简报和历史对话已自动更新。</p><button data-sensing-new-task>查看并处理</button></div>'),
          document.body.appendChild(t)),
          requestAnimationFrame(() => t.classList.add("show")),
          clearTimeout(window.__sensingToastTimer),
          (window.__sensingToastTimer = setTimeout(
            () => t.classList.remove("show"),
            9e3,
          )));
      }
      function sensingDetectNewTask(t = !1) {
        if (state.sensingSense.detected && !t) return;
        if (
          ((state.sensingSense.detected = !0),
          (state.sensingSense.total = 26),
          (state.sensingSense.categories = 6),
          (state.sensingSense.priority = 3),
          (state.sensingSense.lastScan = "刚刚"),
          !state.sensingSense.newTaskAdded)
        ) {
          ((state.sensingSense.newTaskAdded = !0),
            state.conversations.unshift({
              title: "主变压器订单发货确认",
              type: "监控预警",
              time: "刚刚",
              messages: 1,
              live: !0,
              sensingNew: !0,
            }));
          try {
            renderRecent();
          } catch (t) {}
        }
        (document.getElementById("normalBriefCard") && briefnavRerender(),
          sensingShowLiveToast(),
          showToast("持续感知发现1项新任务，今日简报已更新"));
      }
      ((processreviewOrchDetail = function (t, e) {
        const s = sensingBlueprint(e.key),
          a = processreviewAtomKey(t, e.key),
          n = state.processreviewAtomicSelection[a] || "",
          r = s.atoms.find((t) => t.name === n);
        return `<div class="processreview-orch-detail"><div class="processreview-orch-three"><div><span>本步骤目标</span><b>${emergencyEsc(s.goal)}</b></div><div><span>业务判断</span><b>${emergencyEsc(s.judgement)}</b></div><div><span>阶段结果</span><b>${emergencyEsc(s.result)}</b></div></div><div class="processreview-atom-list"><strong>原子能力执行 · 点击查看过程与产出</strong><div class="processreview-atom-grid">${s.atoms.map((t) => `<button class="processreview-atom ${n === t.name ? "active" : ""}" data-processreview-atom="${e.key}|${emergencyEsc(t.name)}"><strong>${emergencyEsc(t.name)}</strong><span>${emergencyEsc(t.result)}</span></button>`).join("")}</div>${r ? sensingAtomOutput(r) : ""}</div></div>`;
      }),
        (workbriefHorizontalProgress = function (t) {
          const e = workbriefOrchSteps(t),
            s = workbriefSelectedOrch(t),
            a = e.find((t) => t.key === s) || e[0];
          return `<div class="workbrief-orch-wrap"><div class="workbrief-orch-strip">${e.map((t, e) => `<button class="workbrief-orch-step ${t.state} ${s === t.key ? "selected" : ""}" data-workbrief-orch-step="${t.key}"><span class="workbrief-orch-node">${"done" === t.state ? "✓" : e + 1}</span><strong>${t.title}</strong><small>${"done" === t.state ? "已完成" : "current" === t.state ? "当前阶段" : "待执行"}</small></button>`).join("")}</div>${processreviewOrchDetail(t, a)}</div>`;
        }),
        (timelineHorizontalProgress = workbriefHorizontalProgress),
        (processreviewVerticalTimeline = function (t) {
          const e = workbriefOrchSteps(t);
          let s = state.processreviewVerticalOpenStep[t];
          return (
            s || (s = (e.find((t) => "current" === t.state) || e[0]).key),
            `<div class="timeline-timeline-shell"><div class="timeline-timeline-top"><div><strong>智能体执行过程</strong><span>按业务阶段展开，每个阶段保留2至4个可理解的原子能力</span></div><button class="timeline-overview-toggle secondary" data-timeline-toggle-timeline>收起全部</button></div><div class="processreview-vtimeline">${e
              .map((e) => {
                const a = sensingBlueprint(e.key),
                  n = s === e.key,
                  r = processreviewAtomKey(t, e.key),
                  v = state.processreviewAtomicSelection[r] || "",
                  i = a.atoms.find((t) => t.name === v);
                return `<article class="processreview-vstage ${e.state} ${n ? "open" : ""}"><button class="processreview-vstage-head" data-processreview-vstep="${e.key}"><span class="processreview-vicon">${"done" === e.state ? "✓" : "current" === e.state ? "●" : "○"}</span><span class="processreview-vcopy"><strong>${e.title}</strong><p>${emergencyEsc(a.result)}</p></span><time class="processreview-vtime">${"done" === e.state ? "已完成" : "current" === e.state ? "当前执行" : "待执行"}</time></button><div class="processreview-vbody"><div class="processreview-orch-three"><div><span>目标</span><b>${emergencyEsc(a.goal)}</b></div><div><span>业务判断</span><b>${emergencyEsc(a.judgement)}</b></div><div><span>结果</span><b>${emergencyEsc(a.result)}</b></div></div><div class="processreview-atom-list"><strong>原子能力</strong><div class="processreview-atom-grid">${a.atoms.map((t) => `<button class="processreview-atom ${v === t.name ? "active" : ""}" data-processreview-atom="${e.key}|${emergencyEsc(t.name)}"><strong>${emergencyEsc(t.name)}</strong><span>${emergencyEsc(t.result)}</span></button>`).join("")}</div>${i ? sensingAtomOutput(i) : ""}</div></div></article>`;
              })
              .join(
                "",
              )}</div><div class="timeline-timeline-foot"><button class="timeline-overview-toggle secondary" data-timeline-open-events>查看完整事件记录</button></div></div>`
          );
        }),
        (timelineVerticalTimeline = processreviewVerticalTimeline),
        document.addEventListener(
          "click",
          (t) => {
            if (t.target.closest("[data-sensing-scan-now]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                void sensingDetectNewTask(!0)
              );
            if (t.target.closest("[data-sensing-new-task]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                document
                  .getElementById("sensingLiveToast")
                  ?.classList.remove("show"),
                void briefnavOpenLevel("newtask", "newtask")
              );
            const e = t.target.closest("[data-sensing-all-progress]");
            if (e)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.sensingAllProgress = e.dataset.sensingAllProgress),
                void briefnavOpenLevel("allprogress", "allprogress")
              );
            const s = t.target.closest("[data-sensing-risk]");
            if (s)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.sensingRisk = s.dataset.sensingRisk),
                void briefnavOpenLevel("risk", "risk")
              );
            const a = t.target.closest("[data-sensing-all-business]");
            if (a)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.briefnavHome.business = a.dataset.sensingAllBusiness),
                (state.briefnavHome.priority = "focus"),
                void briefnavOpenLevel("business", "allprogress")
              );
            if (t.target.closest("[data-sensing-back-summary]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                void briefnavOpenLevel("summary", "summary")
              );
            if (t.target.closest("[data-sensing-remind-new]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                void showToast("已向供应商发送催办，并同步订单发起人")
              );
            if (t.target.closest("[data-sensing-enter-new-task]")) {
              (t.preventDefault(), t.stopImmediatePropagation(), briefnavClose());
              const e = document.getElementById("chatInput");
              return void (
                e &&
                ((e.value = "分析并推进：主变压器订单发货确认"), sendChat())
              );
            }
          },
          !0,
        ),
        clearTimeout(window.__sensingSenseTimer),
        (window.__sensingSenseTimer = setTimeout(
          () => sensingDetectNewTask(!1),
          15e3,
        )));

/* Source runtime block 20 */
function briefdrillCounts() {
        return {
          focus: state.sensingSense && state.sensingSense.detected ? 6 : 5,
          general: 20,
          follow: 3,
        };
      }
      function briefdrillMetric(t, e, s, o = !1) {
        return `<button class="${o ? "urgent " : ""}${state.briefnavHome.root === t && "closed" !== state.briefnavHome.level ? "active" : ""}" data-briefdrill-root="${t}"><b>${s}</b>${e}</button>`;
      }
      function briefdrillBriefMarkup(t = !1, e) {
        const s = "closed" !== state.briefnavHome.level,
          o = `normal-brief-card livebrief-brief-card briefnav-brief briefdrill-brief ${t ? "livebrief-intro" : "livebrief-docked"} ${(void 0 === e ? !t && !s : !!e) ? "collapsed" : ""} ${s ? "livebrief-filter-open" : ""}`,
          a = briefdrillCounts(),
          r = t
            ? "AI已完成今日事项研判：重点关注迎峰度夏等保障任务、临近或已经超期事项，以及可能影响后续里程碑的异常。"
            : "AI已完成重点事项，点击标题查看总体研判，点击右侧分类逐层下钻。",
          n =
            state.sensingSense && state.sensingSense.detected
              ? "刚刚发现1项新任务"
              : "智能体持续感知中";
        return `<section class="${o}" id="normalBriefCard"><div class="normal-brief-head"><div class="normal-brief-bot" data-briefnav-title>${icons("i-bot")}</div><div class="normal-brief-title" data-briefnav-title><strong>今日简报</strong><span>${r}</span></div><button type="button" class="livebrief-brief-status briefdrill-sense-btn" id="livebriefBriefStatus" data-briefdrill-sense title="查看持续感知状态"><i></i><span>${n}</span></button><div class="normal-brief-mini">${briefdrillMetric("focus", "重点事项", a.focus, !0)}${briefdrillMetric("general", "一般事项", a.general)}${briefdrillMetric("follow", "我的关注", a.follow)}</div><button class="normal-brief-chevron" data-briefnav-title aria-label="展开或收起今日简报">${icons("i-down")}</button></div><div class="normal-brief-body">${briefnavPanelMarkup()}</div></section>`;
      }
      function briefdrillSummaryMarkup() {
        const t = briefdrillCounts(),
          e = state.sensingSense && state.sensingSense.detected;
        return `${briefnavHead()}<section class="briefdrill-analysis"><div class="briefdrill-analysis-kicker"><i></i>AI综合研判</div><h3>今日总体概要与重点分析</h3><p>今日共汇集<strong>5类、${e ? 26 : 25}项</strong>业务事项，其中<strong class="risk">${t.focus}项列为重点事项</strong>。重点主要集中在迎峰度夏、重点工程和关键物资保障，以及已经超期、临近超期和里程碑可能冲突的事项。</p><p><strong>迎峰度夏重点项目采购批次已经流标</strong>，距要求到货时间仅剩<strong class="time">18天</strong>。按照常规采购周期测算，重新组织采购后预计晚于要求到货时间5天，并继续压缩合同签订、生产交付和现场安装时间。建议今日内确认加急采购方式，由智能体同步发起人和采购负责人；今日未完成确认时，明日上午自动升级督办。</p><p><strong>主变压器订单已超过计划发货时间3天</strong>，目前仍未获得供应商有效反馈，下游到货验收距计划节点仅剩2天，继续延迟可能影响项目投运安排。该事项已经完成两次普通催办，建议立即升级督办，并同步订单发起人和项目负责人。${e ? " 刚刚新增的发货确认预警已自动纳入重点事项，简报数量和历史对话同步更新。" : ""}</p><div class="briefdrill-analysis-foot"><span>分析已综合保障属性、时间窗口、上下游影响和督办条件</span><b>点击下方三类继续查看</b></div></section><div class="briefdrill-root-grid"><button class="briefdrill-root-card focus" data-briefdrill-root="focus"><b>${t.focus}</b><strong>重点事项</strong><span>保障相关、时间紧迫、风险异常和应急响应事项</span></button><button class="briefdrill-root-card" data-briefdrill-root="general"><b>${t.general}</b><strong>一般事项</strong><span>按业务节奏正常推进，持续监测关键状态变化</span></button><button class="briefdrill-root-card" data-briefdrill-root="follow"><b>${t.follow}</b><strong>我的关注</strong><span>用户主动关注、定时跟踪和智能体自动执行事项</span></button></div>`;
      }
      function briefdrillBusinessCounts(t) {
        return "focus" === t
          ? {
              procurement: 1,
              contract: 1,
              arrival: 1,
              collaboration: 1,
              quality: 1,
            }
          : {
              procurement: 7,
              contract: 5,
              arrival: 4,
              collaboration: 3,
              quality: 1,
            };
      }
      function briefdrillPriorityMarkup() {
        const t = "general" === state.briefnavHome.priority ? "general" : "focus",
          e = "focus" === t ? "重点事项" : "一般事项",
          s = briefdrillBusinessCounts(t),
          o =
            Object.values(s).reduce((t, e) => t + e, 0) +
            ("focus" === t && state.sensingSense && state.sensingSense.detected
              ? 1
              : 0),
          a =
            "focus" === t
              ? "AI已按保障属性、时间窗口、风险影响和督办条件完成归并。先选择业务场景，再进入单个任务查看要做什么、AI做了什么和下一步动作。"
              : "当前事项未触发重点规则，仍按业务类型归并，并持续监测超期、外部响应和里程碑变化。";
        return `${briefnavHead([{ label: e, to: "priority" }])}<div class="briefdrill-category-intro"><strong>${e} · ${o}项</strong><p>${a}</p></div><div class="briefdrill-business-grid">${Object.entries(
          s,
        )
          .map(([e, s]) => {
            const o = workbriefBusinessGroups[e];
            return `<button class="briefdrill-business-card" data-briefnav-business="${e}"><b>${s}</b><strong>${briefnavEsc(o.name)}</strong><span>${"focus" === t ? briefnavEsc(o.risk) : "点击查看该场景下的具体任务"}</span></button>`;
          })
          .join(
            "",
          )}</div><div class="briefdrill-back-note">每个业务场景均可继续下钻到单个任务。</div>`;
      }
      function briefdrillFollowMarkup() {
        const t = { summer: "P1", batch: "P2", agent: "C1" };
        return `${briefnavHead([{ label: "我的关注", to: "follow" }])}<div class="briefdrill-category-intro"><strong>我的关注 · 3项</strong><p>这里展示用户主动钉住的项目、订单和智能体持续执行任务。点击后直接进入对应单个任务。</p></div><div class="briefnav-follow-list">${workbriefFollowItems.map((e) => `<button class="briefdrill-follow-task" data-briefdrill-follow-task="${t[e.id]}"><div class="top"><strong>${briefnavEsc(e.title)}</strong><em>${briefnavEsc(e.tag)}</em></div><p>${briefnavEsc(e.desc)}</p><small>查看单个任务 ›</small></button>`).join("")}</div>`;
      }
      state.briefnavHome = state.briefnavHome || {
        level: "closed",
        root: "summary",
        priority: "focus",
        progress: "pending",
        business: "procurement",
        task: "",
        follow: "",
      };
      const briefdrillPanelBase = briefnavPanelMarkup;
      ((briefnavPanelMarkup = function () {
        switch (state.briefnavHome.level) {
          case "summary":
            return `<div class="briefnav-panel">${briefdrillSummaryMarkup()}</div>`;
          case "priority":
            return `<div class="briefnav-panel">${briefdrillPriorityMarkup()}</div>`;
          case "follow":
            return `<div class="briefnav-panel">${briefdrillFollowMarkup()}</div>`;
          default:
            return briefdrillPanelBase();
        }
      }),
        (briefnavBriefMarkup = briefdrillBriefMarkup),
        (workbriefBriefMarkup = briefdrillBriefMarkup),
        (briefshellBriefMarkup = briefdrillBriefMarkup),
        (livebriefBriefMarkup = briefdrillBriefMarkup),
        (notificationsNormalBriefMarkup = function () {
          return briefdrillBriefMarkup(!1, !0);
        }));
      const briefdrillDockBase = livebriefDockBrief;
      ((livebriefDockBrief = function (t = !1) {
        (briefdrillDockBase(t),
          setTimeout(() => {
            const t = document.getElementById("normalBriefCard");
            if (!t) return;
            const e = t.querySelector(".normal-brief-title span");
            e &&
              (e.textContent =
                "AI已完成重点事项，点击标题查看总体研判，点击右侧分类逐层下钻。");
          }, 100));
      }),
        document.addEventListener(
          "click",
          (t) => {
            const e = t.target.closest("[data-briefdrill-root]");
            if (e) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const s = e.dataset.briefdrillRoot;
              return void ("follow" === s
                ? briefnavOpenLevel("follow", "follow")
                : ((state.briefnavHome.priority = s), briefnavOpenLevel("priority", s)));
            }
            const s = t.target.closest("[data-briefdrill-follow-task]");
            if (s) {
              (t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.briefnavHome.task = s.dataset.briefdrillFollowTask));
              const e = workbriefFindTask(state.briefnavHome.task);
              return (
                e &&
                  ((state.briefnavHome.business =
                    Object.keys(workbriefBusinessGroups).find((t) =>
                      workbriefBusinessGroups[t].tasks.some((t) => t.id === e.id),
                    ) || "procurement"),
                  (state.briefnavHome.priority =
                    "重点" === e.status ? "focus" : "general")),
                void briefnavOpenLevel("task", "follow")
              );
            }
            if (t.target.closest("[data-briefdrill-sense]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                void (state.sensingSense && state.sensingSense.detected
                  ? briefnavOpenLevel("newtask", "newtask")
                  : sensingDetectNewTask(!0))
              );
          },
          !0,
        ));

/* Source runtime block 21 */
function processmodalStageStateLabel(t) {
        return "done" === t.state
          ? "已完成"
          : "current" === t.state
            ? "当前执行"
            : "待执行";
      }
      function processmodalStageTime(t, e) {
        if ("future" === t.state) return "待启动";
        return (
          ["09:02", "09:04", "09:08", "09:11", "09:14", "—", "—"][e] || "—"
        );
      }
      function processmodalBlueprint(t) {
        return "function" == typeof sensingBlueprint
          ? sensingBlueprint(t)
          : sensingOrchBlueprint[t] || sensingOrchBlueprint.demand;
      }
      function processmodalStageStrip(t) {
        return `<div class="processmodal-stage-flow">${workbriefOrchSteps(t)
          .map(
            (t, e) =>
              `<button class="processmodal-stage-btn ${t.state}" data-processmodal-stage="${t.key}" title="点击查看${emergencyEsc(t.title)}执行过程"><span class="processmodal-stage-dot">${"done" === t.state ? "✓" : e + 1}</span><strong>${emergencyEsc(t.title)}</strong><small>${processmodalStageStateLabel(t)}</small></button>`,
          )
          .join(
            "",
          )}</div><div class="processmodal-process-hint"><span><strong>执行过程按需展开</strong>　点击任一阶段，查看该阶段调用的业务能力和产出结果。</span><button data-processmodal-all-process>查看全部过程</button></div>`;
      }
      function processmodalOverviewCard(t) {
        const e = state.emergencyThread,
          s = emergencyMeta(e),
          a = collaborationDecisionCounts();
        return `<article class="timeline-task-overview"><div class="timeline-overview-head"><div><div class="eyebrow">智能体编排过程</div><h3>${emergencyEsc(s.title)}</h3><p>${emergencyEsc(t.text)}</p></div><span class="timeline-overview-status">${emergencyEsc(s.status)}</span></div><div class="timeline-overview-body">${processmodalStageStrip(e)}<div class="timeline-overview-metrics"><button data-emergency-open-canvas="materials"><b>23</b><span>需求物资</span></button><button data-emergency-open-canvas="responses"><b>18</b><span>有效响应</span></button><button data-emergency-open-canvas="plans"><b>2</b><span>补足缺口</span></button><button class="attention" data-emergency-open-canvas="plans"><b>${a.pending}</b><span>待确认差异</span></button></div><div class="processmodal-overview-actions"><span>横向只看阶段；点击阶段后再查看具体执行过程。</span><div><button data-processmodal-all-process>查看全部过程</button><button class="primary" data-emergency-open-canvas="plans">${a.pending ? "处理方案差异" : "查看最终方案"}</button></div></div></div></article>`;
      }
      function processmodalEnsureOverlay() {
        let t = document.getElementById("processmodalProcessOverlay");
        return (
          t ||
          ((t = document.createElement("div")),
          (t.id = "processmodalProcessOverlay"),
          (t.className = "processmodal-process-overlay"),
          (t.innerHTML =
            '<section class="processmodal-process-modal" role="dialog" aria-modal="true" aria-label="智能体执行过程"><div id="processmodalProcessContent"></div></section>'),
          document.body.appendChild(t),
          t)
        );
      }
      function processmodalAbilityMarkup(t, e, s, a) {
        return `<article class="processmodal-ability-item ${a ? "open" : ""}"><button class="processmodal-ability-head" data-processmodal-atom="${t}|${s}"><span class="processmodal-ability-icon">✓</span><span class="processmodal-ability-copy"><strong>${emergencyEsc(e.name)}</strong><span>${emergencyEsc(e.result)}</span></span><span class="processmodal-ability-state">${/待执行/.test(e.result) ? "待执行" : "已完成"}</span><span class="processmodal-ability-arrow">›</span></button><div class="processmodal-ability-detail"><div class="processmodal-ability-detail-grid"><div><span>本次任务</span><b>${emergencyEsc(e.task)}</b></div><div><span>执行摘要</span><b>${emergencyEsc(e.exec)}</b></div><div><span>产出结果</span><b>${emergencyEsc(e.result)}</b></div></div><div class="processmodal-ability-detail-actions"><button data-processmodal-open-result="${e.tab}">查看业务结果</button></div></div></article>`;
      }
      function processmodalStagePanel(t) {
        const e = workbriefOrchSteps(state.emergencyThread),
          s = e.find((e) => e.key === t) || e[0],
          a = processmodalBlueprint(s.key),
          v = state.processmodalProcess.atom || "";
        return `<div class="processmodal-process-head"><div><div class="eyebrow">${processmodalStageStateLabel(s)} · ${emergencyEsc(s.title)}</div><h3>${emergencyEsc(s.title)}执行过程</h3><p>查看这一阶段调用了哪些业务能力，以及每项能力实际产出了什么结果。</p></div><div class="processmodal-process-head-actions"><button data-processmodal-all-process>查看全部过程</button><button class="close" data-processmodal-close>×</button></div></div><div class="processmodal-process-body"><div class="processmodal-stage-summary"><div><span>阶段目标</span><b>${emergencyEsc(a.goal)}</b></div><div><span>业务判断</span><b>${emergencyEsc(a.judgement)}</b></div></div><div class="processmodal-stage-result"><strong>阶段结果</strong><p>${emergencyEsc(a.result)}</p></div><div class="processmodal-ability-title"><strong>执行记录</strong><span>一次只展开一项</span></div><div class="processmodal-ability-list">${a.atoms.map((t, e) => processmodalAbilityMarkup(s.key, t, e, v === `${s.key}|${e}`)).join("")}</div></div>`;
      }
      function processmodalAllPanel() {
        const t = workbriefOrchSteps(state.emergencyThread);
        let e =
          state.processmodalProcess.allStage ||
          (t.find((t) => "current" === t.state) || t[0]).key;
        return `<div class="processmodal-process-head"><div><div class="eyebrow">任务执行记录</div><h3>查看全部过程</h3><p>按阶段查看执行结果；点击阶段展开，再点击具体能力查看单次执行详情。</p></div><div class="processmodal-process-head-actions"><button data-processmodal-back-stage>返回当前阶段</button><button class="close" data-processmodal-close>×</button></div></div><div class="processmodal-process-body"><div class="processmodal-all-list">${t
          .map((t, s) => {
            const a = processmodalBlueprint(t.key),
              v = e === t.key,
              n = state.processmodalProcess.atom || "";
            return `<article class="processmodal-all-stage ${t.state} ${v ? "open" : ""}"><button class="processmodal-all-stage-head" data-processmodal-all-stage="${t.key}"><span class="dot">${"done" === t.state ? "✓" : "current" === t.state ? "●" : s + 1}</span><span><strong>${emergencyEsc(t.title)}</strong><p>${emergencyEsc(a.result)}</p></span><time>${processmodalStageTime(t, s)}</time><i>›</i></button><div class="processmodal-all-stage-body"><div class="processmodal-stage-result"><strong>阶段执行摘要</strong><p>${emergencyEsc(a.judgement)} ${emergencyEsc(a.result)}</p></div><div class="processmodal-ability-list">${a.atoms.map((e, s) => processmodalAbilityMarkup(t.key, e, s, n === `${t.key}|${s}`)).join("")}</div></div></article>`;
          })
          .join("")}</div></div>`;
      }
      function processmodalRenderOverlay() {
        const t = processmodalEnsureOverlay(),
          e = document.getElementById("processmodalProcessContent");
        e &&
          ((e.innerHTML =
            "all" === state.processmodalProcess.mode
              ? processmodalAllPanel()
              : processmodalStagePanel(
                  state.processmodalProcess.stage || workbriefSelectedOrch(state.emergencyThread),
                )),
          t.classList.toggle("open", !!state.processmodalProcess.open));
      }
      function processmodalOpenStage(t) {
        ((state.processmodalProcess.open = !0),
          (state.processmodalProcess.mode = "stage"),
          (state.processmodalProcess.stage = t),
          (state.processmodalProcess.atom = ""),
          (state.processmodalProcess.allStage = t),
          processmodalRenderOverlay());
      }
      function processmodalOpenAll() {
        ((state.processmodalProcess.open = !0),
          (state.processmodalProcess.mode = "all"),
          (state.processmodalProcess.allStage =
            state.processmodalProcess.stage || workbriefSelectedOrch(state.emergencyThread)),
          (state.processmodalProcess.atom = ""),
          processmodalRenderOverlay());
      }
      function processmodalClose() {
        ((state.processmodalProcess.open = !1),
          (state.processmodalProcess.atom = ""),
          processmodalRenderOverlay());
      }
      ((state.processmodalProcess = state.processmodalProcess || {
        open: !1,
        mode: "stage",
        stage: "",
        atom: "",
        allStage: "",
      }),
        (workbriefHorizontalProgress = function (t) {
          return processmodalStageStrip(t);
        }),
        (timelineHorizontalProgress = workbriefHorizontalProgress),
        (timelineTaskOverviewCard = processmodalOverviewCard),
        document.addEventListener(
          "click",
          (t) => {
            const e = t.target.closest("[data-processmodal-stage]");
            if (e)
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                void processmodalOpenStage(e.dataset.processmodalStage)
              );
            if (t.target.closest("[data-processmodal-all-process]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                void processmodalOpenAll()
              );
            if (t.target.closest("[data-processmodal-close]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                void processmodalClose()
              );
            if ("processmodalProcessOverlay" === t.target.id) return void processmodalClose();
            const s = t.target.closest("[data-processmodal-all-stage]");
            if (s) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const e = s.dataset.processmodalAllStage;
              return (
                (state.processmodalProcess.allStage =
                  state.processmodalProcess.allStage === e ? "" : e),
                (state.processmodalProcess.atom = ""),
                void processmodalRenderOverlay()
              );
            }
            const a = t.target.closest("[data-processmodal-atom]");
            if (a) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const e = a.dataset.processmodalAtom;
              return (
                (state.processmodalProcess.atom = state.processmodalProcess.atom === e ? "" : e),
                void processmodalRenderOverlay()
              );
            }
            const v = t.target.closest("[data-processmodal-open-result]");
            return v
              ? (t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.emergencyCanvasTab = v.dataset.processmodalOpenResult || "responses"),
                (state.collaborationTab = state.emergencyCanvasTab),
                (state.emergencyCanvasOpen = !0),
                processmodalClose(),
                void emergencyRender())
              : t.target.closest("[data-processmodal-back-stage]")
                ? (t.preventDefault(),
                  t.stopImmediatePropagation(),
                  (state.processmodalProcess.mode = "stage"),
                  (state.processmodalProcess.stage =
                    state.processmodalProcess.allStage ||
                    workbriefSelectedOrch(state.emergencyThread)),
                  (state.processmodalProcess.atom = ""),
                  void processmodalRenderOverlay())
                : void 0;
          },
          !0,
        ),
        setTimeout(() => {
          ((document.title = "供应链智慧工作台"),
            "emergency" === state.view && emergencyRender());
        }, 120));

/* Source runtime block 22 */
function processinlineStateLabel(t) {
        return "done" === t.state
          ? "已完成"
          : "current" === t.state
            ? "正在执行"
            : "待执行";
      }
      function processinlineThoughtTitle(t) {
        return (
          {
            demand: "需求研判已完成",
            source: "寻源研判已完成",
            response: "响应分析已完成",
            compare: "方案分析已完成",
            confirm: "确认事项已整理",
            writeback: "回写准备状态",
            review: "复盘准备状态",
          }[t] || "业务研判已完成"
        );
      }
      function processinlineThoughtText(t, s) {
        return (
          {
            demand:
              "智能体已完成需求范围、物料编码、数量和到货时间校验，当前需求清单可以直接进入寻源。",
            source:
              "智能体判断内部可调资源应优先使用，同时并行调用协议供应、在途在建和应急采购能力补足缺口。",
            response:
              "智能体已对四渠道响应进行去重、数量覆盖和交期冲突校验，并形成逐物资匹配结果。",
            compare:
              "智能体已将原系统方案与AI组合方案逐物资对齐，只保留来源、数量、缺口或交期不同的事项供用户确认。",
            confirm:
              "智能体已将差异物资置顶并预选AI建议，等待用户逐项确认或手动调整。",
            writeback:
              "智能体将在最终方案确认后执行字段校验、结果回写和回写状态核验。",
            review:
              "智能体将在任务闭环后形成结果复盘、人工决策记录和经验沉淀建议。",
          }[t] || s.judgement
        );
      }
      function processinlineAtomStatus(t, s) {
        return "future" === s || /待执行/.test(t.result)
          ? "future"
          : "current" === s
            ? "running"
            : "done";
      }
      function processinlineAtomRow(t, s, e, a) {
        const n = t + "|" + e,
          o = state.processinlineProcess.atom === n,
          v = processinlineAtomStatus(s, a),
          r = "done" === v ? "✓" : "running" === v ? "●" : "○";
        return `<article class="processinline-kimi-row ${v} ${o ? "open" : ""}" data-processinline-row="${emergencyEsc(n)}"><button class="processinline-kimi-toggle" data-processinline-atom="${emergencyEsc(n)}"><span class="processinline-kimi-icon">${r}</span><span class="processinline-kimi-copy"><strong>${emergencyEsc(s.name)}</strong><span>${emergencyEsc(s.result)}</span></span><span class="processinline-kimi-state">${"done" === v ? "已完成" : "running" === v ? "执行中" : "待执行"}</span><span class="processinline-kimi-arrow">›</span></button><div class="processinline-kimi-detail"><p><b>本次任务：</b>${emergencyEsc(s.task)}</p><p><b>执行情况：</b>${emergencyEsc(s.exec)}</p><p><b>产出结果：</b>${emergencyEsc(s.result)}</p><div class="processinline-result-links"><button data-processinline-open-result="${emergencyEsc(s.tab)}">查看业务结果</button></div></div></article>`;
      }
      function processinlineThoughtRow(t, s, e) {
        const a = t + "|thought",
          n = "future" === e ? "future" : "current" === e ? "running" : "done";
        return `<article class="processinline-kimi-row analysis ${n} ${state.processinlineProcess.atom === a ? "open" : ""}"><button class="processinline-kimi-toggle" data-processinline-atom="${emergencyEsc(a)}"><span class="processinline-kimi-icon">${"done" === n ? "✓" : "running" === n ? "●" : "○"}</span><span class="processinline-kimi-copy"><strong>${emergencyEsc(processinlineThoughtTitle(t))}</strong><span>${emergencyEsc(s.judgement)}</span></span><span class="processinline-kimi-state">${"done" === n ? "已完成" : "running" === n ? "分析中" : "待执行"}</span><span class="processinline-kimi-arrow">›</span></button><div class="processinline-kimi-detail"><p>${emergencyEsc(processinlineThoughtText(t, s))}</p><p><b>阶段结论：</b>${emergencyEsc(s.result)}</p></div></article>`;
      }
      function processinlineRows(t, s) {
        const e = processmodalBlueprint(t);
        return `${processinlineThoughtRow(t, e, s)}${e.atoms.map((e, a) => processinlineAtomRow(t, e, a, s)).join("")}`;
      }
      function processinlineStagePanel(t) {
        const s = workbriefOrchSteps(state.emergencyThread),
          e = s.find((s) => s.key === t) || s[0],
          a = processmodalBlueprint(e.key);
        return `<section class="processinline-inline-process" id="processinlineInlineProcess"><div class="processinline-inline-head"><div class="processinline-inline-title"><span class="bulb">♧</span><div><strong>${emergencyEsc(e.title)} · 执行过程</strong><p>${emergencyEsc(a.result)}　点击任一记录可展开查看任务、执行情况和产出结果。</p></div></div><button data-processinline-collapse title="收起">⌃</button></div><div class="processinline-stage-narrative"><b>${emergencyEsc(e.title)}</b>阶段按照业务能力顺序执行，当前展示的是可解释的业务过程和结果，不展开底层技术日志。</div><div class="processinline-kimi-list">${processinlineRows(e.key, e.state)}</div></section>`;
      }
      function processinlineAllPanel() {
        return `<section class="processinline-inline-process" id="processinlineInlineProcess"><div class="processinline-inline-head"><div class="processinline-inline-title"><span class="bulb">♧</span><div><strong>智能体完整执行过程</strong><p>按业务阶段排列。点击阶段展开，再点击单个原子能力查看具体过程与结果。</p></div></div><button data-processinline-collapse title="收起">⌃</button></div>${workbriefOrchSteps(
          state.emergencyThread,
        )
          .map((t, s) => {
            const e = processmodalBlueprint(t.key),
              a = state.processinlineProcess.allStage === t.key;
            return `<article class="processinline-all-stage ${t.state} ${a ? "open" : ""}"><button class="processinline-all-stage-head" data-processinline-all-stage="${emergencyEsc(t.key)}"><span class="stage-icon">${"done" === t.state ? "✓" : "current" === t.state ? "●" : s + 1}</span><span><strong>${emergencyEsc(t.title)}</strong><span>${emergencyEsc(e.result)}</span></span><em>${processinlineStateLabel(t)}</em><i>›</i></button><div class="processinline-all-stage-body"><div class="processinline-kimi-list">${processinlineRows(t.key, t.state)}</div></div></article>`;
          })
          .join("")}</section>`;
      }
      function processinlineInlineMarkup() {
        return state.processinlineProcess.all
          ? processinlineAllPanel()
          : state.processinlineProcess.stage
            ? processinlineStagePanel(state.processinlineProcess.stage)
            : "";
      }
      function processinlineStageStrip(t) {
        return `<div class="processinline-stage-wrap"><div class="processinline-stage-flow">${workbriefOrchSteps(
          t,
        )
          .map(
            (t, s) =>
              `<button class="processinline-stage-btn ${t.state} ${state.processinlineProcess.stage !== t.key || state.processinlineProcess.all ? "" : "selected"}" data-processinline-stage="${emergencyEsc(t.key)}" title="点击展开${emergencyEsc(t.title)}执行过程"><span class="processinline-stage-dot">${"done" === t.state ? "✓" : s + 1}</span><strong>${emergencyEsc(t.title)}</strong><small>${processinlineStateLabel(t)}</small></button>`,
          )
          .join(
            "",
          )}</div><div class="processinline-process-toolbar"><span><strong>执行过程</strong>　点击任一阶段，在当前对话中展开该阶段的原子能力和业务结果。</span><button data-processinline-all>${state.processinlineProcess.all ? "收起全部过程" : "展开全部过程"}</button></div>${processinlineInlineMarkup()}</div>`;
      }
      function processinlineOverviewCard(t) {
        const s = state.emergencyThread,
          e = emergencyMeta(s),
          a = collaborationDecisionCounts();
        return `<article class="timeline-task-overview"><div class="timeline-overview-head"><div><div class="eyebrow">智能体编排过程</div><h3>${emergencyEsc(e.title)}</h3><p>${emergencyEsc(t.text)}</p></div><span class="timeline-overview-status">${emergencyEsc(e.status)}</span></div><div class="timeline-overview-body">${processinlineStageStrip(s)}<div class="timeline-overview-metrics"><button data-emergency-open-canvas="materials"><b>23</b><span>需求物资</span></button><button data-emergency-open-canvas="responses"><b>18</b><span>有效响应</span></button><button data-emergency-open-canvas="plans"><b>2</b><span>补足缺口</span></button><button class="attention" data-emergency-open-canvas="plans"><b>${a.pending}</b><span>待确认差异</span></button></div><div class="processinline-overview-actions"><span>横向看阶段；点击阶段后在对话内查看可展开的执行记录。</span><div><button data-processinline-all>${state.processinlineProcess.all ? "收起全部过程" : "展开全部过程"}</button><button class="primary" data-emergency-open-canvas="plans">${a.pending ? "处理方案差异" : "查看最终方案"}</button></div></div></div></article>`;
      }
      function processinlineRerender(t) {
        ("emergency" === state.view && emergencyRender(),
          setTimeout(() => {
            const s = document.querySelector(t || "#processinlineInlineProcess");
            if (s) {
              const t = document.querySelector(".emergency-thread-body");
              t
                ? t.scrollTo({
                    top: Math.max(0, s.offsetTop - 90),
                    behavior: "smooth",
                  })
                : s.scrollIntoView({ behavior: "smooth", block: "center" });
            }
          }, 40));
      }
      ((state.processinlineProcess = state.processinlineProcess || {
        stage: "",
        atom: "",
        all: !1,
        allStage: "",
      }),
        (workbriefHorizontalProgress = function (t) {
          return processinlineStageStrip(t);
        }),
        (timelineHorizontalProgress = workbriefHorizontalProgress),
        (timelineTaskOverviewCard = processinlineOverviewCard),
        document.addEventListener(
          "click",
          (t) => {
            const s = t.target.closest("[data-processinline-stage]");
            if (s) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const e = s.dataset.processinlineStage;
              return (
                state.processinlineProcess.stage !== e || state.processinlineProcess.all
                  ? ((state.processinlineProcess.all = !1),
                    (state.processinlineProcess.stage = e),
                    (state.processinlineProcess.atom = e + "|thought"))
                  : ((state.processinlineProcess.stage = ""),
                    (state.processinlineProcess.atom = "")),
                void processinlineRerender()
              );
            }
            if (t.target.closest("[data-processinline-all]")) {
              if (
                (t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.processinlineProcess.all = !state.processinlineProcess.all),
                (state.processinlineProcess.atom = ""),
                state.processinlineProcess.all)
              ) {
                const t = workbriefOrchSteps(state.emergencyThread);
                state.processinlineProcess.allStage = (
                  t.find((t) => "current" === t.state) || t[0]
                ).key;
              } else state.processinlineProcess.allStage = "";
              return void processinlineRerender();
            }
            if (t.target.closest("[data-processinline-collapse]"))
              return (
                t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.processinlineProcess.stage = ""),
                (state.processinlineProcess.all = !1),
                (state.processinlineProcess.atom = ""),
                (state.processinlineProcess.allStage = ""),
                void processinlineRerender(".processinline-process-toolbar")
              );
            const e = t.target.closest("[data-processinline-all-stage]");
            if (e) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const s = e.dataset.processinlineAllStage;
              return (
                (state.processinlineProcess.allStage =
                  state.processinlineProcess.allStage === s ? "" : s),
                (state.processinlineProcess.atom = ""),
                void processinlineRerender('[data-processinline-all-stage="' + s + '"]')
              );
            }
            const a = t.target.closest("[data-processinline-atom]");
            if (a) {
              (t.preventDefault(), t.stopImmediatePropagation());
              const s = a.dataset.processinlineAtom;
              return (
                (state.processinlineProcess.atom = state.processinlineProcess.atom === s ? "" : s),
                void processinlineRerender('[data-processinline-row="' + s.replace(/"/g, "") + '"]')
              );
            }
            const n = t.target.closest("[data-processinline-open-result]");
            return n
              ? (t.preventDefault(),
                t.stopImmediatePropagation(),
                (state.emergencyCanvasTab = n.dataset.processinlineOpenResult || "responses"),
                (state.collaborationTab = state.emergencyCanvasTab),
                (state.emergencyCanvasOpen = !0),
                void emergencyRender())
              : void 0;
          },
          !0,
        ),
        setTimeout(() => {
          (document.getElementById("processmodalProcessOverlay")?.remove(),
            (document.title = "供应链智慧工作台"),
            "emergency" === state.view && emergencyRender());
        }, 160));

/* Source runtime block 23 */
function briefstatusBriefSubtitle() {
        const t = briefdrillCounts();
        return `5类${state.sensingSense && state.sensingSense.detected ? 26 : 25}项 · ${t.focus}项重点 · ${t.follow}项关注`;
      }
      ((sensingSenseMarkup = function () {
        const t = state.sensingSense,
          s = !!t.detected;
        return `<div class="sensing-sense-bar"><div class="sensing-sense-main"><span class="sensing-sense-pulse"></span><div class="sensing-sense-copy"><strong>${s ? "发现1项新任务" : "智能体持续感知中"}</strong><span class="${s ? "briefstatus-sense-update" : ""}">${s ? "主变压器订单发货确认 · 已纳入重点事项" : "最近扫描：" + t.lastScan}</span></div></div>${s ? '<button class="hot" data-sensing-new-task>查看新增任务</button>' : "<button data-sensing-scan-now>立即扫描</button>"}</div>`;
      }),
        (sensingShowLiveToast = function () {
          document.getElementById("sensingLiveToast")?.remove();
        }),
        (sensingDetectNewTask = function (t = !1) {
          if (state.sensingSense.detected && !t) return;
          if (
            ((state.sensingSense.detected = !0),
            (state.sensingSense.total = 26),
            (state.sensingSense.categories = 6),
            (state.sensingSense.priority = 3),
            (state.sensingSense.lastScan = "刚刚"),
            !state.sensingSense.newTaskAdded)
          ) {
            ((state.sensingSense.newTaskAdded = !0),
              state.conversations.unshift({
                title: "主变压器订单发货确认",
                type: "监控预警",
                time: "刚刚",
                messages: 1,
                live: !0,
                sensingNew: !0,
              }));
            try {
              renderRecent();
            } catch (t) {}
          }
          (document.getElementById("normalBriefCard") && briefnavRerender(),
            document.getElementById("sensingLiveToast")?.remove());
        }),
        (briefdrillBriefMarkup = function (t = !1, s) {
          const e = "closed" !== state.briefnavHome.level,
            a = `normal-brief-card livebrief-brief-card briefnav-brief briefdrill-brief ${t ? "livebrief-intro" : "livebrief-docked"} ${(void 0 === s ? !t && !e : !!s) ? "collapsed" : ""} ${e ? "livebrief-filter-open" : ""}`,
            n = briefdrillCounts(),
            v =
              state.sensingSense && state.sensingSense.detected
                ? "发现1项新任务"
                : "智能体持续感知中";
          return `<section class="${a}" id="normalBriefCard"><div class="normal-brief-head"><div class="normal-brief-bot" data-briefnav-title>${icons("i-bot")}</div><div class="normal-brief-title" data-briefnav-title><strong>今日简报</strong><span>${briefstatusBriefSubtitle()}</span></div><button type="button" class="livebrief-brief-status briefdrill-sense-btn" id="livebriefBriefStatus" data-briefdrill-sense><i></i><span>${v}</span></button><div class="normal-brief-mini">${briefdrillMetric("focus", "重点事项", n.focus, !0)}${briefdrillMetric("general", "一般事项", n.general)}${briefdrillMetric("follow", "我的关注", n.follow)}</div><button class="normal-brief-chevron" data-briefnav-title aria-label="展开或收起今日简报">${icons("i-down")}</button></div><div class="normal-brief-body">${briefnavPanelMarkup()}</div></section>`;
        }),
        (briefdrillSummaryMarkup = function () {
          const t = briefdrillCounts(),
            s = state.sensingSense && state.sensingSense.detected;
          return `${briefnavHead()}<section class="briefdrill-analysis"><div class="briefdrill-analysis-kicker"><i></i>AI综合研判</div><h3>今日总体概要与重点分析</h3><p>今日共汇集<strong>5类、${s ? 26 : 25}项</strong>业务事项，其中<strong class="risk">${t.focus}项列为重点事项</strong>。重点主要集中在迎峰度夏、重点工程和关键物资保障，以及已经超期、临近超期和里程碑可能冲突的事项。</p><p><strong>迎峰度夏重点项目采购批次已经流标</strong>，距要求到货时间仅剩<strong class="time">18天</strong>。按照常规采购周期测算，重新组织采购后预计晚于要求到货时间5天，并继续压缩合同签订、生产交付和现场安装时间。建议今日内确认加急采购方式，由智能体同步发起人和采购负责人；今日未完成确认时，明日上午自动升级督办。</p><p><strong>主变压器订单已超过计划发货时间3天</strong>，目前仍未获得供应商有效反馈，下游到货验收距计划节点仅剩2天，继续延迟可能影响项目投运安排。该事项已经完成两次普通催办，建议立即升级督办，并同步订单发起人和项目负责人。${s ? " 刚刚新增的发货确认预警已纳入重点事项。" : ""}</p></section><div class="briefdrill-root-grid"><button class="briefdrill-root-card focus" data-briefdrill-root="focus"><b>${t.focus}</b><strong>重点事项</strong></button><button class="briefdrill-root-card" data-briefdrill-root="general"><b>${t.general}</b><strong>一般事项</strong></button><button class="briefdrill-root-card" data-briefdrill-root="follow"><b>${t.follow}</b><strong>我的关注</strong></button></div>`;
        }),
        (briefdrillPriorityMarkup = function () {
          const t = "general" === state.briefnavHome.priority ? "general" : "focus",
            s = "focus" === t ? "重点事项" : "一般事项",
            e = briefdrillBusinessCounts(t),
            a =
              Object.values(e).reduce((t, s) => t + s, 0) +
              ("focus" === t && state.sensingSense && state.sensingSense.detected
                ? 1
                : 0);
          return `${briefnavHead([{ label: s, to: "priority" }])}<div class="briefdrill-category-intro"><strong>${s} · ${a}项</strong></div><div class="briefdrill-business-grid">${Object.entries(
            e,
          )
            .map(([t, s]) => {
              const e = workbriefBusinessGroups[t];
              return `<button class="briefdrill-business-card" data-briefnav-business="${t}"><b>${s}</b><strong>${briefnavEsc(e.name)}</strong><span>${briefnavEsc(e.risk)}</span></button>`;
            })
            .join("")}</div>`;
        }),
        (briefdrillFollowMarkup = function () {
          const t = { summer: "P1", batch: "P2", agent: "C1" };
          return `${briefnavHead([{ label: "我的关注", to: "follow" }])}<div class="briefdrill-category-intro"><strong>我的关注 · 3项</strong></div><div class="briefnav-follow-list">${workbriefFollowItems.map((s) => `<button class="briefdrill-follow-task" data-briefdrill-follow-task="${t[s.id]}"><div class="top"><strong>${briefnavEsc(s.title)}</strong><em>${briefnavEsc(s.tag)}</em></div><p>${briefnavEsc(s.desc)}</p></button>`).join("")}</div>`;
        }),
        (briefnavBriefMarkup = briefdrillBriefMarkup),
        (workbriefBriefMarkup = briefdrillBriefMarkup),
        (briefshellBriefMarkup = briefdrillBriefMarkup),
        (livebriefBriefMarkup = briefdrillBriefMarkup),
        (notificationsNormalBriefMarkup = function () {
          return briefdrillBriefMarkup(!1, !0);
        }));
      const briefstatusDockBase = livebriefDockBrief;
      ((livebriefDockBrief = function (t = !1) {
        (briefstatusDockBase(t),
          setTimeout(() => {
            const t = document.querySelector(
              "#normalBriefCard .normal-brief-title span",
            );
            t && (t.textContent = briefstatusBriefSubtitle());
          }, 150));
      }),
        (processinlineStagePanel = function (t) {
          const s = workbriefOrchSteps(state.emergencyThread),
            e = s.find((s) => s.key === t) || s[0];
          return `<section class="processinline-inline-process" id="processinlineInlineProcess"><div class="processinline-inline-head"><div class="processinline-inline-title"><span class="bulb">♧</span><div><strong>${emergencyEsc(e.title)}</strong></div></div><span class="briefstatus-inline-status">${processinlineStateLabel(e)}</span><button data-processinline-collapse title="收起">⌃</button></div><div class="processinline-kimi-list">${processinlineRows(e.key, e.state)}</div></section>`;
        }),
        (processinlineAllPanel = function () {
          return `<section class="processinline-inline-process" id="processinlineInlineProcess"><div class="processinline-inline-head"><div class="processinline-inline-title"><span class="bulb">♧</span><div><strong>完整执行过程</strong></div></div><button data-processinline-collapse title="收起">⌃</button></div>${workbriefOrchSteps(
            state.emergencyThread,
          )
            .map((t, s) => {
              const e = processmodalBlueprint(t.key),
                a = state.processinlineProcess.allStage === t.key;
              return `<article class="processinline-all-stage ${t.state} ${a ? "open" : ""}"><button class="processinline-all-stage-head" data-processinline-all-stage="${emergencyEsc(t.key)}"><span class="stage-icon">${"done" === t.state ? "✓" : "current" === t.state ? "●" : s + 1}</span><span><strong>${emergencyEsc(t.title)}</strong><span>${emergencyEsc(e.result)}</span></span><em>${processinlineStateLabel(t)}</em><i>›</i></button><div class="processinline-all-stage-body"><div class="processinline-kimi-list">${processinlineRows(t.key, t.state)}</div></div></article>`;
            })
            .join("")}</section>`;
        }),
        (processinlineStageStrip = function (t) {
          return `<div class="processinline-stage-wrap"><div class="processinline-stage-flow">${workbriefOrchSteps(
            t,
          )
            .map(
              (t, s) =>
                `<button class="processinline-stage-btn ${t.state} ${state.processinlineProcess.stage !== t.key || state.processinlineProcess.all ? "" : "selected"}" data-processinline-stage="${emergencyEsc(t.key)}"><span class="processinline-stage-dot">${"done" === t.state ? "✓" : s + 1}</span><strong>${emergencyEsc(t.title)}</strong><small>${processinlineStateLabel(t)}</small></button>`,
            )
            .join(
              "",
            )}</div><div class="processinline-process-toolbar"><button data-processinline-all>${state.processinlineProcess.all ? "收起全部过程" : "展开全部过程"}</button></div>${processinlineInlineMarkup()}</div>`;
        }),
        (processinlineOverviewCard = function (t) {
          const s = state.emergencyThread,
            e = emergencyMeta(s),
            a = collaborationDecisionCounts();
          return `<article class="timeline-task-overview"><div class="timeline-overview-head"><div><div class="eyebrow">智能体编排过程</div><h3>${emergencyEsc(e.title)}</h3></div><span class="timeline-overview-status">${emergencyEsc(e.status)}</span></div><div class="timeline-overview-body">${processinlineStageStrip(s)}<div class="timeline-overview-metrics"><button data-emergency-open-canvas="materials"><b>23</b><span>需求物资</span></button><button data-emergency-open-canvas="responses"><b>18</b><span>有效响应</span></button><button data-emergency-open-canvas="plans"><b>2</b><span>补足缺口</span></button><button class="attention" data-emergency-open-canvas="plans"><b>${a.pending}</b><span>待确认差异</span></button></div><div class="processinline-overview-actions"><div><button data-processinline-all>${state.processinlineProcess.all ? "收起全部过程" : "展开全部过程"}</button><button class="primary" data-emergency-open-canvas="plans">${a.pending ? "处理方案差异" : "查看最终方案"}</button></div></div></div></article>`;
        }),
        (workbriefHorizontalProgress = processinlineStageStrip),
        (timelineHorizontalProgress = processinlineStageStrip),
        (timelineTaskOverviewCard = processinlineOverviewCard));

/* Source runtime block 26 */
function briefbootUpdateBriefInPlace() {
        const e = document.getElementById("normalBriefCard");
        if (!e) return;
        const t = e.querySelector(".normal-brief-title span");
        t && (t.textContent = briefstatusBriefSubtitle());
        const n = !(!state.sensingSense || !state.sensingSense.detected),
          o = n && !state.sensingstateSenseAcknowledged,
          s = e.querySelector("#livebriefBriefStatus");
        if (s) {
          s.classList.toggle("sensingstate-new-task", o);
          const e = s.querySelector("span");
          e && (e.textContent = n ? "发现1项新任务" : "智能体持续感知中");
        }
        const i = briefdrillCounts();
        if (
          ([
            ["focus", i.focus],
            ["general", i.general],
            ["follow", i.follow],
          ].forEach(([t, n]) => {
            const o = e.querySelector(`[data-briefdrill-root="${t}"] b`);
            o && (o.textContent = String(n));
          }),
          "closed" !== state.briefnavHome.level)
        ) {
          const t = e.querySelector(".normal-brief-body");
          t && (t.innerHTML = briefnavPanelMarkup());
        }
      }
      function briefbootDockBrief(e = !1) {
        const t = document.getElementById("normalBriefCard"),
          n = document.getElementById("chatEmpty");
        t &&
          t.classList.contains("livebrief-intro") &&
          "docking" !== state.briefbootBriefPhase &&
          "docked" !== state.briefbootBriefPhase &&
          (clearTimeout(window.__briefbootRevealTimer),
          clearTimeout(window.__briefbootDockTimer),
          clearTimeout(livebriefIntroTimer),
          (state.briefbootBriefPhase = "docking"),
          (livebriefFirstEntryActive = !1),
          t.classList.remove("briefboot-brief-pending"),
          t.classList.add("briefboot-brief-docking", "livebrief-docking"),
          requestAnimationFrame(
            () =>
              requestAnimationFrame(() => {
                (t.classList.remove(
                  "livebrief-intro",
                  "livebrief-docking",
                  "briefboot-brief-ready",
                  "briefboot-brief-docking",
                ),
                  t.classList.add("livebrief-docked"));
                const o = t.querySelector(".normal-brief-title span");
                o && (o.textContent = briefstatusBriefSubtitle());
                const s = t.querySelector("#livebriefBriefStatus span");
                (s &&
                  (s.textContent = state.sensingSense?.detected
                    ? "发现1项新任务"
                    : "智能体持续感知中"),
                  e && "closed" !== state.briefnavHome.level
                    ? (t.classList.remove("collapsed"),
                      t.classList.add("livebrief-filter-open"),
                      (notificationsNormalBriefCollapsed = !1))
                    : (t.classList.add("collapsed"),
                      t.classList.remove("livebrief-filter-open"),
                      (notificationsNormalBriefCollapsed = !0)),
                  n?.classList.remove("livebrief-awaiting"));
                const i = document.getElementById("crumb");
                (i && (i.innerHTML = "<b>智慧工作台</b> / 对话"),
                  (state.briefbootBriefPhase = "docked"));
              }),
            30,
          ));
      }
      function briefbootRenderConversation(e = !1) {
        (clearTimeout(livebriefIntroTimer),
          clearTimeout(livebriefRefreshTimer),
          clearTimeout(window.__briefbootRevealTimer),
          clearTimeout(window.__briefbootDockTimer),
          (assistantbriefButlerMode = !1),
          (assistantbriefQuestions = []),
          (assistantbriefQuestionSeq = 0),
          (assistantbriefActiveQuestion = 0),
          (briefcategoryButlerSummaryFilter = ""),
          (notificationsNormalBriefCollapsed = !e),
          (livebriefFirstEntryActive = !1),
          (state.briefnavHome.level = "closed"),
          assistantbriefButlerTasks.forEach((e) => {
            ((e.expanded = !1), (e.selected = !1));
          }),
          setView("chat"));
        const t = document.getElementById("view-chat");
        (t?.classList.remove("butler-active"),
          t?.classList.add("livebrief-conversation"),
          document
            .getElementById("emergencyHomeBanner")
            ?.classList.add("hidden"));
        const n = document.getElementById("chatThread");
        if (!n) return;
        n.innerHTML = `${briefdrillBriefMarkup(e, !e)}${livebriefEmptyMarkup(e)}`;
        const o = document.getElementById("normalBriefCard");
        // 今日简报是首屏基础内容：立即呈现，不参与延迟揭示动画。
        e && o && o.classList.remove("briefboot-brief-pending");
        const s = document.getElementById("crumb");
        (s &&
          (s.innerHTML = e
            ? "<b>智慧工作台</b> / 今日简报"
            : "<b>智慧工作台</b> / 对话"),
          renderRecent(),
          assistantbriefRenderQuestionRail(),
          assistantbriefRenderTaskList(),
          livebriefBindSuggestions(),
          (n.scrollTop = 0));
        try {
          briefnavEnsureRecap();
        } catch (e) {}
        try {
          processreviewEnsureRecapUI();
        } catch (e) {}
        e && o
          ? ((state.briefbootBriefPhase = "intro"),
            (state.briefbootBriefShown = !0),
            (livebriefFirstEntryActive = !0),
            (window.__briefbootDockTimer = setTimeout(
              () => briefbootDockBrief(!1),
              9e3,
            )))
          : ((state.briefbootBriefPhase = "docked"),
            requestAnimationFrame(() =>
              document
                .getElementById("chatEmpty")
                ?.classList.remove("livebrief-awaiting"),
            ));
      }
      function briefbootBoot() {
        ((document.title = "供应链智慧工作台"),
          document.getElementById("sensingLiveToast")?.remove(),
          "emergency" === state.view ? emergencyRender() : briefbootRenderConversation(!0),
          document.documentElement.classList.remove("briefboot-booting"),
          document.getElementById("briefbootBootStyle")?.remove(),
          clearTimeout(window.__sensingSenseTimer),
          (window.__sensingSenseTimer = setTimeout(
            () => sensingDetectNewTask(!1),
            15e3,
          )));
      }
      (clearTimeout(window.__sensingSenseTimer),
        clearTimeout(window.__sensingstateBootTimer),
        clearTimeout(window.__briefbootRevealTimer),
        clearTimeout(window.__briefbootDockTimer),
        (state.briefbootBriefPhase = state.briefbootBriefPhase || "idle"),
        (state.briefbootBriefShown = !!state.briefbootBriefShown),
        (sensingDetectNewTask = function (e = !1) {
          if (!state.sensingSense.detected || e) {
            if (
              ((state.sensingstateSenseAcknowledged = !1),
              (state.sensingSense.detected = !0),
              (state.sensingSense.total = 26),
              (state.sensingSense.categories = 6),
              (state.sensingSense.priority = 3),
              (state.sensingSense.lastScan = "刚刚"),
              !state.sensingSense.newTaskAdded)
            ) {
              ((state.sensingSense.newTaskAdded = !0),
                state.conversations.unshift({
                  title: "主变压器订单发货确认",
                  type: "监控预警",
                  time: "刚刚",
                  messages: 1,
                  live: !0,
                  sensingNew: !0,
                }));
              try {
                renderRecent();
              } catch (e) {}
            }
            (briefbootUpdateBriefInPlace(),
              document.getElementById("sensingLiveToast")?.remove());
          }
        }),
        (livebriefDockBrief = briefbootDockBrief),
        (livebriefRenderConversation = briefbootRenderConversation),
        (assistantbriefRenderButlerHome = function () {
          briefbootRenderConversation(!0);
        }),
        (assistantbriefRenderNormalHome = function () {
          briefbootRenderConversation(!1);
        }),
        window.__briefbootBooted ||
          ((window.__briefbootBooted = !0),
          requestAnimationFrame(() => requestAnimationFrame(briefbootBoot))));

/* Approved emergency conversation examples: user questions are the only locator anchors. */
(() => {
  const exampleConversation = [
    {
      role: "assistant",
      kind: "timelineoverview",
      text: "本任务由“应急事件常驻感知任务”于09:48自动创建。需求校验、四渠道寻源和响应汇聚已完成，当前有3项方案差异需要确认。",
      example: true,
    },
    { role: "user", kind: "bubble", text: "这条任务现在到哪一步了？", example: true },
    {
      role: "assistant",
      kind: "bubble",
      text: "四渠道寻源已经完成，当前进入方案确认阶段。已收到18条有效响应，20条物资形成完整来源组合，3项差异等待判断。",
      example: true,
    },
    { role: "user", kind: "bubble", text: "为什么还有3项需要我确认？", example: true },
    {
      role: "assistant",
      kind: "bubble",
      text: "2项使用了原系统未选用的新增资源，1项需要在交期与原项目影响之间选择。右侧方案对比已按物资逐项对齐。",
      example: true,
    },
    { role: "user", kind: "bubble", text: "长寿公司具体回复了什么？", example: true },
    {
      role: "assistant",
      kind: "bubble",
      text: "长寿供电公司确认可协调光缆0.94千米，预计00:40发出、01:30到达。附加条件是不影响原项目关键节点。",
      example: true,
    },
    { role: "user", kind: "bubble", text: "原系统方案和AI方案差在哪里？", example: true },
    {
      role: "assistant",
      kind: "bubble",
      text: "主要有3项差异。AI方案新增4个可用来源，补足2项缺口，并将最晚到货时间提前约4小时。",
      example: true,
    },
    { role: "user", kind: "bubble", text: "采用长寿资源有什么风险？", example: true },
    {
      role: "assistant",
      kind: "bubble",
      text: "主要风险是长寿项目方尚未完成最终释放确认。若30分钟内确认，可按01:30到达；未确认时保留应急采购备选。",
      example: true,
    },
  ];

  function ensureEmergencyExampleConversation() {
    if (!state.emergencyThreads) state.emergencyThreads = {};
    const current = state.emergencyThreads.E001;
    if (!current?.some((message) => message?.example)) {
      state.emergencyThreads.E001 = exampleConversation.map((message) => ({ ...message }));
    }
    return state.emergencyThreads.E001;
  }

  function questionAction(text) {
    const value = String(text || "");
    return /哪一步|执行过程|当前进度|任务进度/.test(value)
      ? "progress"
      : /为什么.*3项|为什么.*确认|待确认/.test(value)
        ? "confirm"
        : /长寿.*回复|回复.*长寿/.test(value)
          ? "response"
          : /前两项.*AI|第三项.*原系统|批量确认/.test(value)
            ? "batch"
          : /长寿.*风险|风险.*长寿/.test(value)
            ? "risk"
            : /原系统.*AI|AI.*原系统|两套方案|方案.*差/.test(value)
              ? "compare"
              : "";
  }

  function applyQuestionAction(action) {
    if (action === "progress") {
      state.timelineTimelineExpanded[state.emergencyThread] = true;
      state.emergencyCanvasOpen = false;
    } else if (action === "confirm") {
      state.emergencyCanvasOpen = true;
      state.emergencyCanvasTab = "plans";
      state.plancomparePlanFilter = "pending";
    } else if (action === "response") {
      state.emergencyCanvasOpen = true;
      state.emergencyCanvasTab = "responses";
      state.planreviewResponseChannel = "unit";
    } else if (action === "batch") {
      state.collaborationDecisions.M01 = "ai";
      state.collaborationDecisions.M03 = "ai";
      state.collaborationDecisions.M04 = "original";
      state.emergencyCanvasOpen = true;
      state.emergencyCanvasTab = "plans";
      state.plancomparePlanFilter = "all";
    } else if (action === "compare" || action === "risk") {
      state.emergencyCanvasOpen = true;
      state.emergencyCanvasTab = "plans";
      state.plancomparePlanFilter = "all";
      state.plancomparePlanDetail = "M01";
    }
    state.collaborationTab = state.emergencyCanvasTab;
  }

  const baseThreadMessages = emergencyThreadMessages;
  emergencyThreadMessages = function (thread) {
    return thread === "E001" ? ensureEmergencyExampleConversation() : baseThreadMessages(thread);
  };

  const baseSendPrompt = emergencySendPrompt;
  emergencySendPrompt = function (preset) {
    const input = document.getElementById("emergencyPrompt");
    const prompt = String(preset ?? input?.value ?? "").trim();
    const action = questionAction(prompt);
    if (state.emergencyThread !== "E001" || !action) return baseSendPrompt(preset);
    if (input) input.value = "";
    emergencyPush("user", prompt);
    applyQuestionAction(action);
    const replies = {
      progress: "四渠道寻源已经完成，当前进入方案确认阶段。已收到18条有效响应，20条物资形成完整来源组合，3项差异等待判断。",
      confirm: "2项使用了原系统未选用的新增资源，1项需要在交期与原项目影响之间选择。右侧已筛选3项待确认差异。",
      response: "长寿供电公司确认可协调光缆0.94千米，预计00:40发出、01:30到达。附加条件是不影响原项目关键节点。",
      batch: "已完成3项差异处理：2项采用AI方案，1项保留原系统方案。当前可以形成最终方案。",
      compare: "主要有3项差异。AI方案新增4个可用来源，补足2项缺口，并将最晚到货时间提前约4小时。",
      risk: "主要风险是长寿项目方尚未完成最终释放确认。若30分钟内确认，可按01:30到达；未确认时保留应急采购备选。",
    };
    emergencyPush("assistant", replies[action]);
    emergencyRender();
  };

  const baseRender = emergencyRender;
  emergencyRender = function () {
    if (state.emergencyThread === "E001") ensureEmergencyExampleConversation();
    baseRender();
    if (state.view !== "emergency" || state.emergencyThread !== "E001") return;
    const suggestions = document.querySelector("#emergencyEmergencyWorkspace .emergency-suggestions");
    if (suggestions) {
      suggestions.innerHTML =
        '<button data-emergency-suggest="这条任务现在到哪一步了？">查看当前进度</button><button data-emergency-suggest="长寿公司具体回复了什么？">查看长寿响应</button><button data-emergency-suggest="原系统方案和AI方案差在哪里？">对比两套方案</button><button data-emergency-suggest="前两项采用AI方案，第三项保留原系统方案。">批量确认方案</button>';
    }
  };

  ensureEmergencyExampleConversation();
})();
