/* 任务线程：今日简报 → 重点事项 → 事项详情 → 去办理。
   左侧为该事项的对话（背景、建议、步骤、确认卡、结果），右侧为办理区。
   六条事项对应三种执行方式：D1 人机协同；D2、D5、D6 链接跳转（源端页面嵌在办理区，由用户操作）；D3、D4 接口调用（合为一个故事）。
   源端界面：D1、D2、D5 用实际系统截图（window.EXEC_SHOTS）叠加输入和点击；D6 按 ERP 选择屏照片用 HTML 绘制。 */
(() => {
  const h = (v) =>
    String(v ?? "").replace(
      /[&<>"]/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c],
    );
  const $id = (x) => document.getElementById(x);
  const toast = (t) => (typeof window.showToast === "function" ? window.showToast(t) : null);
  /* 场景线程（scene-flows.js）：SC(id) 取场景定义；对话中发起的线程没有首页事项，事项信息放在 LOCAL */
  const SC = (id) => (window.SCENES && window.SCENES[id]) || null;
  const LOCAL = {};
  const find = (id) => LOCAL[id] || (typeof window.homeBriefFind === "function" ? window.homeBriefFind(id) : null);
  const st8 = () => (typeof state !== "undefined" ? state : null);
  const now = () => {
    const d = new Date();
    return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
  };

  /* ---------- 三种执行方式 ---------- */

  const MODES = {
    link: {
      name: "链接跳转",
      how: "源端页面在办理区打开，页面上的查询、填写和提交由你操作，AI 不操作页面。办完后工作台查询单据状态确认办结。",
    },
    agent: {
      name: "AI 浏览器人机协同",
      how: "源端网页在办理区打开，AI 按事项填写条件、执行查询、定位单据，会改数据的操作先在对话里请你确认。AI 填过的每一项都可以改。",
    },
    api: {
      name: "接口调用",
      how: "工作台直接调用源端接口查询、发送消息或提交反馈，结果在办理区以卡片显示，不打开源端页面。",
    },
  };

  const USERS = {
    A: { name: "物资部数字化管理专责", unit: "国网重庆市电力公司物资部", ava: "数" },
    H: { name: "忠县公司履约专责", unit: "国网重庆市电力公司忠县供电分公司", ava: "履" },
    B: { name: "大足供电分公司物资专责", unit: "国网重庆市电力公司大足供电分公司", ava: "足" },
    C: { name: "市北供电分公司仓储专责", unit: "国网重庆市电力公司市北供电分公司", ava: "仓" },
    D: { name: "市北供电分公司运检部计划提报人", unit: "国网重庆市电力公司市北供电分公司", ava: "检" },
    E: { name: "市北供电分公司物资部主任", unit: "国网重庆市电力公司市北供电分公司", ava: "主" },
    F: { name: "市区供电分公司履约专责", unit: "国网重庆市电力公司市区供电分公司", ava: "履" },
    G: { name: "市区供电分公司项目管理人员", unit: "国网重庆市电力公司市区供电分公司", ava: "项" },
  };
  /* 切换列表按单位分组 */
  /* 10/23 技术处汇报只演示忠县公司履约专责（打开时默认）和物资部数字化管理专责两个账号；V89 的分组保留在 USER_GROUPS_V89，恢复时换回即可 */
  const USER_GROUPS_V89 = [
    ["市北供电分公司", ["D", "C", "E"]],
    ["市区供电分公司", ["F", "G"]],
    ["物资分公司", ["A"]],
    ["大足供电分公司", ["B"]],
  ];
  const USER_GROUPS = [["忠县供电分公司", ["H"]], ["物资部", ["A"]]];

  /* why：线程「事项背景」里说明为什么用这种方式办理 */
  const DEMOS = {
    D1: { mode: "agent", who: "A", tab: "ERP 网页版 · ZMM20188", why: "要填 5 项查询条件，并在查询结果里定位采购申请，由 AI 在 ERP 网页版代为操作，批准前由你确认。" },
    D2: { mode: "link", who: "A", tab: "智慧供应链运营平台 - 付款申请管理-专责审核", why: "只需填写采购凭证号一项，在运营平台直接办理最快。" },
    D3: { mode: "api", who: "A", tab: "ESC 网省风险预警查询", why: "只查询预警、不改数据，通过 ESC 接口取回结果，不必打开 ESC 页面。" },
    D4: { mode: "api", who: "B", tab: "ESC 网省风险预警反馈", why: "反馈由 AI 依据你上传的现场材料填写，核对后通过 ESC 接口提交。" },
    D5: { mode: "link", who: "A", tab: "实物资源一体化 - 仓储工作台", why: "下架要与现场实物核对，由你在仓储工作台操作。" },
    D6: { mode: "link", who: "B", tab: "采购申请受理及平衡利库--基层", why: "利库数量要结合库存和工程需要判断，由你在 ERP 中受理；工作台先给出利库建议。" },
  };
  const demoOf = (it) => (it && DEMOS[it.id]) || null;
  const mine = (id) => DEMOS[id] && (DEMOS[id].who === "*" || DEMOS[id].who === S.who);

  /* pick：本机文件选择框 */
  const S = { who: "H", open: "", threads: {}, snap: {}, crumb: "", reminded: "", work: "open", fold: false, opening: false, pick: null };
  window.execWho = () => S.who;

  /* ---------- 事项状态 ---------- */

  function snap(id) {
    const it = find(id);
    if (it && !S.snap[id]) S.snap[id] = { status: it.status, current: it.current, remain: it.remain };
    return it;
  }

  function finish(id, fin) {
    const it = snap(id);
    if (!it) return;
    it.status = fin.status || "done";
    it.current = fin.current;
    it.remain = fin.remain || "已完成";
    it.__emlog = it.__emlog || [];
    it.__emlog.push([now(), fin.log]);
    it.__emnext = fin.next || "";
    if (typeof window.homeBriefRefresh === "function") window.homeBriefRefresh();
    recent();
    if (S.open) head();
  }

  const stOf = (it) => (it.status === "done" ? "done" : it.status === "external" ? "ext" : "run");
  const ST_NAME = { run: "办理中", ext: "待外部响应", done: "已办结" };

  /* ---------- 列表徽章、详情信息 ---------- */

  window.execModeBadge = function (item) {
    const d = demoOf(item);
    return d && MODES[d.mode] ? `<span class="em-tag em-tag-${d.mode}">${MODES[d.mode].name}</span>` : "";
  };

  window.execModesBlock = function (item) {
    const d = demoOf(item);
    if (!d || !MODES[d.mode]) return "";
    const logs = item.__emlog || [];
    const rec = logs
      .map((l) => `<div><i class="em-mono">${h(l[0])}</i><span>${h(l[1])}</span></div>`)
      .join("");
    return `<section class="em-block em-block-${d.mode}">
      <div class="em-block-h"><h4>办理方式</h4><span class="em-badge em-badge-${d.mode}">${MODES[d.mode].name}</span></div>
      <div class="em-entry">
        <span class="em-entry-k">处置入口</span>
        <span class="em-entry-v"><b>${h(item.entry.sys)}</b> · <span class="em-mono">${h(item.entry.menu)}</span></span>
      </div>
      <p class="em-how">${MODES[d.mode].how}点「去办理」进入这条事项的任务线程。</p>
      ${rec ? `<div class="em-rec-list"><b>办理记录</b>${rec}${item.__emnext ? `<p class="em-next">${h(item.__emnext)}</p>` : ""}</div>` : ""}
    </section>`;
  };

  /* ---------- 截图坐标：img 原图尺寸，crop 显示区域，box 为原图像素 [x, y, 宽, 高] ---------- */

  const pct = (v, base) => `${((v / base) * 100).toFixed(3)}%`;
  const place = (P, b) =>
    `left:${pct(b[0] - P.crop[0], P.crop[2])};top:${pct(b[1] - P.crop[1], P.crop[3])};width:${pct(b[2], P.crop[2])};height:${pct(b[3], P.crop[3])}`;
  const grow = (b, n = 2) => [b[0] - n, b[1] - n, b[2] + n * 2, b[3] + n * 2];

  function shotView(P, overlay, opt = {}) {
    const [W, H] = P.img;
    const [cx, cy, cw, ch] = P.crop;
    const img = `width:${pct(W, cw)};height:${pct(H, ch)};left:${pct(-cx, cw)};top:${pct(-cy, ch)}`;
    return `<div class="em-shot${opt.bare ? " em-shot-bare" : ""}">
      ${opt.bare ? "" : `<div class="em-shot-bar">${opt.left || `<b>${h(P.frame)}</b>`}${opt.right ? `<span>${opt.right}</span>` : ""}</div>`}
      <div class="em-shot-scroll"><div class="em-shot-view" style="aspect-ratio:${cw} / ${ch};--fs:${P.fs}${P.wide ? `;min-width:${cw}px` : P.minw ? `;min-width:${P.minw}px` : ""}">
        <img src="${(window.EXEC_SHOTS || {})[P.shot] || ""}" alt="${h(P.frame)}" style="${img}" />
        ${overlay}
      </div></div>
      ${opt.legend ? `<div class="em-legend">${opt.legend}</div>` : ""}
    </div>`;
  }

  const srcMsg = (m) => (m ? `<div class="em-src-msg em-src-${m.tone || "info"}">${h(m.t)}</div>` : "");
  const srcDlg = (d) =>
    d
      ? `<div class="em-dlg"><div class="em-dlg-box"><p>${h(d.t)}</p><div>${d.btns
          .map((b) => `<button class="${b[2] ? "p" : ""}" data-em-act="${b[1]}">${h(b[0])}</button>`)
          .join("")}</div></div></div>`
      : "";

  /* ---------- D1 ERP ZMM20188：人机协同 ---------- */

  const D1F = [
    { k: "type", label: "申请类型", kind: "radio", ai: "招标批次", from: "事项类型：集中招标批次计划",
      opts: ["招标批次", "非招标批次", "服务类招标批次", "服务非招标批次", "授权采购批次", "服务类授权采购批次"],
      ys: [110.7, 132.5, 154.3, 176, 198, 219.6], frame: [21, 101, 136, 128] },
    { k: "plan", label: "招标计划编号", kind: "text", ai: "202197", from: "事项业务对象", box: [281, 276, 85, 19] },
    { k: "pr", label: "采购申请", kind: "text", ai: "3800530813", from: "事项业务对象", box: [281, 364, 86, 19] },
    { k: "plant", label: "工厂", kind: "text", ai: "0300", from: "采购申请所属工厂", box: [281, 386, 37, 19] },
    { k: "data", label: "数据选择", kind: "radio", ai: "未审批", from: "事项当前环节：待本人审批",
      opts: ["未审批", "已审批", "已退回"], ys: [549, 572, 594], frame: [21, 539, 64, 64] },
  ];
  const PR8 = ["3100004736", "3800530810", "3800530811", "3800530812", "3800530813", "3800530814", "3800533021", "3800533087"];
  const D1SEL = { shot: "zmm20188Sel", img: [965, 625], crop: [0, 0, 965, 625], fs: 1.25, wide: true, frame: "ERP · ZMM20188 集中招标批次计划审批" };
  const D1L1 = { shot: "zmm20188List", img: [1920, 313], crop: [0, 44, 1540, 116], fs: 0.8, wide: true, frame: "ERP · ZMM20188 集中招标批次计划审批",
    rows: [{ pr: "3800530813", box: [17, 137, 1523, 18] }], approve: [404, 81, 48, 21] };
  const D1L8 = { shot: "zmm20188List8", img: [1899, 315], crop: [0, 70, 1540, 245], fs: 0.8, wide: true, frame: "ERP · ZMM20188 集中招标批次计划审批",
    rows: PR8.map((pr, i) => ({ pr, box: [19, 162.5 + 19 * i, 1521, 19] })), approve: [405, 107, 46, 21] };

  const d1List = (T) => (T.list === 8 ? D1L8 : D1L1);
  const d1Disp = (v) => (v === "" ? "（清空）" : v == null ? "—" : v);
  function d1St(T, k) {
    const f = D1F.find((x) => x.k === k);
    const v = T.f[k];
    if (T.aiSet[k]) return v === f.ai ? "ai" : "me";
    return v ? "me" : "";
  }
  const d1Changed = (T) => D1F.filter((f) => d1St(T, f.k) === "me");

  const frame = (P, k, box, st) =>
    `<span class="em-fr${st ? ` em-fr-${st}` : ""}" data-fr="${k}" style="${place(P, box)}"><sup>${st === "me" ? "人工改写" : "AI 填"}</sup></span>`;

  /* 办理区顶部的 AI 操作进度：stage 0 未开始，1—4 对应四步，5 完成 */
  const D1STEPS = ["填写查询条件", "执行查询", "定位采购申请", "批准"];
  function d1Bar(T) {
    const n = T.stage || 0;
    let txt;
    if (T.handoff) txt = "AI 已停止 · 已转人工";
    else if (n >= 5) txt = "AI 操作完成 · 4/4 步";
    else if (!n) txt = "AI 待命 · 点左侧「开始办理」后开始操作";
    else if (T.busy) txt = `AI 正在操作 · 第 ${n}/4 步 · ${D1STEPS[n - 1]}`;
    else if (pending(T)) txt = "AI 已暂停 · 第 4/4 步 · 等你确认批准";
    else if (n === 1) txt = "AI 已暂停 · 第 1/4 步 · 等你核对查询条件";
    else if (n === 2) txt = "AI 已暂停 · 第 2/4 步 · 查询没有结果，等你修改条件";
    else txt = `AI 已暂停 · 第 ${n}/4 步 · 等你操作`;
    return `<div class="em-ai-bar${T.busy ? " run" : ""}${n >= 5 && !T.handoff ? " fin" : ""}"><b><i></i>${txt}</b><ol>${D1STEPS.map((x, i) => `<li class="${n >= 5 || i + 1 < n ? "done" : i + 1 === n ? "cur" : ""}">${x}</li>`).join("")}</ol></div>`;
  }

  function d1Right(T) {
    const lock = T.busy || T.handoff ? "disabled" : "";
    if (T.p === "sel") {
      const P = D1SEL;
      let ov = "";
      D1F.forEach((f) => {
        const v = T.f[f.k];
        if (f.kind === "radio") {
          f.ys.forEach((y, i) => {
            const on = v === f.opts[i] ? " on" : "";
            ov += `<button class="em-radio${on}" style="${place(P, [26.3, y - 5.7, 11.4, 11.4])}" data-d1-radio="${f.k}:${i}" ${lock} aria-label="${h(f.opts[i])}"></button>`;
            ov += `<button class="em-hit" style="${place(P, [39, y - 8, 116, 16])}" data-d1-radio="${f.k}:${i}" ${lock} aria-label="${h(f.opts[i])}"></button>`;
          });
          ov += frame(P, f.k, f.frame, d1St(T, f.k));
        } else {
          ov += `<input class="em-in" style="${place(P, f.box)}" data-d1-in="${f.k}" value="${h(v)}" ${T.busy || T.handoff ? "readonly" : ""} aria-label="${h(f.label)}" />`;
          ov += frame(P, f.k, grow(f.box), d1St(T, f.k));
        }
      });
      ov += `<button class="em-mk em-mk-go${T.busy || T.handoff ? "" : " ready"}" style="${place(P, [13, 40, 22, 21])}" data-em-act="d1-exec" ${lock} title="执行"></button>`;
      if (T.aiClick === "exec") ov += `<span class="em-cursor" style="${place(P, [13, 40, 22, 21])}"></span>`;
      ov += srcMsg(T.srcMsg);
      return shotView(P, ov, {
        right: T.busy ? "AI 操作中" : "选择屏幕 · 可直接修改",
        legend: `<span><i class="em-lg-ai"></i>AI 填</span><span><i class="em-lg-me"></i>人工改写</span><span><i class="em-lg-go"></i>执行</span>`,
      });
    }
    const L = d1List(T);
    let ov = "";
    L.rows.forEach((r, i) => {
      const on = T.row === i;
      const who = on ? (i === T.aiRow ? "ai" : "me") : "";
      ov += `<button class="em-row${on ? ` on ${who}` : ""}${T.stage >= 5 && on ? " ok" : ""}" style="${place(L, r.box)}" data-d1-row="${i}" ${lock} aria-label="采购申请 ${r.pr}">${on ? `<sup>${T.stage >= 5 ? "已批准" : who === "ai" ? "AI 选中" : "人工改选"}</sup>` : ""}</button>`;
    });
    ov += `<button class="em-mk em-mk-write${T.busy || T.done ? "" : " ready"}" style="${place(L, L.approve)}" data-em-act="d1-approve" ${lock} title="批准：会改数据，点击后先在对话里确认"></button>`;
    if (T.aiClick === "approve") ov += `<span class="em-cursor" style="${place(L, L.approve)}"></span>`;
    ov += srcMsg(T.srcMsg);
    return shotView(L, ov, {
      left: `<button class="em-back" data-em-act="d1-back" ${lock}>‹ 返回选择屏幕</button><b>${h(L.frame)}</b>`,
      right: `查询结果 ${L.rows.length} 条`,
      legend: `<span><i class="em-lg-ai"></i>AI 选中</span><span><i class="em-lg-me"></i>人工改选</span><span><i class="em-lg-write"></i>会改数据，点击后先确认</span>`,
    });
  }

  function d1Start(T) {
    say(T, { k: "me", text: "开始办理" });
    T.busy = true;
    T.stage = 1;
    const st = say(T, { k: "steps", title: "AI 在 ERP 网页版操作", items: [] });
    let t = 500;
    D1F.forEach((f) => {
      later(T, t, () => {
        T.f[f.k] = f.ai;
        T.aiSet[f.k] = true;
        st.items.push({ t: `填写「${f.label}」：${f.ai}`, from: f.from });
        draw(T);
      });
      t += 700;
    });
    later(T, t, () => {
      T.busy = false;
      st.items.push({ t: "5 项条件已填好，停在选择屏等你核对" });
      say(T, { k: "ai", html: "5 项查询条件已填好（黄框）。可以在右侧直接修改，改过的项标「人工改写」。核对后点页面上的【执行】，或点下面的按钮。", btns: [["执行查询", "d1-exec", "p"]] });
      draw(T);
    });
  }

  /* 返回选择屏或重新查询时，作废尚未确认的批准确认卡 */
  function dropPending(T) {
    T.msgs.forEach((m) => {
      if (m.k === "confirm" && m.state === "wait") {
        m.state = "cancel";
        m.at = now();
      }
    });
  }

  function d1Exec(T) {
    const f = T.f;
    T.stage = 2;
    if (!f.type || !f.data) {
      T.busy = false;
      T.srcMsg = { t: "请先选择申请类型和数据选择", tone: "err" };
      return draw(T);
    }
    let n = 0;
    if (f.type === "招标批次" && f.data === "未审批" && f.plan === "202197" && (f.plant === "0300" || !f.plant)) {
      if (f.pr === "3800530813" && T.stage < 5) n = 1;
      else if (!f.pr && T.stage < 5) n = 8;
    }
    if (!n) {
      T.busy = false;
      T.srcMsg = { t: "没有找到符合条件的数据", tone: "err" };
      say(T, { k: "ai", html: `ERP 返回：没有找到符合条件的数据。当前条件为 ${D1F.map((x) => `${x.label} ${h(d1Disp(f[x.k]))}`).join("，")}。` });
      return draw(T);
    }
    T.p = "list";
    T.list = n;
    T.aiRow = n === 8 ? 4 : 0;
    T.row = T.aiRow;
    T.srcMsg = null;
    const loc = n === 8 ? "在 8 行中定位到采购申请 3800530813（第 5 行）" : "定位到采购申请 3800530813";
    T.busy = true;
    T.stage = 3;
    const st = say(T, { k: "steps", title: "AI 继续操作", items: [{ t: `查询返回 ${n} 条，${loc}，选中该行` }] });
    draw(T);
    later(T, 800, () => {
      T.aiClick = "approve";
      T.stage = 4;
      st.items.push({ t: "点【批准】，批准前请你确认" });
      draw(T);
    });
    later(T, 1500, () => {
      T.aiClick = "";
      T.busy = false;
      d1Approve(T);
      draw(T);
    });
  }

  function d1Approve(T) {
    if (T.handoff) return;
    if (T.stage >= 5) {
      T.srcMsg = { t: "该采购申请已批准", tone: "info" };
      return draw(T);
    }
    if (T.row < 0) {
      T.srcMsg = { t: "请先选择行", tone: "err" };
      return draw(T);
    }
    if (pending(T)) return;
    T.srcMsg = null;
    T.stage = 4;
    const L = d1List(T);
    const pr = L.rows[T.row].pr;
    const aiPr = L.rows[T.aiRow].pr;
    const rows = D1F.map((f) => [f.label, T.aiSet[f.k] ? f.ai : "—", d1St(T, f.k) === "me" ? d1Disp(T.f[f.k]) : ""]);
    rows.push(["选中行", `采购申请 ${aiPr}`, T.row !== T.aiRow ? `采购申请 ${pr}` : ""]);
    confirm(T, {
      title: "批准",
      action: `采购申请 ${pr}：未审批 → 批准`,
      rows,
      warn: pr !== "3800530813" ? "选中行与事项对象 3800530813 不一致，请核对。" : "",
      note: "批准后批次计划流转到下一环节，工作台不能撤回。",
      ok: "确认批准",
      onOk: () => {
        T.done = true;
        T.stage = 5;
        T.srcMsg = { t: `采购申请 ${pr} 已批准`, tone: "ok" };
        const n = d1Changed(T).length + (T.row !== T.aiRow ? 1 : 0);
        say(T, { k: "result", title: "已批准", lines: [`ERP 返回成功：采购申请 ${pr} 已批准，招标计划编号 ${T.f.plan}`, "批次计划流转到下一环节，下一环节处理人已收到待办", n ? `本次含人工改写 ${n} 项，已写入办理记录` : "AI 填写的条件未经改动"] });
        finish("D1", {
          current: "已批准，流转下一环节",
          log: `ERP ZMM20188 批准采购申请 ${pr}；AI 填写条件并定位单据${n ? `，人工改写 ${n} 项` : ""}，本人确认`,
          next: "下一环节处理人已收到待办",
        });
      },
      onCancel: () => say(T, { k: "ai", html: "已取消批准。可以在右侧修改条件或改选行，再点【批准】。" }),
    });
  }

  /* ---------- D2 运营平台付款申请专责审核：链接跳转 ---------- */

  const D2P = { shot: "payAudit", img: [1899, 917], crop: [250, 70, 1649, 390], fs: 0.79, minw: 1100, frame: "智慧供应链运营平台 · 付款申请管理-专责审核" };

  function d2Right(T) {
    const P = D2P;
    const s = T.pay;
    let ov = `<input class="em-in em-in-src" style="${place(P, [435, 154, 178, 20])}" data-pay-in value="${h(s.v)}" aria-label="采购凭证号" />`;
    ov += `<button class="em-hit em-hit-src" style="${place(P, [1838, 244, 50, 26])}" data-em-act="pay-query" aria-label="查询"></button>`;
    ov += `<button class="em-hit em-hit-src" style="${place(P, [360, 336, 76, 24])}" data-em-act="pay-submit" aria-label="批量提交"></button>`;
    if (s.found) {
      ov += `<button class="em-cbx${s.checked ? " on" : ""}" style="${place(P, [300, 415, 18, 18])}" data-em-act="pay-check" aria-label="勾选"></button>`;
    } else {
      ov += `<span class="em-cover" style="${place(P, [288, 409, 1596, 30])}">${s.queried ? "暂无数据" : ""}</span>`;
    }
    ov += srcMsg(s.msg) + srcDlg(s.dlg);
    return shotView(P, ov, { bare: true });
  }

  function d2Act(T, a) {
    const s = T.pay;
    if (a === "pay-query") {
      s.queried = true;
      s.checked = false;
      s.found = !s.submitted && s.v.trim() === "4300132824";
      s.msg = s.found ? null : { t: "暂无数据", tone: "info" };
    } else if (a === "pay-check") {
      s.checked = !s.checked;
    } else if (a === "pay-submit") {
      s.msg = null;
      s.dlg = s.checked
        ? { t: "确定提交选中的 1 条付款申请？", btns: [["取消", "pay-dlg-x"], ["确定", "pay-dlg-ok", 1]] }
        : { t: "请选择要提交的数据", btns: [["确定", "pay-dlg-x", 1]] };
    } else if (a === "pay-dlg-x") {
      s.dlg = null;
    } else if (a === "pay-dlg-ok") {
      s.dlg = null;
      s.submitted = true;
      s.found = false;
      s.checked = false;
      s.msg = { t: "提交成功", tone: "ok" };
    }
    right(T);
  }

  /* ---------- D5 实物资源一体化退役资产出库：链接跳转 ---------- */

  const D5P = { shot: "wmsOut", img: [1918, 970], crop: [144, 120, 1774, 810], fs: 0.79, minw: 1100, frame: "实物资源一体化 · 仓储工作台-退役资产代保管出库详情" };

  function d5Right(T) {
    const P = D5P;
    const s = T.wms;
    let ov = "";
    if (s.down) {
      ov += `<span class="em-cover em-cover-c" style="${place(P, [1345, 622, 70, 22])}">1 / 1</span>`;
      ov += `<span class="em-cover em-cover-c em-cover-mute" style="${place(P, [1738, 622, 44, 23])}">已下架</span>`;
    } else {
      ov += `<button class="em-hit em-hit-src" style="${place(P, [1740, 623, 36, 22])}" data-em-act="wms-down" aria-label="下架"></button>`;
    }
    ov += `<button class="em-hit em-hit-src" style="${place(P, [1780, 856, 130, 66])}" data-em-act="wms-post" aria-label="提交过账"></button>`;
    if (s.posted) ov += [1309, 1806].map((x) => `<span class="em-node" style="${place(P, [x, 229, 24, 24])}">&#10003;</span>`).join("");
    ov += srcMsg(s.msg) + srcDlg(s.dlg);
    return shotView(P, ov, { bare: true });
  }

  function d5Act(T, a) {
    const s = T.wms;
    if (a === "wms-down") {
      s.msg = null;
      s.dlg = { t: "确认下架该明细？", btns: [["取消", "wms-dlg-x"], ["确定", "wms-down-ok", 1]] };
    } else if (a === "wms-down-ok") {
      s.dlg = null;
      s.down = true;
      s.msg = { t: "下架成功", tone: "ok" };
    } else if (a === "wms-post") {
      s.msg = null;
      if (s.posted) s.msg = { t: "单据已过账", tone: "info" };
      else
        s.dlg = s.down
          ? { t: "确认提交过账？", btns: [["取消", "wms-dlg-x"], ["确定", "wms-post-ok", 1]] }
          : { t: "存在未下架的明细，不能过账", btns: [["确定", "wms-dlg-x", 1]] };
    } else if (a === "wms-dlg-x") {
      s.dlg = null;
    } else if (a === "wms-post-ok") {
      s.dlg = null;
      s.posted = true;
      s.msg = { t: "过账成功，发货完成", tone: "ok" };
    }
    right(T);
  }

  /* ---------- D6 ERP 采购申请受理及平衡利库--基层：链接跳转 ----------
     选择屏按 ERP 实际页面照片（zmm20012.jpg）的字段和顺序绘制；清单为 ALV 表格样式。 */

  const ZPR = "3800531206";
  const ZSEL = [
    ["审批代码", "appr", 3, 1],
    ["采购组织", "org", 4, 1],
    ["采购组", "pgrp", 3],
    ["采购策略", "strat", 2],
    ["采购方式", "way", 3],
    ["最后更改日期", "date", 10],
    ["需求工厂", "plant", 4],
    ["采购申请", "pr", 10],
    ["采购申请行项目", "item", 5],
    ["物料组", "mg", 9],
    ["物料编号", "mat", 18],
    ["工单号", "wo", 12],
    ["项目定义", "proj", 24, 1],
    ["电子商务技术规范ID", "tsid", 18],
    ["电子商务技术规范ID状态", "tsst", 1],
  ];
  const ZREQ = ["pgrp", "plant"];
  const ZCHK = ["采购申请退回标识", "超市化采购申请", "网省应急物资", "服务类采购申请", "增补采购申请", "国网商城（采购专区）采购申请", "物资直接采购申请", "电网零星物资选购专区", "项目互调/借用申请"];
  const ZROWS = [
    { item: "10", mat: "500014715", desc: "电力电缆,AC10kV,YJV22,3×300,无阻水", qty: 1.2, unit: "KM", need: "2026-10-20", avail: 0.8 },
    { item: "20", mat: "500027351", desc: "柱上断路器,AC10kV,630A,20kA,户外", qty: 3, unit: "台", need: "2026-10-20", avail: 0 },
  ];
  const n3 = (v) => Number(v || 0).toFixed(3);

  const zInit = () => ({
    p: "sel",
    f: { appr: "W1", org: "0100", pgrp: "D27", plant: "0327" },
    chk: {},
    appr: "待审批",
    sel: [],
    lk: ZROWS.map(() => ""),
    lkDone: ZROWS.map(() => 0),
    st: ZROWS.map(() => "待受理"),
    msg: null,
    dlg: null,
  });

  const zIcons = `<span class="em-sap-sys"><i class="ok"></i><input class="em-sap-cmd" aria-label="命令" /><i class="sep"></i><i class="g"></i><i class="g"></i><i class="g"></i><i class="sep"></i><i class="g"></i><i class="g"></i><i class="g"></i><i class="sep"></i><i class="g"></i><i class="g"></i></span>`;

  function zStatus(z) {
    const m = z.msg;
    return `<div class="em-sap-status${m ? ` ${m.tone || "info"}` : ""}">${m ? `<i></i>${h(m.t)}` : ""}</div>`;
  }

  function d6Page(T) {
    const z = T.z;
    const head = `${zIcons}<div class="em-sap-title">采购申请受理及平衡利库--基层</div>`;
    if (z.p === "sel") {
      const rows = ZSEL.map(([label, k, w, single]) => {
        const req = ZREQ.includes(k) && !z.f[k] ? " req" : "";
        const inp = (key) => `<input class="em-sap-in${key === k ? req : ""}" style="width:${Math.max(2, w) * 0.62 + 0.9}em" data-z-in="${key}" value="${h(z.f[key] || "")}" aria-label="${h(label)}" />`;
        return `<div class="em-sap-row"><label>${h(label)}</label>${inp(k)}${single ? "" : `<span class="em-sap-to">到</span>${inp(`${k}2`)}<button class="em-sap-multi" title="多重选择"></button>`}</div>`;
      }).join("");
      const chks = ZCHK.map((c, i) => `<label class="em-sap-chk"><input type="checkbox" data-z-chk="${i}"${z.chk[i] ? " checked" : ""} />${h(c)}</label>`).join("");
      const radios = ["待审批", "已审批"].map((r) => `<label class="em-sap-chk"><input type="radio" name="emZAppr" data-z-appr value="${r}"${z.appr === r ? " checked" : ""} />${r}</label>`).join("");
      return `<div class="em-sap">${head}
        <div class="em-sap-tool"><button class="em-sap-btn em-sap-exec" data-em-act="z-exec" title="执行 (F8)"><i></i></button><button class="em-sap-btn" title="获取变式"><i class="var"></i></button></div>
        <div class="em-sap-body">
          <fieldset class="em-sap-grp"><legend>选择条件</legend>${rows}${chks}</fieldset>
          <fieldset class="em-sap-grp"><legend>审批状态选择</legend>${radios}</fieldset>
        </div>
        ${zStatus(z)}${srcDlg(z.dlg)}</div>`;
    }
    const on = (i) => z.sel.includes(i);
    const all = z.sel.length === ZROWS.length;
    const trs = ZROWS.map((r, i) => {
      const edit = r.avail > 0 && z.st[i] === "待受理";
      return `<tr class="${on(i) ? "on" : ""}">
        <td class="sel"><button class="em-sap-sel${on(i) ? " on" : ""}" data-z-row="${i}" aria-label="选择行 ${r.item}"></button></td>
        <td>${ZPR}</td><td class="r">${r.item}</td><td>${r.mat}</td><td>${h(r.desc)}</td><td class="r">${n3(r.qty)}</td><td>${r.unit}</td><td>${r.need}</td><td class="r">${n3(r.avail)}</td>
        <td class="r">${edit ? `<input class="em-sap-in em-sap-lk" data-z-lk="${i}" value="${h(z.lk[i])}" aria-label="行 ${r.item} 利库数量" />` : z.lkDone[i] ? n3(z.lkDone[i]) : ""}</td>
        <td>${h(z.st[i])}</td></tr>`;
    }).join("");
    return `<div class="em-sap">${head}
      <div class="em-sap-tool">
        <button class="em-sap-btn" data-em-act="z-back" title="返回">‹ 返回</button><i class="sep"></i>
        <button class="em-sap-btn" data-em-act="z-lk">平衡利库</button><button class="em-sap-btn" data-em-act="z-acc">受理</button><button class="em-sap-btn" data-em-act="z-ret">退回</button><button class="em-sap-btn" data-em-act="z-ret">退回原因</button><i class="sep"></i><button class="em-sap-btn">下载</button>
      </div>
      <div class="em-sap-body"><div class="em-sap-alv"><table>
        <thead><tr><th class="sel"><button class="em-sap-sel${all ? " on" : ""}" data-em-act="z-all" aria-label="全选"></button></th><th>采购申请</th><th>行项目</th><th>物料编码</th><th>物料描述</th><th>申请数量</th><th>单位</th><th>需求日期</th><th>可利库数量</th><th>利库数量</th><th>处理状态</th></tr></thead>
        <tbody>${trs}</tbody></table></div></div>
      ${zStatus(z)}${srcDlg(z.dlg)}</div>`;
  }

  function d6Act(T, a) {
    const z = T.z;
    const f = z.f;
    const items = (idx) => idx.map((i) => ZROWS[i].item).join("、");
    z.msg = null;
    if (a === "z-exec") {
      if (ZREQ.some((k) => !String(f[k] || "").trim())) {
        z.msg = { t: "请输入所有必需输入字段", tone: "err" };
      } else {
        const acc = z.st.every((s) => s === "已受理");
        const hit = f.appr === "W1" && f.org === "0100" && f.plant === "0327" && (!f.pr || f.pr === ZPR) && (z.appr === "待审批" ? !acc : acc);
        if (hit) {
          z.p = "list";
          z.sel = [];
        } else z.msg = { t: "没有找到符合条件的数据", tone: "info" };
      }
    } else if (a === "z-back") {
      z.p = "sel";
    } else if (a === "z-all") {
      z.sel = z.sel.length === ZROWS.length ? [] : ZROWS.map((_, i) => i);
    } else if (a === "z-lk") {
      const idx = z.sel.filter((i) => z.st[i] === "待受理");
      const bad = idx.find((i) => ZROWS[i].avail <= 0);
      const over = idx.find((i) => Number(z.lk[i]) > ZROWS[i].avail);
      if (!z.sel.length) z.msg = { t: "请选择行", tone: "err" };
      else if (!idx.length) z.msg = { t: "选中行已处理，不能平衡利库", tone: "err" };
      else if (bad != null) z.msg = { t: `行 ${ZROWS[bad].item} 没有可利库库存`, tone: "err" };
      else if (idx.some((i) => !(Number(z.lk[i]) > 0))) z.msg = { t: "请在选中行输入利库数量", tone: "err" };
      else if (over != null) z.msg = { t: `行 ${ZROWS[over].item} 利库数量超过可利库数量 ${n3(ZROWS[over].avail)}`, tone: "err" };
      else z.dlg = { t: `对行 ${items(idx)} 执行平衡利库？`, btns: [["取消", "z-dlg-x"], ["确定", "z-lk-ok", 1]] };
    } else if (a === "z-lk-ok") {
      z.dlg = null;
      const idx = z.sel.filter((i) => z.st[i] === "待受理");
      idx.forEach((i) => {
        z.lkDone[i] = Number(z.lk[i]);
        z.st[i] = "已利库";
      });
      const r = ZROWS[idx[0]];
      z.msg = { t: `平衡利库完成：行 ${r.item} 利库 ${n3(z.lkDone[idx[0]])} ${r.unit}，剩余 ${n3(r.qty - z.lkDone[idx[0]])} ${r.unit} 转采购`, tone: "ok" };
      z.sel = [];
    } else if (a === "z-acc") {
      const idx = z.sel.filter((i) => z.st[i] !== "已受理");
      const skip = idx.filter((i) => ZROWS[i].avail > 0 && !z.lkDone[i]);
      if (!z.sel.length) z.msg = { t: "请选择行", tone: "err" };
      else if (!idx.length) z.msg = { t: "选中行已受理", tone: "info" };
      else if (skip.length) z.dlg = { t: `行 ${items(skip)} 有可利库库存，尚未平衡利库。是否继续受理？`, btns: [["取消", "z-dlg-x"], ["继续受理", "z-acc-ok", 1]] };
      else z.dlg = { t: `确认受理行 ${items(idx)}？受理后进入采购计划。`, btns: [["取消", "z-dlg-x"], ["确定", "z-acc-ok", 1]] };
    } else if (a === "z-acc-ok") {
      z.dlg = null;
      const idx = z.sel.filter((i) => z.st[i] !== "已受理");
      idx.forEach((i) => (z.st[i] = "已受理"));
      z.msg = { t: `受理成功：采购申请 ${ZPR} 行 ${items(idx)}`, tone: "ok" };
      z.sel = [];
    } else if (a === "z-ret") {
      z.msg = z.sel.length ? { t: "请先维护退回原因", tone: "err" } : { t: "请选择行", tone: "err" };
    } else if (a === "z-dlg-x") {
      z.dlg = null;
    }
    right(T);
  }

  /* ---------- 链接跳转：源端页面嵌在办理区，由用户操作 ---------- */

  const SRC_PAGE = { D2: (T) => d2Right(T), D5: (T) => d5Right(T), D6: (T) => d6Page(T) };
  const SRC_FAV = { ERP: "E", 智慧供应链运营平台: "运", 实物资源一体化: "实" };

  /* 办理区顶部：链接跳转显示「你在操作」，与 AI 浏览器的操作进度区分 */
  function linkBar(T) {
    if (T.done) {
      const it = find(T.id);
      const st = stOf(it);
      return `<div class="em-me-bar${st === "done" ? " fin" : ""}"><b><i></i>${ST_NAME[st]}</b><span>${h(it.current)}</span></div>`;
    }
    return `<div class="em-me-bar"><b><i></i>你在操作</b><span>AI 不操作此页面</span><button class="em-btn em-btn-p" data-em-act="link-done" ${T.busy ? "disabled" : ""}>我已办完</button></div>`;
  }

  function srcAct(T, a) {
    if (a.startsWith("pay-")) return d2Act(T, a);
    if (a.startsWith("wms-")) return d5Act(T, a);
    if (a.startsWith("z-")) return d6Act(T, a);
  }

  /* 链接跳转：用户点「我已办完」后查询源端单据状态 */
  function linkCheck(T, typed) {
    if (T.done || T.busy) return;
    if (!typed) say(T, { k: "me", text: "我已办完" });
    T.busy = true;
    const st = say(T, { k: "steps", title: "查询办理结果", items: [{ t: "查询源端单据状态…" }] });
    draw(T);
    later(T, 900, () => {
      T.busy = false;
      if (T.id === "D2") {
        const ok = T.pay.submitted;
        st.items[0] = { t: `运营平台付款申请状态：${ok ? "待部门负责人审批" : "待专责审核"}` };
        if (ok) {
          T.done = true;
          say(T, { k: "result", title: "已提交，转为待外部响应", lines: ["采购凭证 4300132824 的付款申请已提交，当前在部门负责人审批", "部门负责人审批后，这条事项办结"] });
          finish("D2", { status: "external", current: "已提交，待部门负责人审批", remain: "等待部门负责人审批", log: "运营平台提交采购凭证 4300132824 的付款申请；本人在源端办理，工作台查询确认", next: "部门负责人已收到待办" });
        } else {
          say(T, { k: "ai", html: "付款申请状态仍为待专责审核，没有查到提交记录。请在办理页面完成提交后再点「我已办完」。" });
        }
      } else if (T.id === "D6") {
        const z = T.z;
        const acc = z.st.filter((x) => x === "已受理").length;
        const all = acc === ZROWS.length;
        st.items[0] = { t: `ERP 采购申请 ${ZPR} 状态：${all ? "已受理" : acc ? `已受理 ${acc} 行，待受理 ${ZROWS.length - acc} 行` : "待受理"}` };
        if (all) {
          T.done = true;
          const lk = z.lkDone[0];
          const r = ZROWS[0];
          say(T, { k: "result", title: "已办结", lines: [`采购申请 ${ZPR} 共 ${ZROWS.length} 行已受理，进入采购计划`, lk ? `行 ${r.item} 利库 ${n3(lk)} ${r.unit}，转采购 ${n3(r.qty - lk)} ${r.unit}` : `行 ${r.item} 未平衡利库，大足库可利库 ${n3(r.avail)} ${r.unit} 未使用`] });
          finish("D6", { current: "已受理，进入采购计划", log: `ERP 受理采购申请 ${ZPR}${lk ? `，行 ${r.item} 利库 ${n3(lk)} ${r.unit}` : ""}；本人在源端办理，工作台查询确认`, next: "采购申请已进入采购计划" });
        } else {
          say(T, { k: "ai", html: `采购申请 ${ZPR} 还有 ${ZROWS.length - acc} 行待受理。请在办理页面完成后再点「我已办完」。` });
        }
      } else {
        const s = T.wms;
        st.items[0] = { t: `仓储工作台单据状态：${s.posted ? "发货完成" : s.down ? "已下架，待过账" : "待下架"}` };
        if (s.posted) {
          T.done = true;
          say(T, { k: "result", title: "已办结", lines: ["单据 TYCK0300000000002766 已过账，发货完成"] });
          finish("D5", { current: "已过账，发货完成", log: "仓储工作台单据 TYCK0300000000002766 下架并过账；本人在源端办理，工作台查询确认", next: "退役资产代保管出库已发货完成" });
        } else {
          say(T, { k: "ai", html: `单据状态为${s.down ? "已下架、未过账" : "未下架"}。请在办理页面完成后再点「我已办完」。` });
        }
      }
      draw(T);
    });
  }

  /* ---------- D3 + D4：接口调用 ---------- */

  const fed = () => !!(S.threads.D4 && S.threads.D4.sent);
  const ESC_HEAD = ["状态", "当前环节", "当前环节处理截止时间", "当前处理人", "工厂名称", "预警等级", "业务环节", "指标名称", "预警内容", "工单状态"];
  const escRow = () => [
    fed() ? "已反馈" : "待反馈",
    fed() ? "基层单位主任审批" : "待基层单位反馈",
    "2026-09-16 08:30:02",
    fed() ? "大足供电分公司主任" : "大足供电分公司物资专责",
    "国网重庆市电力公司大足供电分公司",
    "三级预警",
    "供应监察",
    "物资交付逾期",
    "未收货",
    "已发送",
  ];
  const escQuery = (q) => {
    const r = escRow();
    return q.plant !== "永川" && (q.st === "全部" || q.st === r[0]) ? [r] : [];
  };
  const pick = (attr, key, v, opts, dis = "") =>
    `<select ${attr}="${key}" ${dis}>${opts.map((o) => `<option value="${h(o)}"${o === v ? " selected" : ""}>${h(o || "请选择")}</option>`).join("")}</select>`;
  const tagOf = (st) => `<sup>${st === "me" ? "人工改写" : "AI 填"}</sup>`;

  const D3AI = { plant: "大足", st: "待反馈" };

  function d3Right(T) {
    const rows = T.res;
    const tbl = rows
      ? rows.length
        ? `<div class="em-tw"><table class="em-t"><thead><tr>${ESC_HEAD.map((c) => `<th>${h(c)}</th>`).join("")}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${h(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`
        : `<div class="em-empty">接口返回 0 条</div>`
      : `<div class="em-empty">${T.handoff ? "已转人工，未调用接口" : "正在调用接口…"}</div>`;
    const cf = (k, label, opts) => {
      const st = T.q[k] === T.aiQ[k] ? "ai" : "me";
      return `<label class="em-cf ${st}" data-cf="${k}"><span>${label}</span>${pick("data-d3", k, T.q[k], opts)}${tagOf(st)}</label>`;
    };
    return `<div class="em-api">
      <div class="em-api-h"><b>ESC 网省风险预警查询</b><span>接口调用 · 只读</span></div>
      <div class="em-api-q">
        ${cf("plant", "工厂", ["大足", "永川", "全部"])}
        ${cf("st", "状态", ["待反馈", "已反馈", "全部"])}
        <button class="em-btn em-btn-p" data-em-act="d3-query" ${T.handoff ? "disabled" : ""}>重新查询</button>
      </div>
      <div class="em-result-h"><b>返回 ${rows ? rows.length : 0} 条</b>${T.at ? `<span>调用时间 ${h(T.at)}</span>` : ""}</div>
      ${tbl}
    </div>`;
  }

  function d3Query(T, byAI) {
    T.res = escQuery(T.q);
    T.at = now();
    const txt = `调用 ESC 网省风险预警查询接口（只读）：工厂=${T.q.plant}，状态=${T.q.st}，返回 ${T.res.length} 条`;
    if (byAI) {
      say(T, { k: "steps", title: "AI 调用接口", items: [
        { t: "生成查询参数：工厂=大足", from: "事项业务对象" },
        { t: "生成查询参数：状态=待反馈", from: "事项业务对象" },
        { t: txt },
      ] });
    } else {
      say(T, { k: "steps", title: "重新查询", items: [{ t: txt }] });
    }
    if (T.res.length && !fed()) {
      say(T, {
        k: "ai",
        html: `大足有 1 条待反馈预警：<b>物资交付逾期｜未收货</b>，当前处理人为大足供电分公司物资专责，环节截止 2026-09-16 08:30:02。${S.reminded ? "提醒已发送。" : "建议提醒大足办理。"}`,
        btns: S.reminded ? [] : [["提醒大足办理", "d3-remind", "p"]],
      });
    } else if (T.res.length) {
      say(T, { k: "ai", html: "这条预警大足已反馈，当前环节：基层单位主任审批。" });
    }
    draw(T);
  }

  const RM_TEXT = "大足供电分公司物资专责：ESC 网省风险预警有 1 条「物资交付逾期｜未收货」待你反馈，环节截止 2026-09-16 08:30:02，请在工作台办理。";

  function d3Remind(T) {
    if (pending(T) || S.reminded || T.done) return;
    confirm(T, {
      title: "发送提醒",
      action: "向大足供电分公司物资专责发送工作台消息",
      edit: RM_TEXT,
      note: "调用工作台消息发送能力，消息内容可在上方修改。",
      ok: "确认发送",
      onOk: (text) => {
        S.reminded = text || RM_TEXT;
        say(T, { k: "result", title: "提醒已发送", lines: ["消息发送接口返回成功，大足供电分公司物资专责已收到提醒", "大足提交反馈后，这条线程会收到更新"] });
        finish("D3", { status: "external", current: "已提醒大足，等待反馈", remain: "等待大足反馈", log: "调用 ESC 查询接口，大足 1 条待反馈；向大足供电分公司物资专责发送提醒", next: "等待大足供电分公司反馈" });
      },
      onCancel: () => say(T, { k: "ai", html: "已取消发送。" }),
    });
  }

  /* D4：先由用户在对话框「＋附件」上传现场材料，AI 读完后按材料填写，材料没写清的项留给用户判断 */
  const D4FILES = [
    { n: "供应商延期交货说明函.pdf", size: "326 KB", time: "2026-09-15 17:20", key: "letter" },
    { n: "到货现场照片_0915.jpg", size: "2.4 MB", time: "2026-09-15 16:42", key: "photo" },
    { n: "8月仓储盘点表.xlsx", size: "88 KB", time: "2026-09-01 09:05", key: "other" },
  ];
  const D4READ = {
    letter: "10kV 箱式变电站 2 台，合同交货期 2026-09-08；供应商因硅钢片到货延迟推迟排产，2026-09-13 发货，2026-09-15 送达大足现场",
    photo: "拍摄于 2026-09-15 16:42，现场可见 10kV 箱式变电站 2 台，铭牌型号与说明函一致",
    other: "与这条预警无关，不作为依据",
  };
  const D4WHY = "供应商因硅钢片到货延迟推迟排产，10kV 箱式变电站 2 台未在合同交货期 2026-09-08 前交货，2026-09-13 发货、2026-09-15 送达大足现场，逾期 7 天。";
  const D4F = [
    { k: "cls", label: "问题分类" },
    { k: "real", label: "是否属实" },
    { k: "why", label: "问题原因反馈" },
    { k: "proof", label: "佐证材料" },
  ];
  const d4Val = (v) => (Array.isArray(v) ? v.join("、") : v || "");
  const d4St = (T, k) => {
    if (k in T.ai) return d4Val(T.c[k]) === d4Val(T.ai[k]) ? "ai" : "me";
    return d4Val(T.c[k]) ? "me" : "";
  };

  const FLOW = ["市公司下发省侧预警数据", "基层单位专责反馈", "基层单位主任审批", "物资公司业务中心审批", "物资部业务处室初审", "物资部监察处复审", "已办结"];

  function d4Right(T) {
    if (T.tab === 1) {
      return `<div class="em-api">
        <div class="em-api-h"><b>本地风险预警督办反馈审核 · 流程图</b><span>接口返回</span></div>
        <ol class="em-flow7">${FLOW.map((n, i) => `<li class="${i < 2 ? "done" : i === 2 ? "cur" : ""}"><i>${i < 2 ? "&#10003;" : i + 1}</i><span>${h(n)}</span></li>`).join("")}</ol>
      </div>`;
    }
    const c = T.c;
    const dis = !T.read || T.busy || T.done ? "disabled" : "";
    const ro = [
      ["工厂名称", "国网重庆市电力公司大足供电分公司"],
      ["指标名称", "物资交付逾期"],
      ["预警内容", "未收货"],
      ["业务环节", "供应监察"],
      ["预警等级", "三级预警"],
      ["环节截止", "2026-09-16 08:30:02"],
    ];
    const cls = (k) => {
      const st = d4St(T, k);
      return st ? ` ${st}` : "";
    };
    const tag = (k) => (!d4St(T, k) ? "" : k in T.ai ? tagOf(d4St(T, k)) : "<sup>人工填写</sup>");
    const files = c.proof.length
      ? c.proof.map((n, i) => `<span class="em-file">${h(n)}${dis ? "" : `<button data-em-act="d4-rm" data-i="${i}" aria-label="移除">&#10005;</button>`}</span>`).join("")
      : "<em>未上传</em>";
    return `<div class="em-api">
      <div class="em-api-h"><b>ESC 网省风险预警反馈</b><span>接口调用 · 提交前在对话里确认</span></div>
      <div class="em-ro">${ro.map((r) => `<div><span>${r[0]}</span><b>${h(r[1])}</b></div>`).join("")}</div>
      ${T.read ? "" : `<div class="em-wait">${T.busy ? "AI 正在读取材料…" : "上传现场排查材料后，AI 按材料填写以下各项"}</div>`}
      <div class="em-cf-grid${T.read ? "" : " em-cf-off"}">
        <label class="em-cf${cls("cls")}" data-cf="cls"><span>问题分类</span>${pick("data-d4", "cls", c.cls, ["", "业务问题", "系统问题", "数据问题"], dis)}${tag("cls")}</label>
        <div class="em-cf${cls("real")}" data-cf="real"><span>是否属实</span><div class="em-radios">${["是", "否"].map((o) => `<label><input type="radio" name="emReal" data-d4="real" value="${o}"${c.real === o ? " checked" : ""} ${dis} />${o}</label>`).join("")}</div>${tag("real")}</div>
        <label class="em-cf em-cf-wide${cls("why")}" data-cf="why"><span>问题原因反馈</span><textarea data-d4="why" rows="4" ${dis}>${h(c.why)}</textarea>${tag("why")}</label>
        <div class="em-cf em-cf-wide${cls("proof")}" data-cf="proof"><span>佐证材料</span><div class="em-files">${files}${dis ? "" : `<button class="em-btn" data-em-act="d4-add">补充材料</button>`}</div>${tag("proof")}</div>
      </div>
      <div class="em-card-foot">${T.sent ? '<span class="em-done-mark">已提交</span>' : T.handoff ? '<span class="em-done-mark">已转人工</span>' : `<button class="em-btn em-btn-w" data-em-act="d4-submit" ${T.busy ? "disabled" : ""}>提交反馈</button>`}</div>
    </div>`;
  }

  /* 本机文件选择框：for 为 chat（对话框「＋附件」）或 proof（卡片「补充材料」） */
  function pickDraw() {
    let el = $id("emPicker");
    if (!S.pick) {
      if (el) el.remove();
      return;
    }
    if (!el) {
      el = document.createElement("div");
      el.id = "emPicker";
      el.className = "em-pk";
      document.body.appendChild(el);
    }
    const sel = S.pick.sel;
    el.innerHTML = `<div class="em-pk-box" role="dialog" aria-label="打开文件">
      <header><b>打开</b><button data-pk="x" aria-label="关闭">×</button></header>
      <div class="em-pk-path">此电脑 › 桌面 › 大足预警排查</div>
      <table><thead><tr><th>名称</th><th>修改日期</th><th>大小</th></tr></thead><tbody>${D4FILES.map((f, i) => `<tr class="${sel.includes(i) ? "on" : ""}" data-pk-f="${i}"><td><i class="em-pk-ico em-pk-${f.n.split(".").pop()}"></i>${h(f.n)}</td><td>${f.time}</td><td>${f.size}</td></tr>`).join("")}</tbody></table>
      <footer><span>${sel.length ? `已选 ${sel.length} 个文件` : "按住 Ctrl 可多选"}</span><button data-pk="x">取消</button><button class="p" data-pk="ok" ${sel.length ? "" : "disabled"}>打开</button></footer>
    </div>`;
  }
  function pickOpen(kind) {
    const T = S.threads[S.open];
    if (!T || T.id !== "D4" || T.busy || T.done) return;
    S.pick = { for: kind, sel: [] };
    pickDraw();
  }
  function pickDone() {
    const T = S.threads.D4;
    const p = S.pick;
    S.pick = null;
    pickDraw();
    if (!T || !p || !p.sel.length) return;
    const files = p.sel.map((i) => D4FILES[i]);
    if (p.for === "proof") {
      files.forEach((f) => T.c.proof.includes(f.n) || T.c.proof.push(f.n));
      return right(T);
    }
    say(T, { k: "me", files: files.map((f) => f.n) });
    d4Read(T, files);
  }

  function d4Read(T, files) {
    const fresh = files.filter((f) => !T.files.some((x) => x.n === f.n));
    T.files.push(...fresh);
    if (T.read && (!fresh.some((f) => f.key === "letter") || "why" in T.ai)) {
      const add = fresh.filter((f) => f.key !== "other").map((f) => f.n);
      add.forEach((n) => T.c.proof.includes(n) || T.c.proof.push(n));
      say(T, { k: "ai", html: add.length ? `已把 ${add.map(h).join("、")} 加入佐证材料。` : fresh.length ? "这些文件与这条预警无关，没有加入佐证材料。" : "这些文件已经读过，反馈内容没有变化。" });
      return draw(T);
    }
    T.busy = true;
    const st = say(T, { k: "steps", title: "AI 读取材料", items: [] });
    draw(T);
    let t = 600;
    fresh.forEach((f) => {
      later(T, t, () => {
        st.items.push({ t: `${f.n}：${D4READ[f.key]}` });
        draw(T);
      });
      t += 800;
    });
    const has = (k) => T.files.some((f) => f.key === k);
    const proof = [...new Set([...T.c.proof, ...fresh.filter((f) => f.key !== "other").map((f) => f.n)])];
    const fill = [];
    /* 用户已自己填写的项不覆盖 */
    if (has("letter") && !T.c.cls) fill.push(["cls", "业务问题", "说明函：逾期由供应商原材料到货延迟造成"]);
    if (has("letter") && !T.c.why.trim()) fill.push(["why", D4WHY, has("photo") ? "说明函、到货现场照片" : "说明函"]);
    if (proof.length && d4Val(proof) !== d4Val(T.c.proof)) fill.push(["proof", proof, "本次上传的材料"]);
    const fs = say(T, { k: "steps", title: "AI 填写反馈", items: [] });
    fill.forEach(([k, v, from]) => {
      later(T, t, () => {
        T.c[k] = Array.isArray(v) ? [...v] : v;
        T.ai[k] = v;
        const txt = d4Val(v);
        fs.items.push({ t: `填写「${D4F.find((f) => f.k === k).label}」：${txt.length > 18 ? `${txt.slice(0, 18)}…` : txt}`, from });
        draw(T);
      });
      t += 700;
    });
    later(T, t, () => {
      T.busy = false;
      T.read = true;
      if (!fill.length) fs.items.push({ t: "材料中没有可用于反馈的内容" });
      const html = has("letter")
        ? `已按材料填好 ${fill.length} 项（黄框），每项都可以改。<br><b>「是否属实」没有填</b>：材料说明物资 9 月 15 日已送达现场，但没有 ERP 收货记录；预警内容是未收货，请你按 ERP 收货情况选择。<br>核对后点【提交反馈】，提交前我会在这里请你确认。`
        : `材料里没有说明逾期原因，问题分类和问题原因反馈没有填写。可以补充供应商的说明材料，或直接在右侧填写。`;
      say(T, { k: "ai", html });
      draw(T);
    });
  }

  function d4Submit(T) {
    if (T.done || T.busy || pending(T)) return;
    if (!T.read) {
      say(T, { k: "ai", html: "还没有收到现场材料。请先点输入框下方的「＋附件」上传，我读完后填写反馈。" });
      return;
    }
    const miss = D4F.filter((f) => f.k !== "proof" && !String(T.c[f.k] || "").trim()).map((f) => `「${f.label}」`);
    if (miss.length) {
      say(T, { k: "ai", html: `${miss.join("")}还没有填写，请补全后再提交。` });
      return;
    }
    const cut = (v) => (v && v.length > 30 ? `${v.slice(0, 30)}…` : v || "（清空）");
    const rows = D4F.map((f) => [f.label, f.k in T.ai ? cut(d4Val(T.ai[f.k])) : "—", d4St(T, f.k) === "me" || (f.k in T.ai && !d4Val(T.c[f.k])) ? cut(d4Val(T.c[f.k])) : ""]);
    confirm(T, {
      title: "提交反馈",
      action: "向 ESC 提交「物资交付逾期｜未收货」预警反馈",
      rows,
      note: "提交后进入基层单位主任审批，工作台不能撤回。",
      ok: "确认提交",
      onOk: () => {
        T.sent = true;
        T.done = true;
        T.tabs = [DEMOS.D4.tab, "流程图"];
        T.tab = 1;
        const n = rows.filter((r) => r[2]).length;
        say(T, { k: "result", title: "反馈已提交", lines: ["ESC 反馈提交接口返回成功", "当前环节：基层单位主任审批，右侧已打开流程图", n ? `本次含人工填写或改写 ${n} 项` : "AI 填写内容未经改动"] });
        finish("D4", { status: "external", current: "已反馈，待基层单位主任审批", remain: "等待主任审批", log: `ESC 提交预警反馈：问题分类 ${T.c.cls}，是否属实 ${T.c.real}，佐证材料 ${T.c.proof.length} 份${n ? `，人工填写或改写 ${n} 项` : ""}`, next: "ESC 流程：基层单位主任审批" });
        const T3 = thread("D3");
        dropPending(T3);
        T3.timers.forEach(clearTimeout);
        T3.timers = [];
        T3.aiQ = { plant: "大足", st: "全部" };
        T3.q = { ...T3.aiQ };
        T3.res = escQuery(T3.q);
        T3.at = now();
        T3.done = true;
        say(T3, { k: "result", title: "大足已反馈", lines: [`${now()} 大足供电分公司物资专责提交反馈，ESC 当前环节：基层单位主任审批`, "工作台已按工厂=大足、状态=全部重新查询，返回 1 条"] });
        finish("D3", { current: "大足已反馈，进入基层单位主任审批", log: "大足供电分公司提交反馈，ESC 进入基层单位主任审批", next: "ESC 流程：基层单位主任审批" });
      },
      onCancel: () => say(T, { k: "ai", html: "已取消提交，可以继续修改。" }),
    });
  }

  /* ---------- 线程数据 ---------- */

  function thread(id) {
    if (S.threads[id]) return S.threads[id];
    const d = DEMOS[id];
    const T = { id, mode: d.mode, msgs: [], timers: [], tabs: [d.tab], tab: 0, busy: false, done: false, cid: 0 };
    if (id === "D1") Object.assign(T, { p: "sel", f: { type: null, plan: "", pr: "", plant: "", data: null }, aiSet: {}, list: 0, row: -1, aiRow: -1, srcMsg: null, aiClick: "" });
    if (id === "D2") T.pay = { v: "", queried: false, found: false, checked: false, submitted: false, msg: null, dlg: null };
    if (id === "D5") T.wms = { down: false, posted: false, msg: null, dlg: null };
    if (id === "D3") Object.assign(T, { q: { ...D3AI }, aiQ: { ...D3AI }, res: null, at: "" });
    if (id === "D4") Object.assign(T, { c: { cls: "", real: "", why: "", proof: [] }, ai: {}, files: [], read: false, sent: false });
    if (id === "D6") T.z = zInit();
    if (SC(id)) {
      T.tabs = (SC(id).tabs || [d.tab]).slice();
      SC(id).init && SC(id).init(T);
    }
    S.threads[id] = T;
    snap(id);
    intro(T);
    return T;
  }

  function intro(T) {
    if (T.id === "D1") {
      say(T, { k: "ai", html: "这条事项在 ERP 网页版 ZMM20188 办理，页面已在右侧打开。我会按事项填写 5 项查询条件，填好后停下，等你核对、修改后再点【执行】；查询后我在结果中定位采购申请 3800530813，再点【批准】。<br>批准会改 ERP 数据，执行前我会在这里请你确认。", btns: [["开始办理", "d1-start", "p"]] });
    } else if (T.id === "D2") {
      say(T, { k: "ai", html: "这条事项在智慧供应链运营平台「付款申请管理-专责审核」办理，页面已在右侧打开，页面上的内容由你填写和提交。办完后点办理区上方的【我已办完】，我查询单据状态确认。" });
      say(T, { k: "advice", html: "在「采购凭证号」填 <b class=\"em-mono\">4300132824</b>，点【查询】，勾选结果后点【批量提交】", copy: "4300132824", warn: "提交后进入部门负责人审批，不能撤回。" });
    } else if (T.id === "D5") {
      say(T, { k: "ai", html: "这条事项在实物资源一体化「仓储工作台」办理，出库单详情已在右侧打开，下架和过账由你在页面上操作。办完后点办理区上方的【我已办完】，我查询单据状态确认。" });
      say(T, { k: "advice", html: "核对单据号 <b class=\"em-mono\">TYCK0300000000002766</b>；现场下架完成后点明细行的【下架】，再点【提交过账】", copy: "TYCK0300000000002766", warn: "过账后发货完成，不能撤回。" });
    } else if (T.id === "D6") {
      say(T, { k: "ai", html: `这条事项在 ERP「ZMM20012 采购申请受理及平衡利库--基层」办理，选择屏已在右侧打开，受理由你在页面上操作。受理前我先查了大足的库存，给出利库建议。` });
      const st = say(T, { k: "chain", items: [] });
      const push = (ms, row) =>
        later(T, ms, () => {
          st.items.push(row);
          left(T);
        });
      push(500, { a: "查数据", t: `读取待办：采购申请 ${ZPR}，需求工厂 大足，共 2 行，今日 17:00 前受理`, from: "ERP 待办", cap: "查询" });
      push(1200, { a: "查数据", t: "查询本单位库存：行 10 电力电缆 YJV22 3×300 库存可用 0.8 KM；行 20 柱上断路器 630A 库存可用 0 台", from: "ERP 库存查询（同物料号）", cap: "查询" });
      push(1900, { a: "按规则", t: "规则“库存有的先用库存，差额转采购”：行 10 利库 0.8 KM、0.4 KM 转采购；行 20 全部转采购", from: "规则库 · 平衡利库", cap: "分析" });
      push(2600, { a: "交给人", t: "受理后进入采购计划，不能撤回，由本人在 ERP 中操作", warn: true });
      later(T, 3000, () => {
        say(T, {
          k: "advice",
          html: `在选择屏「采购申请号」填 <b class="em-mono">${ZPR}</b>，执行后在行 10 填「利库数量」0.800，只勾选行 10 点【平衡利库】，再勾选两行点【受理】`,
          copy: ZPR,
          table: { head: ["行", "物料", "申请数量", "可用库存", "建议利库", "转采购"], rows: [["10", "电力电缆 YJV22 3×300", "1.200 KM", "0.800 KM", "0.800 KM", "0.400 KM"], ["20", "柱上断路器 630A", "3 台", "0 台", "0", "3 台"]] },
          warn: "受理后进入采购计划，不能撤回。办完后点办理区上方的【我已办完】。",
        });
      });
    } else if (T.id === "D3") {
      say(T, { k: "ai", html: "这条事项通过 ESC 查询接口办理，不打开 ESC 页面。我按事项生成查询条件并调用接口，右侧的条件可以修改后重新查询。" });
      later(T, 500, () => d3Query(T, true));
    } else if (SC(T.id)) {
      SC(T.id).intro && SC(T.id).intro(T);
    } else if (T.id === "D4") {
      say(T, { k: "ai", html: "这条预警通过 ESC 反馈接口提交，不打开 ESC 页面。请点输入框下方的「＋附件」上传现场排查材料（供应商说明、到货照片等），我读完后按材料填写右侧反馈，每一项都可以改，提交前在这里请你确认。" });
    }
  }

  function say(T, m) {
    T.msgs.push(m);
    if (m.k === "chain") m.t0 = Date.now();
    if (STREAM_K[m.k] && !m.instant) queueStream(T, m);
    if (S.open === T.id) left(T);
    return m;
  }

  /* ---------- 流式输出（V90）：智能体回复先显示「思考中」，再逐字出现；正在输出时，后面的消息和按钮先不出现 ---------- */
  const STREAM_K = { ai: 1, card: 1, result: 1, advice: 1 };
  const streamText = (m) => (m.k === "result" ? m.lines.map((l) => `<p>${h(l)}</p>`).join("") : m.html || "");
  const textLen = (x) => x.replace(/<[^>]*>/g, "").replace(/&[#\w]+;/g, "x").length;
  function cut(x, n) {
    let out = "", c = 0, i = 0;
    while (i < x.length && c < n) {
      const ch = x[i];
      if (ch === "<") { const j = x.indexOf(">", i); out += x.slice(i, j + 1); i = j + 1; continue; }
      if (ch === "&") { const j = x.indexOf(";", i); if (j > i && j - i < 10) { out += x.slice(i, j + 1); i = j + 1; c += 1; continue; } }
      out += ch; i += 1; c += 1;
    }
    return out;
  }
  const streaming = (T) => !!(T.sq && T.sq.length);
  function queueStream(T, m) {
    m.typing = true;
    m.shown = 0;
    m.pre = true;
    T.sq = T.sq || [];
    T.sq.push(m);
    runStream(T);
  }
  /* 同一线程同一时刻只有一个输出进程，避免两条计时链同时推进同一条消息 */
  function runStream(T) {
    if (T.sRun) return;
    const m = T.sq && T.sq[0];
    if (!m) { if (S.open === T.id) draw(T); return; }
    T.sRun = true;
    const total = textLen(streamText(m));
    const dur = Math.max(400, Math.min(3000, (total / 70) * 1000));
    const step = Math.max(2, Math.ceil(total / (dur / 30)));
    const tick = () => {
      m.shown += step;
      if (m.shown >= total) {
        m.typing = false;
        T.sq.shift();
        if (S.open === T.id) draw(T);
        setTimeout(() => { T.sRun = false; runStream(T); }, 120);
        return;
      }
      if (S.open === T.id) left(T);
      setTimeout(tick, 30);
    };
    setTimeout(() => { m.pre = false; tick(); }, m.k === "ai" ? 520 : 320);
  }
  function later(T, ms, fn) {
    T.timers.push(setTimeout(fn, ms));
  }
  const pending = (T) => T.msgs.some((m) => m.k === "confirm" && m.state === "wait");

  function confirm(T, c) {
    T.cid += 1;
    say(T, Object.assign({ k: "confirm", state: "wait", cid: T.cid }, c));
  }

  /* ---------- 渲染 ---------- */

  /* 任务线程画在首页对话 #view-chat 内，沿用原输入框；打开时把 .composer-wrap 移入线程对话栏，关闭时移回 */
  function host() {
    let el = $id("emThread");
    if (!el) {
      const view = $id("view-chat");
      if (!view) return null;
      el = document.createElement("div");
      el.id = "emThread";
      el.className = "em-thread";
      view.appendChild(el);
    }
    return el;
  }

  const composer = () => document.querySelector(".composer-wrap");
  function composerHome() {
    const cw = composer();
    const view = $id("view-chat");
    if (!cw || !view || cw.parentNode === view) return;
    view.insertBefore(cw, $id("emThread"));
  }

  function head() {
    const T = S.threads[S.open];
    const el = $id("emThreadHead");
    if (!T || !el) return;
    const it = find(T.id);
    const st = stOf(it);
    el.innerHTML = `<div class="em-th-l">
        ${SC(T.id) && SC(T.id).home ? "" : '<button class="em-th-back" data-em-act="close" title="返回">‹</button>'}
        ${SC(T.id) && SC(T.id).home ? `<div><h3>智能助手</h3><p><span>${h(SC(T.id).headNote || "")}</span></p></div>` : `<div><h3>${h(it.title)}</h3><p>${MODES[T.mode] ? `<span class="em-badge em-badge-${T.mode}">${MODES[T.mode].name}</span>` : ""}${it.entry ? `<span>${h(it.entry.sys)} · <span class="em-mono">${h(it.entry.menu)}</span></span>` : ""}<span class="em-st em-st-${st}"><i class="em-dot em-dot-${st}"></i>${ST_NAME[st]}｜${h(it.current)}</span></p></div>`}
      </div>
      <div class="em-th-r">
        ${S.work === "closed" ? `<button class="em-btn" data-em-work="open">打开${paneName(T)}</button>` : ""}
        ${T.done || T.mode === "chat" || T.mode === "scene" ? "" : '<button class="em-btn" data-em-act="human">转人工</button>'}
      </div>`;
  }

  /* 右侧区域的叫法：源端页面和接口结果叫办理区，工作台生成的内容叫画布 */
  const paneName = (T) => (SC(T.id) && SC(T.id).pane) || "办理区";

  /* 思维链：每行写明动作（查数据、按规则、得结论、交给人）、内容、依据和用到的能力 */
  /* 能力调用行（V90 10.19 重做）：{say} 智能体自述打算；{grp} 专业组合能力分组；{cap, call, t, ms, pending} 调用一项原子能力，
     调用中显示转圈，返回后显示结论和用时；旧行 {a, t, from, cap} 照旧显示 */
  function chainHtml(m) {
    if (!m.live && m.t0 && !m.t1) m.t1 = Date.now();
    let n = 0;
    const calls = m.items.filter((s) => s.call).length;
    const rows = m.items
      .map((s, i) => {
        if (s.say) return `<li class="say"><p>${s.html || h(s.say)}</p></li>`;
        if (s.grp) return `<li class="grp"><span>专业组合能力</span><b>${h(s.grp)}</b>${s.note ? `<small>${h(s.note)}</small>` : ""}</li>`;
        if (s.call && s.pending) return `<li class="run"><i></i><div><p><em class="em-cap">${h(s.cap)}</em><span class="em-call">正在调用 ${h(s.call)}…</span></p></div></li>`;
        n += 1;
        if (s.call)
          return `<li class="${s.warn ? "warn" : ""}"><i>${n}</i><div><p><em class="em-cap">${h(s.cap)}</em><span class="em-call">${h(s.call)}</span>${s.html || h(s.t)}</p><small>${s.from ? `依据：${h(s.from)}` : ""}${s.ms ? `<em>用时 ${(s.ms / 1000).toFixed(1)} 秒</em>` : ""}</small></div></li>`;
        const run = m.live && i === m.items.length - 1 && !calls;
        return `<li class="${s.warn ? "warn" : ""}${s.a === "交给人" ? " hand" : ""}${run ? " run" : ""}"><i>${run ? "" : n}</i><div><p><b>${h(s.a)}</b>${s.html || h(s.t)}</p>${s.from || s.cap ? `<small>${s.from ? `依据：${h(s.from)}` : ""}${s.cap ? `<em>${h(s.cap)}</em>` : ""}</small>` : ""}</div></li>`;
      })
      .join("");
    const sum = calls ? `调用 ${calls} 项能力` : `${n} 步`;
    return `<div class="em-m em-m-card em-chain"><h5>${h(m.title || "思维链")}${m.live ? '<span class="em-chain-live">进行中</span>' : m.t1 ? `<span class="em-chain-done">已完成 · ${sum} · 用时 ${Math.max(1, Math.round((m.t1 - m.t0) / 1000))} 秒</span>` : ""}</h5><ol>${rows}</ol></div>`;
  }

  function msgHtml(T, m) {
    if (m.typing && m.pre) return `<div class="em-m em-m-ai em-typing"><i class="em-ava-ai">AI</i><div class="em-m-body"><span class="em-dots"><i></i><i></i><i></i></span></div></div>`;
    if (m.typing) {
      const part = `${cut(streamText(m), m.shown)}<span class="em-caret"></span>`;
      if (m.k === "ai") return `<div class="em-m em-m-ai"><i class="em-ava-ai">AI</i><div class="em-m-body"><p>${part}</p></div></div>`;
      const cls = m.k === "result" ? "em-result-card" : m.k === "advice" ? "em-advice" : m.cls || "";
      return `<div class="em-m em-m-card ${cls}"><h5>${h(m.k === "advice" ? "建议" : m.title)}</h5>${m.k === "result" ? part : `<div>${part}</div>`}</div>`;
    }
    const btns = (m.btns || []).length
      ? `<div class="em-m-btns">${m.btns.map((b) => `<button class="em-btn${b[2] === "p" ? " em-btn-p" : ""}" data-em-act="${b[1]}" ${T.busy || T.done || streaming(T) || usedBtn(T, b[1]) ? "disabled" : ""}>${h(b[0])}</button>`).join("")}</div>`
      : "";
    if (m.k === "me")
      return `<div class="em-m em-m-me${m.files ? " em-m-up" : ""}">${m.files ? `<div class="em-m-files">${m.files.map((n) => `<span class="em-mfile"><i class="em-pk-ico em-pk-${n.split(".").pop()}"></i>${h(n)}</span>`).join("")}</div>` : `<p>${h(m.text)}</p>`}</div>`;
    if (m.k === "ai") return `<div class="em-m em-m-ai"><i class="em-ava-ai">AI</i><div class="em-m-body"><p>${m.html}</p>${btns}</div></div>`;
    if (m.k === "tip") return `<div class="em-m em-m-tip">${m.html}</div>`;
    /* 场景自绘的卡片：html 可以是函数，每次重绘时按当前状态生成 */
    if (m.k === "raw") return typeof m.html === "function" ? m.html(T) : m.html;
    if (m.k === "chain") return chainHtml(m);
    if (m.k === "card") return `<div class="em-m em-m-card ${m.cls || ""}"><h5>${h(m.title)}</h5>${m.html}${btns}</div>`;
    if (m.k === "advice") {
      const tbl = m.table ? `<table class="em-ct em-adv-t"><thead><tr>${m.table.head.map((x) => `<th>${h(x)}</th>`).join("")}</tr></thead><tbody>${m.table.rows.map((r) => `<tr>${r.map((x) => `<td>${h(x)}</td>`).join("")}</tr>`).join("")}</tbody></table>` : "";
      return `<div class="em-m em-m-card em-advice"><h5>建议</h5><p>${m.html}${m.copy ? ` <button class="em-copy" data-em-copy="${h(m.copy)}">复制</button>` : ""}</p>${tbl}${m.warn ? `<p class="em-warn">${h(m.warn)}</p>` : ""}${btns}</div>`;
    }
    if (m.k === "steps")
      return `<div class="em-m em-m-card em-steps"><h5>${h(m.title)}</h5><ol>${m.items.map((s) => `<li><span>${h(s.t)}</span>${s.from ? `<small>依据：${h(s.from)}</small>` : ""}</li>`).join("")}</ol></div>`;
    if (m.k === "result")
      return `<div class="em-m em-m-card em-result-card"><h5>${h(m.title)}</h5>${m.lines.map((l) => `<p>${h(l)}</p>`).join("")}</div>`;
    if (m.k === "confirm") {
      const wait = m.state === "wait";
      const tbl = m.rows
        ? `<table class="em-ct"><thead><tr><th>项</th><th>AI 值</th><th>人工值</th></tr></thead><tbody>${m.rows.map((r) => `<tr class="${r[2] ? "me" : ""}"><td>${h(r[0])}</td><td>${h(r[1])}</td><td>${r[2] ? h(r[2]) : "—"}</td></tr>`).join("")}</tbody></table>`
        : "";
      const edit = m.edit != null ? (wait ? `<textarea class="em-ct-edit" data-rm-text rows="4">${h(m.editVal ?? m.edit)}</textarea>` : `<p class="em-ct-msg">${h(m.editVal ?? m.edit)}</p>`) : "";
      return `<div class="em-m em-m-card em-confirm-card ${m.state}">
        <h5>需要你确认：${h(m.title)}</h5>
        <p class="em-ct-act">${h(m.action)}</p>
        ${tbl}${edit}
        ${m.warn ? `<p class="em-warn">${h(m.warn)}</p>` : ""}
        <p class="em-sub">${h(m.note)}</p>
        ${wait ? `<div class="em-m-btns"><button class="em-btn" data-em-act="c-no" data-cid="${m.cid}">取消</button><button class="em-btn em-btn-w" data-em-act="c-ok" data-cid="${m.cid}">${h(m.ok)}</button></div>` : `<p class="em-ct-state">${m.state === "ok" ? `已确认 · ${h(m.at)}` : `已取消 · ${h(m.at)}`}</p>`}
      </div>`;
    }
    return "";
  }

  /* 「开始办理」「提醒大足办理」只能点一次 */
  function usedBtn(T, a) {
    if (SC(T.id)) return SC(T.id).used ? !!SC(T.id).used(T, a) : false;
    if (a === "d1-start") return !!T.aiSet.type;
    if (a === "d1-exec") return T.p !== "sel";
    if (a === "d3-remind") return !!S.reminded || pending(T);
    return false;
  }

  function visibleMsgs(T) {
    const out = [];
    for (const m of T.msgs) {
      out.push(msgHtml(T, m));
      if (m.typing) break;
    }
    return out.join("");
  }
  function left(T) {
    const box = $id("emThreadMsgs");
    if (!box) return;
    const it = find(T.id);
    const bg = [
      ["业务对象", it.object],
      ["当前环节", it.current],
      ["时限", `${it.deadline}｜${it.remain}`],
      ["风险", it.risk],
      ["办理方式", DEMOS[T.id].why],
    ];
    if (SC(T.id) && SC(T.id).bg) {
      const rows = SC(T.id).bg(T);
      bg.length = 0;
      rows.forEach((r) => bg.push(r));
    }
    const rm = T.id === "D4" && S.reminded ? `<p class="em-bg-rm"><b>物资公司管理人员提醒：</b>${h(S.reminded)}</p>` : "";
    box.innerHTML = `${bg.length ? `<div class="em-m em-m-card em-bg"><h5>事项背景</h5>${bg.map((r) => `<div><span>${r[0]}</span><b>${h(r[1])}</b></div>`).join("")}${rm}</div>` : ""}${visibleMsgs(T)}`;
    box.scrollTop = box.scrollHeight;
    requestAnimationFrame(() => (box.scrollTop = box.scrollHeight));
  }

  function right(T) {
    const box = $id("emThreadWork");
    if (!box || S.open !== T.id) return;
    const el = $id("emThread");
    ["open", "rail", "full", "closed"].forEach((k) => el.classList.toggle(`em-w-${k}`, S.work === k));
    /* AI 在页面上操作时，办理区加描边 */
    box.classList.toggle("em-ai-live", T.mode === "agent" && T.busy && S.work !== "closed");
    if (!SC(T.id) || S.work !== "open" && S.work !== "full") box.dataset.sig = "";
    if (S.work === "closed") {
      box.innerHTML = "";
      return;
    }
    if (S.work === "rail") {
      const st = stOf(find(T.id));
      box.innerHTML = `<button class="em-rail" data-em-work="open" title="展开${paneName(T)}"><span>▣</span><b>${paneName(T)}</b><em class="em-st-${st}">${ST_NAME[st]}</em></button>`;
      return;
    }
    /* 同一事项重绘时保留源端页面的滚动位置 */
    const keep = box.dataset.id === T.id && box.querySelector(".em-work-body");
    const pos = keep ? [keep.scrollTop, keep.scrollLeft] : [0, 0];
    const full = S.work === "full";
    const acts = SC(T.id) && SC(T.id).layout === "board" ? "" : `<div class="em-work-acts"><button data-em-work="${full ? "open" : "full"}">${full ? "退出全屏" : "全屏"}</button><button data-em-work="rail">收起</button><button data-em-work="closed" title="关闭${paneName(T)}">关闭</button></div>`;
    if (SC(T.id)) {
      const body = SC(T.id).right(T);
      const sig = `${T.id}|${T.tab}|${S.work}|${T.tabs.join(",")}|${body}`;
      if (box.dataset.sig === sig) return;
      T.genSeen = T.genSeen || {};
      const gen = T.genSeen[T.tab] !== body;
      T.genSeen[T.tab] = body;
      box.innerHTML = `<header class="em-work-head"><div class="em-tabs">${T.tabs
        .map((t, i) => `<button class="${i === T.tab ? "on" : ""}" data-em-tab="${i}">${h(t)}</button>`)
        .join("")}</div>${acts}</header><div class="em-work-body em-scene">${body}</div>`;
      box.dataset.sig = sig;
      if (gen) genIn(box.querySelector(".em-work-body"));
    } else if (T.mode === "link") {
      const it = find(T.id);
      box.innerHTML = `<header class="em-work-head em-work-head-src"><div class="em-src-addr"><i>${SRC_FAV[it.entry.sys] || "页"}</i><span>${h(it.entry.sys)} / ${h(it.entry.menu)}</span></div>${acts}</header>
      ${linkBar(T)}<div class="em-work-pane"><div class="em-work-body em-work-src">${SRC_PAGE[T.id](T)}</div></div>`;
      /* 源端弹窗盖在办理区可视范围中央，不随宽页面滚出视野 */
      const dlg = box.querySelector(".em-work-src .em-dlg");
      if (dlg) {
        dlg.classList.toggle("em-dlg-sap", !!dlg.closest(".em-sap"));
        box.querySelector(".em-work-pane").appendChild(dlg);
      }
    } else {
      const body = { D1: d1Right, D3: d3Right, D4: d4Right }[T.id](T);
      box.innerHTML = `<header class="em-work-head">${T.mode === "agent" ? '<span class="em-ai-chip">AI 浏览器</span>' : ""}<div class="em-tabs">${T.tabs
        .map((t, i) => `<button class="${i === T.tab ? "on" : ""}" data-em-tab="${i}">${h(t)}</button>`)
        .join("")}</div>${acts}</header>
      ${T.mode === "agent" ? d1Bar(T) : ""}<div class="em-work-body">${body}</div>`;
    }
    box.dataset.id = T.id;
    const pg = box.querySelector(".em-work-body");
    [pg.scrollTop, pg.scrollLeft] = pos;
  }

  /* 画布内容更新时逐块浮现、条形从左往右长出（V90） */
  function genIn(pg) {
    if (!pg) return;
    const parts = pg.querySelectorAll(".sc-ph, .sc-kpi, .sc-sec > h4, .sc-sec > p, .sc-kv > div, .v90-bar, .v90-report > *, .sc-t tbody tr, .v90-track, .sc-foot, .sc-empty");
    parts.forEach((el, i) => { el.classList.add("em-gen-in"); el.style.animationDelay = `${Math.min(i * 35, 1200)}ms`; });
    setTimeout(() => parts.forEach((el) => el.classList.remove("em-gen-in")), 1900);
  }

  /* 办理区宽度：默认占线程宽度 52%，拖动后记住；上下限沿用应急画布（workspace-layout.js） */
  const WKEY = "em-work-width";
  function workLimit(total) {
    const side = total < 1080 ? 280 : 320;
    return [360, Math.max(360, Math.min(0.82 * total, total - side - 16))];
  }
  function workWidth(w, save) {
    const el = $id("emThread");
    if (!el) return;
    const total = el.getBoundingClientRect().width;
    if (!total) return;
    let v = w;
    if (!v) {
      try {
        v = Number(localStorage.getItem(WKEY)) || 0;
      } catch (_) {
        v = 0;
      }
    }
    if (!v) v = Math.round(total * 0.52);
    const [lo, hi] = workLimit(total);
    v = Math.round(Math.max(lo, Math.min(hi, v)));
    el.style.setProperty("--em-work-w", `${v}px`);
    if (save) {
      try {
        localStorage.setItem(WKEY, String(v));
      } catch (_) {
        /* 本地存储不可用时只在本次生效 */
      }
    }
  }
  function setWork(k) {
    const T = S.threads[S.open];
    if (!T) return;
    S.work = k;
    right(T);
    head();
    if (k === "open") workWidth();
  }

  function draw(T) {
    if (S.open !== T.id) return;
    left(T);
    right(T);
    head();
  }

  function render() {
    const T = S.threads[S.open];
    const el = host();
    if (!T || !el) return;
    composerHome();
    el.innerHTML = `<div class="em-th-chat">
        <header class="em-th-head" id="emThreadHead"></header>
        <div class="em-th-msgs" id="emThreadMsgs"></div>
        <div class="em-th-compose" id="emThreadCompose"></div>
      </div>
      <div class="em-split canvaslayout-canvas-splitter" data-em-split title="左右拖动调整宽度，双击恢复默认" role="separator" aria-orientation="vertical" aria-label="调整对话与办理区宽度"><div class="canvaslayout-splitter-knob"><span class="canvaslayout-splitter-dots"></span><span class="canvaslayout-splitter-text">拖动</span></div></div>
      <aside class="em-th-work" id="emThreadWork"></aside>`;
    el.classList.toggle("em-board", !!(SC(T.id) && SC(T.id).layout === "board"));
    const cw = composer();
    if (cw) $id("emThreadCompose").appendChild(cw);
    const inp = $id("chatInput");
    if (inp) inp.placeholder = (SC(T.id) && SC(T.id).placeholder) || "就这条事项提问，例如：办到哪了";
    draw(T);
    workWidth();
  }

  function openThread(id) {
    const d = DEMOS[id];
    const it = find(id);
    if (!d || !it) return false;
    if (d.who !== "*" && d.who !== S.who) {
      toast(`这条事项属于「${USERS[d.who].name}」，请先在左下角切换账号`);
      return true;
    }
    const el = host();
    if (!el) return false;
    if (st8() && st8().view !== "chat" && typeof window.setView === "function") {
      S.opening = true;
      window.setView("chat");
      S.opening = false;
    }
    const fresh = !S.threads[id];
    thread(id);
    if (fresh) conv(id);
    if (S.open !== id) S.work = "open";
    const s = st8();
    if (s && s.briefnavHome && s.briefnavHome.level !== "closed") {
      if (typeof briefnavClose === "function") briefnavClose();
      else {
        s.briefnavHome.level = "closed";
        if (typeof window.homeBriefRefresh === "function") window.homeBriefRefresh();
      }
    }
    document.body.classList.add("em-open");
    $id("view-chat").classList.add("em-mode");
    const crumb = $id("crumb");
    if (!S.open && crumb) S.crumb = crumb.innerHTML;
    S.open = id;
    el.classList.add("on");
    if (crumb) crumb.innerHTML = `<b>智慧工作台</b> / ${d.mode === "chat" ? "对话" : "任务线程"} / ${h(it.title)}`;
    render();
    recent();
    return true;
  }
  window.execThreadOpen = openThread;

  function closeThread() {
    if (!S.open) return;
    S.open = "";
    document.body.classList.remove("em-open");
    $id("view-chat")?.classList.remove("em-mode");
    composerHome();
    const inp = $id("chatInput");
    if (inp) inp.placeholder = "向智慧工作台发送消息…";
    const el = $id("emThread");
    if (el) {
      el.classList.remove("on", "em-board");
      el.innerHTML = "";
    }
    const crumb = $id("crumb");
    if (crumb && S.crumb) crumb.innerHTML = S.crumb;
    recent();
  }

  /* ---------- 最近对话：任务线程 ---------- */

  /* 任务线程同时记入 state.conversations，类型「任务线程」，在「全部对话」里可查 */
  function conv(id) {
    const s = st8();
    if (!s || !Array.isArray(s.conversations) || s.conversations.some((c) => c.emThread === id)) return;
    s.conversations.unshift({ title: find(id).title, type: DEMOS[id].mode === "chat" ? "普通对话" : "任务线程", time: `今天 ${now()}`, messages: 0, live: true, emThread: id });
  }
  function convSync() {
    const s = st8();
    if (!s || !Array.isArray(s.conversations)) return;
    s.conversations.forEach((c) => {
      const T = c.emThread && S.threads[c.emThread];
      if (!T) return;
      c.messages = T.msgs.length;
      c.live = stOf(find(c.emThread)) !== "done";
    });
    if (typeof window.renderChatTable === "function") {
      try {
        window.renderChatTable();
      } catch (_) {
        /* 全部对话页未渲染时忽略 */
      }
    }
  }

  function recent() {
    const box = $id("recentList");
    if (!box) return;
    convSync();
    box.querySelectorAll(".em-recent-group").forEach((x) => x.remove());
    const s = st8();
    box.querySelectorAll("[data-recent]").forEach((b) => {
      if (s && s.conversations && s.conversations[+b.dataset.recent]?.emThread) b.remove();
    });
    const ids = Object.keys(S.threads).filter((id) => mine(id));
    if (!ids.length) return;
    const html = ids
      .map((id) => {
        const it = find(id);
        const st = stOf(it);
        return `<button class="recent-item em-recent${S.open === id ? " active" : ""}" data-em-thread="${id}"><span class="em-recent-t"><i class="em-dot em-dot-${st}"></i><span>${h(it.title)}</span></span><span class="recent-meta">${DEMOS[id].mode === "chat" ? "对话" : "任务线程"} · ${ST_NAME[st]}</span></button>`;
      })
      .join("");
    box.insertAdjacentHTML(
      "afterbegin",
      `<div class="em-recent-group${S.fold ? " fold" : ""}"><button class="em-recent-h" data-em-fold aria-expanded="${!S.fold}" title="${S.fold ? "展开" : "收起"}"><span>任务线程</span><em>${ids.length}</em><i>▾</i></button><div class="em-recent-items">${html}</div></div>`,
    );
  }

  if (typeof window.renderRecent === "function") {
    const baseRecent = window.renderRecent;
    window.renderRecent = function (...args) {
      const r = baseRecent.apply(this, args);
      recent();
      return r;
    };
  }
  if (typeof window.setView === "function") {
    const baseSetView = window.setView;
    window.setView = function (...args) {
      if (!S.opening) closeThread();
      return baseSetView.apply(this, args);
    };
  }

  /* ---------- 左下角账号 ---------- */

  function userBox() {
    const bottom = document.querySelector(".sidebar-bottom");
    if (!bottom) return;
    if (!$id("emUserBtn")) {
      bottom.insertAdjacentHTML(
        "afterbegin",
        '<div class="em-user-wrap"><div class="em-user-menu" id="emUserMenu"></div><button class="em-user" id="emUserBtn" title="切换账号"></button></div>',
      );
    }
    const u = USERS[S.who];
    $id("emUserBtn").innerHTML = `<span class="em-ava">${u.ava}</span><span class="em-user-copy side-text"><b>${h(u.name)}</b><small>${h(u.unit)}</small></span><em class="side-text">切换</em>`;
    $id("emUserMenu").innerHTML = `<p>切换账号</p>${USER_GROUPS.map(
      ([g, ks]) =>
        `<h6>${h(g)}</h6>${ks.map((k) => `<button class="${k === S.who ? "on" : ""}" data-em-who="${k}"><span class="em-ava">${USERS[k].ava}</span><span class="em-user-copy"><b>${h(USERS[k].name)}</b><small>${h(USERS[k].unit)}</small></span></button>`).join("")}`,
    ).join("")}`;
  }

  function switchWho(k) {
    $id("emUserMenu")?.classList.remove("on");
    if (k === S.who || !USERS[k]) return;
    S.who = k;
    S.pick = null;
    pickDraw();
    closeThread();
    const s = st8();
    if (s) {
      if (s.homebriefBrief) Object.assign(s.homebriefBrief, { root: "summary", filter: "all", category: "", task: "" });
      if (s.briefnavHome) s.briefnavHome.level = "summary";
    }
    userBox();
    if (typeof window.setView === "function") window.setView("chat");
    if (typeof window.homeBriefRefresh === "function") window.homeBriefRefresh();
    if (typeof window.renderRecent === "function") window.renderRecent();
    else recent();
    toast(`已切换为「${USERS[k].name}」`);
  }

  function boot() {
    userBox();
  }

  /* 供场景线程使用的接口 */
  window.EM = {
    S, USERS, h, now, say, later, confirm, draw, left, right, head, finish, toast, find, pending, openThread, cut, textLen,
    register(id, def, item) {
      DEMOS[id] = { mode: def.mode || "api", who: def.who, tab: (def.tabs || ["画布"])[0], why: def.why || "" };
      if (item) LOCAL[id] = item;
    },
    refreshHome() {
      if (typeof window.homeBriefRefresh === "function") window.homeBriefRefresh();
    },
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  /* ---------- 事件 ---------- */

  function act(a, el) {
    if (a === "close") {
      closeThread();
      if (typeof window.setView === "function") window.setView("chat");
      return;
    }
    const T = S.threads[S.open];
    if (!T) return;
    if (T.handoff && /^d[1-4]-/.test(a)) return;
    if (/^s-/.test(a)) return SC(T.id) && SC(T.id).act ? SC(T.id).act(T, a, el) : null;
    if (a === "d1-start") return T.busy || T.aiSet.type ? null : d1Start(T);
    if (a === "d1-exec") {
      if (T.busy || T.p !== "sel") return;
      T.srcMsg = null;
      dropPending(T);
      say(T, { k: "me", text: "点【执行】" });
      return d1Exec(T);
    }
    if (a === "d1-approve") return T.busy ? null : d1Approve(T);
    if (a === "d1-back") {
      if (T.busy) return;
      T.p = "sel";
      if (!T.done) T.stage = 1;
      T.srcMsg = null;
      T.aiClick = "";
      dropPending(T);
      return draw(T);
    }
    if (a === "link-done") return linkCheck(T);
    if (/^(pay|wms|z)-/.test(a)) return srcAct(T, a);
    if (a === "d3-query") return d3Query(T, false);
    if (a === "d3-remind") return d3Remind(T);
    if (a === "d4-rm") {
      T.c.proof.splice(Number(el.dataset.i), 1);
      return right(T);
    }
    if (a === "d4-add") return pickOpen("proof");
    if (a === "d4-submit") return d4Submit(T);
    if (a === "human") {
      if (pending(T) || T.done) return;
      return confirm(T, {
        title: "转人工",
        action: "把这条事项转交人工办理",
        note: "事项信息、已办步骤和源端入口一并交给承接人。",
        ok: "确认转人工",
        onOk: () => {
          T.timers.forEach(clearTimeout);
          T.busy = false;
          T.done = true;
          T.handoff = true;
          if (T.id === "D1") T.aiClick = "";
          say(T, { k: "result", title: "已转人工", lines: ["承接人已收到待办"] });
          finish(T.id, { status: "external", current: "已转人工办理", remain: "等待人工办理", log: "转人工办理", next: "承接人已收到待办" });
        },
        onCancel: () => {},
      });
    }
    if (a === "c-ok" || a === "c-no") {
      const m = T.msgs.find((x) => x.k === "confirm" && x.cid === Number(el.dataset.cid));
      if (!m || m.state !== "wait") return;
      const ta = $id("emThreadMsgs")?.querySelector("[data-rm-text]");
      if (ta) m.editVal = ta.value.trim() || m.edit;
      m.state = a === "c-ok" ? "ok" : "cancel";
      m.at = now();
      if (a === "c-ok") m.onOk(m.editVal);
      else m.onCancel();
      return draw(T);
    }
  }

  document.addEventListener(
    "click",
    (ev) => {
      const t = ev.target;
      if (!t || !t.closest) return;
      const stop = () => {
        ev.preventDefault();
        ev.stopPropagation();
      };
      let el;
      if (t.closest("#emPicker")) {
        stop();
        const p = S.pick;
        if (!p) return;
        if ((el = t.closest("[data-pk-f]"))) {
          const i = Number(el.dataset.pkF);
          if (ev.ctrlKey || ev.metaKey) p.sel = p.sel.includes(i) ? p.sel.filter((x) => x !== i) : [...p.sel, i].sort();
          else p.sel = [i];
          if (ev.detail === 2) return pickDone();
          return pickDraw();
        }
        if ((el = t.closest("[data-pk]"))) {
          if (el.dataset.pk === "ok") return el.disabled ? null : pickDone();
          S.pick = null;
          return pickDraw();
        }
        if (!t.closest(".em-pk-box")) {
          S.pick = null;
          pickDraw();
        }
        return;
      }
      /* 事项 D4 的线程里，对话框「＋ 附件」打开本机文件选择 */
      if (S.open === "D4" && t.closest(".tool-btn") && /附件/.test(t.closest(".tool-btn").textContent)) {
        stop();
        pickOpen("chat");
        return;
      }
      if (t.closest("#emUserBtn")) {
        stop();
        $id("emUserMenu")?.classList.toggle("on");
        return;
      }
      if ((el = t.closest("[data-em-who]"))) {
        stop();
        switchWho(el.dataset.emWho);
        return;
      }
      if (!t.closest("#emUserMenu")) $id("emUserMenu")?.classList.remove("on");
      if ((el = t.closest("[data-em-thread]"))) {
        stop();
        openThread(el.dataset.emThread);
        return;
      }
      if ((el = t.closest("[data-em-fold]"))) {
        stop();
        S.fold = !S.fold;
        recent();
        return;
      }
      if ((el = t.closest("[data-recent],[data-open-chat]"))) {
        const s = st8();
        const c = s && s.conversations && s.conversations[+(el.dataset.recent ?? el.dataset.openChat)];
        if (c && c.emThread) {
          stop();
          openThread(c.emThread);
          return;
        }
      }
      if (!t.closest("#emThread")) {
        if (S.open && t.closest(".nav-btn,.new-chat,[data-view],[data-recent],[data-emergency-thread],[data-open-chat],.recent-item")) closeThread();
        return;
      }
      const T = S.threads[S.open];
      if ((el = t.closest("[data-em-work]"))) {
        stop();
        setWork(el.dataset.emWork);
        return;
      }
      if ((el = t.closest("[data-em-act]"))) {
        stop();
        if (!el.disabled) act(el.dataset.emAct, el);
        return;
      }
      if (!T) return;
      if ((el = t.closest("[data-d1-radio]"))) {
        stop();
        if (T.busy || T.handoff) return;
        const [k, i] = el.dataset.d1Radio.split(":");
        T.f[k] = D1F.find((f) => f.k === k).opts[Number(i)];
        T.srcMsg = null;
        return right(T);
      }
      if ((el = t.closest("[data-d1-row]"))) {
        stop();
        if (T.busy || T.done) return;
        const i = Number(el.dataset.d1Row);
        T.row = T.row === i ? -1 : i;
        T.srcMsg = null;
        return right(T);
      }
      if ((el = t.closest("[data-z-row]"))) {
        stop();
        const z = T.z;
        const i = Number(el.dataset.zRow);
        z.sel = z.sel.includes(i) ? z.sel.filter((x) => x !== i) : [...z.sel, i].sort();
        return right(T);
      }
      if ((el = t.closest("[data-em-tab]"))) {
        stop();
        T.tab = Number(el.dataset.emTab);
        return right(T);
      }
      if ((el = t.closest("[data-em-copy]"))) {
        stop();
        const v = el.dataset.emCopy;
        try {
          navigator.clipboard?.writeText(v)?.catch?.(() => {});
        } catch (_) {
          /* 剪贴板不可用时只提示 */
        }
        toast(`已复制 ${v}`);
      }
    },
    true,
  );

  /* 输入只更新状态和标记，不整体重绘，避免打断输入 */
  function mark(el, st, cls) {
    if (!el) return;
    el.classList.remove(`${cls}ai`, `${cls}me`);
    if (st) el.classList.add(`${cls}${st}`);
    let sup = el.querySelector(":scope > sup");
    if (!sup && st) {
      el.insertAdjacentHTML("beforeend", "<sup></sup>");
      sup = el.querySelector(":scope > sup");
    }
    if (sup) sup.textContent = st === "me" ? "人工改写" : "AI 填";
  }

  function onInput(ev) {
    const t = ev.target;
    if (!t || !t.closest) return;
    const d = t.dataset || {};
    const T = S.threads[S.open];
    if (!T || !t.closest("#emThread")) return;
    if (SC(T.id)) return SC(T.id).input ? SC(T.id).input(T, t, ev.type) : null;
    if (t.hasAttribute("data-pay-in")) T.pay.v = t.value;
    else if (d.zIn) T.z.f[d.zIn] = t.value.trim();
    else if (d.zLk) T.z.lk[Number(d.zLk)] = t.value.trim();
    else if (d.zChk) T.z.chk[d.zChk] = t.checked;
    else if (t.hasAttribute("data-z-appr")) T.z.appr = t.value;
    else if (d.d1In) {
      T.f[d.d1In] = t.value.trim();
      mark(document.querySelector(`#emThread [data-fr="${d.d1In}"]`), d1St(T, d.d1In), "em-fr-");
    } else if (d.d3) {
      T.q[d.d3] = t.value;
      mark(t.closest("[data-cf]"), t.value === T.aiQ[d.d3] ? "ai" : "me", "");
    } else if (d.d4) {
      T.c[d.d4] = t.value;
      const box = t.closest("[data-cf]");
      mark(box, d4St(T, d.d4), "");
      const sup = box && !(d.d4 in T.ai) && box.querySelector(":scope > sup");
      if (sup) sup.textContent = "人工填写";
    }
  }
  document.addEventListener("input", onInput);
  document.addEventListener("change", (ev) => {
    if (ev.target && (ev.target.type === "radio" || ev.target.type === "checkbox")) onInput(ev);
  });

  /* 首页输入框：线程打开时按事项回复；未打开时，输入含演示事项标题则进入该事项的任务线程 */
  function titleHit(v) {
    return Object.keys(DEMOS).find((id) => {
      const it = find(id);
      return it && DEMOS[id].mode !== "chat" && v.includes(it.title);
    });
  }

  function reply(T, v) {
    const it = find(T.id);
    const st = stOf(it);
    if (SC(T.id) && SC(T.id).reply && SC(T.id).reply(T, v)) return;
    if (/转人工/.test(v)) {
      if (T.done) return say(T, { k: "ai", html: "这条事项已结束，不需要转人工。" });
      if (pending(T)) return say(T, { k: "ai", html: "对话里还有一张待确认的卡片，请先处理。" });
      return act("human");
    }
    if (T.mode === "link" && !T.done && !T.busy && /办完|办好了|完成了|提交了|过账了|受理了/.test(v)) return linkCheck(T, true);
    if (/办到|进度|哪一步|到哪|什么状态|状态/.test(v)) {
      const next = it.__emnext ? `下一步：${h(it.__emnext)}。` : "";
      return say(T, { k: "ai", html: `当前状态：${ST_NAME[st]}。当前环节：${h(it.current)}。时限：${h(it.deadline)}｜${h(it.remain)}。${next}` });
    }
    say(T, { k: "ai", html: `我已理解您的请求。当前为智慧工作台通用对话区，可调用工具、技能和专业智能体。这条事项的办理请按上面的步骤继续，或在右侧办理区直接操作；可以问我“办到哪了”，或说“转人工”。` });
  }

  function chatIn(v) {
    const T = S.threads[S.open];
    /* 对话中发起的场景：线程未打开时按输入内容判断进入哪一个 */
    const route = !T && typeof window.SCENE_ROUTE === "function" ? window.SCENE_ROUTE(v, S.who) : "";
    const hit = route || titleHit(v);
    if (hit && hit !== S.open) {
      if (!mine(hit)) return false;
      const fresh = !S.threads[hit];
      if (!openThread(hit)) return false;
      const T2 = S.threads[hit];
      if (fresh) T2.msgs.unshift({ k: "me", text: v });
      else say(T2, { k: "me", text: v });
      left(T2);
      return true;
    }
    if (!T) return false;
    say(T, { k: "me", text: v });
    later(T, 400, () => reply(T, v));
    return true;
  }

  if (typeof window.startChat === "function") {
    const baseStart = window.startChat;
    window.startChat = function (v, ...rest) {
      const text = String(v ?? "").trim();
      if (text && chatIn(text)) return;
      if (text && S.open) return;
      const hit = text && titleHit(text);
      if (hit && !mine(hit)) toast(`这条事项属于「${USERS[DEMOS[hit].who].name}」，请先在左下角切换账号`);
      return baseStart.call(this, v, ...rest);
    };
  }

  /* 拖动调整办理区宽度，双击恢复默认 */
  let drag = null;
  document.addEventListener(
    "pointerdown",
    (ev) => {
      const sp = ev.target.closest && ev.target.closest("[data-em-split]");
      if (!sp) return;
      ev.preventDefault();
      ev.stopPropagation();
      const w = $id("emThreadWork");
      drag = { x: ev.clientX, w: w ? w.getBoundingClientRect().width : 0 };
      $id("emThread")?.classList.add("em-dragging");
    },
    true,
  );
  document.addEventListener("pointermove", (ev) => {
    if (!drag) return;
    ev.preventDefault();
    workWidth(drag.w - (ev.clientX - drag.x), false);
  });
  document.addEventListener("pointerup", () => {
    if (!drag) return;
    drag = null;
    const el = $id("emThread");
    el?.classList.remove("em-dragging");
    const w = parseFloat(el?.style.getPropertyValue("--em-work-w")) || 0;
    if (w) workWidth(w, true);
  });
  document.addEventListener("dblclick", (ev) => {
    if (!ev.target.closest || !ev.target.closest("[data-em-split]")) return;
    try {
      localStorage.removeItem(WKEY);
    } catch (_) {
      /* 忽略 */
    }
    const el = $id("emThread");
    if (el) workWidth(Math.round(el.getBoundingClientRect().width * 0.52), false);
  });
  window.addEventListener("resize", () => {
    if (!S.open) return;
    const w = parseFloat($id("emThread")?.style.getPropertyValue("--em-work-w")) || 0;
    workWidth(w, false);
  });

  document.addEventListener("keydown", (ev) => {
    if (ev.key !== "Escape") return;
    const menu = $id("emUserMenu");
    if (menu && menu.classList.contains("on")) return menu.classList.remove("on");
    if (S.pick) {
      S.pick = null;
      return pickDraw();
    }
    const B = S.threads[S.open];
    const s = B && (B.pay || B.wms || B.z);
    if (s && s.dlg) {
      s.dlg = null;
      return right(B);
    }
    if (S.open && S.work === "full") return setWork("open");
  });
})();
