/* Source runtime block 1 */
const $ = (e, t = document) => t.querySelector(e),
        $$ = (e, t = document) => [...t.querySelectorAll(e)],
        icons = (e) => `<svg class="icon"><use href="#${e}"/></svg>`,
        nowTime = () =>
          new Date().toLocaleTimeString("zh-CN", {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
            hour12: !1,
          }),
        state = {
          view: "chat",
          wbTab: "overview",
          assistantCollapsed: !1,
          autoDemo: !0,
          demoStep: 0,
          tickCount: 0,
          selectedSchedule: 1,
          selectedEmergency: "E001",
          selectedMaterial: null,
          drawerTab: "sources",
          selectedPlan: "P1",
          comparePlanA: "P1",
          comparePlanB: "P2",
          filter: "all",
          materialFilter: "all",
          conversations: [
            {
              title: "重庆北部嘉陵江流域强降雨抢险应急任务",
              type: "应急任务",
              time: "刚刚",
              messages: 42,
              live: !0,
            },
            {
              title: "采购目录编制方案讨论",
              type: "普通对话",
              time: "18分钟前",
              messages: 18,
            },
            {
              title: "供应商履约风险分析",
              type: "智能体对话",
              time: "昨天",
              messages: 27,
            },
            {
              title: "本周库存周转情况",
              type: "数据分析",
              time: "周一",
              messages: 13,
            },
            {
              title: "重庆供应链运维项目需求梳理",
              type: "项目方案",
              time: "7月12日",
              messages: 34,
            },
          ],
          agents: [
            {
              icon: "⚠",
              name: "应急任务智能体",
              desc: "自动感知事件、解析物资需求、跨系统寻源、持续跟踪响应并形成调拨与采购方案。",
              tools: 12,
              skills: 8,
              status: "在线",
              domain: "应急保障",
              skillsNames: ["应急需求解析", "跨单位资源匹配", "保障方案生成"],
            },
            {
              icon: "▦",
              name: "采购问数智能体",
              desc: "面向采购计划、采购执行、合同履约和供应商管理开展自然语言问数、查询与分析。",
              tools: 16,
              skills: 10,
              status: "在线",
              domain: "采购分析",
              skillsNames: ["采购数据查询", "指标分析", "业务问答"],
            },
            {
              icon: "□",
              name: "供应链工单处置智能体",
              desc: "智能解析供应链工单、校验业务字段、生成处置建议并跟踪流程节点。",
              tools: 8,
              skills: 9,
              status: "在线",
              domain: "工单处置",
              skillsNames: ["工单解析", "规则判断", "智能派单"],
            },
          ],
          scheduled: [
            {
              id: 1,
              name: "应急事件常驻感知任务",
              desc: "持续扫描原业务系统的新应急事件，自动创建独立任务并启动需求识别。",
              schedule: "每1分钟",
              next: "1分钟后",
              status: "运行中",
              context: "后台常驻服务",
              last: "刚刚 · 发现0个新增任务",
              system: !0,
            },
            {
              id: 2,
              name: "应急任务未响应提醒",
              desc: "检查执行中的应急任务，对超时未回复单位自动提醒并按规则升级。",
              schedule: "每5分钟",
              next: "3分钟后",
              status: "已启用",
              context: "复用应急任务线程",
              last: "2分钟前 · 已催办6家单位",
            },
            {
              id: 3,
              name: "每日供应链运营简报",
              desc: "汇总昨日供应链运营变化、异常和今日重点事项。",
              schedule: "每天 09:00",
              next: "明日09:00",
              status: "已启用",
              context: "每次新建对话",
              last: "今日09:00 · 成功",
            },
            {
              id: 4,
              name: "每周供应商风险复盘",
              desc: "每周汇总供应商履约、质量和响应风险，形成复盘报告。",
              schedule: "每周一 08:30",
              next: "下周一08:30",
              status: "已暂停",
              context: "每次新建对话",
              last: "上周一 · 成功",
            },
          ],
          emergencies: [
            {
              id: "E001",
              code: "20260714001",
              title: "重庆北部嘉陵江流域强降雨抢险应急任务",
              unit: "国网重庆市电力公司物资分公司",
              received: "昨晚22:16",
              runtime: "42分钟",
              stage: "调拨及协议库存寻源",
              status: "自动执行中",
              statusClass: "running",
              progress: 61,
              materials: "10条",
              summary: "4条满足、3条部分满足、3条寻源中",
              risk: "光缆拼单方案待判断",
              riskLevel: "red",
              attention: !0,
            },
            {
              id: "E002",
              code: "20260714002",
              title: "永川区山火引发变电站故障应急保障",
              unit: "国网重庆永川供电公司",
              received: "今日09:08",
              runtime: "28分钟",
              stage: "初步方案调整",
              status: "需要人工介入",
              statusClass: "attention",
              progress: 84,
              materials: "8条",
              summary: "7条满足、1条待确认",
              risk: "主变附件到货时限需确认",
              riskLevel: "red",
              attention: !0,
            },
            {
              id: "E003",
              code: "20260714003",
              title: "渝东北山洪地质灾害抢修物资保障",
              unit: "国网重庆万州供电公司",
              received: "今日10:32",
              runtime: "12分钟",
              stage: "等待调拨响应",
              status: "等待外部响应",
              statusClass: "waiting",
              progress: 37,
              materials: "14条",
              summary: "3条满足、11条寻源中",
              risk: "暂无重大异常",
              riskLevel: "green",
              attention: !1,
            },
            {
              id: "E004",
              code: "20260713006",
              title: "黔江区高温山火线路抢修物资调拨",
              unit: "国网重庆黔江供电公司",
              received: "昨日15:24",
              runtime: "3小时18分",
              stage: "执行完成",
              status: "已完成",
              statusClass: "done",
              progress: 100,
              materials: "5条",
              summary: "5条全部完成",
              risk: "已回写原系统",
              riskLevel: "green",
              attention: !1,
            },
            {
              id: "E005",
              code: "20260713004",
              title: "綦江区暴雨内涝应急保供任务",
              unit: "国网重庆綦江供电公司",
              received: "昨日08:10",
              runtime: "6小时22分",
              stage: "执行完成",
              status: "已完成",
              statusClass: "done",
              progress: 100,
              materials: "16条",
              summary: "16条全部完成",
              risk: "复盘报告已生成",
              riskLevel: "green",
              attention: !1,
            },
          ],
          task: {
            title: "重庆北部嘉陵江流域强降雨抢险应急任务",
            code: "20260714001",
            unit: "国网重庆市电力公司物资分公司",
            source: "智慧供应链平台",
            received: "2026年7月14日 22:16",
            runtime: 42,
            deadline: "今日12:00",
            stageIndex: 2,
            lastUpdate: "22:58:12",
            nextCheck: "23:03",
            status: "自动执行中",
            counters: {
              sent: 30,
              received: 24,
              replied: 18,
              can: 7,
              partial: 4,
              waiting: 12,
              timeout: 0,
            },
            materials: [
              {
                id: "M01",
                name: "光缆",
                spec: "GYTA-24B1",
                need: 2.74,
                unit: "千米",
                filled: 2.74,
                status: "初步满足",
                statusClass: "waiting",
                method: "两家单位拼单",
                updated: "22:48",
                confirmed: !1,
                allowSplit: !0,
                procure: !1,
                sources: [
                  {
                    name: "北碚供电公司",
                    type: "单位调拨",
                    status: "可以满足",
                    qty: "1.37千米",
                    eta: "今日01:30",
                    distance: "36km",
                    reply: "22:48",
                  },
                  {
                    name: "合川供电公司",
                    type: "单位调拨",
                    status: "可以满足",
                    qty: "1.37千米",
                    eta: "今日02:10",
                    distance: "52km",
                    reply: "22:46",
                  },
                  {
                    name: "国网重庆永川供电公司",
                    type: "单位调拨",
                    status: "等待回复",
                    qty: "—",
                    eta: "—",
                    distance: "88km",
                    reply: "剩余8分钟",
                  },
                ],
                history: [
                  "22:16 自动识别需求",
                  "22:31 向30家单位发起调拨征询",
                  "22:48 形成两家单位拼单初步满足",
                ],
              },
              {
                id: "M02",
                name: "工业交换机",
                spec: "24口千兆工业级",
                need: 20,
                unit: "台",
                filled: 20,
                status: "已确认",
                statusClass: "done",
                method: "单一单位调拨",
                updated: "22:42",
                confirmed: !0,
                allowSplit: !1,
                procure: !1,
                sources: [
                  {
                    name: "江北供电公司",
                    type: "单位调拨",
                    status: "可以满足",
                    qty: "20台",
                    eta: "今日01:00",
                    distance: "18km",
                    reply: "22:42",
                  },
                ],
                history: [
                  "22:18 完成型号澄清",
                  "22:42 江北公司确认可完整满足",
                  "22:44 用户确认采用",
                ],
              },
              {
                id: "M03",
                name: "通信电源",
                spec: "48V/100A",
                need: 5,
                unit: "套",
                filled: 0,
                status: "供应商询供中",
                statusClass: "purple",
                method: "应急采购准备",
                updated: "22:55",
                confirmed: !1,
                allowSplit: !0,
                procure: !0,
                sources: [
                  {
                    name: "重庆电源设备有限公司",
                    type: "供应商询供",
                    status: "可以满足",
                    qty: "5套",
                    eta: "今日06:00",
                    distance: "本地",
                    reply: "22:55",
                  },
                  {
                    name: "重庆通服应急设备有限公司",
                    type: "供应商询供",
                    status: "等待回复",
                    qty: "—",
                    eta: "—",
                    distance: "重庆两江新区",
                    reply: "剩余12分钟",
                  },
                ],
                history: [
                  "22:30 库存及协议库存均无可用资源",
                  "22:40 提前启动供应商询供",
                  "22:55 首家供应商确认可供5套",
                ],
              },
              {
                id: "M04",
                name: "电力电缆",
                spec: "YJV22-10kV 3×300",
                need: 2.5,
                unit: "千米",
                filled: 1.5,
                status: "部分满足",
                statusClass: "waiting",
                method: "协议库存＋调拨",
                updated: "22:52",
                confirmed: !1,
                allowSplit: !0,
                procure: !1,
                sources: [
                  {
                    name: "涪陵供电公司",
                    type: "单位调拨",
                    status: "部分满足",
                    qty: "0.8千米",
                    eta: "今日03:00",
                    distance: "104km",
                    reply: "22:43",
                  },
                  {
                    name: "重庆本地协议供应商A",
                    type: "协议库存",
                    status: "部分满足",
                    qty: "0.7千米",
                    eta: "今日05:30",
                    distance: "重庆",
                    reply: "22:52",
                  },
                ],
                history: [
                  "22:26 发起实物库存和协议库存查询",
                  "22:52 当前满足1.5千米，仍缺1千米",
                ],
              },
              {
                id: "M05",
                name: "电缆终端",
                spec: "10kV 3×300",
                need: 12,
                unit: "套",
                filled: 12,
                status: "初步满足",
                statusClass: "waiting",
                method: "协议库存",
                updated: "22:47",
                confirmed: !1,
                allowSplit: !1,
                procure: !1,
                sources: [
                  {
                    name: "重庆本地协议供应商B",
                    type: "协议库存",
                    status: "可以满足",
                    qty: "12套",
                    eta: "今日04:00",
                    distance: "重庆",
                    reply: "22:47",
                  },
                ],
                history: ["22:47 协议供应商确认可完整满足"],
              },
              {
                id: "M06",
                name: "应急照明灯",
                spec: "便携式防水",
                need: 30,
                unit: "盏",
                filled: 30,
                status: "已确认",
                statusClass: "done",
                method: "本单位库存",
                updated: "22:25",
                confirmed: !0,
                allowSplit: !0,
                procure: !1,
                sources: [
                  {
                    name: "国网重庆市电力公司物资分公司仓库",
                    type: "本单位库存",
                    status: "可以满足",
                    qty: "30盏",
                    eta: "立即出库",
                    distance: "8km",
                    reply: "22:25",
                  },
                ],
                history: ["22:25 本单位库存可完整满足", "22:27 自动锁定库存"],
              },
              {
                id: "M07",
                name: "抢修帐篷",
                spec: "6人防雨型",
                need: 8,
                unit: "顶",
                filled: 8,
                status: "已确认",
                statusClass: "done",
                method: "本单位库存",
                updated: "22:24",
                confirmed: !0,
                allowSplit: !0,
                procure: !1,
                sources: [
                  {
                    name: "国网重庆市电力公司物资分公司仓库",
                    type: "本单位库存",
                    status: "可以满足",
                    qty: "8顶",
                    eta: "立即出库",
                    distance: "8km",
                    reply: "22:24",
                  },
                ],
                history: ["22:24 本单位库存可完整满足", "22:26 自动锁定库存"],
              },
              {
                id: "M08",
                name: "发电机",
                spec: "50kW静音型",
                need: 4,
                unit: "台",
                filled: 2,
                status: "部分满足",
                statusClass: "waiting",
                method: "两家单位征询中",
                updated: "22:56",
                confirmed: !1,
                allowSplit: !0,
                procure: !1,
                sources: [
                  {
                    name: "大渡口供电公司",
                    type: "单位调拨",
                    status: "部分满足",
                    qty: "2台",
                    eta: "今日02:00",
                    distance: "28km",
                    reply: "22:56",
                  },
                  {
                    name: "璧山供电公司",
                    type: "单位调拨",
                    status: "等待回复",
                    qty: "—",
                    eta: "—",
                    distance: "45km",
                    reply: "剩余7分钟",
                  },
                ],
                history: ["22:56 大渡口公司反馈可提供2台"],
              },
              {
                id: "M09",
                name: "安全工器具套装",
                spec: "高压抢修套装",
                need: 15,
                unit: "套",
                filled: 15,
                status: "初步满足",
                statusClass: "waiting",
                method: "单一单位调拨",
                updated: "22:49",
                confirmed: !1,
                allowSplit: !1,
                procure: !1,
                sources: [
                  {
                    name: "南岸供电公司",
                    type: "单位调拨",
                    status: "可以满足",
                    qty: "15套",
                    eta: "今日01:20",
                    distance: "22km",
                    reply: "22:49",
                  },
                ],
                history: ["22:49 南岸公司确认可完整满足"],
              },
              {
                id: "M10",
                name: "防汛沙袋",
                spec: "50kg标准袋",
                need: 500,
                unit: "只",
                filled: 0,
                status: "寻源中",
                statusClass: "running",
                method: "等待单位回复",
                updated: "22:57",
                confirmed: !1,
                allowSplit: !0,
                procure: !1,
                sources: [
                  {
                    name: "沙坪坝供电公司",
                    type: "单位调拨",
                    status: "已接收未回复",
                    qty: "—",
                    eta: "—",
                    distance: "24km",
                    reply: "剩余6分钟",
                  },
                  {
                    name: "九龙坡供电公司",
                    type: "单位调拨",
                    status: "已接收未回复",
                    qty: "—",
                    eta: "—",
                    distance: "26km",
                    reply: "剩余6分钟",
                  },
                ],
                history: ["22:57 两家单位已接收请求，等待回复"],
              },
            ],
            events: [
              {
                time: "22:58",
                title: "当前结果已具备形成初步方案的条件",
                copy: "10条物资中4条已完全满足、3条部分满足、2条等待回复、1条供应商询供中。",
                level: "important",
              },
              {
                time: "22:56",
                title: "大渡口供电公司反馈发电机可部分满足",
                copy: "可提供2台50kW静音发电机，预计今日02:00到达。",
                level: "important",
              },
              {
                time: "22:55",
                title: "重庆电源设备有限公司完成询供回复",
                copy: "通信电源可提供5套，最早今日06:00交付，已纳入应急采购准备方案。",
                level: "important",
              },
              {
                time: "22:52",
                title: "电力电缆当前满足量更新为1.5千米",
                copy: "涪陵公司调拨0.8千米，重庆本地协议供应商A可供0.7千米，仍缺1千米。",
                level: "",
              },
              {
                time: "22:48",
                title: "光缆形成两家单位拼单方案",
                copy: "北碚、合川各可提供1.37千米，当前已完整满足，但需用户判断是否接受拼单。",
                level: "alert",
              },
              {
                time: "22:31",
                title: "已向30家单位发起调拨征询",
                copy: "通过邮件与工单同步发送，响应截止时间23:05。",
                level: "",
              },
              {
                time: "22:16",
                title: "自动接收应急任务",
                copy: "系统识别10条物资需求，无关键字段缺失，已自动启动库存与协议库存寻源。",
                level: "important",
              },
            ],
            constraints: [
              "光缆允许两家单位拼单",
              "工业交换机必须单一单位完整满足",
              "优先省内资源",
              "到货时间优先于调拨距离",
            ],
            plans: [
              {
                id: "P1",
                name: "当前推荐方案",
                desc: "综合到货时效、资源集中度和响应可靠性，采用已确认调拨资源，并对通信电源启动应急采购。",
                fit: "90%",
                eta: "最晚06:00",
                units: "7家",
                risk: "中低",
                cost: "18万元",
                tags: ["时效优先", "资源基本满足", "含1项采购"],
                recommended: !0,
              },
              {
                id: "P2",
                name: "减少调拨单位方案",
                desc: "继续等待单一单位完整满足光缆和发电机，以减少拼单和跨单位协调成本。",
                fit: "80%",
                eta: "预计08:00",
                units: "5家",
                risk: "中",
                cost: "16万元",
                tags: ["单位数量少", "需要继续等待"],
                recommended: !1,
              },
              {
                id: "P3",
                name: "立即截止寻源方案",
                desc: "基于当前结果截止寻源，对缺口全部转入应急采购，最快形成可执行方案。",
                fit: "100%",
                eta: "最晚07:00",
                units: "6家",
                risk: "中",
                cost: "31万元",
                tags: ["立即可执行", "采购成本较高"],
                recommended: !1,
              },
            ],
            selectedPlan: "P1",
            decisionConfirmed: !1,
            writeback: !1,
            orders: [],
          },
          assistant: [
            {
              role: "assistant",
              text: "我已在您不在线期间自动接收任务并持续寻源。当前10条物资中4条完全满足、3条部分满足、2条等待回复、1条已进入供应商询供。",
            },
            {
              role: "assistant",
              text: "光缆当前由北碚、合川两家单位拼单完整满足，需要您判断是否接受拼单，或继续等待单一单位回复。",
              action: "可选择：接受拼单 / 要求单一单位 / 继续等待",
            },
          ],
        };
      function expandResponderPool() {
        const e = [
            "渝北供电公司",
            "江北供电公司",
            "南岸供电公司",
            "巴南供电公司",
            "九龙坡供电公司",
            "沙坪坝供电公司",
            "大渡口供电公司",
            "北碚供电公司",
            "合川供电公司",
            "江津供电公司",
            "璧山供电公司",
            "永川供电公司",
            "涪陵供电公司",
            "长寿供电公司",
            "万州供电公司",
            "黔江供电公司",
            "綦江供电公司",
            "铜梁供电公司",
          ],
          t = [
            "重庆通联电缆有限公司",
            "重庆电源设备有限公司",
            "重庆输配电设备有限公司",
            "重庆应急装备有限公司",
            "重庆防汛物资有限公司",
            "西南电力附件供应中心",
          ],
          s = ["渝西在途工程资源", "渝东北在建项目余量"],
          a = ["重庆应急采购供应池"],
          n = { unit: 1, rush: 2, transit: 3, purchase: 4 };
        state.task.materials.forEach((i, r) => {
          const l = n[i.activeChannel || "unit"];
          i.sources.forEach((e) => {
            (n[e.channelKey] || 1) > l
              ? ((e.requested = !1),
                (e.status = `未触发（${RESPONSE_CHANNELS[e.channelKey]?.name || e.type}阶段未到）`),
                (e.qty = "—"),
                (e.qtyValue = 0),
                (e.reply = "—"),
                (e.eta = "—"))
              : (e.requested = !0);
          });
          const d = new Set(i.sources.map((e) => e.name));
          (e.forEach((e, t) => {
            if (
              d.has(e) ||
              i.sources.filter((e) => "unit" === e.channelKey).length >= 18
            )
              return;
            const s = t % 5 == 0,
              a = s
                ? "等待跨单位响应中"
                : l > 1
                  ? "已回复无库存"
                  : t % 4 == 0
                    ? "部分可调拨"
                    : "已回复无可用量",
              n = a.includes("部分")
                ? Math.max(0.1, +(0.2 * i.need).toFixed(2))
                : 0,
              r = s && t % 10 == 0 ? 1 : 0;
            (i.sources.push({
              id: `${i.id}-UX${t}`,
              name: e,
              type: "跨单位调拨",
              channelKey: "unit",
              status: a,
              qty: n ? `${n}${i.unit}` : "—",
              qtyValue: n,
              eta: n ? `今日0${(t % 6) + 1}:30` : "—",
              reply: s ? `剩余${(t % 8) + 2}分钟` : `22:${30 + t}`,
              distance: 20 + 4 * t + "km",
              requested: !0,
              channel: "智慧供应链平台",
              price: "—",
              risk: "暂无明显风险",
              reminderCount: r,
              reminders: r ? [`22:${40 + t} 达到响应时限，智能体自动催办`] : [],
              replyOrder: t + 10,
            }),
              d.add(e));
          }),
            l >= 2 &&
              t.forEach((e, t) => {
                if (
                  d.has(e) ||
                  i.sources.filter((e) => "rush" === e.channelKey).length >= 6
                )
                  return;
                const s = t % 4 == 0,
                  a = 3 === t,
                  n = t % 3 == 1 && !s,
                  l = s
                    ? "已回复有货"
                    : a
                      ? "部分可供"
                      : n
                        ? "等待供应商响应中"
                        : "已回复无现货",
                  c = s ? i.need : a ? +(0.45 * i.need).toFixed(2) : 0,
                  o = n ? 1 : 0;
                (i.sources.push({
                  id: `${i.id}-RX${t}`,
                  name: e,
                  type: "应急抢单",
                  channelKey: "rush",
                  status: l,
                  qty: c ? `${c}${i.unit}` : "—",
                  qtyValue: c,
                  eta: c ? `今日0${t + 2}:20` : "—",
                  reply: n ? `超时${t + 1}分钟` : `22:${20 + t}`,
                  distance: "重庆本地",
                  requested: !0,
                  channel: "E物资",
                  price: c
                    ? `¥${(68e3 + 9500 * r + 1200 * t).toLocaleString()}`
                    : "—",
                  risk: 0 === t ? "需尽快锁定库存" : "暂无明显风险",
                  reminderCount: o,
                  reminders: o
                    ? [
                        "22:45 达到首次响应时限，自动催办",
                        "23:00 仍未回复，催办次数 +1",
                      ]
                    : [],
                  replyOrder: t + 1,
                }),
                  d.add(e));
              }),
            l >= 3 &&
              s.forEach((e, t) => {
                if (
                  d.has(e) ||
                  i.sources.filter((e) => "transit" === e.channelKey).length >=
                    2
                )
                  return;
                const s = 0 === t,
                  a = s ? "等待在途/在建确认中" : "已核实无可调余量",
                  n = s ? +(0.5 * i.need).toFixed(2) : 0;
                (i.sources.push({
                  id: `${i.id}-TX${t}`,
                  name: e,
                  type: "在途/在建",
                  channelKey: "transit",
                  status: a,
                  qty: n ? `${n}${i.unit}` : "—",
                  qtyValue: n,
                  eta: n ? "今日04:30" : "—",
                  reply: `22:${45 + t}`,
                  distance: "在途/在建平台",
                  requested: !0,
                  channel: "在途/在建资源平台",
                  price: "—",
                  risk: "需项目单位确认释放",
                  reminderCount: 0,
                  reminders: [],
                  replyOrder: t + 1,
                }),
                  d.add(e));
              }),
            l >= 4 &&
              a.forEach((e, t) => {
                d.has(e) ||
                  i.sources.filter((e) => "purchase" === e.channelKey).length >=
                    1 ||
                  (i.sources.push({
                    id: `${i.id}-PX${t}`,
                    name: e,
                    type: "应急采购",
                    channelKey: "purchase",
                    status: "应急采购准备中",
                    qty: "—",
                    qtyValue: 0,
                    eta: "待询价",
                    reply: "—",
                    distance: "采购平台",
                    requested: !0,
                    channel: "E物资",
                    price: "待询价",
                    risk: "需采购专责确认",
                    reminderCount: 0,
                    reminders: [],
                    replyOrder: t + 1,
                  }),
                  d.add(e));
              }),
            i.sources
              .filter(
                (e) =>
                  "rush" === e.channelKey &&
                  !1 !== e.requested &&
                  sourceSelectable(e),
              )
              .sort((e, t) => (e.replyOrder || 99) - (t.replyOrder || 99))
              .forEach((e, t) => (e.rushRank = t + 1)));
        });
        const i = state.task.materials.find((e) => "M01" === e.id);
        if (i) {
          const e = [
            "重庆通联电缆有限公司",
            "重庆西部电缆有限公司",
            "重庆长寿电缆制造有限公司",
            "重庆渝北通信设备商贸公司",
            "重庆嘉陵电气有限公司",
            "重庆博联通信设备有限公司",
          ];
          (e.forEach((e, t) => {
            i.sources.some((t) => t.name === e) ||
              i.sources.push({
                id: `M01-RUSH-${t}`,
                name: e,
                type: "应急抢单",
                channelKey: "rush",
                status:
                  0 === t
                    ? "部分可供"
                    : 1 === t
                      ? "等待供应商响应中"
                      : "已回复无现货",
                qty: 0 === t ? "1.5千米" : "—",
                qtyValue: 0 === t ? 1.5 : 0,
                eta: 0 === t ? "今日03:20" : "—",
                reply: 1 === t ? "超时3分钟" : `22:${50 + t}`,
                distance: "重庆本地",
                requested: !0,
                channel: "E物资",
                price: 0 === t ? "¥68,500" : "—",
                risk: "备选资源，未纳入当前组合",
                reminderCount: 1 === t ? 1 : 0,
                reminders:
                  1 === t
                    ? [
                        "22:45 到达首次响应时限，自动催办",
                        "23:00 仍未回复，催办次数 +1",
                      ]
                    : [],
                replyOrder: t + 1,
              });
          }),
            ["渝西在途光缆资源", "渝东北在建光缆余量"].forEach((e, t) => {
              i.sources.find(
                (t) => "transit" === t.channelKey && t.name === e,
              ) ||
                i.sources.push({
                  id: `M01-TRANSIT-${t}`,
                  name: e,
                  type: "在途/在建",
                  channelKey: "transit",
                  status: 0 === t ? "等待在途资源确认中" : "已核实无可调余量",
                  qty: 0 === t ? "1.37千米" : "—",
                  qtyValue: 0 === t ? 1.37 : 0,
                  eta: 0 === t ? "今日04:30" : "—",
                  reply: `22:${56 + t}`,
                  distance: "在途/在建平台",
                  requested: !0,
                  channel: "在途/在建资源平台",
                  price: "—",
                  risk: "需项目单位确认释放",
                  reminderCount: 0,
                  reminders: [],
                  replyOrder: t + 1,
                });
            }),
            e.forEach((e, t) => {
              const s = i.sources.find((t) => t.name === e);
              s &&
                Object.assign(s, {
                  type: "应急抢单",
                  channelKey: "rush",
                  status:
                    0 === t
                      ? "部分可供"
                      : 1 === t
                        ? "等待供应商响应中"
                        : "已回复无现货",
                  qty: 0 === t ? "1.5千米" : "—",
                  qtyValue: 0 === t ? 1.5 : 0,
                  eta: 0 === t ? "今日03:20" : "—",
                  reply: 1 === t ? "超时3分钟" : `22:${50 + t}`,
                  distance: "重庆本地",
                  requested: !0,
                  channel: "E物资",
                  price: 0 === t ? "¥68,500" : "—",
                  risk: "备选资源，未纳入当前组合",
                  reminderCount: 1 === t ? 1 : 0,
                  reminders:
                    1 === t
                      ? [
                          "22:45 到达首次响应时限，自动催办",
                          "23:00 仍未回复，催办次数 +1",
                        ]
                      : [],
                  replyOrder: t + 1,
                });
            }),
            ["渝西在途光缆资源", "渝东北在建光缆余量"].forEach((e, t) => {
              const s = i.sources.find((t) => t.name === e);
              s &&
                Object.assign(s, {
                  type: "在途/在建",
                  channelKey: "transit",
                  status: 0 === t ? "等待在途资源确认中" : "已核实无可调余量",
                  qty: 0 === t ? "1.37千米" : "—",
                  qtyValue: 0 === t ? 1.37 : 0,
                  eta: 0 === t ? "今日04:30" : "—",
                  reply: `22:${56 + t}`,
                  distance: "在途/在建平台",
                  requested: !0,
                  channel: "在途/在建资源平台",
                  price: "—",
                  risk: "需项目单位确认释放",
                  reminderCount: 0,
                  reminders: [],
                  replyOrder: t + 1,
                });
            }),
            i.sources
              .filter((e) => "purchase" === e.channelKey)
              .forEach((e) => (e.requested = !1)));
        }
      }
      function normalizeEmergencySourcing() {
        ((state.responseChannel = "all"), (state.materialFilter = "all"));
        const e = (e, t, s, a, n, i, r, l, d, c, o = !1, u = {}) => ({
          id: e,
          name: t,
          type: s,
          channelKey: a,
          status: n,
          qty: i,
          qtyValue: r,
          eta: l,
          reply: d,
          distance: c,
          selected: o,
          requested: !1 !== u.requested,
          channel: u.channel || "智慧供应链平台",
          price: u.price || "—",
          risk: u.risk || "暂无明显风险",
          reminderCount: u.reminderCount || 0,
          reminders: u.reminders || [],
        });
        ((state.task.status = "四渠道智能寻源中"),
          (state.task.stageIndex = 2),
          (state.task.counters = {
            sent: 42,
            received: 39,
            replied: 27,
            can: 9,
            partial: 5,
            waiting: 15,
            timeout: 4,
          }),
          (state.task.materials = [
            {
              id: "M01",
              name: "光缆",
              spec: "GYTA-24B1",
              need: 2.74,
              unit: "千米",
              filled: 2.74,
              status: "等待跨单位确认中",
              statusClass: "waiting",
              method: "北碚＋合川拼单调拨",
              updated: "22:48",
              confirmed: !1,
              allowSplit: !0,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: ["M01-U1", "M01-U2"],
              sources: [
                e(
                  "M01-U1",
                  "北碚供电公司",
                  "跨单位调拨",
                  "unit",
                  "已回复可调拨",
                  "1.37千米",
                  1.37,
                  "今日01:30",
                  "22:48",
                  "36km",
                  !0,
                ),
                e(
                  "M01-U2",
                  "合川供电公司",
                  "跨单位调拨",
                  "unit",
                  "已回复可调拨",
                  "1.37千米",
                  1.37,
                  "今日02:10",
                  "22:46",
                  "52km",
                  !0,
                ),
                e(
                  "M01-R1",
                  "重庆通联电缆有限公司",
                  "应急抢单",
                  "rush",
                  "未触发（跨单位可满足）",
                  "—",
                  0,
                  "—",
                  "—",
                  "重庆本地",
                  !1,
                  { requested: !1, price: "¥68,500", channel: "E物资" },
                ),
                e(
                  "M01-T1",
                  "渝西在途光缆资源",
                  "在途/在建",
                  "transit",
                  "未触发（优先级未到）",
                  "—",
                  0,
                  "—",
                  "—",
                  "在途平台",
                  !1,
                  { requested: !1 },
                ),
                e(
                  "M01-P1",
                  "应急采购供应商池",
                  "应急采购",
                  "purchase",
                  "未触发（优先级未到）",
                  "—",
                  0,
                  "—",
                  "—",
                  "采购平台",
                  !1,
                  { requested: !1 },
                ),
              ],
              history: [
                "22:16 本单位库存核验为0",
                "22:31 启动跨单位调拨",
                "22:48 北碚与合川回复可拼单满足",
              ],
            },
            {
              id: "M02",
              name: "工业交换机",
              spec: "24口千兆工业级",
              need: 20,
              unit: "台",
              filled: 20,
              status: "等待跨单位确认中",
              statusClass: "waiting",
              method: "江北供电公司跨单位调拨",
              updated: "22:42",
              confirmed: !1,
              allowSplit: !1,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: ["M02-U1"],
              sources: [
                e(
                  "M02-U1",
                  "江北供电公司",
                  "跨单位调拨",
                  "unit",
                  "已回复可调拨",
                  "20台",
                  20,
                  "今日01:00",
                  "22:42",
                  "18km",
                  !0,
                ),
                e(
                  "M02-U2",
                  "南岸供电公司",
                  "跨单位调拨",
                  "unit",
                  "已回复无可用量",
                  "0台",
                  0,
                  "—",
                  "22:44",
                  "22km",
                ),
                e(
                  "M02-R1",
                  "重庆工业通信设备有限公司",
                  "应急抢单",
                  "rush",
                  "未触发（跨单位已满足）",
                  "—",
                  0,
                  "—",
                  "—",
                  "重庆",
                  !1,
                  { requested: !1 },
                ),
              ],
              history: [
                "22:16 本单位库存核验为0",
                "22:32 向省内单位发送调拨请求",
                "22:42 江北供电公司回复可完整调拨",
              ],
            },
            {
              id: "M03",
              name: "通信电源",
              spec: "48V/100A",
              need: 5,
              unit: "套",
              filled: 5,
              status: "等待供应商确认中",
              statusClass: "purple",
              method: "应急抢单供应商直供",
              updated: "22:55",
              confirmed: !1,
              allowSplit: !1,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["M03-R1"],
              sources: [
                e(
                  "M03-U1",
                  "渝北供电公司",
                  "跨单位调拨",
                  "unit",
                  "已回复无库存",
                  "0套",
                  0,
                  "—",
                  "22:36",
                  "31km",
                ),
                e(
                  "M03-U2",
                  "江津供电公司",
                  "跨单位调拨",
                  "unit",
                  "已回复无库存",
                  "0套",
                  0,
                  "—",
                  "22:38",
                  "68km",
                ),
                e(
                  "M03-R1",
                  "重庆电源设备有限公司",
                  "应急抢单",
                  "rush",
                  "已回复有货",
                  "5套",
                  5,
                  "今日06:00",
                  "22:55",
                  "重庆本地",
                  !0,
                  { price: "¥126,000", channel: "E物资" },
                ),
                e(
                  "M03-R2",
                  "重庆通服应急设备有限公司",
                  "应急抢单",
                  "rush",
                  "等待供应商响应中",
                  "—",
                  0,
                  "—",
                  "剩余4分钟",
                  "两江新区",
                  !1,
                  {
                    channel: "短信＋抢单平台",
                    reminderCount: 1,
                    reminders: [
                      "22:50 达到首次响应时限，系统自动催办",
                      "22:55 仍未回复，催办 +1（累计1次）",
                    ],
                  },
                ),
              ],
              history: [
                "22:16 本单位库存核验为0",
                "22:30 跨单位调拨均无可用量",
                "22:40 启动应急抢单",
                "22:55 首家供应商回复有货",
              ],
            },
            {
              id: "M04",
              name: "电力电缆",
              spec: "YJV22-10kV 3×300",
              need: 2.5,
              unit: "千米",
              filled: 2.5,
              status: "等待在途/在建确认中",
              statusClass: "waiting",
              method: "跨单位0.8千米＋在途资源1.7千米",
              updated: "22:52",
              confirmed: !1,
              allowSplit: !0,
              procure: !1,
              activeChannel: "transit",
              selectedSourceIds: ["M04-U1", "M04-T1"],
              sources: [
                e(
                  "M04-U1",
                  "涪陵供电公司",
                  "跨单位调拨",
                  "unit",
                  "部分可调拨",
                  "0.8千米",
                  0.8,
                  "今日03:00",
                  "22:43",
                  "104km",
                  !0,
                ),
                e(
                  "M04-R1",
                  "渝西电缆供应商",
                  "应急抢单",
                  "rush",
                  "已回复无现货",
                  "0千米",
                  0,
                  "—",
                  "22:47",
                  "重庆",
                ),
                e(
                  "M04-T1",
                  "渝西在途工程电缆资源",
                  "在途/在建",
                  "transit",
                  "等待在途资源确认中",
                  "1.7千米",
                  1.7,
                  "今日04:30",
                  "22:52",
                  "运输中",
                  !0,
                  { channel: "在途/在建资源平台" },
                ),
                e(
                  "M04-P1",
                  "重庆电缆应急采购池",
                  "应急采购",
                  "purchase",
                  "未触发（在途资源可补足）",
                  "—",
                  0,
                  "—",
                  "—",
                  "采购平台",
                  !1,
                  { requested: !1 },
                ),
              ],
              history: [
                "22:16 本单位库存核验为0",
                "22:26 跨单位仅部分满足",
                "22:45 应急抢单无现货",
                "22:52 匹配到在途工程余量1.7千米",
              ],
            },
            {
              id: "M05",
              name: "电缆终端",
              spec: "10kV 3×300",
              need: 12,
              unit: "套",
              filled: 0,
              status: "等待供应商响应中",
              statusClass: "purple",
              method: "应急抢单进行中",
              updated: "22:54",
              confirmed: !1,
              allowSplit: !1,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: [],
              sources: [
                e(
                  "M05-U1",
                  "长寿供电公司",
                  "跨单位调拨",
                  "unit",
                  "已回复无库存",
                  "0套",
                  0,
                  "—",
                  "22:39",
                  "74km",
                ),
                e(
                  "M05-U2",
                  "万州供电公司",
                  "跨单位调拨",
                  "unit",
                  "已回复无库存",
                  "0套",
                  0,
                  "—",
                  "22:41",
                  "228km",
                ),
                e(
                  "M05-R1",
                  "重庆输配电设备有限公司",
                  "应急抢单",
                  "rush",
                  "等待供应商响应中",
                  "—",
                  0,
                  "—",
                  "剩余3分钟",
                  "重庆",
                  !1,
                  {
                    channel: "E物资",
                    reminderCount: 1,
                    reminders: [
                      "22:49 达到首次响应时限，系统自动催办",
                      "22:54 超时未回复，催办 +1（累计1次）",
                    ],
                  },
                ),
                e(
                  "M05-R2",
                  "西南电力附件供应中心",
                  "应急抢单",
                  "rush",
                  "已接单核库中",
                  "—",
                  0,
                  "待确认",
                  "22:53",
                  "成都",
                  !1,
                  { channel: "E物资" },
                ),
              ],
              history: [
                "22:16 本单位库存核验为0",
                "22:41 跨单位调拨无可用量",
                "22:43 启动应急抢单",
                "22:54 1家超时已自动催办",
              ],
            },
            {
              id: "M06",
              name: "应急照明灯",
              spec: "便携式防水",
              need: 30,
              unit: "盏",
              filled: 30,
              status: "等待跨单位确认中",
              statusClass: "waiting",
              method: "南岸供电公司跨单位调拨",
              updated: "22:45",
              confirmed: !1,
              allowSplit: !1,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: ["M06-U1"],
              sources: [
                e(
                  "M06-U1",
                  "南岸供电公司",
                  "跨单位调拨",
                  "unit",
                  "已回复可调拨",
                  "30盏",
                  30,
                  "今日01:20",
                  "22:45",
                  "22km",
                  !0,
                ),
                e(
                  "M06-U2",
                  "巴南供电公司",
                  "跨单位调拨",
                  "unit",
                  "等待跨单位响应中",
                  "—",
                  0,
                  "—",
                  "剩余7分钟",
                  "39km",
                ),
              ],
              history: [
                "22:16 本单位库存核验为0",
                "22:31 启动跨单位调拨",
                "22:45 南岸供电公司回复可完整调拨",
              ],
            },
            {
              id: "M07",
              name: "抢修帐篷",
              spec: "6人防雨型",
              need: 8,
              unit: "顶",
              filled: 8,
              status: "等待供应商确认中",
              statusClass: "purple",
              method: "应急抢单供应商直供",
              updated: "22:53",
              confirmed: !1,
              allowSplit: !1,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["M07-R1"],
              sources: [
                e(
                  "M07-U1",
                  "沙坪坝供电公司",
                  "跨单位调拨",
                  "unit",
                  "已回复无库存",
                  "0顶",
                  0,
                  "—",
                  "22:38",
                  "24km",
                ),
                e(
                  "M07-R1",
                  "重庆应急装备有限公司",
                  "应急抢单",
                  "rush",
                  "已回复有货",
                  "8顶",
                  8,
                  "今日03:40",
                  "22:53",
                  "重庆本地",
                  !0,
                  { price: "¥24,800", channel: "E物资" },
                ),
                e(
                  "M07-R2",
                  "西南防汛物资供应商",
                  "应急抢单",
                  "rush",
                  "等待供应商响应中",
                  "—",
                  0,
                  "—",
                  "剩余8分钟",
                  "成都",
                  !1,
                  { reminderCount: 0, channel: "E物资" },
                ),
              ],
              history: [
                "22:16 本单位库存核验为0",
                "22:38 跨单位调拨无可用量",
                "22:42 启动应急抢单",
                "22:53 本地供应商回复有货",
              ],
            },
            {
              id: "M08",
              name: "发电机",
              spec: "50kW静音型",
              need: 4,
              unit: "台",
              filled: 4,
              status: "等待在建资源确认中",
              statusClass: "waiting",
              method: "跨单位2台＋在建资源2台",
              updated: "22:56",
              confirmed: !1,
              allowSplit: !0,
              procure: !1,
              activeChannel: "transit",
              selectedSourceIds: ["M08-U1", "M08-T1"],
              sources: [
                e(
                  "M08-U1",
                  "大渡口供电公司",
                  "跨单位调拨",
                  "unit",
                  "部分可调拨",
                  "2台",
                  2,
                  "今日02:00",
                  "22:56",
                  "28km",
                  !0,
                ),
                e(
                  "M08-R1",
                  "重庆动力设备有限公司",
                  "应急抢单",
                  "rush",
                  "已回复无现货",
                  "0台",
                  0,
                  "—",
                  "22:50",
                  "重庆",
                ),
                e(
                  "M08-T1",
                  "重庆应急装备在建项目余量",
                  "在途/在建",
                  "transit",
                  "等待在建资源确认中",
                  "2台",
                  2,
                  "今日05:00",
                  "剩余10分钟",
                  "巴南",
                  !0,
                  { channel: "在途/在建资源平台" },
                ),
              ],
              history: [
                "22:16 本单位库存核验为0",
                "22:42 跨单位仅部分满足",
                "22:50 应急抢单无现货",
                "22:56 匹配到在建项目余量2台",
              ],
            },
            {
              id: "M09",
              name: "安全工器具套装",
              spec: "高压抢修套装",
              need: 15,
              unit: "套",
              filled: 0,
              status: "等待跨单位响应中",
              statusClass: "running",
              method: "跨单位调拨请求已发送",
              updated: "22:57",
              confirmed: !1,
              allowSplit: !0,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: [],
              sources: [
                e(
                  "M09-U1",
                  "南岸供电公司",
                  "跨单位调拨",
                  "unit",
                  "等待跨单位响应中",
                  "—",
                  0,
                  "—",
                  "剩余5分钟",
                  "22km",
                ),
                e(
                  "M09-U2",
                  "九龙坡供电公司",
                  "跨单位调拨",
                  "unit",
                  "等待跨单位响应中",
                  "—",
                  0,
                  "—",
                  "剩余5分钟",
                  "26km",
                ),
              ],
              history: [
                "22:16 本单位库存核验为0",
                "22:32 启动跨单位调拨",
                "22:57 等待两家单位回复",
              ],
            },
            {
              id: "M10",
              name: "防汛沙袋",
              spec: "50kg标准袋",
              need: 500,
              unit: "只",
              filled: 0,
              status: "应急采购",
              statusClass: "attention",
              method: "前序渠道无可用量，进入应急采购",
              updated: "22:59",
              confirmed: !1,
              allowSplit: !0,
              procure: !0,
              activeChannel: "purchase",
              selectedSourceIds: [],
              sources: [
                e(
                  "M10-U1",
                  "九龙坡供电公司",
                  "跨单位调拨",
                  "unit",
                  "已回复无库存",
                  "0只",
                  0,
                  "—",
                  "22:40",
                  "26km",
                ),
                e(
                  "M10-R1",
                  "重庆防汛物资有限公司",
                  "应急抢单",
                  "rush",
                  "超时未回复",
                  "—",
                  0,
                  "—",
                  "超时4分钟",
                  "重庆",
                  !1,
                  {
                    channel: "E物资",
                    reminderCount: 2,
                    reminders: [
                      "22:48 达到首次响应时限，系统自动催办",
                      "22:53 仍未回复，催办 +1（累计1次）",
                      "22:58 再次超时，催办 +1（累计2次）",
                    ],
                  },
                ),
                e(
                  "M10-T1",
                  "市级防汛在途储备",
                  "在途/在建",
                  "transit",
                  "已核实无可调余量",
                  "0只",
                  0,
                  "—",
                  "22:55",
                  "运输中",
                ),
                e(
                  "M10-P1",
                  "重庆应急物资采购供应池",
                  "应急采购",
                  "purchase",
                  "应急采购",
                  "—",
                  0,
                  "预计今日07:30",
                  "22:59",
                  "采购平台",
                  !1,
                  { channel: "E物资", reminderCount: 0 },
                ),
              ],
              history: [
                "22:16 本单位库存核验为0",
                "22:40 跨单位无库存",
                "22:43 启动应急抢单",
                "22:58 供应商两次超时未回复",
                "22:59 转入应急采购询价",
              ],
            },
          ]),
          expandResponderPool(),
          (state.task.events = [
            {
              time: "22:59",
              title: "防汛沙袋进入应急采购",
              copy: "跨单位调拨、应急抢单和在途/在建均未形成可用资源，按优先级进入应急采购。",
              level: "important",
            },
            {
              time: "22:58",
              title: "应急抢单供应商第二次超时",
              copy: "重庆防汛物资有限公司仍未回复，系统自动执行催办 +1，累计2次。",
              level: "alert",
            },
            {
              time: "22:56",
              title: "发电机匹配到在建项目余量",
              copy: "跨单位仅可调2台，应急抢单无现货，已匹配在建项目余量2台，等待确认。",
              level: "important",
            },
            {
              time: "22:55",
              title: "通信电源应急抢单首家回复有货",
              copy: "重庆电源设备有限公司可供5套，等待用户确认是否采用。",
              level: "important",
            },
            {
              time: "22:48",
              title: "光缆形成跨单位拼单组合",
              copy: "北碚、合川各可调拨1.37千米，等待用户确认是否接受拼单。",
              level: "alert",
            },
          ]));
        const t = state.emergencies?.find((e) => "E001" === e.id);
        (t &&
          ((t.stage = "四渠道顺序寻源"),
          (t.summary =
            "3条待跨单位确认、3条待供应商响应、2条待在途/在建确认、1条应急采购"),
          (t.risk = "4条物资等待人工确认")),
          (state.assistant = [
            {
              role: "assistant",
              text: "本任务10条物资均已确认本单位无可用库存，智能体正按“跨单位调拨 → 应急抢单 → 在途/在建 → 应急采购”的顺序推进寻源。",
            },
            {
              role: "assistant",
              text: "当前3条等待跨单位确认、3条处于供应商响应或确认、2条等待在途/在建资源确认、1条已进入应急采购。供应商超时会自动催办，再次超时则催办次数 +1。",
            },
          ]));
      }
      const SOUL_TEMPLATES = [
        {
          id: "emergency",
          name: "应急指挥型",
          tag: "行动导向",
          desc: "适合暴雨、山洪、山火和抢修场景。先报状态、缺口和下一步，表达冷静简洁。",
          content:
            "name: 应急指挥型\nidentity: 国网重庆电力应急物资保障指挥助手\ntone: 冷静、明确、简洁、行动导向\nresponse_order:\n  - 先说明任务状态与最近更新时间\n  - 再说明已满足、部分满足和缺口物资\n  - 明确下一步自动动作与需要用户决策的事项\nprinciples:\n  - 不等待用户上线才开始工作\n  - 结论与过程证据分层展示\n  - 物资可逐条确认、逐条转应急采购\n  - 方案调整必须说明收益、代价和风险\nboundaries:\n  - 不虚构库存、供应商回复或原系统状态\n  - 涉及截止寻源和正式回写时要求权限校验\nstyle:\n  sentence: 短句\n  priority: 数字和动作优先\n  avoid: 大段技术过程和无结论描述",
        },
        {
          id: "expert",
          name: "国网业务专家型",
          tag: "规则严谨",
          desc: "强调业务规则、口径、依据和可追溯性，适合采购、库存、合同及供应商专业。",
          content:
            "name: 国网业务专家型\nidentity: 电力物资与供应链业务专家\ntone: 严谨、专业、克制\nresponse_order:\n  - 明确业务对象、时间范围和统计口径\n  - 给出规则依据与当前结论\n  - 展示数据来源、差异和例外情况\nprinciples:\n  - 规则优先但允许说明智能优化建议\n  - 关键结论必须可追溯到系统数据或业务记录\n  - 区分原系统规则结果与智能体推荐结果\nboundaries:\n  - 不替代有权限要求的正式审批\n  - 信息不完整时先澄清，不擅自补齐\nstyle:\n  sentence: 完整正式\n  priority: 依据、口径、结论",
        },
        {
          id: "report",
          name: "领导汇报型",
          tag: "重点突出",
          desc: "适合领导驾驶舱和汇报材料，先讲结论、影响和建议，再补充必要依据。",
          content:
            "name: 领导汇报型\nidentity: 供应链运营汇报助手\ntone: 正式、凝练、重点突出\nresponse_order:\n  - 一句话总体判断\n  - 三项以内关键进展或风险\n  - 明确需要决策的事项和建议\nprinciples:\n  - 使用可朗读的汇报语言\n  - 只保留影响决策的信息\n  - 数字、差异和风险必须突出\nboundaries:\n  - 不用技术术语堆砌\n  - 不掩盖不确定性和数据缺口\nstyle:\n  sentence: 汇报口吻\n  priority: 结论、影响、建议",
        },
        {
          id: "service",
          name: "基层服务型",
          tag: "易懂友好",
          desc: "面向一线业务人员，少术语、步骤清晰，主动告诉用户现在该做什么。",
          content:
            "name: 基层服务型\nidentity: 一线业务协同助手\ntone: 友好、耐心、清楚\nresponse_order:\n  - 用一句话说明当前情况\n  - 给出可以直接执行的步骤\n  - 提醒需要准备的材料和注意事项\nprinciples:\n  - 不要求用户理解系统内部实现\n  - 每次只提出少量明确选择\n  - 错误提示要说明如何修复\nboundaries:\n  - 不用模糊话术推卸问题\n  - 不把系统异常归因于用户\nstyle:\n  sentence: 口语化但正式\n  priority: 步骤和操作结果",
        },
        {
          id: "risk",
          name: "审慎风控型",
          tag: "风险优先",
          desc: "适合方案审核、回写、采购和履约关键节点，优先识别权限、合规和执行风险。",
          content:
            "name: 审慎风控型\nidentity: 供应链风险与合规审查助手\ntone: 审慎、客观、可核验\nresponse_order:\n  - 先列出风险等级和触发原因\n  - 再说明影响范围与可选处置\n  - 给出需人工复核或审批的节点\nprinciples:\n  - 高风险动作默认要求二次确认\n  - 保留方案修改、用户理由和回写记录\n  - 区分事实、推断和建议\nboundaries:\n  - 不绕过审批、权限和审计要求\n  - 不将未回复视为拒绝或同意\nstyle:\n  sentence: 清晰审慎\n  priority: 风险、证据、控制措施",
        },
      ];
      let selectedSoulAgent = 0,
        selectedSoulTemplate = "emergency",
        soulValidated = !1;
      function initAgentSouls() {
        const e = [
          "emergency",
          "expert",
          "expert",
          "expert",
          "risk",
          "service",
        ];
        state.agents.forEach((t, s) => {
          const a =
            SOUL_TEMPLATES.find((t) => t.id === e[s]) || SOUL_TEMPLATES[1];
          (t.soulTemplate || (t.soulTemplate = a.name),
            t.soulVersion || (t.soulVersion = 0 === s ? 4 : 2),
            t.soulUpdated || (t.soulUpdated = 0 === s ? "今天 10:26" : "昨天"),
            t.soulContent || (t.soulContent = a.content),
            t.soulHistory ||
              (t.soulHistory = [
                {
                  version: t.soulVersion,
                  template: t.soulTemplate,
                  time: t.soulUpdated,
                  status: "当前版本",
                },
                {
                  version: Math.max(1, t.soulVersion - 1),
                  template: "国网业务专家型",
                  time: "7月13日 18:40",
                  status: "可回滚",
                },
              ]));
        });
      }
      function renderSoulTemplates() {
        $("#soulTemplateList").innerHTML = SOUL_TEMPLATES.map(
          (e) =>
            `<div class="template-card ${selectedSoulTemplate === e.id ? "active" : ""}" data-soul-template="${e.id}"><div class="template-card-head"><strong>${e.name}</strong><span class="soul-badge">${e.tag}</span></div><p>${e.desc}</p><button class="btn sm success" data-apply-soul="${e.id}">一键写入编辑器</button></div>`,
        ).join("");
      }
      function renderSoulHistory() {
        const e = state.agents[selectedSoulAgent];
        $("#soulHistory").innerHTML = e.soulHistory
          .map(
            (e) =>
              `<div class="history-item"><div><b>${e.version} · ${e.template}</b><br><span>${e.time}</span></div><span>${e.status}</span></div>`,
          )
          .join("");
      }
      function openSoulEditor(e = 0) {
        selectedSoulAgent = e;
        const t = state.agents[e],
          s =
            SOUL_TEMPLATES.find((e) => e.name === t.soulTemplate) ||
            SOUL_TEMPLATES[0];
        ((selectedSoulTemplate = s.id),
          (soulValidated = !1),
          ($("#soulModalTitle").textContent = `${t.name} · Soul 性格文件`),
          ($("#soulModalSub").textContent =
            `${t.tools}个工具 · ${t.skills}项技能 · 当前在线`),
          ($("#soulCurrentTemplate").textContent = t.soulTemplate),
          ($("#soulCurrentVersion").textContent = `${t.soulVersion}`),
          ($("#soulUpdatedAt").textContent = t.soulUpdated),
          ($("#soulEditor").value = t.soulContent),
          ($("#soulValidation").innerHTML =
            '<span class="status neutral">尚未校验</span><span>热更新前将检查身份、语气、原则和安全边界。</span>'),
          ($("#soulPreview").innerHTML =
            '<div class="preview-empty">选择模板或点击“生成效果预览”查看示例回复。</div>'),
          renderSoulTemplates(),
          renderSoulHistory(),
          openOverlay("soulModal"));
      }
      function applySoulTemplate(e) {
        const t = SOUL_TEMPLATES.find((t) => t.id === e);
        t &&
          ((selectedSoulTemplate = e),
          ($("#soulEditor").value = t.content),
          (soulValidated = !1),
          renderSoulTemplates(),
          ($("#soulValidation").innerHTML =
            `<span class="status waiting">待校验</span><span>已写入“${t.name}”，尚未发布。</span>`),
          previewSoul());
      }
      function validateSoul() {
        const e = $("#soulEditor").value,
          t = ["identity:", "tone:", "principles:", "boundaries:"].filter(
            (t) => !e.includes(t),
          );
        return e.length < 120 || t.length
          ? ((soulValidated = !1),
            ($("#soulValidation").innerHTML =
              `<span class="status attention">校验未通过</span><span>${t.length ? "缺少 " + t.join("、") : "配置内容过短，请补充完整规则。"}</span>`),
            !1)
          : ((soulValidated = !0),
            ($("#soulValidation").innerHTML =
              '<span class="status done">校验通过</span><span>结构完整，可执行一键热更新。</span>'),
            !0);
      }
      function previewSoul() {
        const e =
            SOUL_TEMPLATES.find((e) => e.id === selectedSoulTemplate) ||
            SOUL_TEMPLATES[0],
          t = {
            emergency:
              "截至22:58，10条物资中4条已满足、3条部分满足、2条等待回复、1条进入供应商询供。当前可先确认交换机和应急照明灯；光缆需要您判断是否接受两家单位拼单。系统将在23:03再次检查，并对未回复单位自动催办。",
            expert:
              "按当前任务口径，物资满足度以“已确认可供数量”计算，未回复不计入可用资源。现有结果可形成初步方案，但正式回写前仍需确认光缆拆分规则和通信电源采购权限。",
            report:
              "总体看，当前应急寻源已具备初步成案条件。重点有三项：一是4条物资已满足；二是光缆拼单需人工判断；三是通信电源已提前询供。建议先确认已满足物资，并保留缺口继续寻源。",
            service:
              "任务已经自动运行42分钟。目前最需要您处理的是光缆：可以接受北碚和合川两家拼单，也可以继续等一家单位完整满足。点击对应选项后，系统会自动重新计算方案。",
            risk: "当前方案为中低风险。主要风险是光缆涉及两家拼单、通信电源需进入应急采购。建议在回写前复核到货承诺、采购权限和用户确认理由，并保留供应商原始回复。",
          };
        $("#soulPreview").innerHTML =
          `<div class="preview-message"><div class="preview-label">“${e.name}”示例回复</div>${t[e.id] || t.expert}<div class="preview-actions"><span>状态优先</span><span>可执行动作</span><span>风险可追溯</span></div></div>`;
      }
      function hotUpdateSoul() {
        if (!validateSoul()) return;
        const e = state.agents[selectedSoulAgent],
          t = SOUL_TEMPLATES.find((e) => e.id === selectedSoulTemplate) || {
            name: "自定义性格",
          };
        (e.soulHistory.forEach((e) => (e.status = "可回滚")),
          (e.soulVersion += 1),
          (e.soulTemplate = t.name),
          (e.soulContent = $("#soulEditor").value),
          (e.soulUpdated = "刚刚"),
          e.soulHistory.unshift({
            version: e.soulVersion,
            template: e.soulTemplate,
            time: "刚刚",
            status: "当前版本",
          }),
          ($("#soulCurrentTemplate").textContent = e.soulTemplate),
          ($("#soulCurrentVersion").textContent = `${e.soulVersion}`),
          ($("#soulUpdatedAt").textContent = "刚刚"),
          renderSoulHistory(),
          renderAgents(),
          showToast(`${e.name} 已热更新至 ${e.soulVersion}，当前任务不中断`));
      }
      function rollbackSoul() {
        const e = state.agents[selectedSoulAgent],
          t = e.soulHistory[1];
        if (!t) return void showToast("暂无可回滚版本");
        ((e.soulVersion += 1), (e.soulTemplate = t.template));
        const s =
          SOUL_TEMPLATES.find((e) => e.name === t.template) ||
          SOUL_TEMPLATES[1];
        ((e.soulContent = s.content),
          (e.soulUpdated = "刚刚"),
          e.soulHistory.unshift({
            version: e.soulVersion,
            template: e.soulTemplate,
            time: "刚刚",
            status: "当前版本（回滚）",
          }),
          ($("#soulEditor").value = e.soulContent),
          (selectedSoulTemplate = s.id),
          renderSoulTemplates(),
          renderSoulHistory(),
          ($("#soulCurrentTemplate").textContent = e.soulTemplate),
          ($("#soulCurrentVersion").textContent = `${e.soulVersion}`),
          renderAgents(),
          showToast("已回滚并以新版本热更新"));
      }
      function exportSoul() {
        const e = state.agents[selectedSoulAgent],
          t = new Blob([$("#soulEditor").value], {
            type: "text/plain;charset=utf-8",
          }),
          s = URL.createObjectURL(t),
          a = document.createElement("a");
        ((a.href = s),
          (a.download = `${e.name.replace(/\s+/g, "_")}_${e.soulVersion}.soul`),
          a.click(),
          setTimeout(() => URL.revokeObjectURL(s), 500));
      }
      function showToast(e) {
        const t = $("#toast");
        ((t.textContent = e),
          t.classList.add("show"),
          clearTimeout(showToast._t),
          (showToast._t = setTimeout(() => t.classList.remove("show"), 2200)));
      }
      function openOverlay(e) {
        $("#" + e).classList.add("show");
      }
      function closeOverlay(e) {
        $("#" + e).classList.remove("show");
      }
      function setView(e) {
        ((state.view = e),
          $$(".view").forEach((e) => e.classList.remove("active")));
        const t = $("#view-" + e);
        (t && t.classList.add("active"),
          $$("[data-view]").forEach((t) =>
            t.classList.toggle("active", t.dataset.view === e),
          ),
          $$(".mobile-bottom [data-view]").forEach((t) =>
            t.classList.toggle("active", t.dataset.view === e),
          ));
        const s = {
          chat: "对话",
          chats: "查询对话",
          agents: "业务智能体中心",
          agentchat: state.agents?.[state.selectedAgent]?.name || "智能体对话",
          scheduled: "我的常用",
          knowledge: "知识中心",
          emergency: "应急任务智能体 / 应急任务中心",
          workbench: state.task?.title || "应急任务工作台",
        };
        (($("#crumb").innerHTML = `<b>智慧工作台</b> / ${s[e] || e}`),
          innerWidth < 821 && $("#sidebar").classList.remove("mobile-open"),
          "workbench" === e && renderWorkbench(),
          "agents" === e && renderAgents(),
          "agentchat" === e && renderAgentChat(!1),
          "knowledge" === e && renderKnowledge(),
          "emergency" === e &&
            (renderEmergencyTable(), renderEmergencyCenterChat()));
      }
      function renderRecent() {
        $("#recentList").innerHTML = state.conversations
          .map(
            (e, t) =>
              `<button class="recent-item ${0 === t && "workbench" === state.view ? "active" : ""}" data-recent="${t}">${e.title}<span class="recent-meta"><span class="mini-dot ${e.live ? "live" : ""}"></span>${e.time} · ${e.type}</span></button>`,
          )
          .join("");
      }
      function renderChatTable() {
        const e = ($("#chatSearch")?.value || "").toLowerCase();
        $("#chatTable").innerHTML = state.conversations
          .filter(
            (t) =>
              t.title.toLowerCase().includes(e) ||
              t.type.toLowerCase().includes(e),
          )
          .map(
            (e, t) =>
              `<tr><td><div class="task-name">${e.title}</div><div class="task-code">${e.live ? "正在后台运行" : "已保存的对话线程"}</div></td><td><span class="status ${"应急任务" === e.type ? "running" : "neutral"}">${e.type}</span></td><td>${e.time}</td><td>${e.messages}</td><td><button class="text-btn" data-open-chat="${t}">打开</button><button class="text-btn">导出</button></td></tr>`,
          )
          .join("");
      }
      const AGENT_METADATA = [
        {
          domain: "应急",
          category: "专业",
          type: "省级专业智能体",
          glyph: "应",
          featured: !0,
          calls: 36,
          success: "98.6%",
          avg: "12秒",
          knowledge: 3,
          memory: 46,
          recent: "3分钟前完成“渝东北山洪任务”资源初筛",
          tasks: "3个任务执行中",
          attention: "2个任务需要人工介入",
          skillsNames: [
            "应急事件识别",
            "物资需求解析",
            "库存查询",
            "跨单位征询",
            "协议库存查询",
            "供应商询供",
            "满足度分析",
            "方案推荐",
            "回写原系统",
            "事件复盘",
          ],
          knowledgeNames: [
            "应急物资保障知识空间",
            "重庆物资制度知识空间",
            "应急案例与专家经验空间",
          ],
          toolNames: [
            "智慧供应链平台",
            "库存资源接口",
            "供应商通讯录",
            "短信与邮件服务",
            "原系统回写接口",
          ],
        },
        {
          domain: "问数",
          category: "专业",
          type: "省级专业智能体",
          glyph: "数",
          featured: !0,
          calls: 86,
          success: "97.3%",
          avg: "8秒",
          knowledge: 4,
          memory: 32,
          recent: "8分钟前完成采购执行趋势分析",
          tasks: "今日完成86次查询",
          attention: "3个高频口径已沉淀",
          skillsNames: [
            "意图识别",
            "查询计划生成",
            "SQL生成",
            "口径校验",
            "多维分析",
            "结果解释",
            "图表生成",
          ],
          knowledgeNames: [
            "指标口径知识空间",
            "采购数据字典",
            "供应链业务规则",
            "问数案例空间",
          ],
          toolNames: ["数据中台", "SQL执行引擎", "指标服务", "报表生成器"],
        },
        {
          domain: "采购",
          category: "专业",
          type: "专业智能体",
          glyph: "目",
          featured: !1,
          calls: 24,
          success: "98.4%",
          avg: "15秒",
          knowledge: 3,
          memory: 28,
          recent: "18分钟前完成2026年第二批目录规则校验",
          skillsNames: [
            "目录识别",
            "规则审查",
            "历史案例匹配",
            "差异分析",
            "方案生成",
            "风险校验",
          ],
          knowledgeNames: [
            "采购目录制度空间",
            "历史目录案例空间",
            "审查规则空间",
          ],
          toolNames: ["目录管理系统", "规则引擎", "文档解析服务"],
        },
        {
          domain: "采购",
          category: "专业",
          type: "专业智能体",
          glyph: "批",
          featured: !1,
          calls: 19,
          success: "96.1%",
          avg: "18秒",
          knowledge: 3,
          memory: 19,
          recent: "26分钟前更新采购批次排程建议",
          skillsNames: [
            "时限识别",
            "优先级判断",
            "资源约束分析",
            "排程生成",
            "冲突检测",
          ],
          knowledgeNames: ["采购计划规则空间", "批次案例空间", "时限口径空间"],
          toolNames: ["采购计划系统", "排程引擎", "日历服务"],
        },
        {
          domain: "供应商",
          category: "专业",
          type: "专业智能体",
          glyph: "供",
          featured: !1,
          calls: 18,
          success: "96.8%",
          avg: "10秒",
          knowledge: 4,
          memory: 41,
          recent: "1小时前生成2家供应商风险预警",
          skillsNames: [
            "供应商画像",
            "履约分析",
            "质量分析",
            "舆情检索",
            "风险评分",
            "处置建议",
          ],
          knowledgeNames: [
            "供应商制度空间",
            "履约案例空间",
            "质量问题空间",
            "风险规则空间",
          ],
          toolNames: ["供应商平台", "合同系统", "质量监督系统", "外部舆情服务"],
        },
        {
          domain: "工单",
          category: "系统",
          type: "系统智能体",
          glyph: "单",
          featured: !1,
          calls: 51,
          success: "95.9%",
          avg: "9秒",
          knowledge: 4,
          memory: 58,
          recent: "刚刚完成工单意图识别与智能派单",
          skillsNames: [
            "工单解析",
            "字段校验",
            "智能填单",
            "规则判断",
            "候选资源筛选",
            "智能派单",
            "节点督办",
          ],
          knowledgeNames: [
            "工单规则空间",
            "历史处置案例",
            "业务流程空间",
            "专家经验空间",
          ],
          toolNames: ["工单中心", "统一流程平台", "消息中心"],
        },
        {
          domain: "采购",
          category: "个人",
          type: "个人智能体",
          glyph: "报",
          featured: !1,
          calls: 12,
          success: "99.1%",
          avg: "7秒",
          knowledge: 2,
          memory: 14,
          recent: "今日09:00自动生成供应链运营简报",
          skillsNames: ["数据汇总", "异常识别", "报告生成", "领导摘要"],
          knowledgeNames: ["个人知识空间", "领导汇报模板空间"],
          toolNames: ["数据中台", "文档生成器"],
        },
        {
          domain: "通用",
          category: "我的",
          type: "待配置智能体",
          glyph: "＋",
          featured: !1,
          calls: 0,
          success: "—",
          avg: "—",
          knowledge: 0,
          memory: 0,
          recent: "尚未配置",
          skillsNames: [],
          knowledgeNames: [],
          toolNames: [],
        },
      ];
      function enrichAgentData() {
        if (
          (state.agents.forEach((e, t) =>
            Object.assign(
              e,
              AGENT_METADATA[t] || AGENT_METADATA[AGENT_METADATA.length - 1],
            ),
          ),
          false && state.agents.length < 8)
        ) {
          const e = {
            icon: "□",
            name: "供应链工单处置智能体",
            desc: "智能解析工单、校验字段、推荐处置资源并跟踪流程节点。",
            tools: 8,
            skills: 9,
            status: "在线",
            soulTemplate: "基层服务型",
            soulVersion: 2,
            soulUpdated: "昨天",
          };
          state.agents.splice(5, 0, e);
          const t = {
            icon: "▤",
            name: "供应链运营简报智能体",
            desc: "自动汇总业务变化、异常风险和重点事项，生成领导汇报材料。",
            tools: 5,
            skills: 6,
            status: "在线",
            soulTemplate: "领导汇报型",
            soulVersion: 3,
            soulUpdated: "今天09:10",
          };
          (state.agents.splice(6, 0, t),
            state.agents.forEach((e, t) =>
              Object.assign(
                e,
                AGENT_METADATA[t] || AGENT_METADATA[AGENT_METADATA.length - 1],
              ),
            ));
        }
        ((state.agentCategory = state.agentCategory || "全部"),
          (state.agentDomain = state.agentDomain || "全部"),
          (state.agentView = state.agentView || "card"),
          (state.selectedAgent = state.selectedAgent || 0),
          (state.agentManageTab = state.agentManageTab || "overview"),
          (state.agentChatMessages = state.agentChatMessages || {}));
      }
      function normalizeAgentState() {
        [
          {
            name: "应急任务智能体",
            desc: "自动感知应急事件，持续开展寻源、询供、方案推荐和执行衔接。",
            domain: "应急",
            category: "专业",
            type: "专业智能体",
            skills: 12,
            tools: 8,
            knowledge: 3,
            status: "在线",
            soulTemplate: "应急指挥型",
          },
          {
            name: "供应链问数智能体",
            desc: "支持采购、合同、仓储、供应商等业务数据查询与多维分析。",
            domain: "问数",
            category: "专业",
            type: "省级专业智能体",
            skills: 8,
            tools: 7,
            knowledge: 4,
            status: "在线",
            soulTemplate: "业务专家型",
          },
          {
            name: "采购计划编制智能体",
            desc: "自动识别采购需求，校验规则并生成计划草案。",
            domain: "采购",
            category: "专业",
            type: "专业智能体",
            skills: 9,
            tools: 6,
            knowledge: 3,
            status: "在线",
            soulTemplate: "业务专家型",
          },
          {
            name: "合同履约智能体",
            desc: "跟踪合同执行进度，识别逾期与履约风险。",
            domain: "合同",
            category: "专业",
            type: "专业智能体",
            skills: 8,
            tools: 6,
            knowledge: 3,
            status: "在线",
            soulTemplate: "审慎风控型",
          },
          {
            name: "供应商管理智能体",
            desc: "查询供应商档案、履约、质量及风险信息。",
            domain: "供应商",
            category: "专业",
            type: "专业智能体",
            skills: 10,
            tools: 7,
            knowledge: 4,
            status: "在线",
            soulTemplate: "审慎风控型",
          },
          {
            name: "工单处置智能体",
            desc: "自动解析、填单、派单，跟踪工单执行状态。",
            domain: "工单",
            category: "系统",
            type: "系统智能体",
            skills: 0,
            tools: 8,
            knowledge: 2,
            status: "可配置",
            soulTemplate: "基层服务型",
          },
          {
            name: "供应链运营简报智能体",
            desc: "自动汇总业务变化、异常风险和重点事项，生成领导汇报材料。",
            domain: "采购",
            category: "个人",
            type: "个人智能体",
            skills: 6,
            tools: 5,
            knowledge: 2,
            status: "在线",
            soulTemplate: "领导汇报型",
          },
          {
            name: "仓储物流协同智能体",
            desc: "查询库存与配送状态，协同仓储、物流和现场收货任务。",
            domain: "仓储",
            category: "专业",
            type: "专业智能体",
            skills: 7,
            tools: 6,
            knowledge: 3,
            status: "在线",
            soulTemplate: "业务专家型",
          },
        ].forEach((e, t) => {
          state.agents[t] && Object.assign(state.agents[t], e);
        });
      }
      function agentAvailable(e) {
        return "在线" === e.status;
      }
      function agentStatusClass(e) {
        return agentAvailable(e) ? "done" : "neutral";
      }
      function agentDisplayStatus(e) {
        return agentAvailable(e) ? "可用" : "暂不可用";
      }
      function getFilteredAgents() {
        const e = ($("#agentSearch")?.value || "").toLowerCase();
        return state.agents
          .map((e, t) => ({ ...e, _index: t }))
          .filter((t) => {
            const s =
                "全部" === state.agentCategory ||
                t.category === state.agentCategory,
              a =
                "全部" === state.agentDomain || t.domain === state.agentDomain,
              n =
                !e ||
                [t.name, t.desc, t.soulTemplate, t.domain]
                  .join(" ")
                  .toLowerCase()
                  .includes(e);
            return s && a && n;
          });
      }
      function agentIconId(e) {
        return "应急" === e.domain
          ? "i-bot"
          : "问数" === e.domain
            ? "i-activity"
            : "供应商" === e.domain
              ? "i-shield"
              : "工单" === e.domain
                ? "i-file"
                : "采购" === e.domain
                  ? "i-book"
                  : "i-bot";
      }
      function agentMenuHtml(e) {
        const t = agentAvailable(e);
        return `<div class="agent-overflow-agentmanagement" data-agent-menu-panel="${e._index}"><button class="agent-overflow-item-agentmanagement" data-agent-menu="overview" data-agent-index="${e._index}">${icons("i-target")}查看详情</button><button class="agent-overflow-item-agentmanagement" data-agent-menu="soul" data-agent-index="${e._index}">${icons("i-settings")}Soul配置</button><button class="agent-overflow-item-agentmanagement" data-agent-menu="skills" data-agent-index="${e._index}">${icons("i-network")}技能编排</button><button class="agent-overflow-item-agentmanagement" data-agent-menu="knowledge" data-agent-index="${e._index}">${icons("i-book")}知识与记忆</button><button class="agent-overflow-item-agentmanagement" data-agent-menu="tools" data-agent-index="${e._index}">${icons("i-grid")}工具与系统</button><div class="agent-overflow-sep-agentmanagement"></div><button class="agent-overflow-item-agentmanagement" data-agent-menu="versions" data-agent-index="${e._index}">${icons("i-upload")}版本发布</button><button class="agent-overflow-item-agentmanagement" data-agent-menu="copy" data-agent-index="${e._index}">${icons("i-file")}复制智能体</button><button class="agent-overflow-item-agentmanagement danger" data-agent-menu="toggle" data-agent-index="${e._index}">${icons(t ? "i-pause" : "i-play")}${t ? "停用智能体" : "启用智能体"}</button></div>`;
      }
      function agentCardHtml(e) {
        const t = agentAvailable(e);
        return `<article class="agent-card-agentmanagement ${"应急" === e.domain ? "emergency" : ""}"><button class="agent-more-agentmanagement" data-agent-more="${e._index}" aria-label="更多操作">${icons("i-more")}</button>${agentMenuHtml(e)}<div class="agent-card-main-agentmanagement"><div class="agent-icon-agentmanagement">${icons(agentIconId(e))}</div><div class="agent-card-copy-agentmanagement"><div class="agent-card-name-row-agentmanagement"><div class="agent-card-name-agentmanagement">${e.name}</div><span class="agent-availability-agentmanagement ${t ? "" : "off"}">${t ? "可用" : "暂不可用"}</span></div><div class="agent-card-desc-agentmanagement">${e.desc}</div></div></div><div class="agent-card-divider-agentmanagement"></div><div class="agent-meta-agentmanagement"><span>${icons("i-bot")}Soul：${e.soulTemplate}</span><span>${icons("i-grid")}技能：${e.skills ? `${e.skills}项` : "配置中"}</span><span>${icons("i-book")}知识空间：${e.knowledge ? `${e.knowledge}个` : "未绑定"}</span></div><button class="agent-chat-cta-agentmanagement" data-agent-chat="${e._index}" ${t ? "" : "disabled"}>${t ? "与智能体对话" : "暂不可用"}</button></article>`;
      }
      function renderAgents() {
        const e = getFilteredAgents();
        (($("#agentGrid").innerHTML = e.map(agentCardHtml).join("")),
          ($("#agentGrid").style.display =
            "card" === state.agentView ? "grid" : "none"),
          $("#agentList").classList.toggle("show", "list" === state.agentView),
          ($("#agentList").innerHTML =
            `<table class="agent-table"><thead><tr><th>智能体</th><th>业务领域</th><th>Soul</th><th>技能</th><th>知识空间</th><th>状态</th><th>操作</th></tr></thead><tbody>${e
              .map((e) => {
                const t = agentAvailable(e);
                return `<tr class="${t ? "" : "agent-unavailable"}"><td><div class="agent-row-name"><div class="agent-icon-agentmanagement" style="width:36px;height:36px;flex-basis:36px">${icons(agentIconId(e))}</div><div><strong>${e.name}</strong><br><small>${e.type}</small></div></div></td><td>${e.domain}</td><td>${e.soulTemplate}</td><td>${e.skills ? `${e.skills}项` : "配置中"}</td><td>${e.knowledge ? `${e.knowledge}个` : "未绑定"}</td><td><span class="agent-availability-agentmanagement ${t ? "" : "off"}">${t ? "可用" : "暂不可用"}</span></td><td><div class="agent-list-actions-agentmanagement"><button class="text-btn" data-agent-chat="${e._index}" ${t ? "" : "disabled"}>${t ? "与智能体对话" : "暂不可用"}</button><div class="agent-list-more-wrap-agentmanagement"><button class="agent-more-agentmanagement" style="position:relative;top:auto;right:auto" data-agent-more="${e._index}">${icons("i-more")}</button>${agentMenuHtml(e)}</div></div></td></tr>`;
              })
              .join("")}</tbody></table>`),
          ($("#agentCountText").textContent = `共${e.length}个智能体`));
        const t = state.agents.length,
          s = state.agents.filter(agentAvailable).length;
        (($("#agentTotalMetric").textContent = t),
          ($("#agentAvailableMetric").textContent = s),
          $$("[data-agent-category]").forEach((e) =>
            e.classList.toggle(
              "active",
              e.dataset.agentCategory === state.agentCategory,
            ),
          ),
          $$("[data-agent-domain]").forEach((e) =>
            e.classList.toggle(
              "active",
              e.dataset.agentDomain === state.agentDomain,
            ),
          ),
          $$("[data-agent-view]").forEach((e) =>
            e.classList.toggle(
              "active",
              e.dataset.agentView === state.agentView,
            ),
          ));
      }
      function agentPromptSamples(e) {
        return "应急" === e.domain
          ? [
              "查看当前需要我介入的应急任务",
              "分析重庆万州山洪任务的物资缺口",
              "催办所有超时未回复单位",
              "基于现有回复生成初步方案",
            ]
          : "问数" === e.domain
            ? [
                "分析本月采购执行率及异常原因",
                "对比各单位供应商履约情况",
                "查询近三年合同逾期趋势",
                "生成今日供应链运营数据摘要",
              ]
            : "供应商" === e.domain
              ? [
                  "查看高风险供应商及主要风险",
                  "分析供应商近期履约变化",
                  "生成供应商风险处置建议",
                  "查询质量问题重复发生情况",
                ]
              : [
                  "介绍你能处理的业务范围",
                  "基于现有数据给出处理建议",
                  "查看最近运行任务",
                  "生成一份业务分析摘要",
                ];
      }
      function renderAgentChat(e = !1) {
        const t = state.agents[state.selectedAgent] || state.agents[0];
        (($("#agentChatGlyph").textContent = t.glyph),
          ($("#agentChatTitle").textContent = t.name),
          ($("#agentChatMeta").textContent =
            `Soul：${t.soulTemplate} ${t.soulVersion} · ${t.skills}项技能`));
        const s = String(state.selectedAgent);
        (!e && state.agentChatMessages[s]) || (state.agentChatMessages[s] = []);
        const a = state.agentChatMessages[s];
        let n = `<div class="agent-chat-welcome"><div class="agent-glyph">${t.glyph}</div><h1>${t.name}</h1><p>${t.desc}</p><div class="agent-prompt-chips">${agentPromptSamples(
          t,
        )
          .map(
            (e) =>
              `<button class="agent-prompt-chip" data-agent-prompt="${e}">${e}</button>`,
          )
          .join("")}</div></div>`;
        ((n += a
          .map(
            (e) =>
              `<div class="agent-chat-message ${e.role}">${"assistant" === e.role ? '<div class="agent-chat-avatar">智</div>' : ""}<div class="agent-chat-bubble">${e.content}${e.actions ? `<div class="agent-result-actions">${e.actions.map((e) => `<button class="btn sm">${e}</button>`).join("")}</div>` : ""}</div></div>`,
          )
          .join("")),
          ($("#agentChatStream").innerHTML = n),
          ($("#agentChatStream").scrollTop =
            $("#agentChatStream").scrollHeight),
          ($("#agentChatSide").innerHTML =
            `<div class="agent-side-section"><h3>当前智能体配置</h3><dl class="agent-side-kv"><dt>状态</dt><dd><span class="agent-live">在线</span></dd><dt>Soul</dt><dd>${t.soulTemplate} ${t.soulVersion}</dd><dt>知识空间</dt><dd>${t.knowledge}个</dd><dt>技能</dt><dd>${t.skills}项</dd><dt>工具</dt><dd>${t.tools}个</dd><dt>最近热更新</dt><dd>${t.soulUpdated}</dd></dl></div><div class="agent-side-section"><h3>已启用技能</h3><div class="agent-side-tags">${(
              t.skillsNames || []
            )
              .slice(0, 8)
              .map((e) => `<span class="tiny-tag">${e}</span>`)
              .join(
                "",
              )}</div></div><div class="agent-side-section"><h3>知识范围</h3><div class="agent-side-tags">${(t.knowledgeNames || []).map((e) => `<span class="tiny-tag">${e}</span>`).join("")}</div></div><div class="agent-side-section"><h3>运行状态</h3><dl class="agent-side-kv"><dt>今日调用</dt><dd>${t.calls}次</dd><dt>成功率</dt><dd>${t.success}</dd><dt>平均耗时</dt><dd>${t.avg}</dd><dt>最近运行</dt><dd>${t.recent}</dd></dl></div>`));
      }
      function openAgentChat(e) {
        state.selectedAgent = Number(e);
        const t = state.agents[state.selectedAgent];
        if ("应急" === t?.domain)
          return (
            setView("emergency"),
            renderEmergencyCenterChat(),
            void showToast("已进入应急任务智能体定制页面")
          );
        (setView("agentchat"), renderAgentChat(!1));
      }
      function agentReply(e, t) {
        return "应急" === e.domain
          ? t.includes("介入")
            ? {
                content:
                  '当前有2个任务需要人工介入：<div class="agent-result-card"><b>1. 重庆北部嘉陵江强降雨抢险任务</b><br>光缆已初步满足，但需由两家单位拼单。<br><br><b>2. 永川区山火应急保障任务</b><br>主变附件到货时间存在风险。</div>',
                actions: [
                  "查看任务",
                  "接受拼单",
                  "要求单一单位满足",
                  "继续等待",
                ],
              }
            : t.includes("催办")
              ? {
                  content:
                    "已识别12家超时未回复单位。系统将按既定规则发送第二次提醒，并对超过30分钟未回复的3家单位升级督办。",
                  actions: ["确认催办", "查看名单", "调整催办规则"],
                }
              : {
                  content:
                    "我已根据当前应急任务状态完成分析。10条物资中4条已满足、3条部分满足、2条等待回复、1条进入供应商询供。现有结果已具备形成初步方案的条件。",
                  actions: ["生成初步方案", "查看物资缺口", "继续等待20分钟"],
                }
          : "问数" === e.domain
            ? {
                content:
                  "已生成查询计划：①确认指标口径与权限范围；②关联采购、合同和供应商数据；③执行多维统计；④形成结论与异常说明。当前模拟结果显示，本月采购执行率为92.4%，主要异常集中在3个批次的技术规范确认延迟。",
                actions: ["查看查询口径", "展开异常明细", "生成图表"],
              }
            : {
                content: `已由“${e.name}”完成任务解析。系统将调用${(e.skillsNames || []).slice(0, 3).join("、")}等技能，并基于已绑定知识空间生成可追溯结果。`,
                actions: ["查看执行计划", "立即执行", "调整条件"],
              };
      }
      function sendAgentChat(e) {
        const t = $("#agentChatInput"),
          s = (e || t.value).trim();
        if (!s) return;
        const a = state.agents[state.selectedAgent],
          n = String(state.selectedAgent);
        (state.agentChatMessages[n].push({ role: "user", content: s }),
          (t.value = ""),
          renderAgentChat(),
          setTimeout(() => {
            (state.agentChatMessages[n].push({
              role: "assistant",
              ...agentReply(a, s),
            }),
              renderAgentChat());
          }, 350));
      }
      function openAgentManage(e, t = "overview") {
        ((state.selectedAgent = Number(e)),
          (state.agentManageTab = t),
          renderAgentManage(),
          openOverlay("agentManageDrawer"));
      }
      function manageHeader(e) {
        const t = agentAvailable(e);
        (($("#manageAgentIcon").innerHTML = icons(agentIconId(e))),
          ($("#manageAgentName").textContent = e.name),
          ($("#manageAgentStatus").className =
            "agent-availability-agentmanagement " + (t ? "" : "off")),
          ($("#manageAgentStatus").textContent = t ? "可用" : "暂不可用"),
          ($("#manageAgentDesc").textContent = e.desc),
          ($("#manageAgentMeta").innerHTML =
            `<span>${icons("i-bot")}Soul：${e.soulTemplate}</span><span>${icons("i-grid")}技能：${e.skills ? `${e.skills}项` : "配置中"}</span><span>${icons("i-book")}知识空间：${e.knowledge ? `${e.knowledge}个` : "未绑定"}</span>`));
        const s = $("#manageAgentChatBtn");
        ((s.dataset.agentChat = state.selectedAgent), (s.disabled = !t));
      }
      function renderAgentManage() {
        const e = state.agents[state.selectedAgent];
        (manageHeader(e),
          $$("[data-manage-tab]").forEach((e) =>
            e.classList.toggle(
              "active",
              e.dataset.manageTab === state.agentManageTab,
            ),
          ));
        const t = $("#manageContent"),
          s = state.agentManageTab,
          a = `4.${state.selectedAgent + 2}`;
        if (
          ("overview" === s &&
            (t.innerHTML = `<div class="manage-stack-agentmanagement"><section class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement">基本信息</div><div class="manage-grid-4-agentmanagement"><div class="manage-info-item-agentmanagement"><span>智能体类型</span><strong>${e.type}</strong></div><div class="manage-info-item-agentmanagement"><span>业务领域</span><strong>${"应急" === e.domain ? "应急保障" : e.domain}</strong></div><div class="manage-info-item-agentmanagement"><span>当前版本</span><strong>${a}</strong></div><div class="manage-info-item-agentmanagement"><span>最近更新时间</span><strong>2026-07-15 10:28</strong></div></div></section><section class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement">当前配置</div><div class="manage-config-grid-agentmanagement"><div class="manage-config-tile-agentmanagement"><div class="manage-config-icon-agentmanagement">${icons("i-bot")}</div><div><span>Soul</span><strong>${e.soulTemplate} ${e.soulVersion}</strong></div></div><div class="manage-config-tile-agentmanagement"><div class="manage-config-icon-agentmanagement">${icons("i-grid")}</div><div><span>技能</span><strong>${e.skills}项</strong></div></div><div class="manage-config-tile-agentmanagement"><div class="manage-config-icon-agentmanagement">${icons("i-book")}</div><div><span>知识空间</span><strong>${e.knowledge}个</strong></div></div><div class="manage-config-tile-agentmanagement"><div class="manage-config-icon-agentmanagement">${icons("i-network")}</div><div><span>工具系统</span><strong>${e.tools}个</strong></div></div></div></section><section class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement">能力简介</div><div style="font-size:11.5px;color:#536864;line-height:1.7">${e.desc}</div></section><section class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement">典型场景</div><div class="manage-tags-agentmanagement">${("应急" === e.domain ? ["夜间应急任务接收", "物资缺口分析", "跨单位调拨", "供应商询供"] : agentPromptSamples(e)).map((e) => `<span class="manage-tag-agentmanagement">${e}</span>`).join("")}</div></section><section class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement"><span>最近活动</span><span class="muted">查看更多 ›</span></div><div class="activity-list-agentmanagement"><div class="activity-item-agentmanagement"><span class="activity-dot-agentmanagement"></span><span>${e.recent}</span><span class="activity-time-agentmanagement">2026-07-15 10:27</span></div><div class="activity-item-agentmanagement"><span class="activity-dot-agentmanagement"></span><span>新增知识《极端天气下的物资调拨指引》已更新</span><span class="activity-time-agentmanagement">2026-07-15 09:56</span></div><div class="activity-item-agentmanagement"><span class="activity-dot-agentmanagement"></span><span>与用户张伟的对话会话已结束</span><span class="activity-time-agentmanagement">2026-07-15 09:31</span></div></div></section></div>`),
          "soul" === s &&
            (t.innerHTML = `<div class="manage-stack-agentmanagement"><div class="soul-version-agentmanagement"><div><b>当前Soul版本：</b>${e.soulTemplate} ${e.soulVersion}</div><div style="font-size:10.5px;color:#748784">最近热更新：${e.soulUpdated}</div></div><div class="soul-field-agentmanagement"><label>角色定位 <span style="font-size:10px;color:#829491;font-weight:500">86/500</span></label><textarea>你是面向国网重庆应急物资保障场景的智能助手，具备任务理解、物资寻源与询供、供应商评估、方案推荐、进度跟踪与风险预警等能力，致力于在保障合规与安全的前提下提升处置效率。</textarea></div><div class="soul-field-agentmanagement"><label>表达风格</label><div class="manage-tags-agentmanagement"><span class="manage-tag-agentmanagement">准确</span><span class="manage-tag-agentmanagement">简洁</span><span class="manage-tag-agentmanagement">时效导向</span><span class="manage-tag-agentmanagement">可追溯</span></div></div><div><div class="manage-section-title-agentmanagement">决策原则</div><div class="soul-principles-agentmanagement"><div class="principle-card-agentmanagement"><div class="num">1</div><strong>优先保障时效</strong><p>在满足合规要求的前提下，优先选择时效最优方案。</p></div><div class="principle-card-agentmanagement"><div class="num">2</div><strong>关键节点人工确认</strong><p>对关键节点、敏感操作或高风险事项主动提醒人工确认。</p></div><div class="principle-card-agentmanagement"><div class="num">3</div><strong>不确定信息提示风险</strong><p>对数据缺失或不确定内容明确提示风险并给出建议。</p></div><div class="principle-card-agentmanagement"><div class="num">4</div><strong>支持方案反复调整</strong><p>根据最新信息与反馈支持多轮迭代和方案优化。</p></div></div></div><div><div class="manage-section-title-agentmanagement">风险边界</div><div class="risk-boundary-agentmanagement"><span>⊘ 不擅自截止寻源，不替代人工进行重大决策。</span><span>⊘ 不输出未经校验的敏感或涉密信息。</span><span>⊘ 不越权回写核心审批结果，需遵循既有流程与权限。</span><span>⊘ 不调用未授权系统或接口。</span></div></div><div><div class="manage-section-title-agentmanagement">模板库</div><div class="template-strip-agentmanagement">${["应急指挥型", "业务专家型", "领导汇报型", "基层服务型", "审慎风控型", "更多模板"].map((t, s) => `<div class="template-card-agentmanagement ${t === e.soulTemplate ? "active" : ""}"><strong>${t}</strong><span>${t === e.soulTemplate ? "当前使用" : "场景适用"}</span></div>`).join("")}</div></div><div class="drawer-actionbar-agentmanagement"><button class="btn">保存草稿</button><button class="btn">${icons("i-play")}效果测试</button><button class="btn primary" data-agent-soul="${state.selectedAgent}">${icons("i-activity")}一键热更新</button></div></div>`),
          "skills" === s)
        ) {
          const s =
              "应急" === e.domain
                ? [
                    ["任务感知", ["应急事件识别", "物资需求解析", "需求澄清"]],
                    [
                      "资源寻源",
                      ["库存查询", "跨单位征询", "协议库存查询", "供应商询供"],
                    ],
                    [
                      "方案决策",
                      ["满足度分析", "方案推荐", "风险校验", "人工确认"],
                    ],
                    ["业务执行", ["方案回写", "执行跟踪", "事件复盘"]],
                  ]
                : [
                    ["任务理解", (e.skillsNames || []).slice(0, 3)],
                    ["分析与执行", (e.skillsNames || []).slice(3, 7)],
                    ["结果校核", ["结果校核", "数据回流"]],
                  ],
            a = [...new Set(s.flatMap((e) => e[1]))];
          t.innerHTML = `<div class="skill-layout-agentmanagement"><section class="skill-canvas-agentmanagement"><div class="manage-section-title-agentmanagement"><span>编排流程</span><span class="muted">全局配置　布局设置</span></div><div class="skill-lanes-agentmanagement">${s.map((e) => `<div class="skill-lane-agentmanagement"><div class="skill-lane-title-agentmanagement">${e[0]}</div><div class="skill-nodes-agentmanagement">${e[1].map((e, t) => `${t ? '<span class="skill-arrow-agentmanagement">→</span>' : ""}<span class="skill-node-agentmanagement">${icons(t % 2 ? "i-file" : "i-search")}${e}</span>`).join("")}</div></div>`).join("")}</div><div class="drawer-actionbar-agentmanagement" style="position:static;padding:14px 0 0;border-top:0"><button class="btn">编辑编排</button><button class="btn">${icons("i-plus")}添加技能</button><button class="btn">查看运行链路</button></div></section><aside class="skill-list-agentmanagement"><div class="skill-list-head-agentmanagement"><div class="manage-section-title-agentmanagement" style="margin:0">技能清单</div></div><input class="skill-search-agentmanagement" placeholder="搜索技能名称"/><div>${a.map((e) => `<div class="skill-list-item-agentmanagement"><span style="color:#008780">${icons("i-grid")}</span><span>${e}</span><span class="switch-agentmanagement"></span></div>`).join("")}</div></aside></div>`;
        }
        if ("knowledge" === s) {
          const s = (e.knowledgeNames || []).slice(0, 3);
          for (; s.length < 3; )
            s.push(
              [
                "应急物资保障知识空间",
                "重庆物资制度知识空间",
                "应急案例与专家经验空间",
              ][s.length],
            );
          t.innerHTML = `<div class="manage-stack-agentmanagement"><div class="knowledge-layout-agentmanagement"><section class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement">绑定知识空间</div><div class="knowledge-space-list-agentmanagement">${s.map((e, t) => `<div class="knowledge-space-row-agentmanagement"><div class="knowledge-space-icon-agentmanagement">${icons("i-book")}</div><div><strong>${e}</strong><small>${["应急物资目录、保障标准、寻源渠道等知识", "重庆公司物资管理制度、流程、规范性文件", "历史应急案例复盘、专家经验与处置建议"][t]}</small></div><b>${[268, 42, 18][t]} 条 ›</b></div>`).join("")}</div></section><aside class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement">知识状态</div><div class="knowledge-status-agentmanagement"><div class="knowledge-status-item-agentmanagement green"><span>已发布</span><strong>286</strong></div><div class="knowledge-status-item-agentmanagement orange"><span>待审核</span><strong>12</strong></div><div class="knowledge-status-item-agentmanagement orange"><span>即将失效</span><strong>3</strong></div><div class="knowledge-status-item-agentmanagement red"><span>疑似冲突</span><strong>2</strong></div></div></aside></div><div><div class="manage-section-title-agentmanagement">记忆管理</div><div class="memory-grid-agentmanagement"><div class="memory-card-agentmanagement"><strong>当前任务记忆</strong><p>智能体处理中的临时上下文与关键决策记忆</p><b>8 条</b></div><div class="memory-card-agentmanagement"><strong>历史案例记忆</strong><p>历史任务的处置过程与结果记忆</p><b>26 条</b></div><div class="memory-card-agentmanagement"><strong>专家经验记忆</strong><p>专家建议、处置策略与经验沉淀</p><b>12 条</b></div></div></div><div class="manage-two-agentmanagement"><section class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement">候选知识回流</div><div class="candidate-list-agentmanagement">${[
            ["万州山洪物资保障复盘结论", "来源：复盘报告"],
            ["高温预警物资调配要点", "来源：专家建议"],
            ["应急仓库启用流程优化建议", "来源：内部建议"],
          ]
            .map(
              (e) =>
                `<div class="candidate-row-agentmanagement"><span class="knowledge-space-icon-agentmanagement" style="width:28px;height:28px">${icons("i-file")}</span><div><strong>${e[0]}</strong><small>已自动生成摘要与关联关系</small></div><small>${e[1]}</small></div>`,
            )
            .join(
              "",
            )}</div></section><aside class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement">关系预览</div><div class="relation-preview-agentmanagement"><span class="node" style="left:26px;top:20px">制</span><span class="node" style="left:102px;top:12px">技</span><span class="node" style="left:66px;top:70px">智</span><span class="node" style="left:160px;top:66px">案</span><span class="line" style="left:49px;top:32px;width:56px;transform:rotate(-8deg)"></span><span class="line" style="left:47px;top:40px;width:46px;transform:rotate(48deg)"></span><span class="line" style="left:88px;top:78px;width:73px;transform:rotate(-5deg)"></span></div><div class="manage-tags-agentmanagement" style="margin-top:10px"><button class="btn sm">管理绑定</button><button class="btn sm primary" data-open-knowledge="graph" data-close="agentManageDrawer">查看知识图谱</button></div></aside></div></div>`;
        }
        if ("tools" === s) {
          const s = [
            "应急任务感知接口",
            "库存查询服务",
            "协议库存查询服务",
            "供应商询供服务",
            "通知与催办服务",
            "原系统方案回写接口",
            "短信服务",
            "MCP调度服务",
          ];
          t.innerHTML = `<div class="manage-stack-agentmanagement"><div class="tool-summary-agentmanagement">已接入工具 <b>8</b> 个　/　可用 <b style="color:#159c63">7</b> 个　/　需关注 <b style="color:#cf7a13">1</b> 个</div><div class="tool-grid-agentmanagement">${s.map((e, t) => `<div class="tool-card-agentmanagement"><div class="tool-icon-agentmanagement">${icons(t % 3 == 0 ? "i-network" : t % 3 == 1 ? "i-grid" : "i-link")}</div><div><strong>${e}</strong><p>${["对接监测系统，获取应急事件与告警信息。", "查询物资实时库存与可用数量。", "查询协议库存及可用数量。", "发起询供请求并获取供应商报价。", "发送站内通知与催办消息。", "将方案回写至原业务系统。", "发送短信通知与告警。", "统一调度与编排底层系统能力。"][t]}</p><small style="font-size:9px;color:#748784">调用权限：${5 === t ? "需人工审批" : "智能体可调用"}</small></div><span class="tool-badge-agentmanagement ${5 === t ? "warn" : ""}">${5 === t ? "需审批" : 7 === t ? "正常" : "已连接"}</span></div>`).join("")}</div><div class="manage-two-agentmanagement"><section class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement">权限与调用范围</div><div style="font-size:10.5px;line-height:1.9;color:#5e716d">调用身份：${e.name}（Soul：${e.soulTemplate}）<br>数据范围：国网重庆市电力公司及所属单位<br>可调用资源：8个系统 / 22个接口<br>并发限制：20 QPS<br>数据脱敏：<b style="color:#159c63">已开启</b></div></section><section class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement"><span>最近系统联调记录</span><span class="muted">查看全部 ›</span></div><div class="activity-list-agentmanagement">${["库存查询服务 联调成功", "供应商询供服务 联调成功", "通知与催办服务 联调成功"].map((e, t) => `<div class="activity-item-agentmanagement"><span class="check-dot-agentmanagement">✓</span><span>${e}</span><span class="activity-time-agentmanagement">2026-07-15 14:${32 - 7 * t}</span></div>`).join("")}</div></section></div><div class="drawer-actionbar-agentmanagement"><button class="btn">${icons("i-settings")}管理接入</button><button class="btn">${icons("i-file")}查看接口文档</button></div></div>`;
        }
        "versions" === s &&
          (t.innerHTML = `<div class="manage-stack-agentmanagement"><div class="version-top-agentmanagement"><div class="version-stat-agentmanagement"><span>当前线上版本</span><strong>${a} <em class="version-type-agentmanagement">已发布</em></strong></div><div class="version-stat-agentmanagement"><span>草稿版本</span><strong>4.7-beta <em style="font-size:10px;color:#c97812">草稿中</em></strong></div><div class="version-stat-agentmanagement"><span>最近发布时间</span><strong style="font-size:15px">2026-07-15 10:28</strong></div></div><div class="version-main-agentmanagement"><section class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement">变更说明（4.7-beta）</div><ul class="change-list-agentmanagement"><li>优化需求澄清逻辑，提升澄清效率与准确性</li><li>新增供应商询供模板，支持多场景复用</li><li>调整风险提示文案，增强表达一致性</li><li>增强任务回写校验，提升数据准确性</li></ul></section><section class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement">发布检查清单</div><div class="check-list-agentmanagement">${["Soul已校验", "技能链路已验证", "知识空间已同步", "工具连接已检查", "回滚版本可用"].map((e) => `<div class="check-row-agentmanagement"><span><i class="check-dot-agentmanagement">✓</i>${e}</span><b style="color:#169e64">已通过</b></div>`).join("")}</div></section></div><section class="manage-card-agentmanagement"><div class="manage-section-title-agentmanagement">发布记录</div><table class="version-table-agentmanagement"><thead><tr><th>版本号</th><th>版本类型</th><th>发布人</th><th>发布时间</th><th>变更说明</th><th>操作</th></tr></thead><tbody><tr><td>4.6</td><td><span class="version-type-agentmanagement">正式版</span></td><td>张伟</td><td>2026-07-15 10:28</td><td>优化需求澄清逻辑，提升澄清效率</td><td><a>查看详情</a></td></tr><tr><td>4.5</td><td><span class="version-type-agentmanagement">正式版</span></td><td>李娜</td><td>2026-06-30 14:12</td><td>新增供应商询供模板，支持多场景复用</td><td><a>查看详情</a></td></tr><tr><td>4.4</td><td><span class="version-type-agentmanagement">正式版</span></td><td>王强</td><td>2026-06-15 09:45</td><td>调整风险提示文案，增强表达一致性</td><td><a>查看详情</a></td></tr></tbody></table></section><div class="drawer-actionbar-agentmanagement"><button class="btn">保存草稿</button><button class="btn primary">${icons("i-upload")}发布上线</button><button class="btn">${icons("i-refresh")}回滚到上一版本</button></div></div>`);
      }
      const KNOWLEDGE_SPACES = [
          {
            id: "all",
            name: "全部知识",
            group: "全部",
            count: 18632,
            files: 1286,
            health: 86,
            agents: 12,
            desc: "全部可访问知识资产",
          },
          {
            id: "emergency",
            name: "应急物资保障",
            group: "业务知识",
            count: 328,
            files: 46,
            health: 91,
            agents: 3,
            desc: "应急制度、调拨规则、供应商询供与历史案例",
          },
          {
            id: "procurement",
            name: "采购管理",
            group: "业务知识",
            count: 2836,
            files: 214,
            health: 88,
            agents: 4,
            desc: "采购目录、计划、批次、招标和审查规则",
          },
          {
            id: "supplier",
            name: "供应商管理",
            group: "业务知识",
            count: 1962,
            files: 156,
            health: 84,
            agents: 3,
            desc: "供应商档案、履约、质量和风险管理",
          },
          {
            id: "contract",
            name: "合同履约",
            group: "业务知识",
            count: 2214,
            files: 187,
            health: 87,
            agents: 3,
            desc: "合同条款、履约规则、结算与异常处置",
          },
          {
            id: "warehouse",
            name: "仓储物流",
            group: "业务知识",
            count: 1742,
            files: 136,
            health: 82,
            agents: 2,
            desc: "库存、仓储、配送和物流协同",
          },
          {
            id: "metrics",
            name: "智能问数口径",
            group: "数据知识",
            count: 962,
            files: 72,
            health: 94,
            agents: 2,
            desc: "指标定义、字段说明、统计口径和数据字典",
          },
          {
            id: "tickets",
            name: "工单处置案例",
            group: "案例知识",
            count: 1216,
            files: 98,
            health: 85,
            agents: 2,
            desc: "工单流程、历史处置案例和专家经验",
          },
          {
            id: "personal",
            name: "个人知识空间",
            group: "个人知识",
            count: 128,
            files: 18,
            health: 89,
            agents: 1,
            desc: "个人常用材料、模板和工作记忆",
          },
        ],
        KNOWLEDGE_ASSETS = [
          {
            id: "K1",
            space: "emergency",
            name: "国网重庆市电力公司应急物资管理办法",
            type: "制度文件",
            source: "人工上传",
            version: "V3.2",
            usage: "4个智能体引用",
            status: "已发布",
            updated: "2小时前",
            chunks: 42,
            entries: 18,
            relations: 27,
            desc: "规定应急物资需求提报、资源寻源、调拨确认、应急采购和执行衔接要求。",
          },
          {
            id: "K2",
            space: "emergency",
            name: "重庆万州山洪应急物资保障复盘",
            type: "历史案例",
            source: "任务回流",
            version: "V1.0",
            usage: "18次命中",
            status: "待审核",
            updated: "昨日",
            chunks: 26,
            entries: 12,
            relations: 19,
            desc: "记录万州山洪抢修中光缆、发电机和通信电源的寻源过程、方案调整与实际交付。",
          },
          {
            id: "K3",
            space: "emergency",
            name: "跨省应急调拨启动条件",
            type: "业务规则",
            source: "智能抽取",
            version: "V2.1",
            usage: "3个智能体引用",
            status: "已发布",
            updated: "3天前",
            chunks: 4,
            entries: 1,
            relations: 8,
            desc: "当省内实物库存、协议库存及应急采购准备仍无法满足时，经审批可启动跨省应急调拨。",
          },
          {
            id: "K4",
            space: "metrics",
            name: "供应商到货及时率指标口径",
            type: "指标口径",
            source: "数据中台",
            version: "V2.1",
            usage: "问数智能体引用",
            status: "已发布",
            updated: "3天前",
            chunks: 6,
            entries: 3,
            relations: 11,
            desc: "定义供应商到货及时率统计范围、分母分子、异常剔除和组织权限口径。",
          },
          {
            id: "K5",
            space: "procurement",
            name: "采购目录编制审查规则汇编",
            type: "业务规则",
            source: "系统同步",
            version: "V4.0",
            usage: "6个智能体引用",
            status: "已发布",
            updated: "1周前",
            chunks: 186,
            entries: 72,
            relations: 144,
            desc: "汇总采购目录编制、层级判定、技术规范引用和审查校核规则。",
          },
          {
            id: "K6",
            space: "supplier",
            name: "供应商风险分级与处置指引",
            type: "制度文件",
            source: "人工上传",
            version: "V1.8",
            usage: "2个智能体引用",
            status: "即将失效",
            updated: "2周前",
            chunks: 58,
            entries: 22,
            relations: 38,
            desc: "规定供应商履约、质量和响应风险的分级标准与处置要求。",
          },
        ],
        GRAPH_TYPES = {
          rule: { name: "业务规则", color: "#006c66" },
          policy: { name: "制度规范", color: "#008780" },
          process: { name: "业务流程", color: "#22a39b" },
          metric: { name: "指标口径", color: "#55bbb4" },
          expert: { name: "专家经验", color: "#82cfca" },
          case: { name: "历史案例", color: "#acdeda" },
          object: { name: "业务对象", color: "#d1ece9" },
          agent: { name: "智能体/技能", color: "#397e79" },
        },
        GRAPH_NODES = [
          {
            id: "N1",
            label: "跨省应急调拨启动条件",
            type: "rule",
            x: 565,
            y: 340,
            desc: "当省内实物库存、协议库存和应急采购均不能满足需求时，方可发起跨省应急资源调拨。",
            space: "应急物资保障知识空间",
            version: "V2.1",
            source: "应急物资管理办法 第5章第12条",
            uses: 128,
          },
          {
            id: "N2",
            label: "应急物资管理办法",
            type: "policy",
            x: 370,
            y: 180,
            desc: "应急物资需求、寻源、调拨、采购和执行的上位制度。",
            space: "重庆物资制度知识空间",
            version: "V3.2",
            source: "制度文件",
            uses: 386,
          },
          {
            id: "N3",
            label: "省内库存寻源",
            type: "process",
            x: 405,
            y: 330,
            desc: "查询省内实物库存和可调拨资源。",
            space: "应急物资保障知识空间",
            version: "V1.4",
            source: "流程规则",
            uses: 245,
          },
          {
            id: "N4",
            label: "协议库存寻源",
            type: "process",
            x: 440,
            y: 470,
            desc: "查询协议库存可供数量与交付承诺。",
            space: "应急物资保障知识空间",
            version: "V1.6",
            source: "流程规则",
            uses: 194,
          },
          {
            id: "N5",
            label: "应急采购准备",
            type: "process",
            x: 640,
            y: 480,
            desc: "对资源缺口提前开展供应商询供和采购准备。",
            space: "应急物资保障知识空间",
            version: "V1.3",
            source: "流程规则",
            uses: 166,
          },
          {
            id: "N6",
            label: "人工确认原则",
            type: "expert",
            x: 720,
            y: 330,
            desc: "重要执行动作和方案调整必须保留人工确认与理由。",
            space: "专家经验空间",
            version: "V1.2",
            source: "专家经验",
            uses: 112,
          },
          {
            id: "N7",
            label: "重庆万州山洪保障案例",
            type: "case",
            x: 805,
            y: 500,
            desc: "2025年万州山洪应急保障典型案例。",
            space: "应急案例空间",
            version: "V1.0",
            source: "任务复盘",
            uses: 74,
          },
          {
            id: "N8",
            label: "库存查询技能",
            type: "agent",
            x: 250,
            y: 320,
            desc: "调用库存系统查询候选资源。",
            space: "技能库",
            version: "V2.4",
            source: "最小技能单元",
            uses: 468,
          },
          {
            id: "N9",
            label: "供应商询供模板",
            type: "rule",
            x: 660,
            y: 610,
            desc: "标准化供应商询供通知和回复字段。",
            space: "应急物资保障知识空间",
            version: "V2.0",
            source: "模板知识",
            uses: 139,
          },
          {
            id: "N10",
            label: "本地应急供应商库",
            type: "object",
            x: 845,
            y: 610,
            desc: "按物资类别维护的重庆本地应急供应商资源。",
            space: "供应商管理知识空间",
            version: "V3.0",
            source: "业务数据",
            uses: 207,
          },
          {
            id: "N11",
            label: "应急任务智能体",
            type: "agent",
            x: 565,
            y: 185,
            desc: "持续执行应急任务识别、寻源、跟踪、方案和回写。",
            space: "智能体中心",
            version: "V4.6",
            source: "智能体配置",
            uses: 326,
          },
          {
            id: "N12",
            label: "单一单位优先经验",
            type: "expert",
            x: 770,
            y: 190,
            desc: "关键物资具备时效条件时，优先由单一单位完整满足。",
            space: "专家经验空间",
            version: "V1.1",
            source: "案例回流",
            uses: 82,
          },
          {
            id: "N13",
            label: "满足度分析技能",
            type: "agent",
            x: 540,
            y: 610,
            desc: "实时计算物资完全满足、部分满足和缺口状态。",
            space: "技能库",
            version: "V2.2",
            source: "最小技能单元",
            uses: 301,
          },
          {
            id: "N14",
            label: "通信电源",
            type: "object",
            x: 950,
            y: 360,
            desc: "应急场景常用通信保障物资。",
            space: "物资目录",
            version: "2026",
            source: "物资主数据",
            uses: 156,
          },
          {
            id: "N15",
            label: "供应商到货及时率",
            type: "metric",
            x: 965,
            y: 520,
            desc: "供应商实际到货时间符合承诺时间的统计指标。",
            space: "智能问数口径空间",
            version: "V2.1",
            source: "指标口径",
            uses: 218,
          },
        ],
        GRAPH_EDGES = [
          ["N2", "N1", "规定"],
          ["N3", "N1", "前置"],
          ["N4", "N1", "前置"],
          ["N5", "N1", "前置"],
          ["N1", "N6", "需要确认"],
          ["N11", "N1", "引用"],
          ["N11", "N3", "执行"],
          ["N11", "N4", "执行"],
          ["N11", "N5", "执行"],
          ["N11", "N12", "引用"],
          ["N3", "N8", "调用"],
          ["N5", "N9", "使用"],
          ["N9", "N10", "匹配"],
          ["N7", "N12", "沉淀"],
          ["N7", "N6", "验证"],
          ["N13", "N1", "判断"],
          ["N5", "N13", "调用"],
          ["N14", "N10", "供应"],
          ["N15", "N10", "评价"],
        ];
      function initKnowledgeState() {
        ((state.knowledgeTab = state.knowledgeTab || "overview"),
          (state.selectedSpace = state.selectedSpace || "all"),
          (state.selectedAsset = state.selectedAsset || "K1"),
          (state.selectedNode = state.selectedNode || "N1"),
          (state.graphDetailTab = state.graphDetailTab || "details"),
          (state.graphZoom = state.graphZoom || 1));
      }
      function renderKnowledge() {
        (renderKnowledgeTabs(),
          renderKnowledgeSpaces(),
          renderKnowledgeTree(),
          renderKnowledgeAssets(),
          renderGraph());
      }
      function renderKnowledgeTabs() {
        ($$("[data-knowledge-tab]").forEach((e) =>
          e.classList.toggle(
            "active",
            e.dataset.knowledgeTab === state.knowledgeTab,
          ),
        ),
          $$(".knowledge-pane").forEach((e) =>
            e.classList.toggle(
              "active",
              e.id === `knowledge-${state.knowledgeTab}`,
            ),
          ));
      }
      function renderKnowledgeSpaces() {
        $("#knowledgeSpaces").innerHTML = KNOWLEDGE_SPACES.slice(1)
          .map(
            (e) =>
              `<article class="knowledge-space-card" data-space-open="${e.id}"><span class="soul-badge">${e.group}</span><h4>${e.name}</h4><p>${e.desc}</p><div class="space-meta"><span>${e.count}条知识</span><span>健康度${e.health}</span><span>${e.agents}个智能体</span></div></article>`,
          )
          .join("");
      }
      function renderKnowledgeTree() {
        const e = [...new Set(KNOWLEDGE_SPACES.map((e) => e.group))];
        $("#knowledgeTree").innerHTML = e
          .map(
            (e) =>
              `<div class="tree-group"><div class="tree-label">${e}</div>${KNOWLEDGE_SPACES.filter(
                (t) => t.group === e,
              )
                .map(
                  (e) =>
                    `<button class="tree-item ${e.id === state.selectedSpace ? "active" : ""}" data-space="${e.id}"><span>${e.name}</span><span>${e.files}</span></button>`,
                )
                .join("")}</div>`,
          )
          .join("");
      }
      function renderKnowledgeAssets() {
        const e = ($("#knowledgeAssetSearch")?.value || "").toLowerCase(),
          t = KNOWLEDGE_ASSETS.filter(
            (t) =>
              ("all" === state.selectedSpace ||
                t.space === state.selectedSpace) &&
              (!e ||
                [t.name, t.type, t.source, t.desc]
                  .join(" ")
                  .toLowerCase()
                  .includes(e)),
          );
        (!t.find((e) => e.id === state.selectedAsset) &&
          t[0] &&
          (state.selectedAsset = t[0].id),
          ($("#knowledgeAssets").innerHTML = t
            .map(
              (e) =>
                `<tr class="${e.id === state.selectedAsset ? "active" : ""}" data-asset="${e.id}"><td><div class="asset-name"><strong>${e.name}</strong><span>更新：${e.updated}</span></div></td><td>${e.type}</td><td>${e.source}</td><td>${e.version}</td><td>${e.usage}</td><td><span class="status ${"已发布" === e.status ? "done" : "待审核" === e.status ? "waiting" : "attention"}">${e.status}</span></td></tr>`,
            )
            .join("")),
          renderKnowledgeAssetDetail());
      }
      function renderKnowledgeAssetDetail() {
        const e =
          KNOWLEDGE_ASSETS.find((e) => e.id === state.selectedAsset) ||
          KNOWLEDGE_ASSETS[0];
        $("#knowledgeAssetDetail").innerHTML =
          `<div class="asset-detail-title">${e.name}</div><div class="asset-detail-meta">${e.type} · ${e.version} · ${e.source}</div><p style="font-size:11px;line-height:1.7;color:var(--muted)">${e.desc}</p><div class="manage-summary-grid" style="grid-template-columns:repeat(3,1fr);margin:13px 0"><div class="manage-summary"><span>知识切片</span><strong>${e.chunks}</strong></div><div class="manage-summary"><span>知识条目</span><strong>${e.entries}</strong></div><div class="manage-summary"><span>关联关系</span><strong>${e.relations}</strong></div></div><div class="manage-section-title">知识加工流程</div><div class="process-flow">${["文件上传", "文本解析", "知识切片", "条目抽取", "标签识别", "关系抽取", "质量检测", "人工审核", "发布入库", "图谱更新"].map((t, s) => `<div class="process-step"><div class="process-step-index">${s + 1}</div><div><strong>${t}</strong><small>${s < 7 ? "已完成" : "待审核" === e.status && s >= 7 ? "等待业务专家确认" : "已完成"}</small></div><span class="status ${"待审核" === e.status && s >= 7 ? "waiting" : "done"}">${"待审核" === e.status && s >= 7 ? "待处理" : "完成"}</span></div>`).join("")}</div><div class="manage-section" style="margin-top:15px"><div class="manage-section-title">知识标签</div><div class="asset-tags"><span class="tiny-tag">重庆物资</span><span class="tiny-tag">${e.type}</span><span class="tiny-tag">可追溯</span><span class="tiny-tag">智能体引用</span></div></div><div class="manage-section"><div class="manage-section-title">原文依据</div><div class="asset-reference">来源文件：${e.name}<br>支持定位至具体章节、页码和段落，并查看历史版本与上下文。</div></div><div class="actions" style="margin-top:13px"><button class="btn primary" data-asset-graph="${e.id}">查看知识图谱</button><button class="btn">查看原文</button></div>`;
      }
      function graphNode(e) {
        return GRAPH_NODES.find((t) => t.id === e);
      }
      function renderGraph() {
        const e = $("#graphSvg");
        if (!e) return;
        const t = ($("#graphSearch")?.value || "").toLowerCase(),
          s = state.selectedNode,
          a = new Set([s]);
        GRAPH_EDGES.forEach((e) => {
          (e[0] !== s && e[1] !== s) || (a.add(e[0]), a.add(e[1]));
        });
        const n = GRAPH_EDGES.map(([e, t, a]) => {
            const n = graphNode(e),
              i = graphNode(t),
              r = e === s || t === s;
            return `<g><line class="graph-edge ${r ? "active" : ""}" x1="${n.x}" y1="${n.y}" x2="${i.x}" y2="${i.y}"/><text x="${(n.x + i.x) / 2}" y="${(n.y + i.y) / 2 - 5}" font-size="9" fill="${r ? "#008780" : "#9aabaa"}">${a}</text></g>`;
          }).join(""),
          i = GRAPH_NODES.map((e) => {
            const a = t && !e.label.toLowerCase().includes(t),
              n = !t || e.label.toLowerCase().includes(t);
            return `<g class="graph-node ${e.id === s ? "selected" : ""}" data-node="${e.id}" opacity="${a ? 0.22 : 1}"><circle cx="${e.x}" cy="${e.y}" r="${e.id === s ? 18 : 14}" fill="${GRAPH_TYPES[e.type].color}"/><text x="${e.x}" y="${e.y + 31}" text-anchor="middle" font-weight="${n ? 650 : 400}">${e.label}</text></g>`;
          }).join("");
        ((e.innerHTML = `<g id="graphTransform" transform="translate(${560 * (1 - state.graphZoom)} ${360 * (1 - state.graphZoom)}) scale(${state.graphZoom})">${n}${i}</g>`),
          ($("#graphLegend").innerHTML = Object.entries(GRAPH_TYPES)
            .map(
              ([e, t]) =>
                `<div class="legend-row"><span class="legend-key"><i class="legend-dot" style="background:${t.color}"></i>${t.name}</span><span>${GRAPH_NODES.filter((t) => t.type === e).length}/${GRAPH_NODES.filter((t) => t.type === e).length}</span></div>`,
            )
            .join("")),
          ($("#graphMinimap").innerHTML = `${GRAPH_EDGES.map(([e, t]) => {
            const s = graphNode(e),
              a = graphNode(t);
            return `<line x1="${s.x}" y1="${s.y}" x2="${a.x}" y2="${a.y}" stroke="#e2eaea"/>`;
          }).join(
            "",
          )}${GRAPH_NODES.map((e) => `<circle cx="${e.x}" cy="${e.y}" r="5" fill="${GRAPH_TYPES[e.type].color}"/>`).join("")}<rect x="250" y="130" width="610" height="450" fill="rgba(0,135,128,.04)" stroke="#b9d7d4"/>`),
          renderGraphDetail());
      }
      function renderGraphDetail() {
        const e = graphNode(state.selectedNode) || GRAPH_NODES[0],
          t = GRAPH_EDGES.filter((t) => t[0] === e.id || t[1] === e.id).map(
            (t) => ({
              node: graphNode(t[0] === e.id ? t[1] : t[0]),
              rel: t[2],
            }),
          );
        let s = "";
        ("details" === state.graphDetailTab &&
          (s = `<dl class="graph-kv"><dt>知识类型</dt><dd>${GRAPH_TYPES[e.type].name}</dd><dt>所属空间</dt><dd>${e.space}</dd><dt>状态</dt><dd><span class="status done">已发布</span></dd><dt>版本</dt><dd>${e.version}</dd><dt>责任部门</dt><dd>供应链运营中心</dd><dt>最近更新</dt><dd>2026-07-14 10:26</dd><dt>使用次数</dt><dd>${e.uses}</dd></dl><div class="manage-section"><div class="manage-section-title">内容说明</div><p style="font-size:11px;line-height:1.75;color:var(--muted)">${e.desc}</p></div><div class="manage-section"><div class="manage-section-title">使用情况</div><div class="asset-tags"><span class="tiny-tag">被3个智能体使用</span><span class="tiny-tag">${t.length}项关联</span><span class="tiny-tag">依据可追溯</span></div></div>`),
          "relations" === state.graphDetailTab &&
            (s =
              t
                .map(
                  (e) =>
                    `<div class="relation-item" data-node="${e.node.id}"><div><strong>${e.node.label}</strong><br><span>${GRAPH_TYPES[e.node.type].name}</span></div><span>${e.rel}</span></div>`,
                )
                .join("") || '<div class="empty-state">暂无关联</div>'),
          "source" === state.graphDetailTab &&
            (s = `<div class="source-file current"><strong>${e.source}</strong><p>当前出处 · 支持打开原文并定位到具体章节、页码和段落。</p><button class="btn sm">查看原文</button></div><div class="source-file"><strong>相关制度与案例</strong><p>系统基于引用、包含、相似和业务流程关系自动关联其他知识来源。</p></div><div class="manage-section-title">引用原文</div><div class="asset-reference">“${e.desc}”<br><br>原文上下文可在知识库中完整展开，并支持历史版本比对。</div>`),
          ($("#graphDetail").innerHTML =
            `<div class="graph-detail-head"><div><small>知识详情</small><h3>${e.label}</h3></div><button class="icon-btn" id="closeGraphDetail"><svg class="icon"><use href="#i-x"/></svg></button></div><div class="graph-detail-tabs"><button class="graph-detail-tab ${"details" === state.graphDetailTab ? "active" : ""}" data-graph-detail="details">详情</button><button class="graph-detail-tab ${"relations" === state.graphDetailTab ? "active" : ""}" data-graph-detail="relations">关联 (${t.length})</button><button class="graph-detail-tab ${"source" === state.graphDetailTab ? "active" : ""}" data-graph-detail="source">原文</button></div><div class="graph-detail-body">${s}</div>`),
          $("#graphShell").classList.remove("detail-closed"));
      }
      function switchKnowledgeTab(e) {
        ((state.knowledgeTab = e),
          renderKnowledgeTabs(),
          "graph" === e && setTimeout(renderGraph, 0));
      }
      function bindAgentManagement() {
        (document.addEventListener("click", (e) => {
          const t = e.target.closest("[data-agent-category]");
          if (t)
            return (
              (state.agentCategory = t.dataset.agentCategory),
              void renderAgents()
            );
          const s = e.target.closest("[data-agent-domain]");
          if (s)
            return (
              (state.agentDomain = s.dataset.agentDomain),
              void renderAgents()
            );
          const a = e.target.closest("[data-agent-view]");
          if (a)
            return (
              (state.agentView = a.dataset.agentView),
              void renderAgents()
            );
          const n = e.target.closest("[data-agent-chat]");
          if (n) {
            const e = n.dataset.close;
            return (
              e && closeOverlay(e),
              void openAgentChat(n.dataset.agentChat)
            );
          }
          const i = e.target.closest("[data-agent-more]");
          if (i) {
            e.stopPropagation();
            const t = i.dataset.agentMore;
            return (
              $$(".agent-overflow-agentmanagement").forEach((e) =>
                e.classList.toggle(
                  "show",
                  e.dataset.agentMenuPanel === t &&
                    !e.classList.contains("show"),
                ),
              ),
              void $$(".agent-more-agentmanagement").forEach((e) =>
                e.classList.toggle(
                  "open",
                  e === i && e.nextElementSibling?.classList.contains("show"),
                ),
              )
            );
          }
          const r = e.target.closest("[data-agent-menu]");
          if (r) {
            e.stopPropagation();
            const t = Number(r.dataset.agentIndex),
              s = r.dataset.agentMenu;
            if (
              ($$(".agent-overflow-agentmanagement").forEach((e) =>
                e.classList.remove("show"),
              ),
              $$(".agent-more-agentmanagement").forEach((e) => e.classList.remove("open")),
              [
                "overview",
                "soul",
                "skills",
                "knowledge",
                "tools",
                "versions",
              ].includes(s))
            )
              return void openAgentManage(t, s);
            if ("copy" === s)
              return void showToast(
                `已复制“${state.agents[t].name}”，新智能体已保存为草稿`,
              );
            if ("toggle" === s)
              return (
                (state.agents[t].status = agentAvailable(state.agents[t])
                  ? "可配置"
                  : "在线"),
                renderAgents(),
                void showToast(
                  "在线" === state.agents[t].status
                    ? "智能体已启用"
                    : "智能体已停用",
                )
              );
          }
          e.target.closest(".agent-overflow-agentmanagement") ||
            ($$(".agent-overflow-agentmanagement").forEach((e) =>
              e.classList.remove("show"),
            ),
            $$(".agent-more-agentmanagement").forEach((e) => e.classList.remove("open")));
          const l = e.target.closest("[data-agent-manage]");
          if (l) return void openAgentManage(l.dataset.agentManage);
          const d = e.target.closest("[data-manage-tab]");
          if (d)
            return (
              (state.agentManageTab = d.dataset.manageTab),
              void renderAgentManage()
            );
          const c = e.target.closest("[data-manage-switch]");
          if (c)
            return (
              (state.agentManageTab = c.dataset.manageSwitch),
              void renderAgentManage()
            );
          const o = e.target.closest("[data-agent-prompt]");
          if (o) return void sendAgentChat(o.dataset.agentPrompt);
          const u = e.target.closest("[data-knowledge-tab]");
          if (u) return void switchKnowledgeTab(u.dataset.knowledgeTab);
          const p = e.target.closest("[data-open-knowledge]");
          if (p) {
            const e = p.dataset.close;
            return (
              e && closeOverlay(e),
              setView("knowledge"),
              void switchKnowledgeTab(p.dataset.openKnowledge)
            );
          }
          const m = e.target.closest("[data-space-open]");
          if (m)
            return (
              (state.selectedSpace = m.dataset.spaceOpen),
              setView("knowledge"),
              switchKnowledgeTab("library"),
              renderKnowledgeTree(),
              void renderKnowledgeAssets()
            );
          const h = e.target.closest("[data-space]");
          if (h)
            return (
              (state.selectedSpace = h.dataset.space),
              renderKnowledgeTree(),
              void renderKnowledgeAssets()
            );
          const y = e.target.closest("[data-asset]");
          if (y)
            return (
              (state.selectedAsset = y.dataset.asset),
              void renderKnowledgeAssets()
            );
          if (e.target.closest("[data-asset-graph]"))
            return (switchKnowledgeTab("graph"), void renderGraph());
          const v = e.target.closest("[data-node]");
          if (v)
            return ((state.selectedNode = v.dataset.node), void renderGraph());
          const g = e.target.closest("[data-graph-detail]");
          if (g)
            return (
              (state.graphDetailTab = g.dataset.graphDetail),
              void renderGraphDetail()
            );
          const f = e.target.closest("[data-graph-action]");
          if (f) {
            const e = f.dataset.graphAction;
            return (
              "zoom-in" === e &&
                (state.graphZoom = Math.min(1.6, state.graphZoom + 0.15)),
              "zoom-out" === e &&
                (state.graphZoom = Math.max(0.55, state.graphZoom - 0.15)),
              ("reset" !== e && "center" !== e) || (state.graphZoom = 1),
              "fullscreen" === e && $("#graphShell").requestFullscreen?.(),
              void renderGraph()
            );
          }
        }),
          $("#agentChatSend")?.addEventListener("click", () => sendAgentChat()),
          $("#agentChatInput")?.addEventListener("keydown", (e) => {
            "Enter" !== e.key ||
              e.shiftKey ||
              (e.preventDefault(), sendAgentChat());
          }),
          $("#agentChatNew")?.addEventListener("click", () =>
            renderAgentChat(!0),
          ),
          $("#agentChatManage")?.addEventListener("click", () =>
            openAgentManage(state.selectedAgent),
          ),
          $("#knowledgeUploadBtn")?.addEventListener("click", () =>
            openOverlay("knowledgeUploadModal"),
          ),
          $("#knowledgeAuditBtn")?.addEventListener("click", () => {
            (setView("knowledge"),
              switchKnowledgeTab("library"),
              showToast("已筛选32条待审核候选知识"));
          }),
          $("#updateGraphBtn")?.addEventListener("click", () =>
            openOverlay("graphUpdateModal"),
          ),
          $("#saveKnowledgeUpload")?.addEventListener("click", () => {
            (closeOverlay("knowledgeUploadModal"),
              showToast("文件已上传，正在自动解析、切片并抽取知识关系"));
          }),
          $("#startGraphUpdate")?.addEventListener("click", () => {
            (closeOverlay("graphUpdateModal"),
              showToast("知识图谱增量更新已开始"));
          }),
          $("#knowledgeAssetSearch")?.addEventListener(
            "input",
            renderKnowledgeAssets,
          ),
          $("#graphSearch")?.addEventListener("input", renderGraph),
          document.addEventListener("click", (e) => {
            e.target.closest("#closeGraphDetail") &&
              $("#graphShell").classList.add("detail-closed");
          }),
          $("#agentOpsBtn")?.addEventListener("click", () =>
            showToast("能力运营视图：2项异常、3项热更新和12项候选知识待处理"),
          ),
          $("#emergencyCenterSend")?.addEventListener("click", () =>
            sendEmergencyCenterChat(),
          ),
          $("#emergencyCenterInput")?.addEventListener("keydown", (e) => {
            "Enter" !== e.key ||
              e.shiftKey ||
              (e.preventDefault(), sendEmergencyCenterChat());
          }),
          document.addEventListener("click", (e) => {
            const t = e.target.closest("[data-emergency-prompt]");
            t && sendEmergencyCenterChat(t.dataset.emergencyPrompt);
          }));
      }
      const scheduleTemplates = {
        "tpl-emergency-scan": {
          name: "重庆本地灾害应急感知任务",
          prompt:
            "持续扫描重庆本地灾害预警、原业务系统中的新增应急事件和挂接物资需求；一旦发现新事件，自动创建独立应急任务实例并启动需求识别。",
          trigger: "sense",
          frequency: "每天",
          time: "09:00",
          cron: "0 9 * * *",
          intervalValue: 10,
          intervalUnit: "分钟",
          senseSource: "原业务系统应急事件表",
          senseCondition: "新增应急事件且已挂接物资需求",
          senseAction:
            "自动创建独立应急任务，推送工作台提醒，并启动需求识别与寻源。",
          context: "fresh",
          notification: "workspace_sms",
        },
        "tpl-leader-brief": {
          name: "重庆应急任务领导晨报",
          prompt:
            "每天汇总重庆本地灾害预警、执行中的应急任务、未响应单位、缺口物资和保供风险，生成适合领导查看和朗读的晨报。",
          trigger: "plan",
          frequency: "每天",
          time: "08:00",
          cron: "0 8 * * *",
          intervalValue: 1,
          intervalUnit: "天",
          context: "fresh",
          notification: "workspace",
        },
        "tpl-reminder": {
          name: "应急任务未响应自动催办",
          prompt:
            "检查执行中的应急任务，对超过时限仍未回复的单位和供应商自动提醒，并记录催办次数和升级状态。",
          trigger: "interval",
          frequency: "每小时",
          time: "09:00",
          cron: "0 * * * *",
          intervalValue: 10,
          intervalUnit: "分钟",
          context: "reuse",
          notification: "workspace_sms",
        },
        "tpl-supplier": {
          name: "重庆应急采购供应商询供跟踪",
          prompt:
            "固定周期检查供应商询供响应、可供数量、到货时间和风险变化，形成应急采购预警并推送工作台。",
          trigger: "interval",
          frequency: "每小时",
          time: "09:00",
          cron: "0 * * * *",
          intervalValue: 30,
          intervalUnit: "分钟",
          context: "fresh",
          notification: "workspace",
        },
      };
      ((state.scheduleCreateMethod = "dialog"),
        (state.scheduleTrigger = "plan"),
        (state.scheduleTemplate = "tpl-emergency-scan"),
        (state.scheduleFilter = "all"),
        (state.scheduleSearch = ""),
        (state.editingScheduleId = null),
        (state.scheduleWizard = {
          step: "goal",
          messages: [],
          quick: [],
          recognized: {},
          complete: !1,
        }));
      const scheduleTriggerIcons = {
        interval: "⏳",
        plan: "🗓️",
        once: "📌",
        sense: "🧠",
      };
      function inferTriggerKey(e) {
        if (e.triggerKey) return e.triggerKey;
        const t = e.triggerLabel || "";
        return t.includes("感知")
          ? "sense"
          : t.includes("间隔")
            ? "interval"
            : t.includes("单次")
              ? "once"
              : ((e.schedule || "").includes("每") ||
                  (e.schedule || "").includes("Cron"),
                "plan");
      }
      function triggerText() {
        const e = state.scheduleTrigger || "plan";
        if ("interval" === e)
          return `每${$("#intervalValue")?.value || 10}${$("#intervalUnit")?.value || "分钟"}执行一次`;
        if ("plan" === e) {
          const e = $("#scheduleFrequency")?.value || "每天",
            t = $("#scheduleTime")?.value || "08:00";
          return "自定义 Cron" === e
            ? `Cron ${$("#scheduleCron")?.value || ""}`
            : `${e} ${t}`;
        }
        return "once" === e
          ? `单次 ${($("#scheduleRunAt")?.value || "").replace("T", " ")}`
          : `${$("#senseSource")?.value || "业务系统"}：${$("#senseCondition")?.value || "事件满足条件后立即执行"}`;
      }
      function showSchedulePanels() {
        const e = state.scheduleCreateMethod || "dialog";
        ($("#dialogCreatePanel")?.classList.toggle("show", "dialog" === e),
          $("#templateCreatePanel")?.classList.toggle("show", "template" === e),
          $$("[data-create-method]").forEach((t) =>
            t.classList.toggle("active", t.dataset.createMethod === e),
          ));
        const t = state.scheduleTrigger || "plan";
        (["interval", "plan", "once", "sense"].forEach((e) =>
          $("#triggerPanel-" + e)?.classList.toggle("show", e === t),
        ),
          $$("[data-trigger]").forEach((e) =>
            e.classList.toggle("active", e.dataset.trigger === t),
          ),
          $$("[data-template]").forEach((e) =>
            e.classList.toggle(
              "active",
              e.dataset.template === state.scheduleTemplate,
            ),
          ),
          updateScheduleConfigSummary());
      }
      function setScheduleField(e, t) {
        const s = $("#" + e);
        s && null != t && (s.value = t);
      }
      function applyScheduleTemplate(e) {
        const t = scheduleTemplates[e];
        t &&
          ((state.scheduleTemplate = e),
          (state.scheduleTrigger = t.trigger),
          setScheduleField("scheduleTitle", t.name),
          setScheduleField("schedulePrompt", t.prompt),
          setScheduleField("intervalValue", t.intervalValue),
          setScheduleField("intervalUnit", t.intervalUnit),
          setScheduleField("scheduleFrequency", t.frequency),
          setScheduleField("scheduleTime", t.time),
          setScheduleField("scheduleCron", t.cron),
          setScheduleField("senseSource", t.senseSource),
          setScheduleField("senseCondition", t.senseCondition),
          setScheduleField("senseAction", t.senseAction),
          setScheduleField("scheduleContext", t.context),
          setScheduleField("scheduleNotification", t.notification),
          showSchedulePanels(),
          updateScheduleConfigSummary(),
          showToast(`已载入模板：${t.name}`));
      }
      function escapeHtml(e) {
        return String(e || "").replace(
          /[&<>"]/g,
          (e) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[e],
        );
      }
      function initEmergencyCenterChat() {
        const e = state.emergencies || [],
          t = e.filter((e) => e.attention).length;
        state.emergencyCenterMessages = state.emergencyCenterMessages || [
          {
            role: "assistant",
            text: `我会持续感知和处理重庆本地应急物资任务。当前共有${e.length}个任务，其中${t}个需要人工判断。您可以直接查询任务、分析物资缺口、发起催办或打开某个任务。`,
          },
          {
            role: "assistant",
            text: "任务中心中的状态、物资进度和方案结果会随对话指令同步更新，不需要在聊天记录中翻找。",
          },
        ];
      }
      function renderEmergencyCenterChat() {
        initEmergencyCenterChat();
        const e = $("#emergencyCenterMessages");
        e &&
          ((e.innerHTML = state.emergencyCenterMessages
            .map(
              (e) =>
                `<div class="emergency-center-message ${e.role}"><div class="emergency-center-avatar">${"user" === e.role ? "我" : "应"}</div><div class="emergency-center-bubble">${e.text}</div></div>`,
            )
            .join("")),
          (e.scrollTop = e.scrollHeight));
      }
      function emergencyCenterReply(e) {
        return e.includes("待处理") || e.includes("介入")
          ? (setEmergencyFilter("attention"),
            "已筛选出2个需要人工介入的任务：重庆北部嘉陵江强降雨抢险任务需要判断光缆拼单方案；永川区山火应急保障任务需要确认主变附件到货时限。")
          : e.includes("缺口")
            ? "当前重点缺口集中在通信电源、电力电缆和发电机。通信电源已进入供应商询供，电力电缆仍缺1千米，发电机仍缺2台。建议先确认已满足物资，缺口资源继续并行寻源。"
            : e.includes("催办")
              ? (showToast("已对12家未回复单位发起催办"),
                "已对12家超时未回复单位发送第二次提醒，并设置5分钟后再次检查。催办记录已留痕，任务列表将随新回复自动更新。")
              : e.includes("打开") ||
                  e.includes("重庆北部") ||
                  e.includes("重点任务")
                ? (setTimeout(() => setView("workbench"), 260),
                  "正在打开“重庆北部嘉陵江流域强降雨抢险应急任务”的独立任务工作台。")
                : e.includes("方案")
                  ? (setTimeout(() => {
                      (setView("workbench"), switchTab("plans"));
                    }, 260),
                    "当前结果已具备形成初步方案的条件，正在打开重点任务的方案调整页面。")
                  : "已理解您的要求。您可以继续指定任务名称、物资类型、等待时长或处理动作，我会同步更新任务中心中的结构化状态。";
      }
      function sendEmergencyCenterChat(e) {
        const t = $("#emergencyCenterInput"),
          s = (e || t?.value || "").trim();
        s &&
          (initEmergencyCenterChat(),
          state.emergencyCenterMessages.push({ role: "user", text: s }),
          t && (t.value = ""),
          renderEmergencyCenterChat(),
          setTimeout(() => {
            (state.emergencyCenterMessages.push({
              role: "assistant",
              text: emergencyCenterReply(s),
            }),
              renderEmergencyCenterChat());
          }, 260));
      }
      function resetScheduleWizard(e = null) {
        if (
          ((state.scheduleWizard = {
            step: "goal",
            recognized: {},
            complete: !1,
            messages: [],
            quick: [],
          }),
          e)
        )
          return (
            (state.scheduleWizard.messages = [
              {
                role: "assistant",
                text: `已载入“${e.name}”。您可以直接告诉我希望如何修改，例如“改成每30分钟运行，重大异常同时发短信”。`,
              },
            ]),
            (state.scheduleWizard.quick = [
              { label: "改为每30分钟执行", value: "每30分钟执行一次" },
              { label: "重大异常同时发短信", value: "重大异常同时发送短信" },
              { label: "改为主动感知", value: "感知到新应急事件后立即执行" },
            ]),
            void (state.scheduleWizard.step = "modify")
          );
        ((state.scheduleWizard.messages = [
          {
            role: "assistant",
            text: "您好，我是任务创建助手。我会分步确认任务目标、触发时间、上下文和通知方式，并将结果实时写入右侧配置。请先用一句话描述希望系统自动完成什么工作。",
          },
        ]),
          (state.scheduleWizard.quick = [
            {
              label: "每周一8点生成重庆应急晨报",
              value:
                "每周一上午8点汇总重庆本地灾害预警和应急任务进展，生成领导晨报",
            },
            {
              label: "每10分钟检查未回复单位",
              value: "每10分钟检查执行中的应急任务，催办超时未回复单位",
            },
            {
              label: "发现新应急事件后立即执行",
              value:
                "感知到重庆本地新应急事件并挂接物资需求后立即创建任务并开始寻源",
            },
          ]));
      }
      function renderScheduleWizard() {
        const e = $("#scheduleWizardMessages");
        if (!e) return;
        ((e.innerHTML = state.scheduleWizard.messages
          .map(
            (e) =>
              `<div class="wizard-message ${"user" === e.role ? "user" : ""}"><div class="wizard-mini-avatar">${"user" === e.role ? "我" : "智"}</div><div class="wizard-bubble">${escapeHtml(e.text).replace(/\n/g, "<br>")}${e.tags?.length ? `<div class="recognition">${e.tags.map((e) => `<span>${escapeHtml(e)}</span>`).join("")}</div>` : ""}</div></div>`,
          )
          .join("")),
          ($("#scheduleWizardQuick").innerHTML = (
            state.scheduleWizard.quick || []
          )
            .map(
              (e) =>
                `<button class="wizard-choice" data-wizard-choice="${escapeHtml(e.value)}">${escapeHtml(e.label)}</button>`,
            )
            .join("")),
          requestAnimationFrame(() => (e.scrollTop = e.scrollHeight)));
        const t = Math.min(
          3,
          Math.max(
            0,
            [
              "goal",
              "trigger",
              "timing",
              "notify",
              "context",
              "done",
              "modify",
            ].indexOf(state.scheduleWizard.step),
          ),
        );
        $$(".wizard-step-dot", $("#wizardProgress")).forEach((e, s) =>
          e.classList.toggle("on", s <= t),
        );
        $("#wizardStatus").textContent =
          {
            goal: "正在了解任务目标",
            trigger: "正在确认触发方式",
            timing: "正在补全执行时间",
            notify: "正在确认通知渠道",
            context: "正在确认上下文模式",
            done: "配置已补全",
            modify: "正在修改现有配置",
          }[state.scheduleWizard.step] || "正在配置";
      }
      function wizardAssistant(e, t = [], s = []) {
        (state.scheduleWizard.messages.push({
          role: "assistant",
          text: e,
          tags: s,
        }),
          (state.scheduleWizard.quick = t),
          renderScheduleWizard());
      }
      function parseNaturalSchedule(e) {
        const t = {
            raw: e,
            trigger: null,
            title: null,
            prompt: null,
            frequency: null,
            time: null,
            intervalValue: null,
            intervalUnit: null,
            notification: null,
            context: null,
          },
          s =
            !/晨报|简报|汇报|催办|未回复|未响应|供应商|询供|应急事件|灾害|寻源/.test(
              e,
            ) &&
            /通知|工作台|短信|邮件|独立对话|复用|固定间隔|定时计划|单次执行|主动感知|每\s*\d+\s*(分钟|小时)|每天|工作日|每周一/.test(
              e,
            );
        /晨报|简报|汇报/.test(e)
          ? ((t.title = "重庆应急任务领导晨报"),
            (t.prompt =
              "汇总重庆本地灾害预警、执行中的应急任务、未响应单位、缺口物资和保供风险，形成适合领导查看和朗读的简报。"))
          : /催办|未回复|未响应/.test(e)
            ? ((t.title = "应急任务未响应自动催办"),
              (t.prompt =
                "检查执行中的应急任务，对超过时限仍未回复的单位和供应商自动提醒，并记录催办次数和升级状态。"))
            : /供应商|询供/.test(e)
              ? ((t.title = "重庆应急采购供应商询供跟踪"),
                (t.prompt =
                  "持续检查供应商询供响应、可供数量、到货时间和风险变化，形成应急采购预警。"))
              : /应急事件|灾害|寻源/.test(e)
                ? ((t.title = "重庆本地灾害应急感知任务"),
                  (t.prompt =
                    "持续感知重庆本地灾害预警和原业务系统新应急事件，自动创建独立任务并启动需求识别与寻源。"))
                : s || ((t.title = "自定义自动任务"), (t.prompt = e));
        let a = e.match(/每\s*(\d+)\s*分钟/);
        (a &&
          ((t.trigger = "interval"),
          (t.intervalValue = a[1]),
          (t.intervalUnit = "分钟")),
          (a = e.match(/每\s*(\d+)\s*小时/)),
          a &&
            ((t.trigger = "interval"),
            (t.intervalValue = a[1]),
            (t.intervalUnit = "小时")),
          /每周一|周一/.test(e)
            ? ((t.trigger = "plan"), (t.frequency = "每周一"))
            : /工作日/.test(e)
              ? ((t.trigger = "plan"), (t.frequency = "工作日"))
              : /每天|每日/.test(e) &&
                ((t.trigger = "plan"), (t.frequency = "每天")),
          /感知|发现新|新增.*后|状态变化/.test(e) && (t.trigger = "sense"),
          /单次|执行一次|仅一次/.test(e) && (t.trigger = "once"));
        const n = e.match(
          /(?:上午|早上)?\s*(\d{1,2})\s*[点时](?:\s*(\d{1,2})\s*分)?/,
        );
        return (
          n &&
            (t.time = `${String(n[1]).padStart(2, "0")}:${String(n[2] || 0).padStart(2, "0")}`),
          /短信/.test(e) && /邮件/.test(e)
            ? (t.notification = "all")
            : /短信/.test(e)
              ? (t.notification = "workspace_sms")
              : /邮件/.test(e) && (t.notification = "workspace_email"),
          /复用|同一对话|当前对话/.test(e) && (t.context = "reuse"),
          /新建.*对话|独立对话/.test(e) && (t.context = "fresh"),
          t
        );
      }
      function applyNaturalResult(e) {
        (e.title && setScheduleField("scheduleTitle", e.title),
          e.prompt && setScheduleField("schedulePrompt", e.prompt),
          e.trigger && (state.scheduleTrigger = e.trigger),
          e.intervalValue && setScheduleField("intervalValue", e.intervalValue),
          e.intervalUnit && setScheduleField("intervalUnit", e.intervalUnit),
          e.frequency && setScheduleField("scheduleFrequency", e.frequency),
          e.time &&
            (setScheduleField("scheduleTime", e.time),
            "每周一" === e.frequency
              ? setScheduleField(
                  "scheduleCron",
                  `0 ${Number(e.time.split(":")[0])} * * 1`,
                )
              : setScheduleField(
                  "scheduleCron",
                  `0 ${Number(e.time.split(":")[0])} * * *`,
                )),
          e.notification &&
            setScheduleField("scheduleNotification", e.notification),
          e.context && setScheduleField("scheduleContext", e.context),
          showSchedulePanels(),
          updateScheduleConfigSummary());
      }
      function processWizardText(e) {
        if (!(e = e.trim())) return;
        state.scheduleWizard.messages.push({ role: "user", text: e });
        const t = parseNaturalSchedule(e);
        applyNaturalResult(t);
        const s = [
          t.title,
          t.trigger
            ? {
                interval: "固定间隔",
                plan: "定时计划",
                once: "单次执行",
                sense: "主动感知",
              }[t.trigger]
            : null,
          t.time,
        ].filter(Boolean);
        if ("modify" !== state.scheduleWizard.step) {
          if ("goal" === state.scheduleWizard.step)
            return t.trigger
              ? "plan" !== t.trigger || t.time
                ? "interval" !== t.trigger || t.intervalValue
                  ? ((state.scheduleWizard.step = "notify"),
                    void wizardAssistant(
                      `已识别任务目标和触发方式：${t.title || $("#scheduleTitle").value}，${triggerText()}。结果需要通过哪些渠道通知？`,
                      [
                        { label: "仅工作台", value: "仅工作台通知" },
                        { label: "工作台＋短信", value: "工作台和短信通知" },
                        { label: "工作台＋邮件", value: "工作台和邮件通知" },
                      ],
                      s,
                    ))
                  : ((state.scheduleWizard.step = "timing"),
                    void wizardAssistant(
                      "已识别为固定间隔。希望多久执行一次？",
                      [
                        { label: "每5分钟", value: "每5分钟执行一次" },
                        { label: "每10分钟", value: "每10分钟执行一次" },
                        { label: "每30分钟", value: "每30分钟执行一次" },
                        { label: "每1小时", value: "每1小时执行一次" },
                      ],
                      s,
                    ))
                : ((state.scheduleWizard.step = "timing"),
                  void wizardAssistant(
                    "已识别为定时计划。请确认具体执行时间。",
                    [
                      { label: "每天08:00", value: "每天上午8点" },
                      { label: "工作日09:00", value: "工作日上午9点" },
                      { label: "每周一08:00", value: "每周一上午8点" },
                    ],
                    s,
                  ))
              : ((state.scheduleWizard.step = "trigger"),
                void wizardAssistant(
                  "我已经识别了任务目标，但还不知道何时执行。请选择一种触发方式。",
                  [
                    { label: "固定间隔", value: "固定间隔" },
                    { label: "定时计划", value: "定时计划" },
                    { label: "单次执行", value: "单次执行" },
                    { label: "主动感知", value: "主动感知" },
                  ],
                  s,
                ));
          if ("trigger" === state.scheduleWizard.step) {
            if (/间隔/.test(e))
              return (
                (state.scheduleTrigger = "interval"),
                (state.scheduleWizard.step = "timing"),
                showSchedulePanels(),
                void wizardAssistant(
                  "好的，使用固定间隔触发。请选择执行频率。",
                  [
                    { label: "每5分钟", value: "每5分钟执行一次" },
                    { label: "每10分钟", value: "每10分钟执行一次" },
                    { label: "每30分钟", value: "每30分钟执行一次" },
                    { label: "每1小时", value: "每1小时执行一次" },
                  ],
                )
              );
            if (/计划|定时/.test(e))
              return (
                (state.scheduleTrigger = "plan"),
                (state.scheduleWizard.step = "timing"),
                showSchedulePanels(),
                void wizardAssistant("好的，使用定时计划。请选择执行时点。", [
                  { label: "每天08:00", value: "每天上午8点" },
                  { label: "工作日09:00", value: "工作日上午9点" },
                  { label: "每周一08:00", value: "每周一上午8点" },
                ])
              );
            if (/单次/.test(e))
              return (
                (state.scheduleTrigger = "once"),
                (state.scheduleWizard.step = "timing"),
                showSchedulePanels(),
                void wizardAssistant(
                  "好的，请输入具体执行日期和时间，例如“明天上午9点”。",
                )
              );
            if (/感知/.test(e))
              return (
                (state.scheduleTrigger = "sense"),
                (state.scheduleWizard.step = "notify"),
                showSchedulePanels(),
                void wizardAssistant(
                  "已选择主动感知。当前默认条件为“新增应急事件且已挂接物资需求”。触发后如何通知？",
                  [
                    { label: "仅工作台", value: "仅工作台通知" },
                    { label: "工作台＋短信", value: "工作台和短信通知" },
                  ],
                )
              );
          }
          if ("timing" === state.scheduleWizard.step)
            return (
              (state.scheduleWizard.step = "notify"),
              void wizardAssistant(
                `执行时间已补全为“${triggerText()}”。结果需要通过哪些渠道通知？`,
                [
                  { label: "仅工作台", value: "仅工作台通知" },
                  { label: "工作台＋短信", value: "工作台和短信通知" },
                  { label: "工作台＋邮件", value: "工作台和邮件通知" },
                ],
              )
            );
          if ("notify" === state.scheduleWizard.step)
            return (
              t.notification ||
                (/仅工作台/.test(e)
                  ? setScheduleField("scheduleNotification", "workspace")
                  : /短信/.test(e)
                    ? setScheduleField("scheduleNotification", "workspace_sms")
                    : /邮件/.test(e) &&
                      setScheduleField(
                        "scheduleNotification",
                        "workspace_email",
                      )),
              (state.scheduleWizard.step = "context"),
              updateScheduleConfigSummary(),
              void wizardAssistant(
                "通知方式已记录。最后确认：每次运行是新建独立对话，还是复用当前业务对话？",
                [
                  { label: "每次新建独立对话", value: "每次新建独立对话" },
                  { label: "复用当前业务对话", value: "复用当前业务对话" },
                ],
              )
            );
          if ("context" === state.scheduleWizard.step)
            return (
              /复用/.test(e)
                ? setScheduleField("scheduleContext", "reuse")
                : setScheduleField("scheduleContext", "fresh"),
              (state.scheduleWizard.step = "done"),
              (state.scheduleWizard.complete = !0),
              updateScheduleConfigSummary(),
              void wizardAssistant(
                "配置已自动补全并通过基础校验。您可以直接点击“创建并启用”，也可以继续用自然语言修改任意配置。",
                [
                  { label: "改为每30分钟执行", value: "改为每30分钟执行一次" },
                  {
                    label: "重大异常同时发短信",
                    value: "重大异常同时发送短信",
                  },
                  { label: "创建并启用", value: "__CREATE__" },
                ],
                [`完整度 ${calculateCompleteness()}%`],
              )
            );
          ((state.scheduleWizard.step = "modify"),
            wizardAssistant(
              `已根据您的要求更新配置：${triggerText()}。您可以继续修改，或直接创建并启用。`,
              [
                { label: "创建并启用", value: "__CREATE__" },
                { label: "查看右侧配置", value: "__FOCUS_CONFIG__" },
              ],
              s,
            ));
        } else
          wizardAssistant(
            `已根据您的要求更新配置：${t.notification ? "通知方式已调整" : t.context ? "上下文模式已调整" : triggerText()}。您可以继续修改，或直接创建并启用。`,
            [
              { label: "创建并启用", value: "__CREATE__" },
              { label: "查看右侧配置", value: "__FOCUS_CONFIG__" },
            ],
            s,
          );
      }
      function calculateCompleteness() {
        let e = 0;
        return (
          $("#scheduleTitle")?.value.trim() && (e += 25),
          $("#schedulePrompt")?.value.trim() && (e += 25),
          state.scheduleTrigger && (e += 20),
          triggerText().trim() && (e += 15),
          $("#scheduleContext")?.value && (e += 8),
          $("#scheduleNotification")?.value && (e += 7),
          Math.min(100, e)
        );
      }
      function updateScheduleConfigSummary() {
        if (!$("#scheduleCompletenessBar")) return;
        const e = calculateCompleteness();
        (($("#scheduleCompletenessBar").style.width = e + "%"),
          ($("#scheduleCompletenessText").textContent = e + "%"),
          ($("#configAutoFillState").textContent =
            e >= 90 ? "已自动补全" : "随对话实时更新"),
          ($("#reviewTaskName").textContent =
            $("#scheduleTitle").value || "待识别"),
          ($("#reviewTrigger").textContent = triggerText()));
        const t =
            $("#scheduleContext").selectedOptions?.[0]?.text ||
            "每次新建独立对话",
          s =
            $("#scheduleNotification").selectedOptions?.[0]?.text || "仅工作台";
        (($("#reviewContext").textContent = t),
          ($("#reviewNotification").textContent = s),
          ($("#scheduleReviewStatus").textContent =
            e >= 90 ? "配置完整，可创建" : "仍有信息待补充"));
        const a = [];
        (a.push(
          `<span class="config-check ${$("#scheduleTitle").value ? "" : "pending"}">${$("#scheduleTitle").value ? "✓" : "○"} 任务目标${$("#scheduleTitle").value ? "已识别" : "待识别"}</span>`,
        ),
          a.push('<span class="config-check">✓ 触发方式已配置</span>'),
          a.push('<span class="config-check">✓ 时区已设置</span>'),
          a.push(
            `<span class="config-check ${e >= 90 ? "" : "pending"}">${e >= 90 ? "✓" : "○"} 创建条件${e >= 90 ? "已满足" : "待补全"}</span>`,
          ),
          ($("#scheduleConfigChecks").innerHTML = a.join("")));
      }
      function openScheduleModal(e = null) {
        if (
          ((state.editingScheduleId = e?.id || null),
          (state.scheduleCreateMethod = "dialog"),
          ($("#scheduleModalTitle").textContent = e
            ? "编辑定时任务"
            : "新建定时任务"),
          e)
        ) {
          (setScheduleField("scheduleTitle", e.name),
            setScheduleField("schedulePrompt", e.desc),
            (state.scheduleTrigger = inferTriggerKey(e)),
            setScheduleField(
              "scheduleContext",
              (e.context || "").includes("复用") ? "reuse" : "fresh",
            ),
            setScheduleField(
              "scheduleNotification",
              (e.notification || "").includes("短信")
                ? "workspace_sms"
                : (e.notification || "").includes("邮件")
                  ? "workspace_email"
                  : "workspace",
            ));
          const t = (e.schedule || "").match(/每(\d+)(分钟|小时|天)/);
          t &&
            (setScheduleField("intervalValue", t[1]),
            setScheduleField("intervalUnit", t[2]));
          const s = (e.schedule || "").match(
            /(每天|工作日|每周一)\s*(\d{2}:\d{2})/,
          );
          s &&
            (setScheduleField("scheduleFrequency", s[1]),
            setScheduleField("scheduleTime", s[2]));
        } else
          (setScheduleField("scheduleTitle", ""),
            setScheduleField("schedulePrompt", ""),
            (state.scheduleTrigger = "plan"),
            setScheduleField("scheduleFrequency", "每天"),
            setScheduleField("scheduleTime", "08:00"),
            setScheduleField("scheduleContext", "fresh"),
            setScheduleField("scheduleNotification", "workspace"));
        (resetScheduleWizard(e),
          showSchedulePanels(),
          renderScheduleWizard(),
          updateScheduleConfigSummary(),
          ($("#saveSchedule").textContent = e ? "保存并更新" : "创建并启用"),
          openOverlay("scheduleModal"));
      }
      function buildScheduleConfig(e = "已启用") {
        const t = state.scheduleTrigger || "plan",
          s = $("#scheduleContext").selectedOptions[0].text,
          a = $("#scheduleNotification").selectedOptions[0].text;
        let n = triggerText(),
          i = "";
        return (
          "interval" === t &&
            (i = `${$("#intervalValue").value}${$("#intervalUnit").value}后`),
          "plan" === t &&
            (i =
              "每周一" === $("#scheduleFrequency").value
                ? `下周一 ${$("#scheduleTime").value}`
                : `下次 ${$("#scheduleTime").value}`),
          "once" === t && (i = $("#scheduleRunAt").value.replace("T", " ")),
          "sense" === t && (i = "事件触发后立即执行"),
          {
            name: $("#scheduleTitle").value.trim() || "未命名任务",
            desc: $("#schedulePrompt").value.trim(),
            schedule: n,
            next: i,
            status: e,
            context: s,
            last: "尚未运行",
            createMethod:
              "dialog" === state.scheduleCreateMethod ? "对话创建" : "固定模板",
            triggerLabel: {
              interval: "固定间隔",
              plan: "定时计划",
              once: "单次执行",
              sense: "主动感知",
            }[t],
            triggerKey: t,
            notification: a,
            successRate: 100,
            runsToday: 0,
            owner: "李崇阳",
          }
        );
      }
      function saveScheduleTask(e = "已启用") {
        if (calculateCompleteness() < 70)
          return void showToast("请先补充任务目标和执行配置");
        const t = buildScheduleConfig(e);
        if (state.editingScheduleId) {
          const e = state.scheduled.findIndex(
            (e) => e.id === state.editingScheduleId,
          );
          ((state.scheduled[e] = { ...state.scheduled[e], ...t }),
            (state.selectedSchedule = state.editingScheduleId),
            showToast(`已更新：${t.name}`));
        } else {
          const s = { id: Date.now(), ...t };
          (state.scheduled.push(s),
            (state.selectedSchedule = s.id),
            showToast(
              `${"草稿" === e ? "草稿已保存" : "定时任务已创建"}：${t.name}`,
            ));
        }
        (closeOverlay("scheduleModal"), renderSchedules());
      }
      function scheduleStatusClass(e) {
        return "运行中" === e.status
          ? "running"
          : "已暂停" === e.status || "草稿" === e.status
            ? "neutral"
            : "异常" === e.status
              ? "attention"
              : "done";
      }
      function scheduleFilterList() {
        const e = (state.scheduleSearch || "").toLowerCase();
        return state.scheduled.filter(
          (t) =>
            !(
              "enabled" === state.scheduleFilter &&
              !["运行中", "已启用"].includes(t.status)
            ) &&
            ("paused" !== state.scheduleFilter || "已暂停" === t.status) &&
            !("system" === state.scheduleFilter && !t.system) &&
            (!e ||
              [t.name, t.desc, t.schedule, t.triggerLabel]
                .join(" ")
                .toLowerCase()
                .includes(e)),
        );
      }
      function renderSchedules() {
        if (!state.scheduled.length)
          return (
            ($("#scheduleList").innerHTML =
              '<div class="schedule-empty">暂无定时任务</div>'),
            void ($("#scheduleDetail").innerHTML =
              '<div class="schedule-empty">请选择或创建任务</div>')
          );
        const e = state.scheduled.length,
          t = state.scheduled.filter((e) =>
            ["运行中", "已启用"].includes(e.status),
          ).length;
        ($("#scheduleKpiTotal") && ($("#scheduleKpiTotal").textContent = e),
          $("#scheduleKpiEnabled") &&
            ($("#scheduleKpiEnabled").textContent = t),
          $("#scheduleKpiRuns") &&
            ($("#scheduleKpiRuns").textContent = state.scheduled.reduce(
              (e, t) => e + (t.runsToday || Math.floor((t.id % 5) + 1)),
              0,
            )),
          $("#scheduleKpiFailed") &&
            ($("#scheduleKpiFailed").textContent =
              state.scheduled.filter((e) => "异常" === e.status).length || 1));
        const s = scheduleFilterList();
        s.some((e) => e.id === state.selectedSchedule) ||
          (state.selectedSchedule = s[0]?.id || state.scheduled[0].id);
        const a =
          state.scheduled.find((e) => e.id === state.selectedSchedule) ||
          state.scheduled[0];
        (($("#scheduleListCount").textContent = `共${s.length}项`),
          ($("#scheduleList").innerHTML =
            s
              .map((e) => {
                const t = inferTriggerKey(e),
                  s = e.successRate ?? (e.system ? 99.8 : 100);
                return `<div class="schedule-item ${e.id === a.id ? "active" : ""}" data-schedule="${e.id}"><div class="schedule-item-row"><div class="schedule-type-icon">${scheduleTriggerIcons[t]}</div><div class="schedule-item-main"><div class="schedule-item-top"><div class="schedule-name">${e.name}</div><span class="status ${scheduleStatusClass(e)}">${e.status}</span></div><div class="schedule-desc">${e.desc}</div><div class="schedule-meta"><div class="schedule-meta-left"><span class="schedule-source">${e.createMethod || (e.system ? "系统内置" : "固定模板")}</span><span>${e.schedule}</span></div><span class="schedule-next">${e.next}</span></div><div class="schedule-mini-progress"><i style="width:${s}%"></i></div></div></div></div>`;
              })
              .join("") ||
            '<div class="schedule-empty">没有符合条件的任务</div>'));
        const n = inferTriggerKey(a),
          i = a.successRate ?? 99.6,
          r = a.runsToday ?? 6;
        $("#scheduleDetail").innerHTML =
          `<div class="schedule-detail-hero"><div class="schedule-detail-head"><div class="schedule-detail-title"><div class="schedule-type-icon">${scheduleTriggerIcons[n]}</div><div><div class="actions" style="margin-bottom:5px"><span class="status ${scheduleStatusClass(a)}">${a.status}</span>${a.system ? '<span class="status purple">系统任务</span>' : ""}</div><h2>${a.name}</h2><p>${a.desc}</p></div></div><div class="actions"><button class="btn sm" id="runSchedule">${icons("i-play")}立即运行</button><button class="btn sm" id="editSchedule">编辑配置</button><button class="btn sm" id="pauseSchedule">${"已暂停" === a.status ? "恢复" : "暂停"}</button><button class="icon-btn" id="duplicateSchedule" title="复制任务">${icons("i-file")}</button><button class="icon-btn" id="deleteSchedule" title="删除任务">${icons("i-x")}</button></div></div><div class="schedule-overview-grid"><div class="schedule-overview-cell"><span>下次执行</span><strong>${a.next}</strong></div><div class="schedule-overview-cell"><span>今日运行</span><strong>${r}次</strong></div><div class="schedule-overview-cell"><span>近30天成功率</span><strong>${i}%</strong></div><div class="schedule-overview-cell"><span>结果通知</span><strong>${a.notification || "工作台＋短信"}</strong></div></div></div><div class="schedule-detail-body"><div class="schedule-section"><div class="schedule-section-head"><h3>执行链路</h3><span>从触发到结果推送全过程可审计</span></div><div class="schedule-trigger-flow"><div class="trigger-node"><small>01 · 触发</small><strong>${a.triggerLabel || "定时计划"}</strong><p>${a.schedule}</p></div><div class="trigger-arrow">→</div><div class="trigger-node"><small>02 · 智能体执行</small><strong>${a.context || "每次新建独立对话"}</strong><p>调用业务系统、知识库和专业工具完成任务。</p></div><div class="trigger-arrow">→</div><div class="trigger-node"><small>03 · 结果交付</small><strong>${a.notification || "工作台＋短信"}</strong><p>记录运行结果，异常时主动提醒并支持追溯。</p></div></div></div><div class="schedule-section"><div class="schedule-section-head"><h3>任务指令</h3><button class="text-btn" id="editPromptSchedule">通过对话修改</button></div><div class="schedule-prompt-box">${a.desc}</div></div><div class="schedule-section"><div class="schedule-section-head"><h3>最近运行记录</h3><span>查看全部运行日志</span></div><div class="run-timeline"><div class="run-record"><i class="run-dot"></i><span class="run-time">${a.last}</span><div class="run-result"><b>执行成功</b><span>任务正常完成，结果已推送至工作台。</span></div><span class="status done">成功</span></div><div class="run-record"><i class="run-dot"></i><span class="run-time">今日 09:00</span><div class="run-result"><b>执行成功</b><span>发现2项状态变化，生成1条风险提醒。</span></div><span class="status done">成功</span></div><div class="run-record"><i class="run-dot warn"></i><span class="run-time">昨日 18:00</span><div class="run-result"><b>工具调用重试后恢复</b><span>原系统接口短暂超时，5秒后自动重试成功。</span></div><span class="status waiting">已恢复</span></div></div></div>${a.system ? '<div class="schedule-section"><div class="hint-box"><b>系统常驻任务：</b>该任务用于自动感知应急事件，正常情况下无需业务人员手工修改。每发现一个新事件，都会创建独立业务任务，不会混入同一对话。</div></div>' : ""}</div>`;
      }
      function bindScheduleControls() {
        const e = $("#newScheduleBtn");
        (e && (e.onclick = () => openScheduleModal()),
          $("#refreshScheduleStatus") &&
            ($("#refreshScheduleStatus").onclick = () => {
              (renderSchedules(), showToast("定时任务状态已刷新"));
            }),
          ($("#scheduleWizardSend").onclick = () => {
            const e = $("#scheduleWizardInput"),
              t = e.value.trim();
            t && ((e.value = ""), processWizardText(t));
          }),
          $("#scheduleWizardInput").addEventListener("keydown", (e) => {
            "Enter" !== e.key ||
              e.shiftKey ||
              (e.preventDefault(), $("#scheduleWizardSend").click());
          }),
          ($("#saveSchedule").onclick = () => saveScheduleTask("已启用")),
          ($("#saveScheduleDraft").onclick = () => saveScheduleTask("草稿")),
          ($("#scheduleSearch").oninput = (e) => {
            ((state.scheduleSearch = e.target.value), renderSchedules());
          }),
          ($("#scheduleFilterTabs").onclick = (e) => {
            const t = e.target.closest("[data-schedule-filter]");
            t &&
              ((state.scheduleFilter = t.dataset.scheduleFilter),
              $$(".schedule-tab").forEach((e) =>
                e.classList.toggle("active", e === t),
              ),
              renderSchedules());
          }),
          $("#scheduleModal").addEventListener("click", (e) => {
            const t = e.target.closest("[data-create-method]");
            if (t)
              return (
                (state.scheduleCreateMethod = t.dataset.createMethod),
                "template" !== state.scheduleCreateMethod ||
                  $("#scheduleTitle").value ||
                  applyScheduleTemplate(state.scheduleTemplate),
                void showSchedulePanels()
              );
            const s = e.target.closest("[data-template]");
            if (s)
              return (
                (state.scheduleCreateMethod = "template"),
                void applyScheduleTemplate(s.dataset.template)
              );
            const a = e.target.closest("[data-trigger]");
            if (a)
              return (
                (state.scheduleTrigger = a.dataset.trigger),
                void showSchedulePanels()
              );
            const n = e.target.closest("[data-wizard-choice]");
            if (n) {
              const e = n.dataset.wizardChoice;
              return void ("__CREATE__" === e
                ? saveScheduleTask("已启用")
                : "__FOCUS_CONFIG__" === e
                  ? ($(".schedule-config-pane").scrollTo({
                      top: 0,
                      behavior: "smooth",
                    }),
                    showToast("右侧配置可直接修改"))
                  : processWizardText(e));
            }
          }),
          [
            "scheduleTitle",
            "schedulePrompt",
            "intervalValue",
            "intervalUnit",
            "scheduleFrequency",
            "scheduleTime",
            "scheduleCron",
            "scheduleRunAt",
            "senseSource",
            "senseCondition",
            "scheduleContext",
            "scheduleNotification",
          ].forEach((e) =>
            $("#" + e)?.addEventListener("input", updateScheduleConfigSummary),
          ));
      }
      function setEmergencyFilter(e) {
        ((state.filter = e || "all"),
          $$(".filter-tab", $("#emergencyFilters")).forEach((e) =>
            e.classList.toggle("active", e.dataset.filter === state.filter),
          ),
          $$(".hero-stat", $("#emergencySummaryStats")).forEach((e) =>
            e.classList.toggle(
              "active",
              e.dataset.summaryFilter === state.filter,
            ),
          ),
          renderEmergencyTable());
      }
      function renderEmergencyTable() {
        const e = state.emergencies || [],
          t = e.filter((e) => "done" !== e.statusClass).length,
          s = e.filter((e) => e.attention).length,
          a = e.filter((e) => "waiting" === e.statusClass).length,
          n = e.filter((e) => "done" === e.statusClass).length;
        ($("#statCurrent") && ($("#statCurrent").textContent = t),
          $("#statAttention") && ($("#statAttention").textContent = s),
          $("#statWaiting") && ($("#statWaiting").textContent = a),
          $("#statDone") && ($("#statDone").textContent = n),
          $$(".filter-tab", $("#emergencyFilters")).forEach((e) =>
            e.classList.toggle("active", e.dataset.filter === state.filter),
          ),
          $$(".hero-stat", $("#emergencySummaryStats")).forEach((e) =>
            e.classList.toggle(
              "active",
              e.dataset.summaryFilter === state.filter,
            ),
          ));
        const i = ($("#emergencySearch")?.value || "").toLowerCase();
        let r = e.filter(
          (e) =>
            e.title.toLowerCase().includes(i) ||
            e.code.includes(i) ||
            e.unit.toLowerCase().includes(i),
        );
        ("attention" === state.filter && (r = r.filter((e) => e.attention)),
          "running" === state.filter &&
            (r = r.filter(
              (e) =>
                "running" === e.statusClass ||
                "waiting" === e.statusClass ||
                "attention" === e.statusClass,
            )),
          "waiting" === state.filter &&
            (r = r.filter((e) => "waiting" === e.statusClass)),
          "done" === state.filter &&
            (r = r.filter((e) => "done" === e.statusClass)),
          ($("#emergencyTable").innerHTML =
            r
              .map(
                (e) =>
                  `<tr data-emergency="${e.id}" title="点击整行查看任务详情"><td><div class="task-name">${e.title}</div><div class="task-code">${e.code} · ${e.materials}</div></td><td>${e.unit}</td><td><div>${e.received}</div></td><td><span class="status ${e.statusClass}">${e.status}</span><div class="task-code">${e.stage}</div></td><td><div>${e.summary}</div><div class="progress ${100 === e.progress ? "green" : "blue"}" style="margin-top:6px"><i style="width:${e.progress}%"></i></div></td><td><div class="risk-line"><span class="risk-dot ${e.riskLevel}"></span><span class="task-risk-copy-execution">${e.risk}</span></div>${e.action ? `<div class="task-action-execution">待办：${e.action}</div>` : ""}</td></tr>`,
              )
              .join("") ||
            '<tr><td colspan="6"><div class="empty-state">没有符合条件的应急任务</div></td></tr>'));
      }
      function materialStatusGroup(e) {
        const t = e.status || "";
        return t.includes("跨单位响应")
          ? "crossResponse"
          : t.includes("跨单位确认")
            ? "crossConfirm"
            : t.includes("供应商") || t.includes("抢单")
              ? "supplier"
              : t.includes("在途") || t.includes("在建")
                ? "transit"
                : t.includes("应急采购")
                  ? "purchase"
                  : t.includes("确认响应")
                    ? "confirm"
                    : "other";
      }
      function summaryCounts() {
        const e = state.task.materials;
        return {
          total: e.length,
          crossResponse: e.filter(
            (e) => "crossResponse" === materialStatusGroup(e),
          ).length,
          crossConfirm: e.filter(
            (e) => "crossConfirm" === materialStatusGroup(e),
          ).length,
          supplier: e.filter((e) => "supplier" === materialStatusGroup(e))
            .length,
          transit: e.filter((e) => "transit" === materialStatusGroup(e)).length,
          purchase: e.filter((e) => "purchase" === materialStatusGroup(e))
            .length,
        };
      }
      function renderSummary() {
        const e = summaryCounts(),
          t = state.task.finalSolutionGenerated,
          s = t ? buildPlanDefinitions().find((e) => e.selected) : null,
          a = s?.metrics.gap || 0;
        (($("#summaryStrip").innerHTML = t
          ? `<div class="summary-main status-summary channel-task-status"><div class="summary-status-copy"><div class="status-final-icon-execution">✓</div><div><strong>当前待办：请确认最终方案${a ? `及${a}条缺口处置` : ""}并回写原系统</strong><p><span class="running-copy">最终方案已生成，二次确认已完成</span><span class="next-check-copy">${a ? `${a}条缺口进入兜底处置` : "当前无物资缺口"}</span></p></div></div><div class="summary-actions"><button class="btn xs" id="viewFinalFromSummary">查看最终方案</button><button class="btn xs primary" id="enterExecutionFromSummary">进入执行衔接</button></div></div>`
          : `<div class="summary-main status-summary channel-task-status"><div class="summary-status-copy"><div class="spinner compact"></div><div><strong>当前处理：${state.task.currentAction || "核验资源反馈并确认物资组合"}</strong><p><span class="running-copy">任务于 ${state.task.received} 接收</span><span class="next-check-copy">下次检查 ${state.task.nextCheck}</span></p></div></div><div class="summary-actions"><button class="btn xs" id="continueWaiting">继续等待</button><button class="btn xs" id="remindAll">自动催办</button><button class="btn xs primary" id="generatePlan2">生成方案</button></div></div>`),
          ($("#materialBadge").textContent = e.total));
      }
      function renderStage() {
        const e = [
          "任务接收",
          "需求识别",
          "自动寻源",
          "方案与二次确认",
          "回写执行",
          "事件复盘",
        ];
        $("#stagebar").innerHTML = e
          .map(
            (t, s) =>
              `<div class="stage ${s < state.task.stageIndex ? "done" : s === state.task.stageIndex ? "current" : ""}"><div class="stage-circle">${s < state.task.stageIndex ? "✓" : s + 1}</div><div class="stage-label">${t}</div>${s < e.length - 1 ? '<div class="stage-line"></div>' : ""}</div>`,
          )
          .join("");
      }
      function aliveBanner() {
        const e = state.task.counters;
        return `<div class="alive-banner"><div class="alive-left"><div class="spinner"></div><div><div class="alive-title">正在等待调拨与协议库存响应</div><div class="alive-copy">系统持续读取原系统状态和外部回复，无需人工刷新。</div></div></div><div class="alive-metrics"><span class="alive-pill">已发送 ${e.sent}</span><span class="alive-pill">已接收 ${e.received}</span><span class="alive-pill">已回复 ${e.replied}</span><span class="alive-pill">可满足 ${e.can}</span><span class="alive-pill">部分满足 ${e.partial}</span><span class="alive-pill">待回复 ${e.waiting}</span></div><div class="latest-event">最近更新 ${state.task.lastUpdate}<br>下次检查 ${state.task.nextCheck}</div></div>`;
      }
      function materialFilterMatch(e, t) {
        return !t || "all" === t || materialStatusGroup(e) === t;
      }
      function materialRows() {
        return (
          state.task.materials
            .filter((e) => materialFilterMatch(e, state.materialFilter))
            .map((e) => {
              const t = Math.min(
                100,
                Math.round(((e.filled || 0) / e.need) * 100),
              );
              return `<tr data-material="${e.id}" title="点击查看物资详情"><td><div class="material-name">${e.name}</div><div class="material-spec">${e.spec}</div></td><td class="qty"><strong>${e.need}</strong><span> ${e.unit}</span></td><td class="qty"><strong>${e.filled}</strong><span> ${e.unit}</span><div class="fill-bar ${t < 100 ? "partial" : ""}"><i style="width:${t}%"></i></div></td><td><span class="status ${e.statusClass}">${e.status}</span></td><td><span class="material-source-summary">${e.method}</span></td><td>${e.updated}</td></tr>`;
            })
            .join("") ||
          '<tr><td colspan="6"><div class="empty-state">当前筛选状态下暂无物资</div></td></tr>'
        );
      }
      function isInternalResponse(e) {
        return ["unit", "transit"].includes(e.channelKey);
      }
      function materialResponseGroups(e) {
        return {
          internal: e.sources.filter(
            (e) =>
              ["unit", "transit"].includes(e.channelKey) && !1 !== e.requested,
          ),
          suppliers: e.sources.filter(
            (e) =>
              ["rush", "purchase"].includes(e.channelKey) && !1 !== e.requested,
          ),
        };
      }
      function responseTone(e) {
        return /可调拨|有货|可供|可用/.test(e)
          ? "good"
          : /部分|核库|确认/.test(e)
            ? "warn"
            : /等待|未回复|超时|询价中|接单/.test(e)
              ? "wait"
              : "off";
      }
      function sourceSelectable(e) {
        return (
          (e.qtyValue || 0) > 0 &&
          !/无库存|无现货|无可用量|未回复|超时|询价中|未触发/.test(e.status)
        );
      }
      function sourceReminderSummary(e) {
        if (e.reminderStatus) return e.reminderStatus;
        const t = e.reminderCount || 0;
        return t && /已回复|有货|可调拨|可供|可用|部分|确认/.test(e.status)
          ? "催办后已回复"
          : (t >= 2 && /等待|未回复|超时/.test(e.status)) || t
            ? `智能体自动催办 +${t}`
            : /等待|未回复|超时|核库中/.test(e.status)
              ? "尚未到催办时限"
              : "无需催办";
      }
      function selectedSources(e) {
        const t = new Set(e.selectedSourceIds || []);
        return e.sources.filter((e) => t.has(e.id));
      }
      function roundQty(e) {
        return Math.round(1e4 * (e || 0)) / 1e4;
      }
      function groupSourcesByOwner(e) {
        const t = new Map();
        return (
          e.forEach((e) => {
            const s = `${e.channelKey || "unit"}||${e.name}`;
            t.has(s) ||
              t.set(s, {
                key: s,
                name: e.name,
                channelKey: e.channelKey || "unit",
                sources: [],
                qtyValue: 0,
              });
            const a = t.get(s);
            (a.sources.push(e), (a.qtyValue += e.qtyValue || 0));
          }),
          [...t.values()].map((e) => ({
            ...e,
            qtyValue: roundQty(e.qtyValue),
            ids: e.sources.map((e) => e.id),
          }))
        );
      }
      function sourceGroupStatus(e) {
        const t = e.sources.map((e) => e.status).join(" ");
        return /已确认|可调拨|有货|可供|可用/.test(t)
          ? /部分/.test(t)
            ? "部分确认"
            : "已确认"
          : /部分/.test(t)
            ? "部分响应"
            : /等待|未回复|超时|核库中|询价中/.test(t)
              ? "等待响应中"
              : e.sources[0]?.status || "待确认";
      }
      function materialMethodLabel(e) {
        const t = groupSourcesByOwner(e);
        if (!t.length) return "尚未选择资源";
        const s = t.map((e) => e.name);
        return s.length <= 2
          ? s.join(" ＋ ")
          : `${s.slice(0, 2).join(" ＋ ")} 等${s.length}个来源`;
      }
      function normalizeMaterialMethods() {
        state.task.materials.forEach((e) => {
          const t = selectedSources(e);
          t.length && (e.method = materialMethodLabel(t));
        });
      }
      function selectSourceGroup(e, t, s) {
        const a = state.task.materials.find((t) => t.id === e);
        if (!a) return;
        a.selectedSourceIds = a.selectedSourceIds || [];
        const n = new Set(a.selectedSourceIds);
        (t.forEach((e) => {
          const t = a.sources.find((t) => t.id === e);
          t && sourceSelectable(t) && (s ? n.add(e) : n.delete(e));
        }),
          (a.selectedSourceIds = [...n]),
          updateMaterialFromSelections(a),
          a.history.push(
            `${nowTime().slice(0, 5)} 用户${s ? "选择" : "取消"}同一响应对象的${t.length}条资源记录`,
          ));
        const i = selectedSources(a),
          r = Math.max(0, roundQty(a.need - a.filled));
        (state.assistant.push({
          role: "assistant",
          text: `已${s ? "选择" : "取消"}“${a.name}”的一组资源。当前来源按单位/供应商归并为：${materialMethodLabel(i)}；${0 === r ? "需求已满足" : `仍缺${r}${a.unit}`}。`,
          action:
            "同一单位的多条库存、订单或项目记录已归并展示，底层明细仍可展开追溯。",
        }),
          renderWorkbench(),
          renderMaterialDrawer(),
          showToast(s ? "已选择该响应对象" : "已取消该响应对象"));
      }
      function sourceNoticeMethod(e) {
        return ["unit", "transit"].includes(e.channelKey)
          ? "邮件＋工单"
          : ["rush", "purchase"].includes(e.channelKey)
            ? "E物资＋短信"
            : "邮件＋工单";
      }
      function getReminderTone(e) {
        return /越级/.test(e)
          ? "escalated"
          : /手动/.test(e)
            ? "manual"
            : /人工介入/.test(e)
              ? "intervention"
              : /催办后已回复/.test(e)
                ? "done"
                : /自动催办/.test(e)
                  ? "auto"
                  : "neutral";
      }
      function canManuallyRemindSource(e) {
        return (
          /等待|未回复|未响应|超时|核库中|应急采购/.test(e.status || "") &&
          !/人工介入|已关闭/.test(e.reminderStatus || "")
        );
      }
      function manuallyRemindSource(e, t) {
        const s = state.task.materials.find((t) => t.id === e),
          a = s?.sources.find((e) => e.id === t);
        a &&
          ((a.reminderCount = (a.reminderCount || 0) + 1),
          (a.reminderStatus = `手动催办 +${a.reminderCount}`),
          (a.reminders = a.reminders || []),
          a.reminders.push(
            `10:${String(8 + 3 * a.reminderCount).padStart(2, "0")} 业务人员执行手动催办 +1`,
          ),
          state.task.events.unshift({
            time: "刚刚",
            title: `已手动催办：${a.name}`,
            copy: `针对${s.name}的响应请求已再次发送，当前累计催办${a.reminderCount}次。`,
            level: "important",
          }),
          state.assistant.push({
            role: "assistant",
            text: `已对${a.name}执行手动催办，涉及物资“${s.name}”。通知已按对象类型通过${sourceNoticeMethod(a)}发送，并写入过程留痕。`,
          }),
          showToast("手动催办已发送"),
          renderWorkbench());
      }
      function seedReminderScenarios(e, t) {
        const s = [];
        (e.materials || []).forEach((e) =>
          (e.sources || []).forEach((t) => {
            !1 !== t.requested && s.push({ m: e, src: t });
          }),
        );
        const a = s.filter((e) =>
            /等待|未响应|超时|核库中/.test(e.src.status || ""),
          ),
          n = s.filter((e) =>
            /已响应|已回复|已确认|可供|可匹配|满足/.test(e.src.status || ""),
          ),
          i = (e, t, s, a) => {
            e &&
              ((e.src.reminderStatus = t),
              (e.src.reminderCount = s),
              (e.src.reminders = a));
          };
        if ("E001" === t)
          return (
            i(n[0], "催办后已回复", 1, [
              "08-14 15:20 邮件与工单发送",
              "08-14 15:35 智能体自动催办 +1",
              "08-14 15:42 对方完成回复",
            ]),
            void i(n[1], "催办后已回复", 2, [
              "08-14 15:41 E物资与短信通知",
              "08-14 15:56 智能体自动催办 +1",
              "08-14 16:08 智能体自动催办 +2",
              "08-14 16:16 供应商回复",
            ])
          );
        (i(a[0], "智能体自动催办 +1", 1, [
          "09:20 请求发送",
          "09:35 达到首次响应时限，智能体自动催办 +1",
        ]),
          i(a[1], "智能体自动催办 +2", 2, [
            "09:18 请求发送",
            "09:33 智能体自动催办 +1",
            "09:48 仍未回复，智能体自动催办 +2",
          ]),
          i(a[2], "已越级催办", 2, [
            "09:16 请求发送",
            "09:31 自动催办 +1",
            "09:46 自动催办 +2",
            "10:01 仍未回复，已越级通知负责人",
          ]),
          i(a[3], "手动催办 +1", 1, [
            "09:25 请求发送",
            "09:43 业务人员执行手动催办 +1",
          ]),
          i(a[4], "已提级人工介入", 3, [
            "09:10 请求发送",
            "09:25 自动催办 +1",
            "09:40 自动催办 +2",
            "09:55 越级催办",
            "10:10 超过最终时限，提级运营中心人工介入",
          ]),
          i(n[0], "催办后已回复", 1, [
            "09:14 请求发送",
            "09:29 自动催办 +1",
            "09:36 对方回复",
          ]));
      }
      function ensureSourceNotice(e, t = 0) {
        if (e.notice)
          return ((e.notice.method = sourceNoticeMethod(e)), e.notice);
        const s =
            {
              unit: "08-14 15:20",
              rush: "08-14 15:41",
              transit: "08-14 16:05",
              purchase: "08-14 18:00",
            }[e.channelKey] || "08-14 15:30",
          a =
            !/未响应|等待|超时|应急采购|核库中/.test(e.status) &&
            e.reply &&
            "—" !== e.reply;
        return (
          (e.notice = {
            method: sourceNoticeMethod(e),
            target: e.name,
            sentAt: s,
            readAt: /未响应|等待/.test(e.status)
              ? t % 2 == 0
                ? "08-14 15:48"
                : "—"
              : "08-14 15:48",
            replyAt: a ? e.reply : "—",
            deadline: "08-14 16:10",
            sendStatus: "发送成功",
          }),
          e.notice
        );
      }
      function sourceNoticeSummary(e, t = 0) {
        const s = ensureSourceNotice(e, t),
          a =
            s.replyAt && "—" !== s.replyAt
              ? `${s.sentAt}发送 · ${s.replyAt}已回复`
              : s.readAt && "—" !== s.readAt
                ? `${s.sentAt}发送 · ${s.readAt}已读`
                : `${s.sentAt}发送 · 待读取`;
        return `<span class="notice-method">${s.method}</span><span>${a}</span>`;
      }
      function sourceNoticeTimeline(e, t = 0) {
        const s = ensureSourceNotice(e, t),
          a = [`${s.sentAt} ${s.method}发送成功`];
        return (
          s.readAt && "—" !== s.readAt && a.push(`${s.readAt} 对方已读`),
          s.replyAt && "—" !== s.replyAt && a.push(`${s.replyAt} 收到回复`),
          a
        );
      }
      function updateMaterialFromSelections(e) {
        const t = selectedSources(e),
          s = t.reduce((e, t) => e + (t.qtyValue || 0), 0);
        if (
          ((e.filled = Math.min(e.need, Math.round(100 * s) / 100)),
          (e.method = materialMethodLabel(t)),
          (e.updated = nowTime().slice(0, 5)),
          e.filled >= e.need)
        ) {
          const s = new Set(t.map((e) => e.channelKey));
          (s.has("purchase")
            ? (e.status = "应急采购确认中")
            : s.has("transit")
              ? (e.status = "等待在途/在建确认中")
              : s.has("rush")
                ? (e.status = "等待供应商确认中")
                : (e.status = "等待跨单位确认中"),
            (e.statusClass = "waiting"));
        } else
          "unit" === e.activeChannel
            ? ((e.status = "等待跨单位响应中"), (e.statusClass = "running"))
            : "rush" === e.activeChannel
              ? ((e.status = "等待供应商响应中"), (e.statusClass = "purple"))
              : "transit" === e.activeChannel
                ? ((e.status = "等待在途/在建确认中"),
                  (e.statusClass = "waiting"))
                : ((e.status = "应急采购"), (e.statusClass = "attention"));
      }
      function toggleMaterialSource(e, t) {
        const s = state.task.materials.find((t) => t.id === e),
          a = s?.sources.find((e) => e.id === t);
        if (!s || !a || !sourceSelectable(a)) return;
        const n = selectedSources(s),
          i = n.reduce((e, t) => e + (t.qtyValue || 0), 0),
          r = selectedLatestEta(n);
        s.selectedSourceIds = s.selectedSourceIds || [];
        const l = s.selectedSourceIds.includes(t);
        ((s.selectedSourceIds = l
          ? s.selectedSourceIds.filter((e) => e !== t)
          : [...s.selectedSourceIds, t]),
          updateMaterialFromSelections(s));
        const d = selectedSources(s),
          c = selectedLatestEta(d),
          o = Math.max(0, +(s.need - s.filled).toFixed(2));
        s.history.push(
          `${nowTime().slice(0, 5)} 用户${l ? "取消" : "选择"}资源：${a.name}`,
        );
        const u = ["rush", "purchase"].includes(a.channelKey)
            ? l
              ? "采购成本影响已移除"
              : "组合可能增加采购成本"
            : "暂不增加采购成本",
          p = `相较调整前，已选量由${Math.round(100 * i) / 100}${s.unit}变为${s.filled}${s.unit}，最晚到货由${r}变为${c}`;
        (state.assistant.push({
          role: "assistant",
          text: `已${l ? "取消" : "选择"}“${s.name}”来源：${a.name}。当前组合为${materialMethodLabel(d)}；${0 === o ? "需求已满足" : `仍缺${o}${s.unit}`}。${p}；${u}。`,
          action:
            "用户手动选择已同步更新已选数量、剩余缺口、来源数、预计到货时间和组合方案。",
        }),
          renderWorkbench(),
          renderMaterialDrawer(),
          showToast(l ? "已取消该来源" : "已选择该来源"));
      }
      function parseQtyNumber(e) {
        const t = parseFloat(String(e).replace(/,/g, ""));
        return Number.isFinite(t) ? t : 0;
      }
      function bestSource(e, t = !1) {
        return (
          e.sources
            .filter(
              (e) =>
                (!t || isInternalResponse(e)) &&
                (e.status.includes("可以") || e.status.includes("部分")),
            )
            .sort((e, t) => parseQtyNumber(t.qty) - parseQtyNumber(e.qty))[0] ||
          e.sources[0]
        );
      }
      function planMaterialDecision(e, t) {
        state.task.plans.find((e) => e.id === t);
        const s = e.sources.filter(
            (e) => e.status.includes("可以") || e.status.includes("部分"),
          ),
          a =
            s
              .map((e) => e.name)
              .slice(0, 2)
              .join(" + ") || "等待外部响应",
          n = s.map((e) => e.eta).find((e) => e && "—" !== e) || "待确认",
          i = e.filled >= e.need,
          r = e.filled > 0 && !i;
        if ("P1" === t)
          return {
            status: i
              ? "满足"
              : e.procure
                ? "采购补足"
                : r
                  ? "部分满足"
                  : "继续寻源",
            tone: i ? "good" : r || e.procure ? "warn" : "wait",
            route: e.method,
            source: a,
            qty: `${e.filled}/${e.need}${e.unit}`,
            eta: n,
            score: i ? 3 : r ? 2 : 1,
          };
        if ("P2" === t) {
          const t = bestSource(e, !0) || bestSource(e),
            a = t ? t.qty : "—",
            n = i && !e.allowSplit && s.length <= 1;
          return {
            status: n ? "满足" : "继续等待",
            tone: n ? "good" : "wait",
            route: e.procure ? "单一供应商完整供货" : "单一单位优先",
            source: t ? t.name : "等待单一来源",
            qty: n
              ? `${e.need}/${e.need}${e.unit}`
              : `${a} / 需求${e.need}${e.unit}`,
            eta: t?.eta || "预计延后",
            score: n ? 3 : 1,
          };
        }
        return {
          status: "可执行",
          tone: "good",
          route: i && !e.procure ? e.method : "缺口转应急采购",
          source: i && !e.procure ? a : "应急采购供应商池",
          qty: `${e.need}/${e.need}${e.unit}`,
          eta: i ? n : "今日07:00",
          score: i ? 3 : 2,
        };
      }
      function comparePlanOptions(e) {
        return state.task.plans
          .map(
            (t) =>
              `<option value="${t.id}" ${t.id === e ? "selected" : ""}>${t.name}</option>`,
          )
          .join("");
      }
      function comparePlanHead(e, t) {
        const s = state.task.plans.find((t) => t.id === e);
        return `<div class="compare-plan-head"><select class="compare-plan-select" id="comparePlan${t}">${comparePlanOptions(e)}</select><div class="compare-plan-summary"><div><span>满足率</span><strong>${s.fit}</strong></div><div><span>最晚到货</span><strong>${s.eta}</strong></div><div><span>涉及单位</span><strong>${s.units}</strong></div><div><span>预计采购</span><strong>${s.cost}</strong></div></div></div>`;
      }
      function compareMaterialRow(e, t, s) {
        const a = planMaterialDecision(e, t),
          n = planMaterialDecision(e, s),
          i = a.score > n.score,
          r = n.score > a.score,
          l = (e, t) =>
            `<div class="compare-option ${t ? "better" : ""}"><span class="compare-option-status ${e.tone}">${e.status}</span><div class="compare-option-route">${e.route}</div><div class="compare-option-source">${e.source}</div><div class="compare-option-grid"><div><span>满足数量</span><strong>${e.qty}</strong></div><div><span>最早到货</span><strong>${e.eta}</strong></div><div><span>处理建议</span><strong>${"继续等待" === e.status ? "继续响应" : "可纳入方案"}</strong></div></div></div>`;
        return `<div class="compare-material-row"><div class="compare-material-label" data-open-material="${e.id}"><strong>${e.name}</strong><span>${e.spec} · 需求${e.need}${e.unit}</span><em>查看单位/供应商响应 ›</em></div>${l(a, i)}${l(n, r)}</div>`;
      }
      function updateAssistantContext() {
        const e = $$(".quick-chip");
        let t;
        ((t =
          "overview" === state.wbTab
            ? [
                "说明当前需要我判断什么",
                "查看智能体已完成事项",
                "确认后会自动做什么",
                "打开最终方案",
              ]
            : "plans" === state.wbTab
              ? [
                  "对比原系统与AI方案",
                  "查看AI推荐完整方案",
                  "查看二次确认进度",
                  "发起二次确认",
                ]
              : "materials" === state.wbTab
                ? [
                    "查看光缆单位与供应商响应",
                    "查看当前物资缺口",
                    "催办所有未回复单位",
                    "将通信电源转入应急采购",
                  ]
                : "responses" === state.wbTab
                  ? [
                      "汇总四渠道寻源结果",
                      "只看应急抢单",
                      "催办所有未回复单位",
                      "查看当前物资缺口",
                    ]
                  : [
                      "查看当前物资缺口",
                      "查看当前人工介入事项",
                      "催办所有未回复单位",
                      "生成下一步建议",
                    ]),
          e.forEach((e, s) => {
            t[s] && ((e.textContent = t[s]), (e.dataset.quick = t[s]));
          }));
        const s = $("#assistantInput");
        s &&
          (s.placeholder =
            "plans" === state.wbTab
              ? "输入方案约束、对比维度或二次确认要求…"
              : "输入查询、约束或执行指令，页面数据会同步更新…");
      }
      function renderMaterials() {
        const e = state.materialFilter || "all";
        return `<div class="card section-card"><div class="section-head"><div><h3>物资级任务清单</h3></div></div><div class="section-body" style="padding-top:4px">${"all" !== e ? `<div class="material-filter-note"><span>当前筛选：<b>${{ all: "全部物资", crossResponse: "等待跨单位响应中", crossConfirm: "等待跨单位确认中", supplier: "供应商响应与确认中", transit: "在途/在建确认中", purchase: "应急采购处理中" }[e]}</b></span><button id="clearMaterialFilter">查看全部物资</button></div>` : ""}<table class="material-table"><thead><tr><th>物资</th><th>需求</th><th>当前已选</th><th>寻源状态</th><th>当前来源组合</th><th>最近更新</th></tr></thead><tbody>${materialRows()}</tbody></table></div></div>`;
      }
      const RESPONSE_CHANNELS = {
        unit: {
          name: "跨单位调拨",
          icon: "i-network",
          desc: "优先查询其他单位可调拨实物库存",
        },
        rush: {
          name: "应急抢单",
          icon: "i-bot",
          desc: "向系统外供应商抢单，优先采用先回复且有货的供应商",
        },
        transit: {
          name: "在途/在建",
          icon: "i-external",
          desc: "核实在途、在建项目及待调余量",
        },
        purchase: {
          name: "应急采购",
          icon: "i-file",
          desc: "前三渠道无法满足后启动应急采购",
        },
      };
      function responseChannelKey(e) {
        return e.channelKey || "unit";
      }
      function allResponseRecords() {
        const e = [];
        return (
          state.task.materials.forEach((t) =>
            t.sources
              .filter((e) => !1 !== e.requested)
              .forEach((s) =>
                e.push({
                  material: t,
                  source: s,
                  channel: responseChannelKey(s),
                }),
              ),
          ),
          e
        );
      }
      function channelStats(e, t) {
        const s = t.filter((t) => t.channel === e),
          a = s.filter((e) =>
            /等待|未回复|超时|询价中|接单|确认中|核库中/.test(e.source.status),
          ),
          n = s.filter(
            (e) =>
              (e.source.qtyValue || 0) > 0 ||
              /可调拨|有货|可供|可用|部分/.test(e.source.status),
          ),
          i = s.filter((e) => !a.includes(e)),
          r = s.filter((e) => /部分/.test(e.source.status)),
          l = new Set(s.map((e) => e.material.id));
        return {
          total: s.length,
          replied: i.length,
          can: n.length,
          unreplied: a.length,
          confirmed: n.length,
          partial: r.length,
          waiting: a.length,
          materials: l.size,
        };
      }
      function responseChannelStage(e, t) {
        return "unit" === e
          ? { label: "优先启动 · 进行中", tone: "running" }
          : "rush" === e
            ? {
                label: t.total ? "按缺口触发 · 进行中" : "待触发",
                tone: t.total ? "running" : "neutral",
              }
            : "transit" === e
              ? {
                  label: t.total ? "部分触发" : "待触发",
                  tone: t.total ? "waiting" : "neutral",
                }
              : {
                  label: t.total ? "兜底处理中" : "兜底 · 未启动",
                  tone: t.total ? "attention" : "neutral",
                };
      }
      function ownerCoverageCount(e, t) {
        return new Set(
          state.task.materials
            .filter((s) =>
              s.sources.some((s) => s.name === e && s.channelKey === t),
            )
            .map((e) => e.id),
        ).size;
      }
      function sourceDistanceValue(e) {
        const t = `${e.distance || ""} ${e.name || ""}`,
          s = t.match(/(\d+(?:\.\d+)?)\s*km/i);
        if (s) return +s[1];
        const a = [
          ["忠县", 0],
          ["石柱", 55],
          ["万州", 82],
          ["垫江", 90],
          ["丰都", 96],
          ["云阳", 115],
          ["长寿", 128],
          ["涪陵", 142],
          ["梁平", 145],
          ["开州", 155],
          ["江津", 175],
          ["北碚", 185],
          ["市区", 190],
          ["南岸", 195],
          ["江北", 198],
          ["市北", 198],
          ["合川", 205],
          ["铜梁", 218],
          ["璧山", 225],
          ["永川", 245],
          ["大足", 270],
          ["潼南", 285],
          ["南川", 295],
          ["武隆", 310],
          ["黔江", 345],
        ];
        for (const [e, s] of a) if (t.includes(e)) return s;
        return 9999;
      }
      function sourceEtaValue(e) {
        const t = String(e.eta || "");
        if (/^\d{4}-\d{2}-\d{2}/.test(t)) return new Date(t).getTime();
        const s = t.match(/(?:今日|明日)?\s*(\d{1,2}):(\d{2})/);
        return s ? 60 * +s[1] + +s[2] : Number.MAX_SAFE_INTEGER;
      }
      function sourceWarehouseRank(e) {
        const t = `${e.distance || ""}${e.channel || ""}`;
        return /物资库|仓库|虚拟库/.test(t)
          ? 0
          : /专业仓/.test(t)
            ? 1
            : /生产仓/.test(t)
              ? 2
              : 3;
      }
      function sourceTypeRank(e) {
        const t = `${e.distance || ""}${e.risk || ""}`;
        return /项目结余/.test(t)
          ? 0
          : /生产剩余/.test(t)
            ? 1
            : /寄存结余/.test(t)
              ? 2
              : /应急物资/.test(t)
                ? 3
                : /寄存物资/.test(t)
                  ? 4
                  : 5;
      }
      function compareTuple(e, t) {
        for (let s = 0; s < Math.max(e.length, t.length); s++) {
          const a = e[s] ?? 0,
            n = t[s] ?? 0;
          if (a !== n) return a - n;
        }
        return 0;
      }
      function sourcePriorityTuple(e, t) {
        const s = ownerCoverageCount(t.name, t.channelKey),
          a = sourceDistanceValue(t),
          n = (t.qtyValue || 0) >= e.need ? 0 : 1,
          i = sourceEtaValue(t),
          r = i < Number.MAX_SAFE_INTEGER ? 0 : 1;
        return "unit" === t.channelKey
          ? [-s, a, 0, sourceWarehouseRank(t), sourceTypeRank(t), n, 0]
          : "rush" === t.channelKey
            ? [0, n, r, i, a]
            : "transit" === t.channelKey
              ? [-s, a, n, i]
              : [9, n, i, a];
      }
      function compareSourcePriority(e, t, s) {
        const a = { unit: 0, rush: 1, transit: 2, purchase: 3 },
          n = (a[t.channelKey] ?? 9) - (a[s.channelKey] ?? 9);
        return (
          n ||
          compareTuple(sourcePriorityTuple(e, t), sourcePriorityTuple(e, s)) ||
          String(t.name).localeCompare(String(s.name), "zh-CN")
        );
      }
      function compareSourceGroups(e, t, s) {
        const a = { unit: 0, rush: 1, transit: 2, purchase: 3 },
          n = (a[t.channelKey] ?? 9) - (a[s.channelKey] ?? 9);
        if (n) return n;
        const i = [...t.sources].sort((t, s) =>
            compareSourcePriority(e, t, s),
          )[0],
          r = [...s.sources].sort((t, s) => compareSourcePriority(e, t, s))[0];
        return compareSourcePriority(e, i, r);
      }
      function renderResponses() {
        ((state.responseChannel = state.responseChannel || "all"),
          (state.responseSearch = state.responseSearch || ""),
          (state.responseStatus = state.responseStatus || "all"),
          (state.responseSort = state.responseSort || "priority"),
          (state.responsePage = state.responsePage || 1),
          (state.responsePageSize = state.responsePageSize || 20));
        const e = allResponseRecords(),
          t = Object.entries(RESPONSE_CHANNELS)
            .map(
              ([e, t]) =>
                `<button class="channel-feedback-card channel-channel-card ${state.responseChannel === e ? "active" : ""}" data-response-channel="${e}" aria-pressed="${state.responseChannel === e}"><span class="channelmeta-channel-name">${t.name}</span></button>`,
            )
            .join("");
        let s = (
          "all" === state.responseChannel
            ? e
            : e.filter((e) => e.channel === state.responseChannel)
        ).filter((e) => {
          const t = state.responseSearch.toLowerCase();
          return (
            !(
              t &&
              !`${e.material.name}${e.source.name}${e.source.status}`
                .toLowerCase()
                .includes(t)
            ) &&
            !(
              "available" === state.responseStatus &&
              !sourceSelectable(e.source)
            ) &&
            !(
              "waiting" === state.responseStatus &&
              !/等待|未回复|超时|核库中|应急采购/.test(e.source.status)
            ) &&
            ("reminded" !== state.responseStatus ||
              "无需催办" !== sourceReminderSummary(e.source))
          );
        });
        s.sort((e, t) =>
          "priority" === state.responseSort
            ? compareSourcePriority(e.material, e.source, t.source)
            : "reminder" === state.responseSort
              ? (t.source.reminderCount || 0) - (e.source.reminderCount || 0)
              : "channel" === state.responseSort
                ? ["unit", "rush", "transit", "purchase"].indexOf(e.channel) -
                  ["unit", "rush", "transit", "purchase"].indexOf(t.channel)
                : String(e.source.reply || "").localeCompare(
                    String(t.source.reply || ""),
                  ),
        );
        const a = s.length,
          n = Math.max(1, Math.ceil(a / state.responsePageSize));
        state.responsePage = Math.min(state.responsePage, n);
        const i = (state.responsePage - 1) * state.responsePageSize,
          r =
            s
              .slice(i, i + state.responsePageSize)
              .map((e, t) => {
                const s = e.source,
                  a = e.material,
                  n = sourceReminderSummary(s);
                return `<tr><td><span class="channel-tag ${e.channel}">${RESPONSE_CHANNELS[e.channel].name}</span></td><td><strong>${s.name}</strong><small>${s.type} · ${s.channel || RESPONSE_CHANNELS[e.channel].name}</small></td><td><button class="text-btn" data-open-material="${a.id}"><strong>${a.name}</strong></button><small>需求 ${a.need}${a.unit}</small></td><td>${s.qty}</td><td><span class="response-status ${responseTone(s.status)}">${s.status}</span><div class="notice-inline">${sourceNoticeSummary(s, t)}</div></td><td>${s.eta}</td><td>${s.reply}</td><td><div class="reminder-cell-execution"><span class="reminder-label-execution ${getReminderTone(n)}">${n}</span>${canManuallyRemindSource(s) ? `<button class="manual-remind-execution" data-manual-remind="${a.id}|${s.id}">手动催办</button>` : ""}</div></td></tr>`;
              })
              .join("") ||
            '<tr><td colspan="8"><div class="empty-state">当前条件下暂无响应记录</div></td></tr>',
          l = Array.from({ length: Math.min(n, 5) }, (e, t) => t + 1)
            .map(
              (e) =>
                `<button class="${e === state.responsePage ? "active" : ""}" data-response-page="${e}">${e}</button>`,
            )
            .join("");
        return `<div class="channel-feedback-grid">${t}</div><div class="card section-card response-ledger"><div class="section-head"><div><h3>${"all" === state.responseChannel ? "渠道响应明细" : RESPONSE_CHANNELS[state.responseChannel].name + "响应明细"}</h3></div><div class="actions"><button class="btn sm ${"all" === state.responseChannel ? "primary" : ""}" id="showAllResponseChannels">全部渠道</button><button class="btn sm" id="openEvidence">过程证据</button></div></div><div class="section-body" style="padding-top:4px"><div class="response-filter-bar"><input id="responseSearch" value="${escapeHtml(state.responseSearch)}" placeholder="搜索物资、单位或供应商"><select id="responseStatus"><option value="all" ${"all" === state.responseStatus ? "selected" : ""}>全部状态</option><option value="available" ${"available" === state.responseStatus ? "selected" : ""}>仅看可用</option><option value="waiting" ${"waiting" === state.responseStatus ? "selected" : ""}>仅看待回复</option><option value="reminded" ${"reminded" === state.responseStatus ? "selected" : ""}>仅看已催办</option></select><select id="responseSort"><option value="priority" ${"priority" === state.responseSort ? "selected" : ""}>按智能推荐</option><option value="reply" ${"reply" === state.responseSort ? "selected" : ""}>按回复时间</option><option value="reminder" ${"reminder" === state.responseSort ? "selected" : ""}>按催办状态</option><option value="channel" ${"channel" === state.responseSort ? "selected" : ""}>按渠道顺序</option></select><select id="responsePageSize"><option value="20" ${20 === state.responsePageSize ? "selected" : ""}>20条/页</option><option value="50" ${50 === state.responsePageSize ? "selected" : ""}>50条/页</option><option value="100" ${100 === state.responsePageSize ? "selected" : ""}>100条/页</option></select></div><div class="response-table-wrap"><table class="response-ledger-table"><thead><tr><th>寻源渠道</th><th>响应对象</th><th>物资需求</th><th>可供数量</th><th>响应与通知</th><th>最早到货</th><th>回复时间</th><th>催办状态</th></tr></thead><tbody>${r}</tbody></table></div><div class="response-pagination"><span>共 ${a} 条，当前第 ${state.responsePage}/${n} 页</span><div class="pager-buttons"><button data-response-page="${state.responsePage - 1}" ${state.responsePage <= 1 ? "disabled" : ""}>‹</button>${l}<button data-response-page="${state.responsePage + 1}" ${state.responsePage >= n ? "disabled" : ""}>›</button></div></div></div></div>`;
      }
      function ensurePlanBuilderState() {
        ((state.planMaterial =
          state.planMaterial || state.task.materials[0].id),
          (state.customSelections =
            state.customSelections ||
            Object.fromEntries(
              state.task.materials.map((e) => [
                e.id,
                state.task.selectedPlan || "P1",
              ]),
            )));
      }
      function customPlanMetrics() {
        ensurePlanBuilderState();
        const e = Object.fromEntries(state.task.plans.map((e) => [e.id, e])),
          t = state.task.materials.map(
            (e) => state.customSelections[e.id] || "P1",
          ),
          s = (s) => t.reduce((t, a) => t + s(e[a]), 0) / t.length,
          a = Math.round(s((e) => parseInt(e.fit) || 0)),
          n = Math.max(1, Math.round(s((e) => parseInt(e.units) || 0))),
          i = t.map((t) => parseFloat(e[t].cost)).filter(Number.isFinite),
          r = i.length
            ? Math.round((i.reduce((e, t) => e + t, 0) / i.length) * 10) / 10 +
              "万元"
            : "待核价",
          l = Math.max(
            1,
            Math.round(
              t.reduce((e, t) => e + ("P1" === t ? 3 : "P2" === t ? 1 : 2), 0) /
                t.length,
            ),
          ),
          d = { P1: 6, P2: 8, P3: 7 };
        return {
          fit: `${a}%`,
          eta: `今日0${Math.max(...t.map((e) => d[e] || 7))}:00`,
          units: `${n}家`,
          cost: r,
          coordination: `${l}项`,
          risk: t.filter((e) => "P3" === e).length > 3 ? "中" : "中低",
        };
      }
      function planCandidateCard(e, t) {
        const s = planMaterialDecision(e, t.id),
          a = state.customSelections[e.id] === t.id;
        return `<button class="material-choice-card ${a ? "selected" : ""}" data-plan-choice="${t.id}" data-plan-material-id="${e.id}"><div class="material-choice-head"><span>${"P1" === t.id ? "推荐A" : "P2" === t.id ? "备选B" : "快速执行"}</span><i>${a ? "✓" : "○"}</i></div><strong>${s.route}</strong><p>${s.source}</p><div class="material-choice-meta"><span>满足 ${s.qty}</span><span>到货 ${s.eta}</span><span>风险 ${t.risk}</span></div><small>${"继续等待" === s.status ? "需要继续等待外部响应" : "选择后纳入当前组合方案"}</small></button>`;
      }
      function combinationRows() {
        return (
          ensurePlanBuilderState(),
          state.task.materials
            .map((e) => {
              const t = state.customSelections[e.id],
                s = state.task.plans.find((e) => e.id === t),
                a = planMaterialDecision(e, t);
              return `<div class="combo-row" data-edit-combo-material="${e.id}"><div><strong>${e.name}</strong><span>${e.spec}</span></div><div><b>${a.route}</b><small>${a.source}</small></div><span class="combo-plan-tag">${"P1" === s.id ? "A" : "P2" === s.id ? "B" : "C"}</span><button>修改</button></div>`;
            })
            .join("")
        );
      }
      function buildSecondConfirmRecords() {
        const e = new Map(),
          t = state.task.selectedDecisionPlan || "time";
        state.task.materials.forEach((s) =>
          planPickSources(s, t).forEach((t) => {
            if (e.has(t.name)) {
              const a = e.get(t.name);
              a.materials.includes(s.name) || a.materials.push(s.name);
            } else
              e.set(t.name, {
                id: `SC${e.size + 1}`,
                name: t.name,
                channelKey: t.channelKey,
                material: s.name,
                materials: [s.name],
                firstQty: t.qty,
                confirmQty: t.qty,
                eta: t.eta,
                sourceId: t.id,
              });
          }),
        );
        const s = [...e.values()].slice(0, 8),
          a = state.task.finalSolutionGenerated
            ? [
                "confirmed",
                "confirmed",
                "confirmed",
                "confirmed",
                "adjusted",
                "confirmed",
                "confirmed",
                "confirmed",
              ]
            : [
                "confirmed",
                "confirmed",
                "confirmed",
                "confirmed",
                "partial",
                "waiting",
                "confirmed",
                "waiting",
              ];
        return (
          s.forEach((e, t) => {
            ((e.status = a[t] || "confirmed"),
              (e.noticeMethod = ["unit", "transit"].includes(e.channelKey)
                ? "邮件＋工单"
                : "E物资＋短信"),
              (e.sentAt = `08-15 09:${String(10 + 3 * t).padStart(2, "0")}`),
              (e.replyAt =
                "waiting" === e.status
                  ? "—"
                  : `08-15 09:${String(18 + 3 * t).padStart(2, "0")}`),
              "partial" === e.status &&
                (e.confirmQty = `部分确认（${e.firstQty}中的可执行量）`),
              (e.change =
                "partial" === e.status
                  ? "确认数量减少，智能体已启用下一优先级备选来源"
                  : "adjusted" === e.status
                    ? "确认数量发生变化，已由备选来源补足"
                    : "首次反馈与二次确认一致"));
          }),
          s
        );
      }
      function ensureSecondConfirmRecords() {
        return (
          state.task.secondConfirmRecords?.length ||
            (state.task.secondConfirmRecords = buildSecondConfirmRecords()),
          state.task.secondConfirmRecords
        );
      }
      function secondConfirmStatusMeta(e) {
        return "confirmed" === e
          ? { label: "已确认", tone: "done" }
          : "partial" === e
            ? { label: "部分确认", tone: "waiting" }
            : "adjusted" === e
              ? { label: "已调整确认", tone: "done" }
              : "rejected" === e
                ? { label: "已驳回", tone: "attention" }
                : { label: "待回复", tone: "running" };
      }
      function startSecondConfirmation() {
        ((state.task.secondConfirmStarted = !0),
          (state.task.secondConfirmReady = !1),
          (state.task.secondConfirmCompleted = !1),
          (state.task.finalSolutionGenerated = !1),
          (state.task.secondConfirmRecords = buildSecondConfirmRecords()),
          (state.task.stageIndex = 3));
        const e = state.task.secondConfirmRecords;
        (state.assistant.push({
          role: "assistant",
          text: `已向${e.length}个方案涉及对象发起二次确认。系统内单位统一使用邮件与工单，外部供应商统一使用E物资与短信。当前${e.filter((e) => "confirmed" === e.status).length}个已确认，${e.filter((e) => "partial" === e.status).length}个部分确认，${e.filter((e) => "waiting" === e.status).length}个待回复。`,
          action:
            "二次确认由状态变化驱动；部分确认后将自动调用备选来源并重新计算组合。",
        }),
          showToast("已发起二次确认"),
          renderWorkbench());
      }
      function refreshSecondConfirmation() {
        (ensureSecondConfirmRecords().forEach((e) => {
          "waiting" === e.status
            ? ((e.status = "confirmed"),
              (e.replyAt = "08-15 09:46"),
              (e.change = "已完成二次确认"))
            : "partial" === e.status &&
              ((e.status = "adjusted"),
              (e.change = "原确认量减少，已由备选来源补足"));
        }),
          (state.task.secondConfirmReady = !0),
          state.assistant.push({
            role: "assistant",
            text: "二次确认状态已更新：待回复对象已确认；部分确认对象的减少数量已由备选资源补足。当前覆盖率保持100%，来源数量增加1个，最晚到货时间未发生变化。",
            action: "最终方案已具备生成条件。",
          }),
          showToast("已回收最新二次确认结果"),
          renderWorkbench());
      }
      function finalizeSecondConfirmation() {
        if (!state.task.secondConfirmReady)
          return void showToast("仍有二次确认结果待回收");
        ((state.task.secondConfirmCompleted = !0),
          (state.task.finalSolutionGenerated = !0),
          (state.task.decisionConfirmed = !0),
          (state.task.stageIndex = 4),
          (state.task.status = "待执行确认"));
        const e = state.emergencies?.find(
          (e) => e.id === state.selectedEmergency,
        );
        (e &&
          Object.assign(e, {
            stage: "最终方案已生成",
            status: "待执行确认",
            statusClass: "attention",
            progress: 94,
            summary: `${buildPlanDefinitions().find((e) => e.selected)?.metrics.covered || 0}条形成执行来源，${buildPlanDefinitions().find((e) => e.selected)?.metrics.gap || 0}条进入兜底处置`,
            risk: `最终方案已生成，仍有${buildPlanDefinitions().find((e) => e.selected)?.metrics.gap || 0}条缺口`,
            action: "请确认最终方案及缺口处置后回写原系统",
            riskLevel: "green",
            attention: !0,
          }),
          state.assistant.push({
            role: "assistant",
            text: "二次确认已完成，最终方案已生成。所有关键来源均完成确认，部分数量变化已通过备选资源自动补足。现在可以进入执行衔接并回写原业务系统。",
          }),
          showToast("最终方案已生成"),
          renderWorkbench());
      }
      function renderPlanFlowStages() {
        const e = state.task.secondConfirmStarted,
          t = state.task.finalSolutionGenerated;
        return `<div class="plan-flow-stages"><div class="plan-flow-stage ${e || t ? "done" : "current"}"><i>${e || t ? "✓" : "1"}</i><div><strong>候选方案选择</strong><span>${e || t ? "已完成" : "正在调整物资组合"}</span></div></div><div class="plan-flow-stage ${t ? "done" : e ? "current" : ""}"><i>${t ? "✓" : "2"}</i><div><strong>二次确认</strong><span>${t ? "已完成" : e ? "正在回收单位与供应商确认" : "尚未发起"}</span></div></div><div class="plan-flow-stage ${t ? "current" : ""}"><i>${t ? "✓" : "3"}</i><div><strong>最终方案</strong><span>${t ? "已生成，可进入执行" : "等待二次确认收敛"}</span></div></div></div>`;
      }
      function renderSecondConfirmSection() {
        if (!state.task.secondConfirmStarted) return "";
        const e = ensureSecondConfirmRecords(),
          t = e.filter((e) =>
            ["confirmed", "adjusted"].includes(e.status),
          ).length,
          s = e.filter((e) => "partial" === e.status).length,
          a = e.filter((e) => "waiting" === e.status).length,
          n =
            (e.filter((e) => "rejected" === e.status).length,
            e
              .map((e) => {
                const t = secondConfirmStatusMeta(e.status),
                  s = state.expandedSecondConfirm === e.id;
                return `<article class="second-confirm-card"><div class="second-confirm-card-head"><div><strong>${e.name}</strong><small>${RESPONSE_CHANNELS[e.channelKey]?.name || "寻源渠道"} · ${e.materials.slice(0, 2).join("、")}${e.materials.length > 2 ? `等${e.materials.length}条物资` : ""}</small></div><span class="status ${t.tone}">${t.label}</span></div><div class="second-confirm-data"><div><span>首次反馈</span><b>${e.firstQty}</b></div><div><span>二次确认</span><b>${e.confirmQty}</b></div><div><span>预计到货</span><b>${e.eta}</b></div></div><div class="notice-inline"><span class="notice-method">${e.noticeMethod}</span><span>${e.sentAt}发送${"—" !== e.replyAt ? ` · ${e.replyAt}回复` : " · 等待回复"}</span></div><button data-second-confirm-detail="${e.id}">${s ? "收起记录" : "查看记录"}</button>${s ? `<div class="second-confirm-detail">${e.change}<br>通知发送、响应回收、确认数量变化和备选启用均已写入过程留痕。</div>` : ""}</article>`;
              })
              .join(""));
        return `<section class="second-confirm-shell"><div class="second-confirm-head"><div><h3>二次确认进度</h3><p>候选方案选择后，智能体向涉及单位、供应商和项目责任人再次确认数量、到货时间及资源可释放性。</p></div><div class="second-confirm-summary"><span>对象 <b>${e.length}</b></span><span>已确认 <b>${t}</b></span><span>部分确认 <b>${s}</b></span><span>待回复 <b>${a}</b></span></div></div><div class="second-confirm-grid">${n}</div>${s || state.task.secondConfirmReady ? `<div class="plan-change-note"><strong>方案已重新计算</strong><p>${state.task.secondConfirmReady ? "待回复对象已完成确认；部分确认导致的数量变化已由备选来源补足。当前需求仍可完整满足，最终方案可生成。" : "1个对象二次确认数量发生变化，智能体已自动启用备选来源。当前覆盖率保持不变，继续等待剩余对象回复。"}</p>${state.task.secondConfirmReady ? `<div class="plan-final-summary"><div><span>满足物资</span><b>${state.task.materials.length}条</b></div><div><span>涉及来源</span><b>${e.length + 1}个</b></div><div><span>跨单位调拨</span><b>${e.filter((e) => "unit" === e.channelKey).length}个</b></div><div><span>供应商保障</span><b>${e.filter((e) => "rush" === e.channelKey).length}个</b></div><div><span>仍有缺口</span><b>0条</b></div></div>` : ""}</div>` : ""}</section>`;
      }
      function deepClone(e) {
        return JSON.parse(JSON.stringify(e));
      }
      function selectablePlanSources(e) {
        return (e.sources || [])
          .filter(sourceSelectable)
          .sort((t, s) => compareSourcePriority(e, t, s));
      }
      function planPickSources(e, t) {
        const s = selectablePlanSources(e);
        if (!s.length) return [];
        if ("original" === t) {
          const t = selectedSources(e);
          return t.length ? t : [s[0]];
        }
        let a = [...s];
        ("time" === t &&
          a.sort(
            (t, s) =>
              sourceEtaValue(t) - sourceEtaValue(s) ||
              compareSourcePriority(e, t, s),
          ),
          "local" === t &&
            a.sort(
              (t, s) =>
                (["unit", "transit"].includes(t.channelKey) ? 0 : 1) -
                  (["unit", "transit"].includes(s.channelKey) ? 0 : 1) ||
                compareSourcePriority(e, t, s),
            ),
          "minimal" === t &&
            a.sort(
              (t, s) =>
                ownerCoverageCount(s.name, s.channelKey) -
                  ownerCoverageCount(t.name, t.channelKey) ||
                (s.qtyValue || 0) - (t.qtyValue || 0) ||
                compareSourcePriority(e, t, s),
            ));
        const n = a.find((t) => (t.qtyValue || 0) >= e.need);
        if (n) return [n];
        const i = [];
        let r = 0;
        for (const t of a)
          if (
            !((t.qtyValue || 0) <= 0) &&
            (i.push(t), (r += t.qtyValue || 0), r >= e.need)
          )
            break;
        return i;
      }
      function calculatePlanMetrics(e) {
        const t = state.task.materials.map((t) => ({
          material: t,
          sources: planPickSources(t, e),
        }));
        let s = 0;
        const a = new Set(),
          n = { unit: 0, rush: 0, transit: 0, purchase: 0 };
        let i = 0;
        t.forEach((e) => {
          (e.sources.reduce((e, t) => e + (t.qtyValue || 0), 0) >=
            e.material.need && s++,
            e.sources.forEach((e) => {
              (a.add(`${e.channelKey}|${e.name}`),
                (n[e.channelKey] = (n[e.channelKey] || 0) + 1),
                (i = Math.max(
                  i,
                  sourceEtaValue(e) < Number.MAX_SAFE_INTEGER
                    ? sourceEtaValue(e)
                    : 0,
                )));
            }));
        });
        const r = state.task.materials.length,
          l = r - s;
        let d = "待确认";
        return (
          i > 1e12
            ? (d = new Date(i).toISOString().slice(0, 10))
            : i > 0 &&
              i < 1440 &&
              (d = `${String(Math.floor(i / 60)).padStart(2, "0")}:${String(i % 60).padStart(2, "0")}`),
          {
            assignments: t,
            covered: s,
            gap: l,
            coverage: `${Math.round((s / Math.max(1, r)) * 100)}%`,
            sources: a.size,
            channelCounts: n,
            eta: d,
            cost: "待核价",
          }
        );
      }
      function buildPlanDefinitions() {
        const e = [
            {
              id: "original",
              type: "原业务系统基线",
              name: "原系统固定逻辑编排方案",
              desc: "按原业务系统既定规则形成的资源组合，作为AI方案比对基线。",
              metrics: calculatePlanMetrics("original"),
              recommended: !1,
            },
            {
              id: "time",
              type: "AI多维方案",
              name: "AI时效优先方案",
              desc: "优先采用能够最早到货的可执行资源，必要时跨渠道组合补足。",
              metrics: calculatePlanMetrics("time"),
              recommended: !0,
            },
            {
              id: "local",
              type: "AI多维方案",
              name: "AI省内资源优先方案",
              desc: "优先使用重庆公司内部实物库存及可释放在建资源，降低外部依赖。",
              metrics: calculatePlanMetrics("local"),
              recommended: !1,
            },
            {
              id: "minimal",
              type: "AI多维方案",
              name: "AI协调对象最少方案",
              desc: "优先选择覆盖物料种类更多的单位或供应商，减少协调对象和确认链路。",
              metrics: calculatePlanMetrics("minimal"),
              recommended: !1,
            },
          ],
          t = state.task.selectedDecisionPlan || "time";
        return (e.forEach((e) => (e.selected = e.id === t)), e);
      }
      function buildPlanAdvice() {
        const e = buildPlanDefinitions(),
          t = e.find((e) => "time" === e.id),
          s = e[0],
          a = Math.max(0, s.metrics.sources - t.metrics.sources),
          n = state.task.finalSolutionGenerated
            ? "已完成二次确认，可直接进入执行衔接"
            : "建议先采用AI推荐方案并完成二次确认";
        return {
          title: "AI综合建议",
          text: `建议采用“${t.name}”。当前可覆盖${t.metrics.covered}/${state.task.materials.length}条物资，仍有${t.metrics.gap}条需继续寻源或确认。相比原系统方案，协调对象${a ? `预计减少${a}个` : "基本持平"}，同时保留省内资源和协议库存作为备选。${n}。`,
          tags: [
            `覆盖率 ${t.metrics.coverage}`,
            `来源 ${t.metrics.sources}个`,
            `最晚到货 ${t.metrics.eta}`,
            state.task.finalSolutionGenerated
              ? "二次确认已完成"
              : state.task.secondConfirmStarted
                ? "二次确认进行中"
                : "待发起二次确认",
          ],
        };
      }
      function getPlanStatusLabel(e) {
        return state.task.finalSolutionGenerated && e.selected
          ? "最终方案"
          : e.recommended
            ? "AI推荐"
            : "original" === e.id
              ? "对比基线"
              : "备选方案";
      }
      function describePlanDelta(e, t) {
        if ("original" === e.id) return "原系统固定逻辑";
        const s = e.metrics.sources - t.metrics.sources,
          a = e.metrics.covered - t.metrics.covered,
          n = [];
        return (
          a && n.push(`覆盖${a > 0 ? "+" : ""}${a}条`),
          s && n.push(`来源${s > 0 ? "+" : ""}${s}个`),
          n.join(" · ") || "整体指标与基线接近"
        );
      }
      function describePlanChannels(e) {
        const t = e.channelCounts;
        return [
          `跨单位 ${t.unit || 0}`,
          `协议库存 ${t.rush || 0}`,
          `在途/在建 ${t.transit || 0}`,
          `应急采购 ${t.purchase || 0}`,
        ];
      }
      function renderPlanDetailDrawer(e) {
        const t = buildPlanDefinitions(),
          s = t.find((t) => t.id === e) || t[1],
          a = t[0],
          n = state.task.finalSolutionGenerated && s.selected;
        ((state.openPlanId = s.id),
          ($("#planDetailTitle").textContent = n
            ? `最终方案报告｜${s.name}`
            : s.name),
          ($("#planDetailMeta").textContent =
            `${s.type} · ${n ? "最终方案" : getPlanStatusLabel(s)} · ${state.task.code}`));
        const i = s.metrics.assignments
            .map((e) => {
              const t = e.sources.reduce((e, t) => e + (t.qtyValue || 0), 0),
                s = e.sources.length
                  ? e.sources
                      .map((e) => e.name)
                      .filter((e, t, s) => s.indexOf(e) === t)
                      .join(" ＋ ")
                  : "尚未匹配可执行来源",
                a = e.sources.length
                  ? [
                      ...new Set(
                        e.sources.map(
                          (e) =>
                            RESPONSE_CHANNELS[e.channelKey]?.name || e.type,
                        ),
                      ),
                    ].join("＋")
                  : "待寻源",
                n = selectedLatestEta(e.sources);
              return `<div class="plan-detail-material-row-taskworkspace"><div><strong>${e.material.name}</strong><small>${e.material.spec} · 需求${e.material.need}${e.material.unit}</small></div><div class="source-name"><strong>${s}</strong><small>${a}</small></div><div class="qty">${roundQty(t)}${e.material.unit}</div><div class="eta">${n}</div></div>`;
            })
            .join(""),
          r = [
            [
              "物资覆盖",
              `${a.metrics.covered}/${state.task.materials.length}`,
              `${s.metrics.covered}/${state.task.materials.length}`,
              s.metrics.covered - a.metrics.covered,
            ],
            [
              "来源数量",
              `${a.metrics.sources}个`,
              `${s.metrics.sources}个`,
              a.metrics.sources - s.metrics.sources,
            ],
            ["最晚到货", a.metrics.eta, s.metrics.eta, "—"],
            [
              "应急采购",
              `${a.metrics.channelCounts.purchase || 0}项`,
              `${s.metrics.channelCounts.purchase || 0}项`,
              (a.metrics.channelCounts.purchase || 0) -
                (s.metrics.channelCounts.purchase || 0),
            ],
            ["成本状态", "待核价", "待核价", "—"],
          ]
            .map(
              (e) =>
                `<tr><td>${e[0]}</td><td>${e[1]}</td><td>${e[2]}</td><td class="${"number" == typeof e[3] && e[3] > 0 ? "plan-positive-taskworkspace" : "plan-neutral-taskworkspace"}">${"number" == typeof e[3] ? (e[3] > 0 ? `优化 ${e[3]}` : e[3] < 0 ? `增加 ${Math.abs(e[3])}` : "持平") : e[3]}</td></tr>`,
            )
            .join(""),
          l = n
            ? ensureSecondConfirmRecords()
                .map(
                  (e) =>
                    `<div class="final-confirm-item-execution"><strong>${e.name}</strong><span>${e.noticeMethod} · ${secondConfirmStatusMeta(e.status).label} · ${e.confirmQty}</span></div>`,
                )
                .join("")
            : "";
        (($("#planDetailBody").innerHTML =
          `${n ? `<div class="final-report-note-execution"><strong>最终执行结论</strong>该方案已经完成二次确认并形成当前最终资源组合。${s.metrics.covered}条物资可进入执行，${s.metrics.gap ? `${s.metrics.gap}条缺口按兜底建议继续寻源或启动应急采购` : "当前无物资缺口"}；业务人员确认后同步进入执行衔接并回写原系统。</div>` : ""}<div class="plan-detail-summary-taskworkspace"><div><span>覆盖物资</span><b>${s.metrics.covered}/${state.task.materials.length}</b></div><div><span>仍有缺口</span><b>${s.metrics.gap}条</b></div><div><span>涉及来源</span><b>${s.metrics.sources}个</b></div><div><span>二次确认</span><b>${state.task.finalSolutionGenerated ? "已完成" : state.task.secondConfirmStarted ? "进行中" : "未发起"}</b></div></div><section class="plan-detail-section-taskworkspace"><h4>方案总体结论</h4><div class="plan-detail-copy-taskworkspace">${s.desc}<br>${"original" === s.id ? "该方案仅作为原业务系统固定逻辑的对照基线。" : n ? "AI已根据二次确认结果收敛最终来源组合；未被最终采用的响应仍保留在过程留痕中。" : "AI已按物资逐条完成来源匹配，并按照业务推荐优先级排列候选资源；缺失的报价、到货承诺和业务字段继续显示待确认。"}</div></section><section class="plan-detail-section-taskworkspace"><h4>与原系统方案对比</h4><table class="plan-detail-diff-taskworkspace"><thead><tr><th>维度</th><th>原系统</th><th>当前方案</th><th>变化</th></tr></thead><tbody>${r}</tbody></table></section>${n ? `<section class="plan-detail-section-taskworkspace"><h4>二次确认结果</h4><div class="final-confirm-list-execution">${l}</div></section>` : ""}<section class="plan-detail-section-taskworkspace"><h4>完整物资来源方案</h4><div class="plan-detail-materials-taskworkspace">${i}</div></section><section class="plan-detail-section-taskworkspace"><h4>风险与执行要求</h4><div class="plan-detail-copy-taskworkspace">${n ? "关键来源均已完成二次确认。进入执行后仍需跟踪调拨出库、供应商发运、在途节点和实际到货；异常变化将重新触发风险提示。" : "未响应对象不视为可执行来源；二次确认需再次核实确认数量、预计到货时间和资源可释放性。若关键来源驳回或减少数量，智能体将自动启用下一优先级候选并重新生成方案。"}</div></section>`),
          ($("#planDetailAdopt").textContent = n
            ? "确认并进入执行衔接"
            : "original" === s.id
              ? "采用原系统方案"
              : "采用此AI方案"),
          openOverlay("planDetailDrawer"));
      }
      function renderFinalSolutionCard(e) {
        if (!state.task.finalSolutionGenerated) return "";
        const t = ensureSecondConfirmRecords(),
          s = t.filter((e) =>
            ["confirmed", "adjusted"].includes(e.status),
          ).length;
        return `<section class="final-solution-card-execution"><div class="final-solution-head-execution"><div class="final-solution-title-execution"><div class="final-solution-icon-execution">✓</div><div class="final-solution-copy-execution"><h3>最终方案已生成</h3><p>采用“${e.name}”。二次确认已完成，关键来源数量与到货承诺已收敛；${e.metrics.gap ? `${e.metrics.gap}条缺口已纳入继续寻源或应急采购兜底建议。` : "当前无物资缺口。"}请业务人员确认后进入执行衔接并回写原系统。</p></div></div><span class="final-solution-badge-execution">待执行确认</span></div><div class="final-solution-metrics-execution"><div><span>覆盖物资</span><b>${e.metrics.covered}/${state.task.materials.length}</b></div><div><span>仍有缺口</span><b>${e.metrics.gap}条</b></div><div><span>涉及来源</span><b>${e.metrics.sources}个</b></div><div><span>二次确认</span><b>${s}/${t.length}完成</b></div><div><span>最晚到货</span><b>${e.metrics.eta}</b></div></div><div class="final-solution-actions-execution"><button class="btn" data-final-report-id="${e.id}">查看完整最终方案</button><button class="btn primary" data-enter-execution>确认并进入执行衔接</button></div></section>`;
      }
      function renderPlans() {
        const e = buildPlanDefinitions(),
          t = buildPlanAdvice(),
          s = e[0],
          a = e.find((e) => e.selected) || e[1],
          n = renderFinalSolutionCard(a),
          i = e
            .map(
              (e) =>
                `<button class="plan-card-taskworkspace ${e.recommended ? "recommended" : ""} ${e.selected ? "selected" : ""}" data-plan-card-id="${e.id}"><span class="plan-card-badge-taskworkspace">${getPlanStatusLabel(e)}</span><span class="plan-card-type-taskworkspace">${e.type}</span><h4>${e.name}</h4><p>${e.desc}</p><div class="plan-card-metrics-taskworkspace"><div><span>覆盖物资</span><b>${e.metrics.covered}/${state.task.materials.length}</b></div><div><span>仍有缺口</span><b>${e.metrics.gap}条</b></div><div><span>涉及来源</span><b>${e.metrics.sources}个</b></div><div><span>最晚到货</span><b>${e.metrics.eta}</b></div></div><div class="plan-card-channel-taskworkspace">${describePlanChannels(
                  e.metrics,
                )
                  .map((e) => `<span>${e}</span>`)
                  .join(
                    "",
                  )}</div><div class="plan-card-foot-taskworkspace"><strong>查看完整方案</strong><em>${describePlanDelta(e, s)}</em></div></button>`,
            )
            .join(""),
          r = state.task.finalSolutionGenerated
            ? ""
            : state.task.secondConfirmStarted
              ? state.task.secondConfirmReady
                ? '<button class="btn" id="viewPlanChange">查看方案变化</button><button class="btn primary" id="finalizeSecondConfirm">生成最终方案</button>'
                : '<button class="btn" id="continueWaiting">继续等待响应</button><button class="btn primary" id="refreshSecondConfirm">回收最新确认</button>'
              : `<button class="btn" id="continueWaiting">继续等待响应</button><button class="btn primary" id="startSecondConfirm">对“${a.name}”发起二次确认</button>`;
        return `<div class="plan-taskworkspace-shell"><section class="plan-ai-advice-taskworkspace"><div class="plan-ai-icon-taskworkspace">AI</div><div class="plan-ai-copy-taskworkspace"><h3>${t.title}</h3><p>${t.text}</p><div class="plan-ai-tags-taskworkspace">${t.tags.map((e) => `<span>${e}</span>`).join("")}</div></div><div class="plan-ai-action-taskworkspace"><button class="btn sm" data-plan-card-id="${a.id}">查看推荐方案</button></div></section>${n}${renderPlanFlowStages()}<div class="plan-section-head-taskworkspace"><h3>完整方案总览</h3><span>原系统方案作为固定逻辑基线，AI从时效、省内资源和协调对象等维度生成备选方案</span></div><section class="plan-option-grid-taskworkspace">${i}</section><section class="plan-baseline-taskworkspace"><div class="plan-baseline-head-taskworkspace"><h3>当前选中方案与原系统基线</h3><span>点击任一方案可在侧栏查看${state.task.materials.length}条物资的完整来源明细</span></div><table class="plan-baseline-table-taskworkspace"><thead><tr><th>对比维度</th><th>原系统方案</th><th>${a.name}</th><th>AI判断</th></tr></thead><tbody><tr><td>物资覆盖</td><td>${s.metrics.covered}/${state.task.materials.length}</td><td>${a.metrics.covered}/${state.task.materials.length}</td><td class="plan-positive-taskworkspace">${a.metrics.covered >= s.metrics.covered ? "不低于原方案" : "仍需补足"}</td></tr><tr><td>来源数量</td><td>${s.metrics.sources}个</td><td>${a.metrics.sources}个</td><td class="plan-positive-taskworkspace">${a.metrics.sources <= s.metrics.sources ? "协调对象减少或持平" : "协调对象增加"}</td></tr><tr><td>最晚到货</td><td>${s.metrics.eta}</td><td>${a.metrics.eta}</td><td class="plan-neutral-taskworkspace">以二次确认结果为准</td></tr><tr><td>应急采购</td><td>${s.metrics.channelCounts.purchase || 0}项</td><td>${a.metrics.channelCounts.purchase || 0}项</td><td class="plan-positive-taskworkspace">优先利用现有资源</td></tr></tbody></table></section>${renderSecondConfirmSection()}<div class="plan-actions-taskworkspace"><button class="btn" data-plan-card-id="original">查看原系统完整方案</button>${r}</div></div>`;
      }
      function renderExecution() {
        const e =
            state.task.finalSolutionGenerated || state.task.decisionConfirmed,
          t = state.task.writeback;
        return `<div class="execution-grid single"><div class="card execution-card"><div class="card-title">业务闭环进度</div><div class="card-sub">智能体持续衔接原业务系统，只有完成二次确认并生成最终方案后，才能进入正式回写与执行。</div><div style="margin-top:10px"><div class="execution-step done"><div class="exec-index">1</div><div class="exec-copy"><strong>自动接收并解析应急任务</strong><span>已读取任务编号、事件信息和${state.task.materials.length}条有效物资需求。</span></div></div><div class="execution-step done"><div class="exec-index">2</div><div class="exec-copy"><strong>第一轮征询与响应回收</strong><span>已通过邮件、工单、E物资和短信完成多渠道征询，并持续读取响应状态。</span></div></div><div class="execution-step ${state.task.secondConfirmStarted ? "done" : "current"}"><div class="exec-index">3</div><div class="exec-copy"><strong>候选方案选择</strong><span>${state.task.secondConfirmStarted ? "已记录用户逐物资选择和组合方案。" : "等待用户确认候选组合并发起二次确认。"}</span></div></div><div class="execution-step ${e ? "done" : state.task.secondConfirmStarted ? "current" : ""}"><div class="exec-index">4</div><div class="exec-copy"><strong>二次确认与方案收敛</strong><span>${e ? "关键来源已完成二次确认，最终方案已生成。" : state.task.secondConfirmStarted ? "正在回收确认数量、到货时间和资源可释放性。" : "尚未发起二次确认。"}</span></div></div><div class="execution-step ${t ? "done" : e ? "current" : ""}"><div class="exec-index">5</div><div class="exec-copy"><strong>回写原系统并启动执行</strong><span>${t ? "回写成功，当前正在跟踪调拨、采购和运输状态。" : "最终方案生成后可校验字段并回写智慧供应链平台。"}</span></div></div><div class="execution-step ${t ? "current" : ""}"><div class="exec-index">6</div><div class="exec-copy"><strong>到货跟踪、停止寻源与复盘</strong><span>最终方案执行完成后，自动关闭未采用的寻源请求并生成复盘与候选知识。</span></div></div></div><button class="btn primary" id="writebackBtn" style="margin-top:12px;width:100%" ${e ? "" : "disabled"}>${icons("i-upload")}${t ? "查看执行与回写结果" : "回写原业务系统"}</button></div></div>`;
      }
      function renderReview() {
        return `<div class="review-grid"><div class="card review-card"><strong>100%</strong><span>通知发送成功率</span></div><div class="card review-card"><strong>12分钟</strong><span>平均首次响应</span></div><div class="card review-card"><strong>4次</strong><span>自动催办次数</span></div><div class="card review-card"><strong>${state.task.secondConfirmCompleted ? "100%" : "进行中"}</strong><span>二次确认完成率</span></div><div class="card review-card"><strong>${state.task.secondConfirmReady ? "1次" : "0次"}</strong><span>方案自动重算</span></div><div class="card review-card"><strong>全程</strong><span>Run与Tool留痕</span></div></div><div class="card section-card"><div class="section-head"><div><h3>事件复盘与优化建议</h3><p>任务完成后自动汇总通知发送、响应回收、催办、二次确认、方案变化和执行结果。</p></div><button class="btn sm" id="openEvidence">查看全过程证据</button></div><div class="section-body"><div class="insight-list"><div class="insight"><strong>通知通道效果</strong><p>基层单位通过平台工单与短信响应较快；供应商邮件与确认链接可完整留存回复内容，建议继续保留双通道触达。</p></div><div class="insight"><strong>二次确认必要性</strong><p>首次反馈只能用于形成候选方案，二次确认阶段需要再次核实数量、到货时间和资源可释放性，避免直接回写不可执行资源。</p></div><div class="insight"><strong>来源归并与可追溯</strong><p>同一单位的多条库存、订单或在建记录在主列表中归并展示，详情中保留记录编号、数量、项目和到货信息，兼顾简洁与追溯。</p></div></div></div></div>`;
      }
      function renderWorkbench() {
        ($("#workbenchBody")?.classList.remove("panel-collapsed"),
          ($("#summaryStrip").innerHTML = ""),
          ($("#wbTitle").textContent = state.task.title));
        const e = (state.task.unit || "")
          .replace("国网重庆市电力公司", "")
          .replace("供电分公司", "公司");
        $("#wbMeta").innerHTML =
          `<span>${state.task.code}</span><i>·</i><span>${e}</span><i>·</i><span>${state.task.source}</span><i>·</i><span>${state.task.received}</span>`;
        const t = !!state.overviewDecisionConfirmed,
          s = $("#incidentcockpitHeadStatus");
        (s &&
          ((s.textContent = t
            ? "执行跟踪中"
            : "E001" === state.selectedEmergency
              ? "待确认最终方案"
              : state.task.status),
          s.classList.toggle("done", t)),
          $$(".wb-tab").forEach((e) =>
            e.classList.toggle("active", e.dataset.tab === state.wbTab),
          ));
        let a = "";
        ("overview" === state.wbTab && (a = renderTaskOverview()),
          "materials" === state.wbTab && (a = renderMaterials()),
          "responses" === state.wbTab && (a = renderResponses()),
          "plans" === state.wbTab && (a = renderPlans()),
          "execution" === state.wbTab && (a = renderExecution()),
          "review" === state.wbTab && (a = renderReview()),
          ($("#wbMain").innerHTML =
            `<div class="wb-tab-stage wb-tab-stage-${state.wbTab}">${a}</div>`),
          $("#workbenchBody")?.classList.toggle(
            "incidentcockpit-overview-mode",
            "overview" === state.wbTab,
          ),
          updateAssistantContext(),
          renderAssistant(),
          bindWorkbenchActions());
      }
      function renderAssistant() {
        const e = $("#assistantBody");
        ((e.innerHTML = state.assistant
          .map(
            (e) =>
              `<div class="assistant-message ${e.role}"><div class="assistant-avatar">${"user" === e.role ? "我" : "智"}</div><div class="assistant-bubble">${e.text}${e.action ? `<div class="action-card">${e.action}</div>` : ""}</div></div>`,
          )
          .join("")),
          (e.scrollTop = e.scrollHeight));
      }
      function bindWorkbenchActions() {
        ($$("[data-material]").forEach((e) => {
          (e.classList.toggle(
            "selected",
            e.dataset.material === state.selectedMaterial,
          ),
            (e.onclick = (t) => {
              t.target.closest("button") || openMaterial(e.dataset.material);
            }));
        }),
          $$("[data-open-material]").forEach(
            (e) =>
              (e.onclick = (t) => {
                (t.stopPropagation(), openMaterial(e.dataset.openMaterial));
              }),
          ),
          $$("[data-confirm-material]").forEach(
            (e) =>
              (e.onclick = (t) => {
                (t.stopPropagation(),
                  confirmMaterial(e.dataset.confirmMaterial));
              }),
          ),
          $$("[data-material-chat]").forEach(
            (e) => (e.onclick = () => assistantAction(e.dataset.materialChat)),
          ),
          $$("[data-response-chat]").forEach(
            (e) =>
              (e.onclick = () =>
                assistantAction(
                  `请处理${e.dataset.responseChat}的响应，并说明建议动作`,
                )),
          ),
          $$("[data-material-filter]").forEach(
            (e) =>
              (e.onclick = () => {
                ((state.materialFilter = e.dataset.materialFilter),
                  (state.wbTab = "materials"),
                  renderWorkbench());
              }),
          ),
          $("#clearMaterialFilter")?.addEventListener("click", () => {
            ((state.materialFilter = "all"), renderWorkbench());
          }),
          $("#continueWaiting")?.addEventListener("click", () =>
            assistantAction("继续等待20分钟后重新分析"),
          ),
          $("#remindAll")?.addEventListener("click", remindAll),
          $("#generatePlan2")?.addEventListener("click", () =>
            switchTab("plans"),
          ),
          $("#openEvidence")?.addEventListener("click", openEvidence),
          $$("[data-evidence]").forEach((e) => (e.onclick = openEvidence)),
          $$("[data-response-channel]").forEach(
            (e) =>
              (e.onclick = () => {
                ((state.responseChannel = e.dataset.responseChannel),
                  (state.responsePage = 1),
                  renderWorkbench());
              }),
          ),
          $("#showAllResponseChannels")?.addEventListener("click", () => {
            ((state.responseChannel = "all"),
              (state.responsePage = 1),
              renderWorkbench());
          }),
          $("#responseSearch")?.addEventListener("input", (e) => {
            ((state.responseSearch = e.target.value),
              (state.responsePage = 1),
              renderWorkbench());
          }),
          $("#responseStatus")?.addEventListener("change", (e) => {
            ((state.responseStatus = e.target.value),
              (state.responsePage = 1),
              renderWorkbench());
          }),
          $("#responseSort")?.addEventListener("change", (e) => {
            ((state.responseSort = e.target.value),
              (state.responsePage = 1),
              renderWorkbench());
          }),
          $("#responsePageSize")?.addEventListener("change", (e) => {
            ((state.responsePageSize = +e.target.value),
              (state.responsePage = 1),
              renderWorkbench());
          }),
          $$("[data-response-page]").forEach(
            (e) =>
              (e.onclick = () => {
                const t = +e.dataset.responsePage;
                t >= 1 && ((state.responsePage = t), renderWorkbench());
              }),
          ),
          $$("[data-manual-remind]").forEach(
            (e) =>
              (e.onclick = () => {
                const [t, s] = e.dataset.manualRemind.split("|");
                manuallyRemindSource(t, s);
              }),
          ),
          $$("[data-plan-card-id]").forEach(
            (e) =>
              (e.onclick = (t) => {
                (t.stopPropagation(),
                  renderPlanDetailDrawer(e.dataset.planCardId));
              }),
          ),
          $("#planDetailAdopt")?.addEventListener("click", () => {
            if (state.task.finalSolutionGenerated)
              return (
                closeOverlay("planDetailDrawer"),
                switchTab("execution"),
                void showToast("已进入执行衔接")
              );
            const e = state.openPlanId || "time";
            ((state.task.selectedDecisionPlan = e),
              state.task.materials.forEach((t) => {
                const s = planPickSources(t, e);
                ((t.selectedSourceIds = s.map((e) => e.id)),
                  (t.filled = roundQty(
                    s.reduce((e, t) => e + (t.qtyValue || 0), 0),
                  )),
                  (t.method = materialMethodLabel(s)),
                  (t.activeChannel = s[0]?.channelKey || t.activeChannel),
                  (t.confirmed = !1),
                  t.filled >= t.need
                    ? ((t.status = "方案待二次确认"),
                      (t.statusClass = "waiting"))
                    : ((t.status = "仍有缺口"), (t.statusClass = "attention")));
              }),
              state.assistant.push({
                role: "assistant",
                text: `已将“${buildPlanDefinitions().find((t) => t.id === e)?.name || "当前方案"}”设为当前决策方案，并同步更新逐物资来源组合。下一步建议发起二次确认，核实数量、到货时间和资源可释放性。`,
              }),
              closeOverlay("planDetailDrawer"),
              showToast("已采用该方案"),
              renderWorkbench());
          }),
          $("#planDetailCompare")?.addEventListener("click", () => {
            showToast("当前侧栏已展示与原系统方案的逐维度对比");
          }),
          $$("[data-plan-material]").forEach(
            (e) =>
              (e.onclick = () => {
                ((state.planMaterial = e.dataset.planMaterial),
                  renderWorkbench());
              }),
          ),
          $$("[data-plan-choice]").forEach(
            (e) =>
              (e.onclick = () => {
                (ensurePlanBuilderState(),
                  (state.customSelections[e.dataset.planMaterialId] =
                    e.dataset.planChoice),
                  (state.planMaterial = e.dataset.planMaterialId),
                  showToast("已更新该物资的满足方式"),
                  renderWorkbench());
              }),
          ),
          $$("[data-edit-combo-material]").forEach(
            (e) =>
              (e.onclick = () => {
                ((state.planMaterial = e.dataset.editComboMaterial),
                  renderWorkbench());
              }),
          ),
          $$("[data-apply-full-plan]").forEach(
            (e) =>
              (e.onclick = () => {
                (ensurePlanBuilderState(),
                  state.task.materials.forEach(
                    (t) =>
                      (state.customSelections[t.id] = e.dataset.applyFullPlan),
                  ),
                  showToast("已应用整套方案，可继续逐条物资调整"),
                  renderWorkbench());
              }),
          ),
          $("#compareCustomPlan")?.addEventListener("click", () =>
            assistantAction(
              "请评估当前自定义组合方案，并说明相对推荐方案A的收益、代价和风险",
            ),
          ),
          $("#resetCustomPlan")?.addEventListener("click", () => {
            ((state.customSelections = Object.fromEntries(
              state.task.materials.map((e) => [e.id, "P1"]),
            )),
              showToast("已恢复推荐方案A"),
              renderWorkbench());
          }),
          $("#startSecondConfirm")?.addEventListener(
            "click",
            startSecondConfirmation,
          ),
          $("#refreshSecondConfirm")?.addEventListener(
            "click",
            refreshSecondConfirmation,
          ),
          $("#finalizeSecondConfirm")?.addEventListener(
            "click",
            finalizeSecondConfirmation,
          ),
          $("#saveCurrentSelection")?.addEventListener("click", () =>
            showToast("当前逐物资选择已保存"),
          ),
          $("#viewPlanChange")?.addEventListener("click", () =>
            assistantAction("请说明二次确认后方案发生了哪些变化"),
          ),
          $("#viewFinalReport")?.addEventListener("click", () =>
            renderPlanDetailDrawer(
              state.task.selectedDecisionPlan || "time",
            ),
          ),
          $("#enterExecution")?.addEventListener("click", () =>
            switchTab("execution"),
          ),
          $$("[data-final-report-id]").forEach(
            (e) =>
              (e.onclick = () =>
                renderPlanDetailDrawer(e.dataset.finalReportId)),
          ),
          $$("[data-enter-execution]").forEach(
            (e) => (e.onclick = () => switchTab("execution")),
          ),
          $("#viewFinalFromSummary")?.addEventListener("click", () => {
            ((state.wbTab = "plans"), renderWorkbench());
          }),
          $("#enterExecutionFromSummary")?.addEventListener("click", () =>
            switchTab("execution"),
          ),
          $$("[data-second-confirm-detail]").forEach(
            (e) =>
              (e.onclick = () => {
                ((state.expandedSecondConfirm =
                  state.expandedSecondConfirm === e.dataset.secondConfirmDetail
                    ? null
                    : e.dataset.secondConfirmDetail),
                  renderWorkbench());
              }),
          ),
          $("#incidentcockpitConfirmDecision")?.addEventListener("click", () => {
            ((state.overviewDecisionConfirmed = !0),
              (state.task.decisionConfirmed = !0),
              (state.task.stageIndex = 4),
              (state.task.status = "执行与到货跟踪"),
              state.assistant.push({
                role: "assistant",
                text: "已记录您的确认。智能体正在回写最终方案、生成调拨与应急采购指令，并启动执行与到货跟踪。",
              }),
              showToast("已确认，智能体开始执行下一步"),
              renderWorkbench());
          }),
          $("#incidentcockpitAdjustPlan")?.addEventListener("click", () =>
            switchTab("plans"),
          ),
          $("#incidentcockpitViewEvidence")?.addEventListener("click", () => {
            ((state.overviewEvidence = !state.overviewEvidence),
              renderWorkbench());
          }),
          $("#incidentcockpitOpenPlan")?.addEventListener("click", () =>
            switchTab("plans"),
          ),
          $("#incidentcockpitOpenExecution")?.addEventListener("click", () =>
            switchTab("execution"),
          ),
          $("#incidentcockpitRefreshOverview")?.addEventListener("click", () => {
            (showToast("已刷新任务状态"), renderWorkbench());
          }),
          $("#writebackBtn")?.addEventListener("click", () => {
            state.task.writeback
              ? showToast("已回写，正在打开执行结果")
              : (renderMapping(), openOverlay("writebackModal"));
          }));
      }
      function switchTab(e) {
        state.wbTab = e;
        const t = $("#wbMain");
        (t && (t.scrollTop = 0),
          renderWorkbench(),
          requestAnimationFrame(() => {
            const e = $("#wbMain");
            e && (e.scrollTop = 0);
          }));
      }
      function openMaterial(e) {
        ((state.selectedMaterial = e),
          (state.drawerTab = "sources"),
          (state.drawerChannel = "all"),
          (state.drawerSearch = ""),
          (state.drawerStatus = "all"),
          (state.drawerSort = "priority"),
          (state.drawerPage = 1),
          (state.drawerPageSize = 20),
          (state.expandedSourceId = null),
          renderMaterialDrawer(),
          openOverlay("materialDrawer"));
      }
      function sourceReminderTimeline(e) {
        if (e.reminders?.length) return [...e.reminders];
        const t = [],
          s = e.reply && /^\d{2}:\d{2}$/.test(e.reply) ? e.reply : "09:20";
        if ((t.push(`${s} 请求发送`), (e.reminderCount || 0) > 0))
          for (let s = 0; s < (e.reminderCount || 0); s++)
            t.push(
              `09:${String(35 + 15 * s).padStart(2, "0")} 智能体自动催办 +1`,
            );
        return (
          /已回复|有货|可调拨|可供|可用|部分|确认/.test(e.status) &&
            t.push(`${e.reply || "10:03"} 对方完成回复`),
          t
        );
      }
      function selectedLatestEta(e) {
        return (
          e
            .map((e) => e.eta)
            .filter((e) => e && "—" !== e && !e.includes("待确认"))
            .sort()
            .slice(-1)[0] || "待确认"
        );
      }
      function renderMaterialDrawer() {
        const e = state.task.materials.find(
          (e) => e.id === state.selectedMaterial,
        );
        if (!e) return;
        ((state.drawerChannel = state.drawerChannel || "all"),
          (state.drawerSearch = state.drawerSearch || ""),
          (state.drawerStatus = state.drawerStatus || "all"),
          (state.drawerSort = state.drawerSort || "priority"),
          (state.expandedSourceId = state.expandedSourceId || null));
        const t = new Set(e.selectedSourceIds || []),
          s = Math.max(0, roundQty(e.need - e.filled)),
          a = e.sources.filter((e) => !1 !== e.requested),
          n = Object.fromEntries(
            Object.keys(RESPONSE_CHANNELS).map((e) => [
              e,
              groupSourcesByOwner(a.filter((t) => t.channelKey === e)).length,
            ]),
          ),
          i = selectedSources(e),
          r = i.reduce((e, t) => e + (t.qtyValue || 0), 0),
          l = selectedLatestEta(i),
          d = groupSourcesByOwner(i);
        (($("#drawerMaterialTitle").textContent = e.name),
          ($("#drawerMaterialMeta").textContent = `${e.spec} · ${e.status}`),
          ($("#drawerMaterialSummary").innerHTML =
            `<div><span>需求量</span><b>${e.need}${e.unit}</b></div><div><span>已选量</span><b>${e.filled}${e.unit}</b></div><div><span>当前缺口</span><b>${s}${e.unit}</b></div><div><span>已选来源数</span><b>${d.length}</b></div>`),
          ($("#drawerFooterSummary").innerHTML =
            `<span>已选 ${d.length} 个响应对象 · ${roundQty(r)}${e.unit}</span><b>预计最晚到货：${l}</b>`));
        const c = d.length
            ? d
                .map(
                  (t) =>
                    `<div class="selected-combo-row"><div><strong>${t.name}</strong><span>${RESPONSE_CHANNELS[t.channelKey]?.name || t.sources[0].type}${t.sources.length > 1 ? ` · ${t.sources.length}条资源记录` : ""}</span></div><b>${t.qtyValue}${e.unit}</b><button data-source-group="${t.ids.join("|")}" data-group-action="cancel">取消</button></div>`,
                )
                .join("")
            : '<div class="selected-combo-empty">尚未选择来源</div>',
          o =
            groupSourcesByOwner(
              a.filter((e) => sourceSelectable(e) && !t.has(e.id)),
            )
              .sort((t, s) => compareSourceGroups(e, t, s))
              .slice(0, 3)
              .map(
                (t, s) =>
                  `<div class="recommendation-row"><div><span class="recommendation-rank">推荐 ${s + 1}</span><strong>${t.name}</strong><small>${RESPONSE_CHANNELS[t.channelKey]?.name || t.sources[0].type} · ${t.sources.length > 1 ? `${t.sources.length}条记录合计` : ""}可供${t.qtyValue}${e.unit} · ${selectedLatestEta(t.sources)}</small></div><button data-source-group="${t.ids.join("|")}" data-group-action="select">选择</button></div>`,
              )
              .join("") ||
            '<div class="selected-combo-empty">暂无新的可选候选</div>';
        const u = groupSourcesByOwner(
          ("all" === state.drawerChannel
            ? a
            : a.filter((e) => e.channelKey === state.drawerChannel)
          ).filter((e) => {
            const t = state.drawerSearch.toLowerCase();
            return (
              !(
                t &&
                !`${e.name}${e.status}${e.type}${e.distance || ""}`
                  .toLowerCase()
                  .includes(t)
              ) &&
              !("available" === state.drawerStatus && !sourceSelectable(e)) &&
              !(
                "waiting" === state.drawerStatus &&
                !/等待|未回复|超时|核库中|询价中/.test(e.status)
              ) &&
              !(
                "reminded" === state.drawerStatus &&
                !e.reminderCount &&
                !e.reminders?.length
              )
            );
          }),
        );
        u.sort((t, s) =>
          "qty" === state.drawerSort
            ? s.qtyValue - t.qtyValue
            : "reminder" === state.drawerSort
              ? Math.max(...s.sources.map((e) => e.reminderCount || 0)) -
                Math.max(...t.sources.map((e) => e.reminderCount || 0))
              : "reply" === state.drawerSort
                ? String(t.sources[0].reply || "").localeCompare(
                    String(s.sources[0].reply || ""),
                  )
                : compareSourceGroups(e, t, s),
        );
        const p =
            u
              .map((s, a) => {
                const n = s.ids.every((e) => t.has(e)),
                  i = s.sources.some(sourceSelectable),
                  r = state.expandedSourceId === s.key,
                  l = sourceGroupStatus(s),
                  d = selectedLatestEta(s.sources),
                  c =
                    s.sources
                      .map(sourceReminderSummary)
                      .find((e) => "无需催办" !== e) || "无需催办",
                  o = s.sources[0],
                  u = s.sources
                    .map(
                      (e, t) =>
                        `<div class="source-record-row"><div><span>记录</span><b>${e.id}</b></div><div><span>可供</span><b>${e.qty}</b></div><div><span>到货/回复</span><b>${e.eta}<br>${e.reply}</b></div><div class="record-note"><span>库存地点／项目／协议信息</span><b>${e.distance || e.channel || "—"}</b></div></div>`,
                    )
                    .join("");
                return `<article class="drawer-response-item ${n ? "selected" : ""}"><div class="drawer-response-item-head"><div><strong>${s.name}</strong><span>${RESPONSE_CHANNELS[s.channelKey]?.name || s.sources[0].type}${s.sources.length > 1 ? ` · ${s.sources.length}条资源记录` : ""}</span></div><span class="response-status ${responseTone(l)}">${l}</span></div><div class="drawer-response-core"><div><span>可供</span><b>${s.qtyValue || "—"}${s.qtyValue ? e.unit : ""}</b></div><div><span>预计到货</span><b>${d}</b></div><div><span>催办状态</span><b>${c}</b></div></div><div class="drawer-notice-line"><b>通知链路：</b>${sourceNoticeSummary(o, a)}</div><div class="drawer-response-item-actions"><button data-expand-source-group="${s.key}">${r ? "收起" : "详情"}</button><button class="${n ? "selected" : ""}" data-source-group="${s.ids.join("|")}" data-group-action="${n ? "cancel" : "select"}" ${i ? "" : "disabled"}>${n ? "取消" : "选择"}</button></div>${
                  r
                    ? `<div class="drawer-response-detail"><div class="notice-detail-grid"><dt>通知对象</dt><dd>${ensureSourceNotice(o, a).target}</dd><dt>通知方式</dt><dd>${sourceNoticeMethod(o)}</dd><dt>发送时间</dt><dd>${ensureSourceNotice(o, a).sentAt}</dd><dt>确认截止</dt><dd>${ensureSourceNotice(o, a).deadline}</dd><dt>发送状态</dt><dd>${ensureSourceNotice(o, a).sendStatus}</dd></div>${s.sources.length > 1 ? `<div class="source-record-list"><strong style="font-size:9.5px">底层资源明细（用于区分同一单位的多条记录）</strong>${u}</div>` : ""}<div class="reminder-timeline"><strong>通知、回复与催办时间线</strong>${sourceNoticeTimeline(
                        o,
                        a,
                      )
                        .concat(sourceReminderTimeline(o))
                        .filter((e, t, s) => s.indexOf(e) === t)
                        .map((e) => `<div>${e}</div>`)
                        .join(
                          "",
                        )}</div><button class="drawer-chat-link" data-response-chat="${e.name}-${s.name}">在右侧智能体对话中处理 →</button></div>`
                    : ""
                }</article>`;
              })
              .join("") ||
            '<div class="empty-state">当前筛选条件下暂无响应</div>',
          m = `<section class="drawer-selected-block"><div class="drawer-section-title"><h4>已选组合</h4><span>累计满足 ${roundQty(r)}${e.unit}</span></div><div class="selected-combo-list">${c}</div><div class="drawer-section-title recommendation-title"><h4>智能体推荐候选</h4><span>最多展示3个响应对象</span></div><div class="recommendation-list">${o}</div></section><section class="drawer-response-section-channel"><div class="drawer-channel-tabs channel-drawer-channels"><button class="drawer-channel-tab ${"all" === state.drawerChannel ? "active" : ""}" data-drawer-channel="all"><strong>全部响应</strong><span>${groupSourcesByOwner(a).length}</span></button>${Object.entries(
            RESPONSE_CHANNELS,
          )
            .map(
              ([e, t]) =>
                `<button class="drawer-channel-tab ${state.drawerChannel === e ? "active" : ""}" data-drawer-channel="${e}"><strong>${t.name}</strong><span>${n[e] || 0}</span></button>`,
            )
            .join(
              "",
            )}</div><div class="drawer-tools channel-drawer-tools"><input id="drawerSearch" value="${escapeHtml(state.drawerSearch)}" placeholder="搜索单位或供应商"><select id="drawerStatus"><option value="all" ${"all" === state.drawerStatus ? "selected" : ""}>全部状态</option><option value="available" ${"available" === state.drawerStatus ? "selected" : ""}>仅看可选</option><option value="waiting" ${"waiting" === state.drawerStatus ? "selected" : ""}>仅看待回复</option><option value="reminded" ${"reminded" === state.drawerStatus ? "selected" : ""}>仅看已催办</option></select><select id="drawerSort"><option value="priority" ${"priority" === state.drawerSort ? "selected" : ""}>按渠道优先级</option><option value="reply" ${"reply" === state.drawerSort ? "selected" : ""}>按回复时间</option><option value="qty" ${"qty" === state.drawerSort ? "selected" : ""}>按可供数量</option><option value="reminder" ${"reminder" === state.drawerSort ? "selected" : ""}>按催办次数</option></select></div><div class="drawer-response-list-channel">${p}</div></section>`;
        (($("#materialDrawerBody").innerHTML = m),
          ($("#materialConfirm").disabled = e.confirmed || e.filled < e.need),
          ($("#materialConfirm").textContent = e.confirmed
            ? "已确认"
            : "确认当前组合"),
          ($("#materialProcure").disabled = "purchase" === e.activeChannel),
          $$("#materialDrawerBody [data-source-group]").forEach(
            (t) =>
              (t.onclick = () =>
                selectSourceGroup(
                  e.id,
                  t.dataset.sourceGroup.split("|"),
                  "select" === t.dataset.groupAction,
                )),
          ),
          $$("#materialDrawerBody [data-response-chat]").forEach(
            (e) =>
              (e.onclick = () =>
                assistantAction(
                  `请处理${e.dataset.responseChat}的响应，并说明建议动作`,
                )),
          ),
          $$("#materialDrawerBody [data-drawer-channel]").forEach(
            (e) =>
              (e.onclick = () => {
                ((state.drawerChannel = e.dataset.drawerChannel),
                  renderMaterialDrawer());
              }),
          ),
          $$("#materialDrawerBody [data-expand-source-group]").forEach(
            (e) =>
              (e.onclick = () => {
                ((state.expandedSourceId =
                  state.expandedSourceId === e.dataset.expandSourceGroup
                    ? null
                    : e.dataset.expandSourceGroup),
                  renderMaterialDrawer());
              }),
          ),
          $("#drawerSearch")?.addEventListener("input", (e) => {
            ((state.drawerSearch = e.target.value), renderMaterialDrawer());
          }),
          $("#drawerStatus")?.addEventListener("change", (e) => {
            ((state.drawerStatus = e.target.value), renderMaterialDrawer());
          }),
          $("#drawerSort")?.addEventListener("change", (e) => {
            ((state.drawerSort = e.target.value), renderMaterialDrawer());
          }));
      }
      function confirmMaterial(e) {
        const t = state.task.materials.find((t) => t.id === e);
        t.filled < t.need
          ? showToast("当前资源尚未完整满足，不能直接确认")
          : ((t.confirmed = !0),
            (t.status = "已确认"),
            (t.statusClass = "done"),
            (t.updated = nowTime().slice(0, 5)),
            t.history.push(`${t.updated} 用户确认当前资源方案`),
            state.assistant.push({
              role: "assistant",
              text: `已确认“${t.name}”当前资源方案。其他物资继续寻源，不受影响。`,
            }),
            showToast(`已确认：${t.name}`),
            renderWorkbench(),
            $("#materialDrawer")?.classList.contains("show") &&
              renderMaterialDrawer());
      }
      function analyzeNow() {
        const e = summaryCounts();
        (state.assistant.push({ role: "user", text: "分析当前四渠道寻源结果" }),
          state.assistant.push({
            role: "assistant",
            text: `截至${nowTime().slice(0, 5)}，共${e.total}条物资：${e.crossResponse}条等待跨单位响应、${e.crossConfirm}条等待跨单位确认、${e.supplier}条处于应急抢单响应或确认、${e.transit}条等待在途/在建确认、${e.purchase}条进入应急采购。`,
            action:
              "系统严格按跨单位调拨、应急抢单、在途/在建、应急采购的优先级推进。",
          }),
          renderAssistant(),
          showToast("已完成四渠道分析"));
      }
      function remindAll() {
        ((state.task.lastUpdate = nowTime()),
          (state.task.nextCheck = "5分钟后"));
        let e = 0,
          t = 0;
        (state.task.materials.forEach((s) =>
          s.sources
            .filter(
              (e) =>
                !1 !== e.requested && /等待|未回复|超时|接单/.test(e.status),
            )
            .forEach((s) => {
              (e++,
                (s.reminderCount = (s.reminderCount || 0) + 1),
                t++,
                (s.reminders = s.reminders || []),
                s.reminders.push(
                  `${nowTime().slice(0, 5)} 超时未回复，催办 +1（累计${s.reminderCount}次）`,
                ));
            }),
        ),
          state.task.events.unshift({
            time: nowTime().slice(0, 5),
            title: `已对${e}个未回复对象自动催办`,
            copy: `到达检查时间后系统自动发送提醒；再次超时未回复，催办次数 +1，本次新增${t}次催办记录。`,
            level: "important",
          }),
          state.assistant.push({
            role: "assistant",
            text: `已完成自动催办：共处理${e}个未回复单位或供应商，每个对象催办次数已 +1。打开物资详情后，可在供应商信息下方查看完整催办时间线。`,
          }),
          showToast("已自动催办，次数已更新"),
          renderWorkbench(),
          $("#materialDrawer")?.classList.contains("show") &&
            renderMaterialDrawer());
      }
      function assistantAction(e) {
        state.assistant.push({ role: "user", text: e });
        let t = "已记录您的要求，并同步更新任务。",
          s = null,
          a = !1;
        if (e.includes("当前需要我判断") || e.includes("需要我确认"))
          ((state.wbTab = "overview"),
            (t =
              "当前需要您确认最终保障方案及3条缺口处置方式。确认后将自动回写原系统，生成调拨与采购指令并进入到货跟踪。"));
        else if (e.includes("已完成事项") || e.includes("智能体已完成"))
          ((state.wbTab = "overview"),
            (t =
              "智能体已完成灾损预测、23条需求解析、四渠道资源寻源、二次确认和最终保障方案生成。"));
        else if (e.includes("确认后") && e.includes("自动"))
          ((state.wbTab = "overview"),
            (t =
              "确认后将依次完成原系统回写、调拨与采购指令生成、执行对象通知、发运跟踪和异常监测。"));
        else if (e.includes("打开最终方案"))
          ((state.wbTab = "plans"),
            (t =
              "已切换至方案与决策，可查看完整物资来源、二次确认结果和缺口兜底方式。"));
        else if (e.includes("发起二次确认"))
          return ((state.wbTab = "plans"), void startSecondConfirmation());
        if (
          (e.includes("查看二次确认进度") &&
            ((state.wbTab = "plans"),
            (t = state.task.secondConfirmStarted
              ? "已切换至二次确认进度，页面将展示确认对象、通知发送、回复状态和方案变化。"
              : "当前尚未发起二次确认，请先完成候选方案选择。")),
          e.includes("查看光缆") &&
            (e.includes("响应") || e.includes("单位") || e.includes("供应商")))
        )
          ((state.selectedMaterial = (
            state.task.materials.find((e) => e.name.includes("OPGW光缆")) ||
            state.task.materials[0]
          ).id),
            (state.wbTab = "materials"),
            (s = state.selectedMaterial),
            (t =
              "已打开光缆响应侧栏。侧栏分别展示系统内单位响应和供应商响应，右侧智能体聊天框继续保留，您可以要求采纳、排除、催办或改为单一来源。"));
        else if (e.includes("物资缺口")) {
          const e = state.task.materials.filter((e) => e.filled < e.need);
          ((state.wbTab = "materials"),
            (t = `当前共有${e.length}条物资存在缺口：${e.map((e) => `${e.name}缺${+(e.need - e.filled).toFixed(2)}${e.unit}`).join("；")}。建议优先复核OPGW光缆、铁塔、钢芯铝绞线等关键物资。`));
        } else if (e.includes("四渠道") || e.includes("寻源结果"))
          ((state.wbTab = "responses"),
            (state.responseChannel = "all"),
            (t =
              "已切换至四渠道寻源反馈。当前页面默认展示跨单位调拨、应急抢单、在途/在建和应急采购的全部请求与确认信息，点击任一渠道卡片可单独筛选。"));
        else if (e.includes("只看供应商"))
          ((state.wbTab = "responses"),
            (state.responseChannel = "rush"),
            (t =
              "已筛选应急抢单渠道，页面仅展示系统外供应商抢单回复、可供量、交付时间和自动催办信息。"));
        else if (e.includes("评估当前组合") || e.includes("自定义组合")) {
          state.wbTab = "plans";
          const e = customPlanMetrics();
          t = `当前组合方案满足率约${e.fit}，最晚到货${e.eta}，涉及${e.units}，预计采购${e.cost}，人工协调约${e.coordination}。您可以继续按单条物资修改，整体指标会实时更新。`;
        } else if (
          e.includes("两个方案") ||
          e.includes("两方案") ||
          e.includes("方案差异")
        )
          ((state.wbTab = "plans"),
            (t =
              "已进入方案与决策。页面不再一次性铺开全部参数，而是按物资逐条选择候选满足方式，并在下方实时汇总我的组合方案。"));
        else if (e.includes("优先最早到货"))
          ((state.task.constraints = state.task.constraints.filter(
            (e) => !e.includes("最早到货"),
          )),
            state.task.constraints.unshift("优先最早到货时间"),
            (state.wbTab = "plans"),
            (t =
              "已将“优先最早到货时间”设为高优先级约束，并同步更新各物资候选方式。"));
        else if (
          e.includes("单一单位") ||
          e.includes("单一来源") ||
          e.includes("不要拼单")
        ) {
          const e =
            state.task.materials.find((e) => e.name.includes("OPGW光缆")) ||
            state.task.materials[0];
          ((e.allowSplit = !1),
            (e.status = "待人工判断"),
            (e.statusClass = "attention"),
            (e.method = "等待单一来源完整满足"),
            (state.task.constraints = state.task.constraints.filter(
              (e) => !e.includes("光缆允许") && !e.includes("光缆必须"),
            )),
            state.task.constraints.unshift("光缆必须由单一来源完整满足"),
            ensurePlanBuilderState(),
            (state.customSelections[e.id] = "P2"),
            (state.planMaterial = e.id),
            (state.wbTab = "plans"),
            (t =
              "已将光缆约束调整为“必须由单一来源完整满足”，并同步更新我的组合方案。到货时间可能略有延后，但跨单位协调量会下降。"));
        } else if (e.includes("通信电源") && e.includes("本地供应商"))
          (ensurePlanBuilderState(),
            (state.customSelections.M03 = "P2"),
            (state.planMaterial = "M03"),
            (state.wbTab = "plans"),
            state.task.constraints.includes("通信电源优先本地供应商") ||
              state.task.constraints.unshift("通信电源优先本地供应商"),
            (t =
              "已将“通信电源优先本地供应商”加入约束，并同步更新当前组合方案。采购金额可能略有增加，但供货稳定性与本地协同效率更高。"));
        else if (e.includes("采用当前组合") || e.includes("采用当前方案"))
          ((state.wbTab = "plans"),
            (a = !0),
            (t =
              "已准备确认当前组合方案。确认后将记录每条物资的选择、用户调整理由和风险接受情况。"));
        else {
          if (e.includes("催办")) return void remindAll();
          if (e.includes("通信电源") && e.includes("采购")) {
            const e = state.task.materials.find((e) => "通信电源" === e.name);
            ((e.procure = !0),
              (e.activeChannel = "purchase"),
              (e.status = "应急采购"),
              (e.statusClass = "attention"),
              (e.method = "用户指定转应急采购"),
              (t =
                "已按您的要求将通信电源转入应急采购。原跨单位调拨和应急抢单响应仍保留为过程证据，采购询价将并行记录。"));
          } else if (e.includes("继续等待"))
            ((state.task.nextCheck = "20分钟后"),
              (t =
                "已继续等待20分钟。系统仍会自动接收新回复，并在满足度变化时立即更新页面。"));
          else if (e.includes("请处理") && e.includes("供应商"))
            t =
              "已读取该供应商的响应和原始回执。您可以要求催办、采纳为候选、排除该供应商或加入当前组合方案。";
          else if (e.includes("请处理") && e.includes("单位"))
            t =
              "已读取该系统内单位的库存、可供数量、调出时间和运输时效。您可以要求优先采用、排除或继续等待。";
          else if (e.includes("排除")) {
            const s = e.match(/排除(.+?)(单位|公司|供应商)/)?.[1] || "指定单位";
            (state.task.constraints.push(`排除${s}`),
              (t = `已将“${s}”加入排除清单，并重新计算候选资源。该调整可能增加运输距离或延长到货时间。`));
          }
        }
        (state.assistant.push({
          role: "assistant",
          text: t,
          action: "页面中的物资状态、渠道筛选、约束和组合方案已同步更新。",
        }),
          renderWorkbench(),
          s &&
            ((state.selectedMaterial = s),
            renderMaterialDrawer(),
            openOverlay("materialDrawer")),
          a &&
            (($("#decisionPlanName").textContent = "我的组合方案"),
            openOverlay("decisionModal")),
          showToast("已执行对话指令"));
      }
      function openEvidence() {
        (($("#evidenceBody").innerHTML =
          '<div class="hint-box"><b>证据范围：</b>第一轮征询、邮件与工单发送、短信提醒、响应回收、自动催办、二次确认、备选启用和最终方案生成均按时间留痕。</div><table class="mapping-table" style="margin-top:12px"><thead><tr><th>时间</th><th>对象</th><th>动作/状态</th><th>通知渠道</th><th>原始记录</th></tr></thead><tbody><tr><td>08-14 15:20</td><td>重庆公司相关单位</td><td>跨单位调拨征询已发送</td><td>平台工单＋短信</td><td>WO-CQ-0814-01</td></tr><tr><td>08-14 15:41</td><td>协议库存供应商</td><td>询供邮件及确认链接已发送</td><td>邮件＋确认链接</td><td>MAIL-CQ-0814-01</td></tr><tr><td>08-14 16:21</td><td>帕尔普线路器材有限公司</td><td>回复可供光缆卡具74件</td><td>邮件确认链接</td><td>RESP-0191</td></tr><tr><td>08-15 09:10</td><td>候选方案涉及对象</td><td>二次确认请求已发送</td><td>工单＋短信＋邮件</td><td>SC-CQ-0815-01</td></tr><tr><td>08-15 09:46</td><td>待回复对象</td><td>二次确认完成，方案重新收敛</td><td>响应状态回收</td><td>SC-RESULT-01</td></tr></tbody></table>'),
          openOverlay("evidenceModal"));
      }
      function renderMapping() {
        const e = [
          ["任务编号", "emergency_task_no", state.task.code],
          ["物资需求明细", "material_items", "10条物资"],
          ["调拨分配结果", "transfer_allocations", "7家单位／9条资源"],
          ["应急采购准备", "emergency_purchase", "通信电源5套"],
          [
            "人工确认记录",
            "decision_log",
            state.task.decisionConfirmed ? "已确认" : "未确认",
          ],
        ];
        $("#mappingBody").innerHTML = e
          .map(
            (e) =>
              `<tr><td>${e[0]}</td><td>${e[1]}</td><td><input value="${e[2]}"/></td><td><span class="status done">通过</span></td></tr>`,
          )
          .join("");
      }
      function advanceDemo() {
        state.demoStep++;
        const e = [
          () => {
            (state.task.counters.replied++,
              state.task.counters.waiting--,
              (state.task.lastUpdate = nowTime()),
              state.task.events.unshift({
                time: nowTime().slice(0, 5),
                title: "璧山供电公司回复发电机可提供2台",
                copy: "发电机需求已由大渡口和璧山两家单位完整满足。",
                level: "important",
              }));
            const e = state.task.materials.find((e) => "发电机" === e.name);
            ((e.filled = 4),
              (e.status = "初步满足"),
              (e.statusClass = "waiting"),
              (e.method = "两家单位拼单"),
              (e.updated = nowTime().slice(0, 5)),
              e.sources.push({
                name: "璧山供电公司",
                type: "单位调拨",
                status: "可以满足",
                qty: "2台",
                eta: "今日02:40",
                distance: "45km",
                reply: e.updated,
              }),
              showToast("收到新回复：发电机已完整满足"));
          },
          () => {
            (state.task.counters.replied++,
              state.task.counters.waiting--,
              (state.task.lastUpdate = nowTime()),
              state.task.events.unshift({
                time: nowTime().slice(0, 5),
                title: "九龙坡供电公司回复防汛沙袋可完整满足",
                copy: "可提供500只，预计今日01:10送达。",
                level: "important",
              }));
            const e = state.task.materials.find((e) => "防汛沙袋" === e.name);
            ((e.filled = 500),
              (e.status = "初步满足"),
              (e.statusClass = "waiting"),
              (e.method = "单一单位调拨"),
              (e.updated = nowTime().slice(0, 5)),
              (e.sources = [
                {
                  name: "九龙坡供电公司",
                  type: "单位调拨",
                  status: "可以满足",
                  qty: "500只",
                  eta: "今日01:10",
                  distance: "26km",
                  reply: e.updated,
                },
              ]),
              showToast("收到新回复：防汛沙袋已满足"));
          },
          () => {
            ((state.task.lastUpdate = nowTime()),
              state.task.events.unshift({
                time: nowTime().slice(0, 5),
                title: "协议供应商补充电力电缆1千米",
                copy: "电力电缆需求已完整满足，可生成最终调拨与订单组合。",
                level: "important",
              }));
            const e = state.task.materials.find((e) => "电力电缆" === e.name);
            ((e.filled = 2.5),
              (e.status = "初步满足"),
              (e.statusClass = "waiting"),
              (e.method = "协议库存＋调拨"),
              (e.updated = nowTime().slice(0, 5)),
              showToast("电力电缆已完整满足"));
          },
          () => {
            ((state.task.status = "可生成最终方案"),
              (state.task.stageIndex = 3),
              (state.task.lastUpdate = nowTime()),
              showToast("当前结果已可生成最终方案"));
          },
        ];
        (e[(state.demoStep - 1) % e.length](),
          state.task.runtime++,
          renderWorkbench());
      }
      function showEmergencyHomeNotice(e = !1) {
        const t = $("#emergencyNotifyCard");
        t && (e || "chat" === state.view) && t.classList.add("show");
      }
      function hideEmergencyHomeNotice() {
        const e = $("#emergencyNotifyCard");
        e && e.classList.remove("show");
      }
      function openPriorityEmergency(e = "workbench") {
        if (
          (hideEmergencyHomeNotice(),
          $("#notificationPanel")?.classList.remove("show"),
          $("#notificationBtn")?.classList.remove("open"),
          "workbench" === e)
        )
          return (
            (state.wbTab = "overview"),
            (state.overviewDecisionConfirmed = !1),
            setView("workbench"),
            switchTab("overview"),
            void showToast("已进入最高优先级应急任务总览")
          );
        [
          "emergency",
          "scheduled",
          "agents",
          "knowledge",
          "chat",
          "chats",
        ].includes(e)
          ? setView(e)
          : setView("chat");
      }
      function initEmergencyHomeNotice() {
        const e = $("#notificationBtn"),
          t = $("#notificationPanel");
        (e &&
          t &&
          ((e.onclick = (s) => {
            (s.stopPropagation(),
              t.classList.toggle("show"),
              e.classList.toggle("open", t.classList.contains("show")));
          }),
          (t.onclick = (e) => {
            const t = e.target.closest("[data-notice-target]")?.dataset
              .noticeTarget;
            t && openPriorityEmergency(t);
          }),
          document.addEventListener("click", (s) => {
            s.target.closest(".top-right") ||
              (t.classList.remove("show"), e.classList.remove("open"));
          })),
          $("#emergencyNoticeClose") &&
            ($("#emergencyNoticeClose").onclick = hideEmergencyHomeNotice),
          $("#emergencyNoticeLater") &&
            ($("#emergencyNoticeLater").onclick = () => {
              (hideEmergencyHomeNotice(),
                showToast("提醒已收起，首页提醒条和应急任务角标继续保留"));
            }),
          $("#emergencyNoticeEnter") &&
            ($("#emergencyNoticeEnter").onclick = () =>
              openPriorityEmergency("workbench")),
          $("#emergencyNoticeOriginal") &&
            ($("#emergencyNoticeOriginal").onclick = () =>
              showToast("模拟跳转：应急物资需求原系统任务详情")),
          $("#homeEmergencyEnter") &&
            ($("#homeEmergencyEnter").onclick = () =>
              openPriorityEmergency("workbench")),
          $("#homeEmergencyAll") &&
            ($("#homeEmergencyAll").onclick = () =>
              openPriorityEmergency("emergency")),
          setTimeout(() => showEmergencyHomeNotice(), 620));
      }
      function bindGlobal() {
        ($$("[data-view]").forEach((e) =>
          e.addEventListener("click", () => setView(e.dataset.view)),
        ),
          ($("#collapseSidebar").onclick = () =>
            $("#sidebar").classList.toggle("collapsed")),
          ($("#mobileMenu").onclick = () =>
            $("#sidebar").classList.toggle("mobile-open")),
          ($("#settingsBtn").onclick = (e) => {
            (e.stopPropagation(), $("#settingsMenu").classList.toggle("show"));
          }),
          document.addEventListener("click", (e) => {
            e.target.closest(".sidebar-bottom") ||
              $("#settingsMenu").classList.remove("show");
          }),
          $$("[data-close]").forEach(
            (e) => (e.onclick = () => closeOverlay(e.dataset.close)),
          ),
          $$(".overlay").forEach((e) =>
            e.addEventListener("mousedown", (t) => {
              t.target === e && closeOverlay(e.id);
            }),
          ),
          ($('[data-open="settings"]').onclick = () =>
            openOverlay("settingsModal")),
          $("#openTemplateLibrary")?.addEventListener("click", () =>
            openSoulEditor(0),
          ),
          $("#createAgentBtn")?.addEventListener("click", () =>
            openSoulEditor(state.agents.length - 1),
          ),
          $("#importAgentBtn")?.addEventListener("click", () =>
            showToast("请选择智能体配置包进行导入"),
          ),
          ($("#validateSoul").onclick = validateSoul),
          ($("#previewSoul").onclick = previewSoul),
          ($("#hotUpdateSoul").onclick = hotUpdateSoul),
          ($("#rollbackSoul").onclick = rollbackSoul),
          ($("#exportSoul").onclick = exportSoul),
          ($("#soulTemplateList").onclick = (e) => {
            const t = e.target.closest("[data-apply-soul]"),
              s = e.target.closest("[data-soul-template]");
            t
              ? applySoulTemplate(t.dataset.applySoul)
              : s && applySoulTemplate(s.dataset.soulTemplate);
          }),
          ($("#soulFile").onchange = (e) => {
            const t = e.target.files?.[0];
            if (!t) return;
            const s = new FileReader();
            ((s.onload = () => {
              (($("#soulEditor").value = String(s.result || "")),
                (soulValidated = !1),
                ($("#soulValidation").innerHTML =
                  '<span class="status waiting">待校验</span><span>已导入本地 Soul 文件。</span>'));
            }),
              s.readAsText(t, "utf-8"));
          }),
          bindScheduleControls(),
          $("#manualEmergencyBtn") &&
            ($("#manualEmergencyBtn").onclick = () =>
              openOverlay("emergencyModal")),
          ($("#saveEmergency").onclick = () => {
            const e = $("#newEmergencyTitle").value,
              t = $("#newEmergencyCode").value;
            (state.emergencies.unshift({
              id: "E" + Date.now(),
              code: t,
              title: e,
              unit: "国网重庆市电力公司物资分公司",
              received: "刚刚",
              runtime: "1分钟",
              stage: "需求识别",
              status: "自动执行中",
              statusClass: "running",
              progress: 8,
              materials: "2条",
              summary: "2条正在识别",
              risk: "暂无重大异常",
              riskLevel: "green",
              attention: !1,
            }),
              closeOverlay("emergencyModal"),
              renderEmergencyTable(),
              showToast("已创建独立应急任务并自动开始寻源"));
          }),
          ($("#chatSend").onclick = sendChat),
          $("#chatInput").addEventListener("keydown", (e) => {
            "Enter" !== e.key || e.shiftKey || (e.preventDefault(), sendChat());
          }),
          $$("[data-suggest]").forEach(
            (e) =>
              (e.onclick = () => {
                (($("#chatInput").value = e.dataset.suggest), sendChat());
              }),
          ),
          ($("#chatSearch").oninput = renderChatTable),
          ($("#agentSearch").oninput = renderAgents),
          ($("#emergencySearch").oninput = renderEmergencyTable),
          $("#globalSearch")?.addEventListener("keydown", (e) => {
            if ("Enter" === e.key) {
              const t = e.target.value.toLowerCase();
              t.includes("运行") || t.includes("轨迹") || t.includes("run")
                ? setView("runtime")
                : t.includes("应急")
                  ? setView("emergency")
                  : t.includes("智能体")
                    ? setView("agents")
                    : t.includes("知识")
                      ? setView("knowledge")
                      : setView("chats");
            }
          }),
          ($("#emergencyFilters").onclick = (e) => {
            const t = e.target.closest(".filter-tab");
            t && setEmergencyFilter(t.dataset.filter);
          }),
          ($("#emergencySummaryStats").onclick = (e) => {
            const t = e.target.closest(".hero-stat");
            t && setEmergencyFilter(t.dataset.summaryFilter);
          }),
          ($("#wbTabs").onclick = (e) => {
            const t = e.target.closest(".wb-tab");
            t && switchTab(t.dataset.tab);
          }),
          $("#collapseAssistant") &&
            ($("#collapseAssistant").onclick = () => {
              $("#workbenchBody").classList.remove("panel-collapsed");
            }),
          ($("#assistantHead").onclick = () => {
            innerWidth < 821 &&
              $("#assistantPanel").classList.toggle("mobile-open");
          }),
          ($("#assistantSend").onclick = sendAssistant),
          $("#assistantInput").addEventListener("keydown", (e) => {
            "Enter" !== e.key ||
              e.shiftKey ||
              (e.preventDefault(), sendAssistant());
          }),
          $$("[data-quick]").forEach(
            (e) => (e.onclick = () => assistantAction(e.dataset.quick)),
          ),
          ($("#clearAssistant").onclick = () => {
            ((state.assistant = []), renderAssistant());
          }),
          $("#demoAdvance") && ($("#demoAdvance").onclick = advanceDemo),
          $("#toggleAuto") &&
            ($("#toggleAuto").onclick = () => {
              ((state.autoDemo = !state.autoDemo),
                ($("#toggleAuto span:last-child").textContent =
                  "自动更新：" + (state.autoDemo ? "开" : "关")),
                showToast("自动更新已" + (state.autoDemo ? "开启" : "关闭")));
            }),
          $("#openOriginal") &&
            ($("#openOriginal").onclick = () =>
              showToast("模拟跳转：应急物资需求原系统任务详情")),
          $$("[data-drawer-tab]").forEach(
            (e) =>
              (e.onclick = () => {
                ((state.drawerTab = e.dataset.drawerTab),
                  renderMaterialDrawer());
              }),
          ),
          ($("#materialConfirm").onclick = () =>
            confirmMaterial(state.selectedMaterial)),
          ($("#materialWait").onclick = () => {
            const e = state.task.materials.find(
              (e) => e.id === state.selectedMaterial,
            );
            ((e.status =
              "unit" === e.activeChannel
                ? "等待跨单位响应中"
                : "rush" === e.activeChannel
                  ? "等待供应商响应中"
                  : "transit" === e.activeChannel
                    ? "等待在途/在建确认中"
                    : "应急采购"),
              (e.statusClass =
                "purchase" === e.activeChannel ? "attention" : "running"),
              e.history.push(`${nowTime().slice(0, 5)} 用户选择继续等待`),
              renderMaterialDrawer(),
              renderWorkbench(),
              showToast("已继续寻源"));
          }),
          ($("#materialProcure").onclick = () => {
            const e = state.task.materials.find(
              (e) => e.id === state.selectedMaterial,
            );
            ((e.procure = !0),
              (e.activeChannel = "purchase"),
              (e.status = "应急采购"),
              (e.statusClass = "attention"),
              (e.method = "应急采购处理中"),
              e.history.push(`${nowTime().slice(0, 5)} 用户转入应急采购`),
              renderMaterialDrawer(),
              renderWorkbench(),
              showToast("已转入应急采购准备"));
          }),
          $$(".reason-chip").forEach(
            (e) => (e.onclick = () => e.classList.toggle("on")),
          ),
          ($("#saveDecision").onclick = () => {
            ((state.task.decisionConfirmed = !0),
              (state.task.stageIndex = 4),
              (state.task.status = "待回写原系统"),
              state.assistant.push({
                role: "assistant",
                text: `方案已由用户确认。选择理由：${$$(".reason-chip.on")
                  .map((e) => e.textContent)
                  .join("、")}。下一步可回写智慧供应链平台并生成业务单据。`,
              }),
              closeOverlay("decisionModal"),
              switchTab("execution"),
              showToast("方案已确认并完成决策留痕"));
          }),
          ($("#confirmWriteback").onclick = () => {
            ((state.task.writeback = !0),
              (state.task.stageIndex = 5),
              (state.task.status = "执行跟踪中"),
              (state.task.orders = [
                {
                  name: "应急资源调拨方案草稿",
                  id: "DBFA-20260714-0081",
                  system: "智慧供应链平台",
                  time: nowTime().slice(0, 5),
                  materials: "9条",
                  status: "已提交",
                  next: "调拨执行与发运跟踪",
                },
                {
                  name: "应急采购准备单",
                  id: "YJCG-20260714-0026",
                  system: "采购执行系统",
                  time: nowTime().slice(0, 5),
                  materials: "通信电源5套",
                  status: "草稿",
                  next: "采购专责确认",
                },
              ]),
              closeOverlay("writebackModal"),
              renderWorkbench(),
              showToast("回写成功，已生成2张业务单据"));
          }),
          $("#settingsModal .segmented")?.addEventListener("click", (e) => {
            const t = e.target.closest("button");
            t &&
              [...t.parentElement.children].forEach((e) =>
                e.classList.toggle("active", e === t),
              );
          }),
          $("#contextSegment") &&
            ($("#contextSegment").onclick = (e) => {
              const t = e.target.closest("button");
              t &&
                $$("#contextSegment button").forEach((e) =>
                  e.classList.toggle("active", e === t),
                );
            }),
          document.addEventListener("click", (e) => {
            if (
              e.target.closest("#editSchedule") ||
              e.target.closest("#editPromptSchedule")
            ) {
              return void openScheduleModal(
                state.scheduled.find((e) => e.id === state.selectedSchedule),
              );
            }
            if (e.target.closest("#duplicateSchedule")) {
              const e = state.scheduled.find(
                  (e) => e.id === state.selectedSchedule,
                ),
                t = {
                  ...e,
                  id: Date.now(),
                  name: e.name + "（副本）",
                  status: "草稿",
                  last: "尚未运行",
                  system: !1,
                };
              return (
                state.scheduled.push(t),
                (state.selectedSchedule = t.id),
                renderSchedules(),
                void showToast("已复制为草稿任务")
              );
            }
            if (e.target.closest("#deleteSchedule")) {
              const e = state.scheduled.find(
                (e) => e.id === state.selectedSchedule,
              );
              return e?.system
                ? void showToast("系统常驻任务不可删除")
                : ((state.scheduled = state.scheduled.filter(
                    (e) => e.id !== state.selectedSchedule,
                  )),
                  (state.selectedSchedule = state.scheduled[0]?.id),
                  renderSchedules(),
                  void showToast("定时任务已删除"));
            }
            if (e.target.closest("#runSchedule")) {
              const e = state.scheduled.find(
                (e) => e.id === state.selectedSchedule,
              );
              return (
                (e.last = "刚刚 · 手动触发运行"),
                (e.status = "运行中"),
                renderSchedules(),
                void showToast("定时任务已开始运行")
              );
            }
            if (e.target.closest("#pauseSchedule")) {
              const e = state.scheduled.find(
                (e) => e.id === state.selectedSchedule,
              );
              return (
                (e.status = "已暂停" === e.status ? "已启用" : "已暂停"),
                renderSchedules(),
                void showToast(
                  "已暂停" === e.status ? "定时任务已暂停" : "定时任务已恢复",
                )
              );
            }
            const t = e.target.closest("[data-schedule]");
            t &&
              ((state.selectedSchedule = +t.dataset.schedule),
              renderSchedules());
            const s = e.target.closest("[data-emergency]");
            s && switchEmergencyTask(s.dataset.emergency);
            const a = e.target.closest("[data-recent]");
            if (a) {
              const e = state.conversations[+a.dataset.recent];
              "应急任务" === e.type
                ? setView("workbench")
                : (setView("chat"), startChat(e.title));
            }
            const n = e.target.closest("[data-agent-soul]");
            if (n) return void openSoulEditor(+n.dataset.agentSoul);
            const i = e.target.closest("[data-agent-enter]");
            if (i) {
              const e = state.agents[+i.dataset.agentEnter];
              return (
                setView("chat"),
                void startChat(
                  `已进入${e.name}。当前采用“${e.soulTemplate}” Soul ${e.soulVersion}，请描述需要处理的任务。`,
                )
              );
            }
          }));
      }
      function sendChat() {
        const e = $("#chatInput"),
          t = e.value.trim();
        t && (startChat(t), (e.value = ""));
      }
      function startChat(e) {
        $("#chatEmpty").classList.add("hidden");
        const t = $("#chatThread");
        (t.insertAdjacentHTML(
          "beforeend",
          `<div class="message user"><div class="avatar">我</div><div class="bubble">${e}</div></div><div class="message"><div class="avatar">智</div><div class="bubble assistant-copy"><div class="thinking"><span class="live-dot"></span>正在使用工具与技能</div>我已理解您的请求。当前为智慧工作台通用对话区，可调用工具、技能和专业智能体。涉及持续执行的应急事件，建议进入“应急任务中心”查看结构化工作台。<div class="tool-call"><b>路由判断：</b> 普通问答留在当前对话；应急任务跳转独立业务线程。</div></div></div>`,
        ),
          (t.scrollTop = t.scrollHeight));
      }
      function sendAssistant() {
        const e = $("#assistantInput"),
          t = e.value.trim();
        t && ((e.value = ""), assistantAction(t));
      }
      function autoTick() {
        if ("workbench" === state.view && state.autoDemo) {
          state.tickCount++;
          const e = new Date().getSeconds();
          if (
            (state.tickCount % 60 == 0 && state.task.runtime++, e % 20 == 0)
          ) {
            ((state.task.lastUpdate = nowTime()), renderSummary());
            const e = $(".alive-banner .latest-event");
            e &&
              (e.innerHTML = `最近检查 ${state.task.lastUpdate}<br>暂无新的外部回复`);
          }
        }
      }
      const SAMPLE_DATA = {
        event: {
          code: "YJ202508105396",
          name: "国网重庆市电力公司忠县供电分公司暴雨黄色、强对流黄色预警通知〔2025〕第10号",
          level: "三级",
          unit: "国网重庆市电力公司忠县供电分公司",
          status: "已审批",
          source: "ECS集成",
          remark: "开展应急预警",
        },
        emergencies: [
          {
            id: "E001",
            code: "YJ202508105396-01",
            title: "国网重庆忠县公司110kV石拔南线#22滑坡应急",
            unit: "国网重庆市电力公司忠县供电分公司",
            received: "08-12 09:48",
            runtime: "",
            stage: "资源组合确认",
            status: "需要人工确认",
            statusClass: "attention",
            progress: 78,
            materials: "23条",
            summary: "23条有效物资，四渠道匹配完成",
            risk: "已确认资源组合待复核",
            riskLevel: "red",
            attention: !0,
          },
          {
            id: "E002",
            code: "YJ202508105396-02",
            title: "国网重庆忠县公司110kV石拔北线#26滑坡应急",
            unit: "国网重庆市电力公司忠县供电分公司",
            received: "08-12 10:53",
            runtime: "",
            stage: "四渠道寻源",
            status: "自动执行中",
            statusClass: "running",
            progress: 62,
            materials: "21条",
            summary: "21条有效物资，正在核验资源",
            risk: "持续接收资源反馈",
            riskLevel: "green",
            attention: !1,
          },
          {
            id: "E003",
            code: "YJ202508105396-03",
            title: "石拔南、石拔北滑坡应急物资补提",
            unit: "国网重庆市电力公司忠县供电分公司",
            received: "08-19 09:08",
            runtime: "",
            stage: "需求解析完成",
            status: "自动执行中",
            statusClass: "running",
            progress: 38,
            materials: "6条",
            summary: "6条有效物资，已启动寻源",
            risk: "补提物资正在匹配",
            riskLevel: "green",
            attention: !1,
          },
        ],
        task: {
          title: "国网重庆忠县公司110kV石拔南线#22滑坡应急",
          code: "YJ202508105396-01",
          unit: "国网重庆市电力公司忠县供电分公司",
          source: "手工提报",
          received: "08-12 09:48",
          runtime: 0,
          deadline: "2025-08-20",
          stageIndex: 3,
          lastUpdate: "2025-08-14 18:23",
          nextCheck: "5分钟后",
          status: "资源组合确认中",
          currentAction:
            "已完成库存、供应商及在建资源匹配，正在确认可执行资源组合",
          applicant: "古利民",
          applicantTel: "15923422559",
          receiver: "黄薪岗",
          receiverTel: "18083027143",
          shipAddr: "重庆市忠县驼丘仓库",
          description:
            "110kV石拔南线#22铁塔受滑坡影响，需采取杆塔移位进行改造。需要铁塔、OPGW光缆、钢芯铝绞线等物资",
          voltage: "110kV",
          counters: {
            sent: 206,
            received: 206,
            replied: 199,
            can: 22,
            partial: 0,
            waiting: 6,
            timeout: 7,
          },
          materials: [
            {
              id: "M01",
              matReqId: "f2d9d4eb22724b7ba2d461c7c50ee0cf",
              matnr: "500026702",
              name: "钢芯铝绞线",
              spec: "JL/G1A,240/30",
              need: 3.0846,
              unit: "吨",
              filled: 3.0846,
              status: "已确认资源满足",
              statusClass: "done",
              method: "江苏中天科技股份有限公司",
              updated: "2025-08-07",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0034"],
              sources: [
                {
                  id: "U0001",
                  name: "国网重庆市电力公司北碚供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "北碚公司运检部输电运检室专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0002",
                  name: "国网重庆市电力公司云阳供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "2吨",
                  qtyValue: 2,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "云阳公司运检部输电运检班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0003",
                  name: "国网重庆市电力公司武隆供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "0.26吨",
                  qtyValue: 0.26,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力武隆供电公司运检部配网生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0004",
                  name: "国网重庆市电力公司武隆供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "2.4吨",
                  qtyValue: 2.4,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力武隆供电公司运检部配网2号生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0005",
                  name: "合川",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "1.045吨",
                  qtyValue: 1.045,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网合川供电公司马家沟仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0006",
                  name: "城口",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网城口供电公司复兴仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0007",
                  name: "国网重庆市电力公司南川供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "1.228吨",
                  qtyValue: 1.228,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力南川供电公司运检部输电班生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0008",
                  name: "国网重庆市电力公司南川供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力南川供电公司运检部输电班生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0009",
                  name: "国网重庆市电力公司潼南供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "0.164吨",
                  qtyValue: 0.164,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "潼南公司运检部输电运行班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0010",
                  name: "国网重庆市电力公司潼南供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "2吨",
                  qtyValue: 2,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "潼南公司运检部输电运行班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0011",
                  name: "超高压",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "应急物资虚拟库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0012",
                  name: "超高压",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "0.1吨",
                  qtyValue: 0.1,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "应急物资虚拟库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0013",
                  name: "国网重庆市电力公司大足供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "大足公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0014",
                  name: "国网重庆市电力公司大足供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "大足公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0015",
                  name: "国网重庆市电力公司大足供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "大足公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0016",
                  name: "国网重庆市电力公司大足供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "大足公司运检部变电检修班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0017",
                  name: "永川",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力永川仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0018",
                  name: "国网重庆市电力公司永川供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance:
                    "国网重庆电力永川供电分公司变电运检中心变电检修班生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0019",
                  name: "璧山",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网璧山区供电公司兴旺正街仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0020",
                  name: "市北",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力市北仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0021",
                  name: "市北",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力市北仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0022",
                  name: "国网重庆市电力公司市北供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "江北公司运检部输电室检修班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0023",
                  name: "国网重庆市电力公司石柱供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "石柱公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0024",
                  name: "国网重庆市电力公司铜梁供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "铜梁公司运检部输电运检班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0025",
                  name: "国网重庆市电力公司巫溪供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "巫溪公司运检部专业仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0026",
                  name: "国网重庆市电力公司酉阳供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "酉阳公司运检部输电运维班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0027",
                  name: "开州",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "3.752吨",
                  qtyValue: 3.752,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网开州供电公司中集仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0028",
                  name: "开州",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网开州供电公司中集仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0029",
                  name: "开州",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网开州供电公司中集仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0030",
                  name: "开州",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网开州供电公司中集仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0031",
                  name: "开州",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网开州供电公司中集仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0032",
                  name: "国网重庆市电力公司开州供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "开州公司运检部变电检修班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0033",
                  name: "国网重庆市电力公司市区供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "市区公司运检部输电室专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0034",
                  name: "江苏中天科技股份有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "3.0846吨",
                  qtyValue: 3.0846,
                  eta: "2025-08-20",
                  reply: "08-14 16:11",
                  distance: "南通 · 1500km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0035",
                  name: "国网重庆市电力公司北碚供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "3.64吨",
                  qtyValue: 3.64,
                  eta: "待项目单位确认",
                  reply: "2025-08-07",
                  distance: "北碚公司110kV梅碚南北线#1到#6和#13到#22段老旧",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：钢芯铝绞线 3.0846吨",
                "跨单位调拨匹配 33 条库存记录",
                "协议库存收到 1 条供应商反馈",
                "在途/在建匹配 1 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 19917,
            },
            {
              id: "M02",
              matReqId: "695f49c7276e4f92ae159b167632022c",
              matnr: "500141245",
              name: "铝包钢绞线",
              spec: "LBGJ-20AC,50",
              need: 2.0218,
              unit: "吨",
              filled: 2.0218,
              status: "已确认资源满足",
              statusClass: "done",
              method: "江苏中天科技股份有限公司",
              updated: "08-14 16:11",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0037"],
              sources: [
                {
                  id: "U0036",
                  name: "綦江",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力綦江仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0037",
                  name: "江苏中天科技股份有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "2.0218吨",
                  qtyValue: 2.0218,
                  eta: "2025-08-20",
                  reply: "08-14 16:11",
                  distance: "南通 · 1500km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：铝包钢绞线 2.0218吨",
                "跨单位调拨匹配 1 条库存记录",
                "协议库存收到 1 条供应商反馈",
                "在途/在建匹配 0 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 13859,
            },
            {
              id: "M03",
              matReqId: "f7847d9601454745adbc86fe302c7825",
              matnr: "500122793",
              name: "交流盘形悬式瓷绝缘子",
              spec: "U70BP/146D,280,450",
              need: 399,
              unit: "片",
              filled: 399,
              status: "已确认资源满足",
              statusClass: "done",
              method:
                "国网重庆市电力公司超高压分公司 ＋ 国网重庆市电力公司城口供电分公司 ＋ 国网重庆市电力公司城口供电分公司",
              updated: "2025-08-13",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: ["U0038", "U0041", "U0042"],
              sources: [
                {
                  id: "U0038",
                  name: "国网重庆市电力公司超高压分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已确认调拨",
                  qty: "21片",
                  qtyValue: 21,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance:
                    "国网重庆电力公司超高压分公司运检部输电运检中心专业仓",
                  selected: !0,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "库存已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0039",
                  name: "国网重庆市电力公司云阳供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "云阳公司运检部输电运检班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0040",
                  name: "国网重庆市电力公司合川供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "合川公司运检部输电运维班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0041",
                  name: "国网重庆市电力公司城口供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已确认调拨",
                  qty: "200片",
                  qtyValue: 200,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "城口公司运检部专业仓",
                  selected: !0,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "库存已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0042",
                  name: "国网重庆市电力公司城口供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已确认调拨",
                  qty: "178片",
                  qtyValue: 178,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "城口公司运检部专业仓",
                  selected: !0,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "库存已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0043",
                  name: "秀山",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网秀山供电公司园区仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0044",
                  name: "綦江",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力綦江仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0045",
                  name: "国网重庆市电力公司奉节供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "奉节公司营销部宝塔坪供电所专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0046",
                  name: "国网重庆市电力公司市南供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "南岸公司输电运检室专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0047",
                  name: "国网重庆市电力公司巫溪供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "巫溪公司运检部专业仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0048",
                  name: "国网重庆市电力公司巫溪供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "巫溪公司运检部专业仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0049",
                  name: "国网重庆市电力公司璧山供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "璧山公司运检部变电运检室专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0050",
                  name: "国网重庆市电力公司市北供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "江北公司运检部输电室检修班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0051",
                  name: "国网重庆市电力公司酉阳供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "酉阳公司运检部输电运维班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0052",
                  name: "黔江",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网黔江供电公司正阳仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0053",
                  name: "苏州电瓷厂股份有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已生成供货方案",
                  qty: "576片",
                  qtyValue: 576,
                  eta: "2025-08-20",
                  reply: "08-14 17:06",
                  distance: "苏州 · 1407km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0054",
                  name: "大连电瓷集团输变电材料有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "576片",
                  qtyValue: 576,
                  eta: "2025-08-20",
                  reply: "08-14 15:54",
                  distance: "大连 · 2400km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0055",
                  name: "国网重庆市电力公司物资分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "4500片",
                  qtyValue: 4500,
                  eta: "待项目单位确认",
                  reply: "2025-08-13",
                  distance:
                    "重庆大足智凤220千伏输变电工程桥八东西线π接入智凤变220",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0056",
                  name: "国网重庆市电力公司江津区供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "1098片",
                  qtyValue: 1098,
                  eta: "待项目单位确认",
                  reply: "2025-08-13",
                  distance:
                    "国网重庆江津公司220kV珞长南北线等6条线路绝缘子大修-材",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0057",
                  name: "国网重庆市电力公司彭水供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "3391片",
                  qtyValue: 3391,
                  eta: "待项目单位确认",
                  reply: "2025-08-19",
                  distance: "国网重庆彭水公司35kV保坪二线等线路综合大修",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0058",
                  name: "国网重庆市电力公司彭水供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "1708片",
                  qtyValue: 1708,
                  eta: "待项目单位确认",
                  reply: "2025-08-13",
                  distance: "国网重庆彭水公司35kV东龙线老旧线路大修",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0059",
                  name: "国网重庆市电力公司彭水供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "2338片",
                  qtyValue: 2338,
                  eta: "待项目单位确认",
                  reply: "2025-08-13",
                  distance: "国网重庆彭水公司35kV摩润线线路综合大修",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：交流盘形悬式瓷绝缘子 399片",
                "跨单位调拨匹配 15 条库存记录",
                "协议库存收到 2 条供应商反馈",
                "在途/在建匹配 5 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 93,
            },
            {
              id: "M04",
              matReqId: "fd2ab4acbfc34d3c89e19710f42aaff3",
              matnr: "500120805",
              name: "110kV导线耐张通用",
              spec: "1ND21Y-0040-07P(H)",
              need: 24,
              unit: "套",
              filled: 24,
              status: "已确认资源满足",
              statusClass: "done",
              method: "江苏捷凯电力器材有限公司",
              updated: "2025-08-06",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0074"],
              sources: [
                {
                  id: "U0060",
                  name: "綦江",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力綦江仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0061",
                  name: "国网重庆市电力公司大足供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "大足公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0062",
                  name: "酉阳",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "部分可调拨",
                  qty: "4套",
                  qtyValue: 4,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网酉阳供电公司小坝仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0063",
                  name: "国网重庆市电力公司酉阳供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "酉阳公司运检部输电运维班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0064",
                  name: "国网重庆市电力公司酉阳供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "酉阳公司运检部输电运维班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0065",
                  name: "国网重庆市电力公司酉阳供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "酉阳公司运检部输电运维班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0066",
                  name: "国网重庆市电力公司酉阳供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "酉阳公司运检部输电运维班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0067",
                  name: "国网重庆市电力公司巫山供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "巫山公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0068",
                  name: "国网重庆市电力公司巫山供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "巫山公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0069",
                  name: "川东",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网川东电力公司李渡仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0070",
                  name: "国网重庆市电力公司永川供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "永川公司输电运检中心汇龙基地专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0071",
                  name: "国网重庆市电力公司铜梁供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "铜梁公司运检部输电运检班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0072",
                  name: "黔江",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "59套",
                  qtyValue: 59,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网黔江供电公司正阳仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0073",
                  name: "江东金具设备有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "24套",
                  qtyValue: 24,
                  eta: "2025-08-20",
                  reply: "08-14 16:16",
                  distance: "南通 · 1500km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0074",
                  name: "江苏捷凯电力器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "24套",
                  qtyValue: 24,
                  eta: "2025-08-20",
                  reply: "08-14 16:05",
                  distance: "江苏 · 1500km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0075",
                  name: "国网重庆市电力公司市区供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "110套",
                  qtyValue: 110,
                  eta: "待项目单位确认",
                  reply: "2025-08-13",
                  distance:
                    "国网重庆市区公司110kV马桥线综合改造输电线路-架空线路输",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0076",
                  name: "国网重庆市电力公司南川供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "36套",
                  qtyValue: 36,
                  eta: "待项目单位确认",
                  reply: "2025-08-12",
                  distance: "110kV北郊线线路大修1.25",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0077",
                  name: "国网重庆市电力公司南川供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "138套",
                  qtyValue: 138,
                  eta: "待项目单位确认",
                  reply: "2025-08-12",
                  distance: "110kV南北线等线路大修1.25",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0078",
                  name: "国网重庆市电力公司璧山供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "27套",
                  qtyValue: 27,
                  eta: "待项目单位确认",
                  reply: "2025-08-11",
                  distance: "重庆璧山天河220kV变电站110kV送出工程青都线π接入天",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0079",
                  name: "国网重庆市电力公司黔江供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "36套",
                  qtyValue: 36,
                  eta: "待项目单位确认",
                  reply: "2025-08-14",
                  distance:
                    "重庆黔江五福岭二期风电场110kV送出工程五福岭一期、二期升",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0080",
                  name: "国网重庆市电力公司丰都供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源不满足",
                  qty: "132套",
                  qtyValue: 132,
                  eta: "待项目单位确认",
                  reply: "2025-08-06",
                  distance:
                    "重庆丰都许明寺农光互补项目110kV送出工程农光互补升压站～",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：110kV导线耐张通用 24套",
                "跨单位调拨匹配 13 条库存记录",
                "协议库存收到 2 条供应商反馈",
                "在途/在建匹配 6 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 518,
            },
            {
              id: "M05",
              matReqId: "67c75d3530114825bdda5c9c1baa5e1c",
              matnr: "500120823",
              name: "110kV导线跳线通用",
              spec: "1TD-00-07H(P)Z",
              need: 8,
              unit: "套",
              filled: 0,
              status: "等待跨单位确认中",
              statusClass: "waiting",
              method: "已有候选资源待确认",
              updated: "2025-08-14",
              confirmed: !1,
              allowSplit: !0,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: [],
              sources: [
                {
                  id: "U0081",
                  name: "国网重庆市电力公司武隆供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "武隆公司运检部输电运检中心专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0082",
                  name: "国网重庆市电力公司武隆供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "8套",
                  qtyValue: 8,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "武隆公司运检部输电运检中心专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0083",
                  name: "国网重庆市电力公司武隆供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "武隆公司运检部输电运检中心专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0084",
                  name: "国网重庆市电力公司大足供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "大足公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0085",
                  name: "国网重庆市电力公司大足供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "大足公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0086",
                  name: "国网重庆市电力公司丰都供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源不满足",
                  qty: "58套",
                  qtyValue: 58,
                  eta: "待项目单位确认",
                  reply: "2025-08-06",
                  distance:
                    "重庆丰都许明寺农光互补项目110kV送出工程农光互补升压站～",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0087",
                  name: "国网重庆市电力公司市区供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "16套",
                  qtyValue: 16,
                  eta: "待项目单位确认",
                  reply: "2025-08-13",
                  distance:
                    "国网重庆市区公司110kV马桥线综合改造输电线路-架空线路输",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0088",
                  name: "国网重庆市电力公司南川供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "54套",
                  qtyValue: 54,
                  eta: "待项目单位确认",
                  reply: "2025-08-12",
                  distance: "110kV南北线等线路大修1.25",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0089",
                  name: "国网重庆市电力公司黔江供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "24套",
                  qtyValue: 24,
                  eta: "待项目单位确认",
                  reply: "2025-08-14",
                  distance:
                    "重庆黔江五福岭二期风电场110kV送出工程五福岭一期、二期升",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：110kV导线跳线通用 8套",
                "跨单位调拨匹配 5 条库存记录",
                "协议库存收到 0 条供应商反馈",
                "在途/在建匹配 4 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 215,
            },
            {
              id: "M06",
              matReqId: "62fbc54ff49048709ccd70af191330ad",
              matnr: "500120825",
              name: "110kV导线跳线通用",
              spec: "1TD-00-07H(P)RS",
              need: 4,
              unit: "套",
              filled: 4,
              status: "已确认资源满足",
              statusClass: "done",
              method: "江苏捷凯电力器材有限公司 ＋ 江苏捷凯电力器材有限公司",
              updated: "2025-08-06",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0092", "R0094"],
              sources: [
                {
                  id: "U0090",
                  name: "国网重庆市电力公司大足供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "大足公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0091",
                  name: "江东金具设备有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "4套",
                  qtyValue: 4,
                  eta: "2025-08-20",
                  reply: "08-14 16:16",
                  distance: "南通 · 1500km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0092",
                  name: "江苏捷凯电力器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "4套",
                  qtyValue: 4,
                  eta: "2025-08-20",
                  reply: "08-14 16:05",
                  distance: "江苏 · 1500km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0093",
                  name: "江东金具设备有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "8套",
                  qtyValue: 8,
                  eta: "2025-08-20",
                  reply: "08-14 16:16",
                  distance: "南通 · 1500km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0094",
                  name: "江苏捷凯电力器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "8套",
                  qtyValue: 8,
                  eta: "2025-08-20",
                  reply: "08-14 16:05",
                  distance: "江苏 · 1500km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0095",
                  name: "国网重庆市电力公司丰都供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源不满足",
                  qty: "11套",
                  qtyValue: 11,
                  eta: "待项目单位确认",
                  reply: "2025-08-06",
                  distance:
                    "重庆丰都许明寺农光互补项目110kV送出工程农光互补升压站～",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：110kV导线跳线通用 4套",
                "跨单位调拨匹配 1 条库存记录",
                "协议库存收到 4 条供应商反馈",
                "在途/在建匹配 1 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 632,
            },
            {
              id: "M07",
              matReqId: "51f58e515a5b4b339b26113c94e372ea",
              matnr: "500125701",
              name: "地线悬垂通用",
              spec: "BX-BG-07-1A",
              need: 3,
              unit: "套",
              filled: 3,
              status: "已确认资源满足",
              statusClass: "done",
              method: "江苏捷凯电力器材有限公司",
              updated: "08-14 16:05",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0099"],
              sources: [
                {
                  id: "U0096",
                  name: "国网重庆市电力公司江津供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复可调拨",
                  qty: "3套",
                  qtyValue: 3,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力江津供电公司运检部输电运检班生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0097",
                  name: "国网重庆市电力公司江津供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力江津供电公司运检部输电运检班生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0098",
                  name: "国网重庆市电力公司长寿供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "长寿公司输电运检中心专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0099",
                  name: "江苏捷凯电力器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "3套",
                  qtyValue: 3,
                  eta: "2025-08-20",
                  reply: "08-14 16:05",
                  distance: "江苏 · 1500km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：地线悬垂通用 3套",
                "跨单位调拨匹配 3 条库存记录",
                "协议库存收到 1 条供应商反馈",
                "在途/在建匹配 0 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 79,
            },
            {
              id: "M08",
              matReqId: "23c2715bbee2411f9c8398d64630da27",
              matnr: "500126056",
              name: "保护金具-防振锤",
              spec: "FRYJ-2/G",
              need: 20,
              unit: "个",
              filled: 0,
              status: "等待跨单位确认中",
              statusClass: "waiting",
              method: "已有候选资源待确认",
              updated: "2025-08-12",
              confirmed: !1,
              allowSplit: !0,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: [],
              sources: [
                {
                  id: "U0100",
                  name: "国网重庆市电力公司长寿供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "长寿公司输电运检中心专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0101",
                  name: "超高压",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复可调拨",
                  qty: "20个",
                  qtyValue: 20,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "应急物资虚拟库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0102",
                  name: "国网重庆电力送变电公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力送变电公司运维业务部生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0103",
                  name: "国网重庆电力送变电公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力送变电公司运维业务部生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：保护金具-防振锤 20个",
                "跨单位调拨匹配 4 条库存记录",
                "协议库存收到 0 条供应商反馈",
                "在途/在建匹配 0 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 62,
            },
            {
              id: "M09",
              matReqId: "36099b1ac1b44f6ba8fdc5bd0e065128",
              matnr: "500126055",
              name: "保护金具-防振锤",
              spec: "FRYJ-2/4",
              need: 33,
              unit: "个",
              filled: 33,
              status: "已确认资源满足",
              statusClass: "done",
              method:
                "中国能源建设集团南京线路器材有限公司 ＋ 江苏天南电力股份有限公司",
              updated: "2025-08-08",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0108", "R0109"],
              sources: [
                {
                  id: "U0104",
                  name: "綦江",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力綦江仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0105",
                  name: "秀山",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复可调拨",
                  qty: "33个",
                  qtyValue: 33,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网秀山供电公司园区仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0106",
                  name: "万州",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力万州仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0107",
                  name: "江苏天南电力股份有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "33个",
                  qtyValue: 33,
                  eta: "2025-08-20",
                  reply: "08-14 17:37",
                  distance: "江苏如皋 · 1500km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0108",
                  name: "中国能源建设集团南京线路器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "33个",
                  qtyValue: 33,
                  eta: "2025-08-20",
                  reply: "08-14 16:10",
                  distance: "南京 · 1450km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0109",
                  name: "江苏天南电力股份有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "20个",
                  qtyValue: 20,
                  eta: "2025-08-20",
                  reply: "08-14 17:37",
                  distance: "江苏如皋 · 1500km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0110",
                  name: "中国能源建设集团南京线路器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待供应商确认",
                  reply: "08-14 16:10",
                  distance: "—",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0111",
                  name: "国网重庆市电力公司北碚供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "234个",
                  qtyValue: 234,
                  eta: "待项目单位确认",
                  reply: "2025-08-08",
                  distance: "北碚公司110kV梅碚南北线#1到#6和#13到#22段老旧",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：保护金具-防振锤 33个",
                "跨单位调拨匹配 3 条库存记录",
                "协议库存收到 4 条供应商反馈",
                "在途/在建匹配 1 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 55,
            },
            {
              id: "M10",
              matReqId: "5c2b1753c0b443e7a96daa76decf0bf3",
              matnr: "500119188",
              name: "保护金具-铝包带",
              spec: "1mm×10mm",
              need: 9,
              unit: "米",
              filled: 0,
              status: "等待跨单位响应中",
              statusClass: "running",
              method: "四渠道持续寻源",
              updated: "2025-08-12",
              confirmed: !1,
              allowSplit: !0,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: [],
              sources: [],
              history: [
                "2025-08-12 09:48 解析物资需求：保护金具-铝包带 9米",
                "跨单位调拨匹配 0 条库存记录",
                "协议库存收到 0 条供应商反馈",
                "在途/在建匹配 0 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 1,
            },
            {
              id: "M11",
              matReqId: "7bb7036c7a7e4f9880bfac82728aed37",
              matnr: "500020290",
              name: "耐张线夹-螺栓型",
              spec: "NLL-1",
              need: 2,
              unit: "个",
              filled: 0,
              status: "等待跨单位响应中",
              statusClass: "running",
              method: "四渠道持续寻源",
              updated: "2025-08-12",
              confirmed: !1,
              allowSplit: !0,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: [],
              sources: [],
              history: [
                "2025-08-12 09:48 解析物资需求：耐张线夹-螺栓型 2个",
                "跨单位调拨匹配 0 条库存记录",
                "协议库存收到 0 条供应商反馈",
                "在途/在建匹配 0 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 100,
            },
            {
              id: "M12",
              matReqId: "4881a36bb1264a3cb64a5ba87eca5194",
              matnr: "500028150",
              name: "接续金具-钢芯钢铝绞线接续管",
              spec: "JYD-240/30",
              need: 6,
              unit: "个",
              filled: 6,
              status: "已确认资源满足",
              statusClass: "done",
              method: "江苏捷凯电力器材有限公司",
              updated: "08-14 16:05",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0118"],
              sources: [
                {
                  id: "U0112",
                  name: "国网重庆市电力公司云阳供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "云阳公司运检部输电运检班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0113",
                  name: "国网重庆市电力公司酉阳供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "20个",
                  qtyValue: 20,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "酉阳公司运检部输电运维班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0114",
                  name: "国网重庆市电力公司奉节供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "20个",
                  qtyValue: 20,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "奉节公司运检部输电运检班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0115",
                  name: "国网重庆市电力公司铜梁供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "铜梁公司运检部输电运检班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0116",
                  name: "国网重庆市电力公司永川供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "永川公司输电运检中心汇龙基地专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0117",
                  name: "江东金具设备有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "6个",
                  qtyValue: 6,
                  eta: "2025-08-20",
                  reply: "08-14 16:16",
                  distance: "南通 · 1500km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0118",
                  name: "江苏捷凯电力器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "6个",
                  qtyValue: 6,
                  eta: "2025-08-20",
                  reply: "08-14 16:05",
                  distance: "江苏 · 1500km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：接续金具-钢芯钢铝绞线接续管 6个",
                "跨单位调拨匹配 5 条库存记录",
                "协议库存收到 2 条供应商反馈",
                "在途/在建匹配 0 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 39,
            },
            {
              id: "M13",
              matReqId: "a305639a3ef74bf6a74283502536fb6e",
              matnr: "500130769",
              name: "接续金具-地线接续管",
              spec: "JY-50BG-20",
              need: 2,
              unit: "个",
              filled: 2,
              status: "已确认资源满足",
              statusClass: "done",
              method: "江东金具设备有限公司",
              updated: "2025-08-12",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0121"],
              sources: [
                {
                  id: "U0119",
                  name: "国网重庆市电力公司江津供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复可调拨",
                  qty: "2个",
                  qtyValue: 2,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力江津供电公司运检部输电运检班生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0120",
                  name: "国网重庆市电力公司江津供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力江津供电公司运检部输电运检班生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0121",
                  name: "江东金具设备有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "2个",
                  qtyValue: 2,
                  eta: "2025-08-20",
                  reply: "08-14 16:16",
                  distance: "南通 · 1500km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0122",
                  name: "国网重庆市电力公司忠县供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "2个",
                  qtyValue: 2,
                  eta: "待项目单位确认",
                  reply: "2025-08-12",
                  distance:
                    "国网重庆忠县公司35kV龙白西线33-49号段老旧线路改造输",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：接续金具-地线接续管 2个",
                "跨单位调拨匹配 2 条库存记录",
                "协议库存收到 1 条供应商反馈",
                "在途/在建匹配 1 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 46,
            },
            {
              id: "M14",
              matReqId: "be56a7b3cb6241f4998a8f1f991d7f45",
              matnr: "500134695",
              name: "接地石墨",
              spec: "φ20",
              need: 4,
              unit: "米",
              filled: 4,
              status: "已确认资源满足",
              statusClass: "done",
              method: "国网重庆市电力公司长寿供电分公司",
              updated: "08-14 16:56",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: ["U0125"],
              sources: [
                {
                  id: "U0123",
                  name: "国网重庆市电力公司北碚供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "3米",
                  qtyValue: 3,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "北碚公司广汇分公司澄江供电所专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0124",
                  name: "国网重庆市电力公司长寿供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "长寿公司园区供电服务中心晏家供电所专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0125",
                  name: "国网重庆市电力公司长寿供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已确认调拨",
                  qty: "4米",
                  qtyValue: 4,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "长寿公司园区供电服务中心晏家供电所专业仓",
                  selected: !0,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "库存已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0126",
                  name: "国网重庆市电力公司武隆供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "武隆公司营销部江口供电所专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0127",
                  name: "潼南",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网潼南供电公司哨楼仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0128",
                  name: "国网重庆市电力公司潼南供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "潼南公司营销部塘坝供电所专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0129",
                  name: "国网重庆市电力公司潼南供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "潼南公司营销部桂林供电所专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0130",
                  name: "国网重庆市电力公司潼南供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "潼南公司营销部双江供电所专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0131",
                  name: "国网重庆市电力公司潼南供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "4米",
                  qtyValue: 4,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力潼南供电公司农网中心供电所生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0132",
                  name: "国网重庆市电力公司潼南供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力潼南供电公司农网中心供电所生产仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0133",
                  name: "国网重庆市电力公司市南供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "23米",
                  qtyValue: 23,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "南岸公司营销部双柳供电所专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0134",
                  name: "国网重庆市电力公司酉阳供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "22米",
                  qtyValue: 22,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "酉阳公司运检部输电运维班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0135",
                  name: "国网重庆市电力公司璧山供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "103米",
                  qtyValue: 103,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "璧山公司广汇分公司安全生产部1专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0136",
                  name: "国网重庆市电力公司璧山供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "23米",
                  qtyValue: 23,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "璧山公司广汇分公司八塘供电营业所生产专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0137",
                  name: "国网重庆市电力公司璧山供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "10米",
                  qtyValue: 10,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "璧山公司广汇分公司城北供电营业所生产专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0138",
                  name: "国网重庆市电力公司璧山供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "70米",
                  qtyValue: 70,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "璧山公司广汇分公司广普供电营业所生产专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0139",
                  name: "国网重庆市电力公司璧山供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "12米",
                  qtyValue: 12,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "璧山公司广汇分公司大路供电营业所生产专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0140",
                  name: "国网重庆市电力公司璧山供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "15米",
                  qtyValue: 15,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "璧山公司广汇分公司丁家供电营业所生产专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0141",
                  name: "四川诺特科技有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已生成供货方案",
                  qty: "4米",
                  qtyValue: 4,
                  eta: "2025-08-19",
                  reply: "08-14 16:53",
                  distance: "四川遂宁 · 300km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0142",
                  name: "广东景呈智能装备集团有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "4米",
                  qtyValue: 4,
                  eta: "2025-08-20",
                  reply: "08-14 16:56",
                  distance: "广东 · 1330km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "T0143",
                  name: "广东景呈智能装备集团有限公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在途订单待确认",
                  qty: "4米",
                  qtyValue: 4,
                  eta: "2025-08-05",
                  reply: "订单数据已同步",
                  distance: "国网重庆市电力公司长寿供电分公司",
                  selected: !1,
                  requested: !0,
                  channel: "在途订单",
                  price: "—",
                  risk: "需核实订单释放及到货安排",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：接地石墨 4米",
                "跨单位调拨匹配 18 条库存记录",
                "协议库存收到 2 条供应商反馈",
                "在途/在建匹配 1 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 3e3,
            },
            {
              id: "M15",
              matReqId: "7807a9c2820d4551bf66cdc4cdc81945",
              matnr: "500142738",
              name: "铁塔",
              spec: "AC110kV,通用,角钢,Q355(Q345),常规塔",
              need: 35.8191,
              unit: "吨",
              filled: 35.8191,
              status: "已确认资源满足",
              statusClass: "done",
              method: "河南鼎力杆塔股份有限公司",
              updated: "08-14 16:10",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0152"],
              sources: [
                {
                  id: "R0144",
                  name: "青岛武晓集团股份有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待供应商确认",
                  reply: "08-14 17:10",
                  distance: "—",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0145",
                  name: "青岛东方铁塔股份有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待供应商确认",
                  reply: "08-14 16:45",
                  distance: "—",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0146",
                  name: "浙江元利江东铁塔有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "未响应",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待供应商确认",
                  reply: "—",
                  distance: "—",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "供应商尚未响应",
                  reminderCount: 1,
                  reminders: [
                    "08-14 15:41 征询发送",
                    "达到响应时限后自动催办 +1",
                  ],
                },
                {
                  id: "R0147",
                  name: "江苏电力装备有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "未响应",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待供应商确认",
                  reply: "—",
                  distance: "—",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "供应商尚未响应",
                  reminderCount: 1,
                  reminders: [
                    "08-14 15:41 征询发送",
                    "达到响应时限后自动催办 +1",
                  ],
                },
                {
                  id: "R0148",
                  name: "绍兴电力设备有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待供应商确认",
                  reply: "08-14 15:47",
                  distance: "—",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0149",
                  name: "湖州飞剑杆塔制造有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "未响应",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待供应商确认",
                  reply: "—",
                  distance: "—",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "供应商尚未响应",
                  reminderCount: 1,
                  reminders: [
                    "08-14 15:41 征询发送",
                    "达到响应时限后自动催办 +1",
                  ],
                },
                {
                  id: "R0150",
                  name: "山东力源铁塔制造有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待供应商确认",
                  reply: "08-14 15:51",
                  distance: "—",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0151",
                  name: "青岛汇金通电力设备股份有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "未响应",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待供应商确认",
                  reply: "—",
                  distance: "—",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "供应商尚未响应",
                  reminderCount: 1,
                  reminders: [
                    "08-14 15:41 征询发送",
                    "达到响应时限后自动催办 +1",
                  ],
                },
                {
                  id: "R0152",
                  name: "河南鼎力杆塔股份有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "35.8191吨",
                  qtyValue: 35.8191,
                  eta: "2025-09-15",
                  reply: "08-14 16:10",
                  distance: "河南送西平县 · 900km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：铁塔 35.8191吨",
                "跨单位调拨匹配 0 条库存记录",
                "协议库存收到 9 条供应商反馈",
                "在途/在建匹配 0 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 7219,
            },
            {
              id: "M16",
              matReqId: "e0c554a41f4f44fca27df0c1cb315001",
              matnr: "500082911",
              name: "OPGW光缆",
              spec: "24芯,G.652,50/58/11.5,铝包钢",
              need: 2.1618,
              unit: "千米",
              filled: 2.1618,
              status: "已确认资源满足",
              statusClass: "done",
              method: "国网重庆市电力公司江津供电分公司",
              updated: "2025-08-08",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: ["U0153"],
              sources: [
                {
                  id: "U0153",
                  name: "国网重庆市电力公司江津供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已确认调拨",
                  qty: "2.1618千米",
                  qtyValue: 2.1618,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力江津供电公司营销部白沙供电所营销仓",
                  selected: !0,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "库存已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0154",
                  name: "国网重庆市电力公司大足供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "大足公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0155",
                  name: "深圳市特发信息股份有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已生成供货方案",
                  qty: "2.1618千米",
                  qtyValue: 2.1618,
                  eta: "2025-09-20",
                  reply: "08-14 16:37",
                  distance: "东莞 · 1000km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0156",
                  name: "江苏亨通电力智网科技有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "未响应",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待供应商确认",
                  reply: "—",
                  distance: "—",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "供应商尚未响应",
                  reminderCount: 1,
                  reminders: [
                    "08-14 15:41 征询发送",
                    "达到响应时限后自动催办 +1",
                  ],
                },
                {
                  id: "TRANSIT-0157",
                  name: "国网重庆市电力公司长寿供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源不满足",
                  qty: "5.2千米",
                  qtyValue: 5.2,
                  eta: "待项目单位确认",
                  reply: "2025-08-11",
                  distance:
                    "国网重庆长寿公司110kV八菩西13号-20号等线路老旧区段",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0158",
                  name: "国网重庆市电力公司市区供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "4.09千米",
                  qtyValue: 4.09,
                  eta: "待项目单位确认",
                  reply: "2025-08-08",
                  distance:
                    "国网重庆市区公司110kV马桥线综合改造输电线路-架空线路输",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：OPGW光缆 2.1618千米",
                "跨单位调拨匹配 2 条库存记录",
                "协议库存收到 2 条供应商反馈",
                "在途/在建匹配 2 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 4920,
            },
            {
              id: "M17",
              matReqId: "c73171225d5344498295aa1770db600b",
              matnr: "500124806",
              name: "光缆耐张串",
              spec: "120kN,OPGW用单线夹,非绝缘,9.1/10.1",
              need: 10,
              unit: "套",
              filled: 10,
              status: "已确认资源满足",
              statusClass: "done",
              method: "帕尔普线路器材有限公司",
              updated: "08-14 16:25",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0159"],
              sources: [
                {
                  id: "R0159",
                  name: "帕尔普线路器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "10套",
                  qtyValue: 10,
                  eta: "2025-08-20",
                  reply: "08-14 16:21",
                  distance: "北京 · 1750km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0160",
                  name: "南通赛博通信有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "10套",
                  qtyValue: 10,
                  eta: "2025-08-25",
                  reply: "08-14 16:25",
                  distance: "江苏南通 · 2000km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：光缆耐张串 10套",
                "跨单位调拨匹配 0 条库存记录",
                "协议库存收到 2 条供应商反馈",
                "在途/在建匹配 0 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 313,
            },
            {
              id: "M18",
              matReqId: "864260853a764e609a4ea196a44ad79b",
              matnr: "500124828",
              name: "光缆悬垂串",
              spec: "70kN,OPGW用单线夹,非绝缘,9.1/10.1",
              need: 3,
              unit: "套",
              filled: 0,
              status: "等待跨单位确认中",
              statusClass: "waiting",
              method: "已有候选资源待确认",
              updated: "2025-08-12",
              confirmed: !1,
              allowSplit: !0,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: [],
              sources: [
                {
                  id: "U0161",
                  name: "酉阳",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "部分可调拨",
                  qty: "1套",
                  qtyValue: 1,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网酉阳供电公司小坝仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：光缆悬垂串 3套",
                "跨单位调拨匹配 1 条库存记录",
                "协议库存收到 0 条供应商反馈",
                "在途/在建匹配 0 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 320,
            },
            {
              id: "M19",
              matReqId: "c6510dc11af4431788e832700fef0da6",
              matnr: "500022145",
              name: "光缆接头盒",
              spec: "OPGW光缆用,24",
              need: 1,
              unit: "只",
              filled: 0,
              status: "等待跨单位确认中",
              statusClass: "waiting",
              method: "已有候选资源待确认",
              updated: "2025-08-11",
              confirmed: !1,
              allowSplit: !0,
              procure: !1,
              activeChannel: "unit",
              selectedSourceIds: [],
              sources: [
                {
                  id: "U0162",
                  name: "国网重庆市电力公司合川供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "合川公司调控中心信通运检班专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0163",
                  name: "国网重庆市电力公司大足供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "大足公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0164",
                  name: "国网重庆市电力公司永川供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "2只",
                  qtyValue: 2,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "永川公司输电运检中心汇龙基地专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0165",
                  name: "国网重庆市电力公司市区供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "4只",
                  qtyValue: 4,
                  eta: "待项目单位确认",
                  reply: "2025-08-08",
                  distance:
                    "国网重庆市区公司110kV马桥线综合改造输电线路-架空线路输",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0166",
                  name: "国网重庆市电力公司南川供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "2只",
                  qtyValue: 2,
                  eta: "待项目单位确认",
                  reply: "2025-08-11",
                  distance: "110kV北郊线线路大修1.25",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0167",
                  name: "国网重庆市电力公司丰都供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源不满足",
                  qty: "10只",
                  qtyValue: 10,
                  eta: "待项目单位确认",
                  reply: "2025-08-11",
                  distance:
                    "重庆丰都许明寺农光互补项目110kV送出工程农光互补升压站～",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0168",
                  name: "国网重庆市电力公司丰都供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源不满足",
                  qty: "4只",
                  qtyValue: 4,
                  eta: "待项目单位确认",
                  reply: "2025-08-11",
                  distance:
                    "重庆丰都许明寺农光互补项目110kV送出工程农光互补升压站～",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：光缆接头盒 1只",
                "跨单位调拨匹配 3 条库存记录",
                "协议库存收到 0 条供应商反馈",
                "在途/在建匹配 4 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 460,
            },
            {
              id: "M20",
              matReqId: "6c7a3e3875a54ed38fd645c4e2b6ff0d",
              matnr: "500022170",
              name: "光缆余缆架",
              spec: "—",
              need: 2,
              unit: "个",
              filled: 2,
              status: "已确认资源满足",
              statusClass: "done",
              method: "帕尔普线路器材有限公司",
              updated: "2025-08-11",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0174"],
              sources: [
                {
                  id: "U0169",
                  name: "酉阳",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复可调拨",
                  qty: "2个",
                  qtyValue: 2,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网酉阳供电公司小坝仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0170",
                  name: "国网重庆市电力公司黔江供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "6个",
                  qtyValue: 6,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance:
                    "黔江供电公司电力调度控制中心通信自动化信息班调控仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0171",
                  name: "璧山",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "9个",
                  qtyValue: 9,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网璧山区供电公司兴旺正街仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0172",
                  name: "国网重庆市电力公司开州供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "可匹配库存，待确认",
                  qty: "4个",
                  qtyValue: 4,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力开州供电公司调控中心通讯自动班调控仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "可匹配，尚需单位确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0173",
                  name: "国网重庆市电力公司信通分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "信通公司通信建设运维中心昆亚调控仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0174",
                  name: "帕尔普线路器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "2个",
                  qtyValue: 2,
                  eta: "2025-08-20",
                  reply: "08-14 16:21",
                  distance: "北京 · 1750km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0175",
                  name: "国网重庆市电力公司南川供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "5个",
                  qtyValue: 5,
                  eta: "待项目单位确认",
                  reply: "2025-08-11",
                  distance:
                    "国网重庆南川公司密集输电通道巡检站通信建设通信系统-通信线路",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0176",
                  name: "国网重庆市电力公司南川供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "2个",
                  qtyValue: 2,
                  eta: "待项目单位确认",
                  reply: "2025-08-11",
                  distance: "110kV北郊线线路大修1.25",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0177",
                  name: "国网重庆市电力公司市区供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "4个",
                  qtyValue: 4,
                  eta: "待项目单位确认",
                  reply: "2025-08-08",
                  distance:
                    "国网重庆市区公司110kV马桥线综合改造输电线路-架空线路输",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0178",
                  name: "国网重庆市电力公司北碚供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "4个",
                  qtyValue: 4,
                  eta: "待项目单位确认",
                  reply: "2025-08-08",
                  distance: "国网重庆北碚公司110kV玉碚线#21至#31段老旧线路改造",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0179",
                  name: "国网重庆市电力公司丰都供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源不满足",
                  qty: "4个",
                  qtyValue: 4,
                  eta: "待项目单位确认",
                  reply: "2025-08-11",
                  distance:
                    "重庆丰都许明寺农光互补项目110kV送出工程农光互补升压站～",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0180",
                  name: "国网重庆市电力公司丰都供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源不满足",
                  qty: "10个",
                  qtyValue: 10,
                  eta: "待项目单位确认",
                  reply: "2025-08-11",
                  distance:
                    "重庆丰都许明寺农光互补项目110kV送出工程农光互补升压站～",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：光缆余缆架 2个",
                "跨单位调拨匹配 5 条库存记录",
                "协议库存收到 1 条供应商反馈",
                "在途/在建匹配 6 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 151,
            },
            {
              id: "M21",
              matReqId: "4baf1894be1b40098d60343958be09a5",
              matnr: "500141074",
              name: "光缆防振金具",
              spec: "OPGW光缆用,预绞丝式,9.1/10.1",
              need: 20,
              unit: "个",
              filled: 20,
              status: "已确认资源满足",
              statusClass: "done",
              method: "帕尔普线路器材有限公司 ＋ 帕尔普线路器材有限公司",
              updated: "2025-08-08",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0184", "R0186"],
              sources: [
                {
                  id: "U0181",
                  name: "国网重庆市电力公司大足供电分公司",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "大足公司运检部专业仓",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "U0182",
                  name: "永川",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "国网重庆电力永川仓库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0183",
                  name: "石家庄开发区华能电气有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "20个",
                  qtyValue: 20,
                  eta: "2025-08-25",
                  reply: "08-14 18:23",
                  distance: "石家庄 · 1500km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0184",
                  name: "帕尔普线路器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "20个",
                  qtyValue: 20,
                  eta: "2025-08-20",
                  reply: "08-14 16:21",
                  distance: "北京 · 1750km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0185",
                  name: "南通赛博通信有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "20个",
                  qtyValue: 20,
                  eta: "2025-08-25",
                  reply: "08-14 16:25",
                  distance: "江苏南通 · 2000km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0186",
                  name: "帕尔普线路器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "3个",
                  qtyValue: 3,
                  eta: "2025-08-20",
                  reply: "08-14 16:21",
                  distance: "北京 · 1750km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0187",
                  name: "南通赛博通信有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "3个",
                  qtyValue: 3,
                  eta: "2025-08-25",
                  reply: "08-14 16:25",
                  distance: "江苏南通 · 2000km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0188",
                  name: "国网重庆市电力公司市区供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "39个",
                  qtyValue: 39,
                  eta: "待项目单位确认",
                  reply: "2025-08-08",
                  distance:
                    "国网重庆市区公司110kV马桥线综合改造输电线路-架空线路输",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：光缆防振金具 20个",
                "跨单位调拨匹配 2 条库存记录",
                "协议库存收到 5 条供应商反馈",
                "在途/在建匹配 1 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 63,
            },
            {
              id: "M22",
              matReqId: "9c1a4840646644bf8e1ff7a276bb47ea",
              matnr: "500141097",
              name: "光缆卡具",
              spec: "OPGW光缆用,塔用",
              need: 74,
              unit: "个",
              filled: 74,
              status: "已确认资源满足",
              statusClass: "done",
              method: "帕尔普线路器材有限公司",
              updated: "2025-08-11",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0191"],
              sources: [
                {
                  id: "U0189",
                  name: "超高压",
                  type: "跨单位调拨",
                  channelKey: "unit",
                  status: "已回复无可用量",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待调出单位确认",
                  reply: "已完成库存匹配",
                  distance: "应急物资虚拟库",
                  selected: !1,
                  requested: !0,
                  channel: "库存资源匹配",
                  price: "—",
                  risk: "当前记录未形成可用量",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0190",
                  name: "石家庄开发区华能电气有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "74个",
                  qtyValue: 74,
                  eta: "2025-08-25",
                  reply: "08-14 18:23",
                  distance: "石家庄 · 1500km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0191",
                  name: "帕尔普线路器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "74个",
                  qtyValue: 74,
                  eta: "2025-08-20",
                  reply: "08-14 16:21",
                  distance: "北京 · 1750km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0192",
                  name: "南通赛博通信有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "74个",
                  qtyValue: 74,
                  eta: "2025-08-25",
                  reply: "08-14 16:25",
                  distance: "江苏南通 · 2000km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0193",
                  name: "石家庄开发区华能电气有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "2个",
                  qtyValue: 2,
                  eta: "2025-08-25",
                  reply: "08-14 18:23",
                  distance: "石家庄 · 1500km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0194",
                  name: "南通赛博通信有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "2个",
                  qtyValue: 2,
                  eta: "2025-08-25",
                  reply: "08-14 16:25",
                  distance: "江苏南通 · 2000km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0195",
                  name: "石家庄开发区华能电气有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "1个",
                  qtyValue: 1,
                  eta: "2025-08-25",
                  reply: "08-14 18:23",
                  distance: "石家庄 · 1500km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0196",
                  name: "帕尔普线路器材有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "1个",
                  qtyValue: 1,
                  eta: "2025-08-20",
                  reply: "08-14 16:21",
                  distance: "北京 · 1750km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0197",
                  name: "南通赛博通信有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已响应，待确认",
                  qty: "1个",
                  qtyValue: 1,
                  eta: "2025-08-25",
                  reply: "08-14 16:25",
                  distance: "江苏南通 · 2000km",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "回复结果尚未纳入当前组合",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0198",
                  name: "国网重庆市电力公司市区供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "80个",
                  qtyValue: 80,
                  eta: "待项目单位确认",
                  reply: "2025-08-08",
                  distance:
                    "国网重庆市区公司110kV马桥线综合改造输电线路-架空线路输",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0199",
                  name: "国网重庆市电力公司北碚供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "80个",
                  qtyValue: 80,
                  eta: "待项目单位确认",
                  reply: "2025-08-08",
                  distance: "国网重庆北碚公司110kV玉碚线#21至#31段老旧线路改造",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0200",
                  name: "国网重庆市电力公司丰都供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源不满足",
                  qty: "240个",
                  qtyValue: 240,
                  eta: "待项目单位确认",
                  reply: "2025-08-11",
                  distance:
                    "重庆丰都许明寺农光互补项目110kV送出工程农光互补升压站～",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：光缆卡具 74个",
                "跨单位调拨匹配 1 条库存记录",
                "协议库存收到 8 条供应商反馈",
                "在途/在建匹配 3 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 36,
            },
            {
              id: "M23",
              matReqId: "122dcb5499794c999fcd2e2bf8776332",
              matnr: "500163774",
              name: "铁塔防坠落导轨装置",
              spec: "刚性导轨",
              need: 134,
              unit: "米",
              filled: 134,
              status: "已确认资源满足",
              statusClass: "done",
              method: "湖北恒东电力设备有限公司",
              updated: "2025-08-14",
              confirmed: !0,
              allowSplit: !0,
              procure: !1,
              activeChannel: "rush",
              selectedSourceIds: ["R0201"],
              sources: [
                {
                  id: "R0201",
                  name: "湖北恒东电力设备有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "已确认供应",
                  qty: "134米",
                  qtyValue: 134,
                  eta: "2025-08-19",
                  reply: "08-14 16:59",
                  distance: "湖北省孝感市孝南区 · 690km",
                  selected: !0,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "已由运营中心确认",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "R0202",
                  name: "中国电建集团成都电力金具有限公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "未响应",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待供应商确认",
                  reply: "—",
                  distance: "—",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "供应商尚未响应",
                  reminderCount: 1,
                  reminders: [
                    "08-14 15:41 征询发送",
                    "达到响应时限后自动催办 +1",
                  ],
                },
                {
                  id: "R0203",
                  name: "北京国网富达科技发展有限责任公司",
                  type: "应急抢单",
                  channelKey: "rush",
                  status: "未响应",
                  qty: "—",
                  qtyValue: 0,
                  eta: "待供应商确认",
                  reply: "—",
                  distance: "—",
                  selected: !1,
                  requested: !0,
                  channel: "协议库存／供应商反馈",
                  price: "待核价",
                  risk: "供应商尚未响应",
                  reminderCount: 1,
                  reminders: [
                    "08-14 15:41 征询发送",
                    "达到响应时限后自动催办 +1",
                  ],
                },
                {
                  id: "TRANSIT-0204",
                  name: "国网重庆市电力公司南川供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "3067.44米",
                  qtyValue: 3067.44,
                  eta: "待项目单位确认",
                  reply: "2025-08-07",
                  distance: "110kV大宏线等线1.25",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0205",
                  name: "国网重庆市电力公司南川供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "2497米",
                  qtyValue: 2497,
                  eta: "待项目单位确认",
                  reply: "2025-08-07",
                  distance: "固定式防坠导轨2.5",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
                {
                  id: "TRANSIT-0206",
                  name: "国网重庆市电力公司黔江供电分公司",
                  type: "在途/在建",
                  channelKey: "transit",
                  status: "在建资源可匹配，待确认",
                  qty: "2704米",
                  qtyValue: 2704,
                  eta: "待项目单位确认",
                  reply: "2025-08-14",
                  distance:
                    "重庆黔江五福岭二期风电场110kV送出工程五福岭一期、二期升",
                  selected: !1,
                  requested: !0,
                  channel: "在建资源匹配",
                  price: "—",
                  risk: "需项目单位确认资源可释放性",
                  reminderCount: 0,
                  reminders: [],
                },
              ],
              history: [
                "2025-08-12 09:48 解析物资需求：铁塔防坠落导轨装置 134米",
                "跨单位调拨匹配 0 条库存记录",
                "协议库存收到 3 条供应商反馈",
                "在途/在建匹配 3 条资源",
              ],
              deliveryDate: "2025-08-20",
              estimatedUnitPrice: 56,
            },
          ],
          events: [
            {
              time: "08-14 18:23",
              title: "供应商反馈持续汇集",
              copy: "协议库存共收到50条供应商反馈，其中43条已响应或生成结果。",
              level: "important",
            },
            {
              time: "08-14 17:00",
              title: "在建资源匹配完成",
              copy: "共匹配38条在建资源，作为跨单位和供应商资源的备选补充。",
              level: "important",
            },
            {
              time: "08-14 16:00",
              title: "跨单位库存匹配完成",
              copy: "共匹配117条单位库存记录，已形成运营中心确认资源。",
              level: "important",
            },
            {
              time: "08-12 09:48",
              title: "应急任务提报",
              copy: "110kV石拔南线#22铁塔受滑坡影响，需采取杆塔移位进行改造。需要铁塔、OPGW光缆、钢芯铝绞线等物资",
              level: "important",
            },
          ],
          constraints: [
            "优先采用已确认省内资源",
            "未响应不视为拒绝或同意",
            "供应商报价与到货时间以原始反馈为准",
            "缺失字段统一显示待确认",
          ],
          plans: [
            {
              id: "P1",
              name: "当前已确认资源方案",
              desc: "优先采用运营中心已确认的跨单位及协议库存资源。",
              fit: "74%",
              eta: "待确认",
              units: "22个来源",
              risk: "中低",
              cost: "待核价",
              tags: ["已确认资源优先", "省内协同", "结果可追溯"],
              recommended: !0,
            },
            {
              id: "P2",
              name: "省内资源优先方案",
              desc: "优先采用重庆各单位库存及在建项目资源，减少外省供应商依赖。",
              fit: "待评估",
              eta: "待确认",
              units: "待确认",
              risk: "中",
              cost: "待核价",
              tags: ["省内资源优先", "需项目单位确认"],
              recommended: !1,
            },
            {
              id: "P3",
              name: "供应商完整保障方案",
              desc: "对可完整满足的物资采用已确认协议供应商，其他物资保留跨单位资源。",
              fit: "待评估",
              eta: "待确认",
              units: "待确认",
              risk: "中",
              cost: "待核价",
              tags: ["协议库存保障", "需核价"],
              recommended: !1,
            },
          ],
          selectedPlan: "P1",
          decisionConfirmed: !1,
          writeback: !1,
          orders: [],
        },
        assistant: [
          {
            role: "assistant",
            text: "已载入忠县石拔南线#22滑坡应急任务的真实样例数据，共23条有效物资。跨单位调拨匹配117条库存记录，协议库存收到50条供应商反馈，在途/在建匹配39条资源。",
          },
          {
            role: "assistant",
            text: "当前17条物资已由确认资源完整满足，0条部分满足，6条仍需确认或继续寻源。建议先复核OPGW光缆、铁塔、钢芯铝绞线等关键物资的已选来源。",
            action: "可打开任一物资查看真实单位、供应商和在建资源反馈。",
          },
        ],
        noticeTime: "09:48",
      };
      function makeTaskProfile(e, t) {
        const s = deepClone(e),
          a = SAMPLE_DATA.emergencies.find((e) => e.id === t);
        if (
          ((s.title = a.title),
          (s.code = a.code),
          (s.received = a.received),
          (s.selectedDecisionPlan = "time"),
          (s.secondConfirmStarted = !1),
          (s.secondConfirmReady = !1),
          (s.secondConfirmCompleted = !1),
          (s.finalSolutionGenerated = !1),
          (s.secondConfirmRecords = []),
          (s.writeback = !1),
          (s.decisionConfirmed = !1),
          "E001" === t)
        )
          return (
            (s.currentAction = "最终方案已生成，等待业务人员确认并回写原系统"),
            (s.status = "待执行确认"),
            (s.stageIndex = 4),
            (s.selectedDecisionPlan = "time"),
            (s.secondConfirmStarted = !0),
            (s.secondConfirmReady = !0),
            (s.secondConfirmCompleted = !0),
            (s.finalSolutionGenerated = !0),
            (s.decisionConfirmed = !0),
            s
          );
        if ("E002" === t)
          return (
            (s.materials = s.materials.slice(0, 21)),
            (s.description =
              "110kV石拔北线#26铁塔受滑坡影响，需开展杆塔移位改造及配套物资保障。"),
            (s.currentAction =
              "正在回收跨单位、协议库存及在建资源反馈，动态更新候选方案"),
            (s.status = "四渠道寻源中"),
            (s.stageIndex = 2),
            (s.lastUpdate = "2025-08-14 17:36"),
            (s.nextCheck = "3分钟后"),
            (s.counters = {
              sent: 168,
              received: 151,
              replied: 123,
              can: 15,
              partial: 3,
              waiting: 28,
              timeout: 5,
            }),
            s.materials.forEach((e, t) => {
              ((e.confirmed = !1),
                t % 4 == 0
                  ? ((e.selectedSourceIds = []),
                    (e.filled = 0),
                    (e.status = "等待跨单位响应"),
                    (e.statusClass = "running"),
                    (e.method = "跨单位调拨寻源中"),
                    (e.activeChannel = "unit"))
                  : t % 4 == 1
                    ? ((e.status = "应急抢单响应中"),
                      (e.statusClass = "purple"),
                      (e.method = "协议库存供应商待确认"),
                      (e.activeChannel = "rush"))
                    : t % 4 == 2
                      ? ((e.status = "在途/在建确认中"),
                        (e.statusClass = "waiting"),
                        (e.method = "在建资源待项目单位确认"),
                        (e.activeChannel = "transit"))
                      : ((e.status = "资源待复核"),
                        (e.statusClass = "waiting")));
            }),
            (s.events = [
              {
                time: "08-14 17:36",
                title: "跨单位资源反馈持续回收",
                copy: "已收到部分单位库存反馈，智能体正在按业务优先级更新推荐顺序。",
                level: "important",
              },
              {
                time: "08-14 16:48",
                title: "协议库存征询已发送",
                copy: "针对内部资源未满足物资，已向协议供应商通过E物资和短信发送确认请求。",
                level: "important",
              },
              {
                time: "08-12 10:53",
                title: "应急任务提报",
                copy: "110kV石拔北线#26滑坡应急任务进入运营中心。",
                level: "important",
              },
            ]),
            s
          );
        return (
          (s.materials = ["M02", "M06", "M11", "M14", "M20", "M23"]
            .map((e) => s.materials.find((t) => t.id === e))
            .filter(Boolean)),
          (s.description =
            "石拔南、石拔北滑坡应急新增物资补提，需在原任务资源基础上重新开展补充寻源。"),
          (s.currentAction =
            "已完成补提需求解析，正在优先核验实物库存并准备缺口扩展寻源"),
          (s.status = "补提物资寻源中"),
          (s.stageIndex = 2),
          (s.lastUpdate = "2025-08-19 09:24"),
          (s.nextCheck = "1分钟后"),
          (s.deadline = "2025-08-22"),
          (s.counters = {
            sent: 36,
            received: 18,
            replied: 9,
            can: 3,
            partial: 1,
            waiting: 27,
            timeout: 0,
          }),
          s.materials.forEach((e, t) => {
            ((e.confirmed = !1),
              (e.selectedSourceIds = []),
              (e.filled = 0),
              t < 2
                ? ((e.status = "跨单位响应中"),
                  (e.statusClass = "running"),
                  (e.method = "实物库存优先寻源"),
                  (e.activeChannel = "unit"))
                : t < 4
                  ? ((e.status = "应急抢单"),
                    (e.statusClass = "purple"),
                    (e.method = "协议库存补充寻源"),
                    (e.activeChannel = "rush"))
                  : 4 === t
                    ? ((e.status = "在途/在建确认中"),
                      (e.statusClass = "waiting"),
                      (e.method = "在途/在建资源匹配"),
                      (e.activeChannel = "transit"))
                    : ((e.status = "应急采购"),
                      (e.statusClass = "attention"),
                      (e.method = "前序渠道暂未满足"),
                      (e.activeChannel = "purchase"),
                      (e.procure = !0)));
          }),
          (s.events = [
            {
              time: "08-19 09:24",
              title: "补提物资已启动寻源",
              copy: "6条补提物资已完成标准化解析，优先启动实物库存查询。",
              level: "important",
            },
            {
              time: "08-19 09:16",
              title: "需求澄清完成",
              copy: "补提物资编码、规格和需求数量已确认。",
              level: "important",
            },
            {
              time: "08-19 09:08",
              title: "补提任务创建",
              copy: "石拔南、石拔北滑坡应急补提需求进入运营中心。",
              level: "important",
            },
          ]),
          s
        );
      }
      function buildTaskProfiles() {
        const e = deepClone(state.task);
        ((state.taskProfiles = {
          E001: makeTaskProfile(e, "E001"),
          E002: makeTaskProfile(e, "E002"),
          E003: makeTaskProfile(e, "E003"),
        }),
          Object.entries(state.taskProfiles).forEach(([e, t]) =>
            seedReminderScenarios(t, e),
          ));
        const t = state.emergencies || [],
          s = t.find((e) => "E001" === e.id);
        s &&
          Object.assign(s, {
            stage: "最终方案已生成",
            status: "待执行确认",
            statusClass: "attention",
            progress: 94,
            summary: "20条形成执行来源，3条进入兜底处置",
            risk: "最终方案已生成，仍有3条缺口",
            action: "请确认最终方案及缺口处置后回写原系统",
            riskLevel: "green",
            attention: !0,
          });
        const a = t.find((e) => "E002" === e.id);
        a &&
          Object.assign(a, {
            stage: "响应回收与催办",
            status: "智能体执行中",
            statusClass: "running",
            progress: 66,
            summary: "多渠道响应持续回收，方案动态更新",
            risk: "含自动催办、越级催办和待回复对象",
            action: "",
            riskLevel: "amber",
            attention: !1,
          });
        const n = t.find((e) => "E003" === e.id);
        (n &&
          Object.assign(n, {
            stage: "补提物资寻源",
            status: "智能体执行中",
            statusClass: "running",
            progress: 42,
            summary: "6条补提物资按渠道顺序寻源",
            risk: "部分响应可由业务人员手动催办",
            action: "",
            riskLevel: "green",
            attention: !1,
          }),
          (state.taskAssistants = {
            E001: deepClone(state.assistant),
            E002: [
              {
                role: "assistant",
                text: "已进入石拔北线#26滑坡应急任务。当前21条物资正在回收跨单位、协议库存及在建资源反馈。",
              },
              {
                role: "assistant",
                text: "系统将按单位覆盖物料种类、距离、仓库和资源满足情况更新推荐顺序；前序渠道缺口才触发后续寻源。",
              },
            ],
            E003: [
              {
                role: "assistant",
                text: "已进入石拔南、石拔北滑坡应急物资补提任务，共6条补提物资。",
              },
              {
                role: "assistant",
                text: "当前优先核验实物库存；对未满足物资依次触发协议库存、在途/在建和应急采购。",
              },
            ],
          }));
      }
      function switchEmergencyTask(e) {
        state.taskProfiles?.[e] &&
          ((state.selectedEmergency = e),
          (state.task = state.taskProfiles[e]),
          (state.assistant = state.taskAssistants[e]),
          (state.wbTab = "overview"),
          (state.overviewDecisionConfirmed = !1),
          (state.materialFilter = "all"),
          (state.responseChannel = "all"),
          (state.responseSearch = ""),
          (state.responseStatus = "all"),
          (state.responseSort = "E001" === e ? "priority" : "reminder"),
          (state.responsePage = 1),
          (state.selectedMaterial = state.task.materials[0]?.id || null),
          (state.planMaterial = state.selectedMaterial),
          (state.customSelections = {}),
          (state.openPlanId = null),
          normalizeMaterialMethods(),
          state.task.materials.forEach((e, t) =>
            e.sources.forEach((e, s) => ensureSourceNotice(e, t + s)),
          ),
          setView("workbench"),
          showToast(`已进入：${state.task.title}`));
      }
      function applySampleData() {
        const e = SAMPLE_DATA;
        ((state.conversations[0] = {
          title: e.task.title,
          type: "应急任务",
          time: "刚刚",
          messages: 42,
          live: !0,
        }),
          (state.emergencies = e.emergencies),
          (state.selectedEmergency = "E001"),
          Object.assign(state.task, e.task),
          (state.assistant = e.assistant),
          (state.task.secondConfirmStarted = !1),
          (state.task.secondConfirmReady = !1),
          (state.task.secondConfirmCompleted = !1),
          (state.task.finalSolutionGenerated = !1),
          (state.task.secondConfirmRecords = []),
          (state.expandedSecondConfirm = null),
          normalizeMaterialMethods(),
          state.task.materials.forEach((e, t) =>
            e.sources.forEach((e, s) => ensureSourceNotice(e, t + s)),
          ),
          buildTaskProfiles(),
          (state.task = state.taskProfiles.E001),
          (state.assistant = state.taskAssistants.E001),
          (state.selectedMaterial = (
            state.task.materials.find((e) => e.name.includes("OPGW光缆")) ||
            state.task.materials[0]
          ).id),
          (state.planMaterial = state.selectedMaterial),
          (state.responseChannel = "all"),
          (state.materialFilter = "all"),
          (state.customSelections = {}));
        const t = document.querySelector(".emergency-notice-title");
        t && (t.textContent = e.task.title);
        const s = document.querySelector(".emergency-notice-sub");
        s &&
          (s.textContent =
            "检测到需要关注的应急物资保障任务，智能体已载入样例数据并完成多渠道资源匹配。");
        const a = document.querySelectorAll(".emergency-notice-meta strong");
        a.length >= 4 &&
          ((a[0].textContent = e.task.code),
          (a[1].textContent = e.task.unit),
          (a[2].textContent = e.task.source),
          (a[3].textContent = e.task.received));
        const n = document.querySelector(".emergency-notice-time");
        n && (n.textContent = e.noticeTime);
        const i = document.querySelector(".emergency-notice-progress p");
        i && (i.textContent = e.task.currentAction + "。");
        const r = document.querySelector(".emergency-home-banner-copy strong");
        r && (r.textContent = "1 个应急任务需要关注：" + e.task.title);
        const l = document.querySelector(".emergency-home-banner-copy p");
        l &&
          (l.textContent = `已载入${e.task.materials.length}条有效物资，正在确认已匹配的跨单位、供应商及在建资源组合。`);
        const d = document.getElementById("emergencyBadge");
        d && (d.textContent = e.emergencies.length);
        const c = document.getElementById("notificationCount");
        c && (c.textContent = "4");
        const o = document.querySelectorAll(".notification-item-copy p");
        o.length >= 4 &&
          ((o[0].textContent =
            "忠县石拔南线#22滑坡应急已有确认资源，需要复核物资组合。"),
          (o[1].textContent =
            "未响应供应商保留自动催办状态，完整时间线可在物资详情中查看。"),
          (o[2].textContent =
            "已完成跨单位库存、协议库存供应商和在建资源匹配。"),
          (o[3].textContent =
            "手工提报的忠县应急任务已进入独立应急任务工作台。"));
      }
      function init() {
        (normalizeEmergencySourcing(),
          applySampleData(),
          initAgentSouls(),
          enrichAgentData(),
          normalizeAgentState(),
          initAgentSouls(),
          initKnowledgeState(),
          renderRecent(),
          renderChatTable(),
          renderAgents(),
          renderSchedules(),
          renderEmergencyTable(),
          renderWorkbench(),
          renderKnowledge(),
          bindGlobal(),
          bindAgentManagement(),
          initEmergencyHomeNotice(),
          document.addEventListener("keydown", (e) => {
            "Escape" === e.key &&
              ($$(".overlay.show").forEach((e) => closeOverlay(e.id)),
              hideEmergencyHomeNotice(),
              $("#notificationPanel")?.classList.remove("show"),
              $("#notificationBtn")?.classList.remove("open"));
          }),
          setInterval(autoTick, 1e3));
      }

/* Source runtime block 2 */
!(function () {
        const e = {
            unit: "跨单位调拨",
            rush: "应急抢单",
            transit: "在途／在建",
            purchase: "应急采购",
          },
          t = {
            unit: "系统内单位",
            rush: "外部供应商",
            transit: "项目及订单责任单位",
            purchase: "应急采购资源",
          };
        function a(e, t) {
          const a = sourceEtaValue(t);
          if (a === Number.MAX_SAFE_INTEGER) return 1;
          const s = String(e.deliveryDate || state.task.deadline || "");
          if (!s) return 0;
          const n = new Date(s).getTime();
          return Number.isFinite(n) && a > n ? 1 : 0;
        }
        function s(e) {
          const t = Number(e.stockAgeDays ?? e.ageDays ?? 0);
          return -Math.max(0, t);
        }
        ((window.sourcePriorityTuple = function (e, t) {
          const n = ownerCoverageCount(t.name, t.channelKey),
            r = sourceDistanceValue(t),
            i = (t.qtyValue || 0) >= e.need ? 0 : 1,
            d = (function (e) {
              const t = String(e.extensionCode ?? e.extCode ?? "").trim();
              return "" === t || "000" === t ? 0 : 1;
            })(t),
            c = sourceEtaValue(t);
          return "unit" === t.channelKey
            ? [-n, r, d, sourceWarehouseRank(t), sourceTypeRank(t), i, s(t)]
            : "rush" === t.channelKey
              ? [d, i, a(e, t), c, r]
              : "transit" === t.channelKey
                ? [-n, r]
                : [9, i, c, r];
        }),
          (window.openMaterial = function (e) {
            ((state.selectedMaterial = e),
              (state.drawerTab = "sources"),
              (state.drawerChannel = null),
              (state.expandedSourceId = null),
              renderMaterialDrawer(),
              openOverlay("materialDrawer"));
          }),
          (window.renderMaterialDrawer = function () {
            const a = state.task.materials.find(
              (e) => e.id === state.selectedMaterial,
            );
            if (!a) return;
            state.drawerTab = state.drawerTab || "sources";
            const s = (a.sources || []).filter((e) => !1 !== e.requested),
              n = (function (e) {
                const t = (e.sources || []).filter((e) => !1 !== e.requested);
                if (
                  e.activeChannel &&
                  t.some((t) => t.channelKey === e.activeChannel)
                )
                  return e.activeChannel;
                const a = selectedSources(e);
                return a.length
                  ? a[0].channelKey
                  : ["unit", "rush", "transit", "purchase"].find((e) =>
                      t.some((t) => t.channelKey === e),
                    ) || "unit";
              })(a),
              r = s.filter((e) => e.channelKey === n),
              i = groupSourcesByOwner(r).sort((e, t) =>
                compareSourceGroups(a, e, t),
              ),
              d = selectedSources(a),
              c = groupSourcesByOwner(d),
              o = d.reduce((e, t) => e + (t.qtyValue || 0), 0),
              l = Math.max(0, roundQty(a.need - a.filled)),
              u = selectedLatestEta(d);
            (($("#drawerMaterialTitle").textContent = a.name),
              ($("#drawerMaterialMeta").textContent =
                `${a.spec} · 需求${a.need}${a.unit} · ${a.status}`),
              ($("#drawerMaterialSummary").innerHTML = ""),
              ($("#drawerFooterSummary").innerHTML =
                `<span>已选 ${c.length} 个来源 · ${roundQty(o)}${a.unit}</span><b>预计最晚到货：${u}</b>`),
              $$("#materialDrawer [data-drawer-tab]").forEach((e) =>
                e.classList.toggle(
                  "active",
                  e.dataset.drawerTab === state.drawerTab,
                ),
              ));
            let v = "";
            if ("sources" === state.drawerTab) {
              const s = (function (e, t, a) {
                  const s = a
                      .filter((e) => e.sources.some(sourceSelectable))
                      .reduce((e, t) => e + t.qtyValue, 0),
                    n = e.need,
                    r = Math.max(0, roundQty(n - s));
                  return "unit" === t
                    ? s >= n
                      ? "现有系统内实物库存已满足需求，可选择资源并进行人工确认。"
                      : `系统内实物库存当前可满足${roundQty(s)}${e.unit}，仍缺${r}${e.unit}；缺口确认后再启动外部供应商寻源。`
                    : "rush" === t
                      ? s >= n
                        ? "外部供应商反馈已覆盖当前缺口，可选择供应商并进行人工确认。"
                        : `外部供应商当前可满足${roundQty(s)}${e.unit}，仍缺${r}${e.unit}，智能体将继续回收E物资响应。`
                      : "transit" === t
                        ? s >= n
                          ? "在途／在建资源已覆盖当前缺口，待责任单位确认资源可释放性。"
                          : `在途／在建资源当前可匹配${roundQty(s)}${e.unit}，仍缺${r}${e.unit}。`
                        : "前序渠道暂未形成可执行组合，当前进入应急采购兜底。";
                })(a, n, i),
                r = i
                  .slice(0, 12)
                  .map((e, t) => {
                    const s = e.ids.every((e) =>
                        (a.selectedSourceIds || []).includes(e),
                      ),
                      n = e.sources.some(sourceSelectable),
                      r = state.expandedSourceId === e.key,
                      i = sourceGroupStatus(e),
                      d = e.sources[0],
                      c = selectedLatestEta(e.sources),
                      o = (function (e, t, a) {
                        return t.ids.every((t) =>
                          (e.selectedSourceIds || []).includes(t),
                        )
                          ? "已纳入方案"
                          : 0 === a
                            ? "推荐优先"
                            : t.qtyValue >= e.need
                              ? "可完整满足"
                              : t.qtyValue > 0
                                ? "可作为补充"
                                : "继续跟踪";
                      })(a, e, t),
                      l = ensureSourceNotice(d, t),
                      u = e.sources
                        .map(
                          (e) =>
                            `<div class="candidates-record-row"><b>${e.id}</b><b>${e.qty}</b><b>${e.distance || e.channel || "—"}</b></div>`,
                        )
                        .join("");
                    return `<article class="candidates-candidate-card ${s ? "selected" : ""} ${n ? "" : "disabled"}" data-candidates-group-card="${e.ids.join("|")}"><div class="candidates-candidate-head"><div class="candidates-candidate-name"><strong><span class="candidates-candidate-rank">${0 === t ? "推荐优先" : `候选${t + 1}`}</span>${e.name}</strong><small>${(function (
                      e,
                    ) {
                      const t = e.sources[0];
                      var a;
                      return `${"unit" === (a = e.channelKey) || "transit" === a ? "单位资源" : "供应商资源"} · ${t.distance || t.channel || "距离待确认"}`;
                    })(
                      e,
                    )}</small></div><span class="response-status ${responseTone(i)}">${i}</span></div><div class="candidates-candidate-metrics"><div class="candidates-candidate-metric"><span>可供数量</span><b>${e.qtyValue || "—"}${e.qtyValue ? a.unit : ""}</b></div><div class="candidates-candidate-metric"><span>最早到货</span><b>${c}</b></div><div class="candidates-candidate-metric"><span>回复时间</span><b>${d.reply || "—"}</b></div><div class="candidates-candidate-metric"><span>推荐判断</span><b>${o}</b></div></div><div class="candidates-candidate-foot"><span>${sourceNoticeMethod(d)} · ${sourceReminderSummary(d)}</span><div class="candidates-candidate-actions"><button data-candidates-detail="${e.key}">${r ? "收起" : "详情"}</button><button class="${s ? "selected" : ""}" data-candidates-select="${e.ids.join("|")}" data-candidates-action="${s ? "cancel" : "select"}" ${n ? "" : "disabled"}>${s ? "取消" : "选择"}</button></div></div>${r ? `<div class="candidates-expanded-detail"><dl class="candidates-detail-grid"><dt>通知对象</dt><dd>${l.target}</dd><dt>通知方式</dt><dd>${sourceNoticeMethod(d)}</dd><dt>发送时间</dt><dd>${l.sentAt}</dd><dt>确认截止</dt><dd>${l.deadline}</dd><dt>当前状态</dt><dd>${i}</dd></dl>${e.sources.length > 1 ? `<div class="candidates-records"><div class="candidates-record-row"><b>记录编号</b><b>可供数量</b><b>库存地点／项目／协议信息</b></div>${u}</div>` : ""}</div>` : ""}</article>`;
                  })
                  .join("");
              v = `<div class="candidates-judgement"><b>当前判断：</b><span>${s}</span></div><div class="candidates-stage-note"><h4>${e[n]}候选资源</h4><span>当前只展示${t[n]}，按业务规则顺序排列</span></div><div class="candidates-candidate-list">${r || `<div class="candidates-empty">当前阶段暂无${t[n]}响应。<br>可继续等待，或根据业务判断转入下一寻源渠道。</div>`}</div>`;
            } else if ("evidence" === state.drawerTab) {
              const e = (function (e, t) {
                const a = [];
                return (
                  (e.history || []).forEach((e) =>
                    a.push({
                      time: String(e).slice(0, 16),
                      title: String(e).replace(/^\S+\s*/, "") || "任务更新",
                      copy: "已写入当前物资过程记录。",
                    }),
                  ),
                  t.slice(0, 6).forEach((e, t) => {
                    const s = e.sources[0];
                    sourceNoticeTimeline(s, t)
                      .concat(sourceReminderTimeline(s))
                      .filter((e, t, a) => a.indexOf(e) === t)
                      .forEach((t) =>
                        a.push({
                          time: t.slice(0, 11),
                          title: `${e.name}：${t.replace(/^\S+\s*/, "")}`,
                          copy: `通知方式：${sourceNoticeMethod(s)}；当前状态：${sourceGroupStatus(e)}。`,
                        }),
                      );
                  }),
                  a.slice(-18).reverse()
                );
              })(a, i);
              v = `<section class="candidates-section-card"><h4>当前物资过程证据</h4><div class="candidates-timeline">${e.map((e) => `<div class="candidates-timeline-item"><time>${e.time}</time><strong>${e.title}</strong><p>${e.copy}</p></div>`).join("") || '<div class="candidates-empty">暂无过程证据</div>'}</div></section>`;
            } else {
              const e = (function (e) {
                const t = (e.history || [])
                  .filter((e) =>
                    /选择|取消|确认|等待|采购|调整|替换|补足|方案/.test(e),
                  )
                  .map((e) => ({
                    time: String(e).slice(0, 16),
                    text: String(e).replace(/^\S+\s*/, ""),
                  }));
                return (
                  t.length ||
                    t.push({
                      time: "当前",
                      text: "尚无人工调整记录，候选资源仍按智能推荐顺序展示。",
                    }),
                  t.reverse()
                );
              })(a);
              v = `<section class="candidates-section-card"><h4>人工选择与智能体调整记录</h4>${e.map((e) => `<div class="candidates-change-row"><time>${e.time}</time><span>${e.text}</span></div>`).join("")}</section><section class="candidates-section-card"><h4>当前组合结果</h4><div class="candidates-change-row"><time>已选来源</time><span>${c.length ? c.map((e) => e.name).join("、") : "尚未选择"}</span></div><div class="candidates-change-row"><time>数量变化</time><span>需求${a.need}${a.unit}，已选${roundQty(o)}${a.unit}，剩余缺口${l}${a.unit}</span></div><div class="candidates-change-row"><time>预计到货</time><span>${u}</span></div></section>`;
            }
            (($("#materialDrawerBody").innerHTML = v),
              ($("#materialConfirm").disabled =
                a.confirmed || a.filled < a.need),
              ($("#materialConfirm").textContent = a.confirmed
                ? "已确认"
                : "确认该物资"),
              ($("#materialProcure").disabled = "purchase" === a.activeChannel),
              $$("#materialDrawer [data-drawer-tab]").forEach(
                (e) =>
                  (e.onclick = () => {
                    ((state.drawerTab = e.dataset.drawerTab),
                      renderMaterialDrawer());
                  }),
              ),
              $$("#materialDrawerBody [data-candidates-detail]").forEach(
                (e) =>
                  (e.onclick = (t) => {
                    (t.stopPropagation(),
                      (state.expandedSourceId =
                        state.expandedSourceId === e.dataset.candidatesDetail
                          ? null
                          : e.dataset.candidatesDetail),
                      renderMaterialDrawer());
                  }),
              ),
              $$("#materialDrawerBody [data-candidates-select]").forEach(
                (e) =>
                  (e.onclick = (t) => {
                    (t.stopPropagation(),
                      selectSourceGroup(
                        a.id,
                        e.dataset.candidatesSelect.split("|"),
                        "select" === e.dataset.candidatesAction,
                      ));
                  }),
              ),
              $$("#materialDrawerBody [data-candidates-group-card]").forEach(
                (e) =>
                  (e.onclick = (t) => {
                    if (
                      t.target.closest("button") ||
                      e.classList.contains("disabled")
                    )
                      return;
                    const s = e.dataset.candidatesGroupCard.split("|"),
                      n = s.every((e) =>
                        (a.selectedSourceIds || []).includes(e),
                      );
                    selectSourceGroup(a.id, s, !n);
                  }),
              ));
          }));
        const n = window.assistantAction;
        window.assistantAction = function (e) {
          if (
            e.includes("查看光缆") &&
            (e.includes("响应") || e.includes("单位") || e.includes("供应商"))
          ) {
            const e =
              state.task.materials.find((e) => e.name.includes("OPGW光缆")) ||
              state.task.materials[0];
            return (
              (state.selectedMaterial = e.id),
              (state.wbTab = "materials"),
              renderWorkbench(),
              openMaterial(e.id),
              state.assistant.push({
                role: "assistant",
                text: "已打开覆盖式物资详情。当前候选资源按该物资所处寻源阶段展示，不会将系统内单位与外部供应商平级混排。",
              }),
              void renderAssistant()
            );
          }
          return n(e);
        };
      })();
