/* 高频场景的任务线程：仓储（库存消纳，市北）与履约（订单问询、催货与延期处置，市区）。
   账号：C 仓储专责、D 运检部计划提报人、E 物资部主任（市北）；F 履约专责、G 项目管理人员（市区）；A 物资公司管理人员。
   每条线程由 SCENES[id] 定义：intro 开场、right 右侧画布、act 按钮（data-em-act="s-…"）、input 表单、reply 输入框回复。
   数据只从 window.SCENE_DATA 取。 */
(() => {
  const EM = window.EM;
  const DATA = window.SCENE_DATA;
  if (!EM || !DATA) return;
  const { h, say, later, confirm, draw, left, right, finish, toast } = EM;
  const LY = DATA.lvyue;
  const CC = DATA.cangchu;

  /* 跨线程的业务状态 */
  const G = { w2: false, w2At: "", w2Txt: "", w2Pass: 0, w2Seg: 0, w3: "", w4: false, w6b: "", w6: "", l2up: false, l5: "", l4: false, cz: "", l6fb: "" };

  /* ---------- 通用小件 ---------- */

  const num = (n, d = 2) => Number(n).toLocaleString("zh-CN", { maximumFractionDigits: d });
  const wan = (n) => `${num(n / 10000, 2)} 万元`;
  const yuan = (n) => `${num(n, 2)} 元`;
  const supName = (o) => (LY.实名 ? o.供应商 : o.供应商名);
  const mono = (v) => `<span class="em-mono">${h(v)}</span>`;
  const chip = (t, tone = "") => `<span class="sc-chip ${tone}">${h(t)}</span>`;
  const btn = (t, a, kind = "", dis = false) => `<button class="em-btn ${kind === "p" ? "em-btn-p" : kind === "w" ? "em-btn-w" : ""}" data-em-act="${a}" ${dis ? "disabled" : ""}>${h(t)}</button>`;

  function tbl(head, rows, cls = "") {
    return `<div class="sc-tw"><table class="sc-t ${cls}"><thead><tr>${head.map((x) => `<th>${h(x)}</th>`).join("")}</tr></thead><tbody>${rows
      .map((r) => (r.html ? r.html : `<tr${r.cls ? ` class="${r.cls}"` : ""}>${r.map((c) => `<td>${c}</td>`).join("")}</tr>`))
      .join("")}</tbody></table></div>`;
  }
  function kpis(list) {
    return `<div class="sc-kpis">${list.map((k) => `<div class="sc-kpi ${k.tone || ""}"><b>${h(k.v)}</b><span>${h(k.k)}</span>${k.s ? `<small>${h(k.s)}</small>` : ""}</div>`).join("")}</div>`;
  }
  function page(title, sub, body, acts = "") {
    return `<div class="sc-page"><div class="sc-ph"><div><h3>${h(title)}</h3>${sub ? `<p>${sub}</p>` : ""}</div>${acts ? `<div class="sc-ph-r">${acts}</div>` : ""}</div>${body}</div>`;
  }
  const sec = (title, body, extra = "") => `<section class="sc-sec"><h4>${title}${extra}</h4>${body}</section>`;
  const kv = (rows) => `<dl class="sc-kv">${rows.map((r) => `<div><dt>${h(r[0])}</dt><dd>${r[1]}</dd></div>`).join("")}</dl>`;
  const empty = (t) => `<div class="sc-empty">${h(t)}</div>`;

  /* 思维链逐行出现；结束后执行 done */
  function stream(T, title, rows, done, gap = 650) {
    T.busy = true;
    const m = say(T, { k: "chain", title, items: [], live: true });
    rows.forEach((r, i) =>
      later(T, gap * (i + 1), () => {
        m.items.push(r);
        left(T);
      }),
    );
    later(T, gap * (rows.length + 1), () => {
      m.live = false;
      T.busy = false;
      if (done) done();
      draw(T);
    });
    return m;
  }

  /* 已发生过的思维链（回看历史时用） */
  const past = (T, title, rows) => say(T, { k: "chain", title, items: rows });

  function show(id) {
    const it = (window.homeBriefFocusItems || []).find((x) => x.id === id);
    if (it && it.dynamic) {
      it.dynamic = false;
      EM.refreshHome();
    }
  }

  /* ---------- 首页事项 ---------- */

  const ITEMS = [
    /* D 运检部计划提报人 */
    { id: "W2", who: "D", cat: "需求计划提报", title: "11月需求计划提报", status: "pending", entry: { sys: "ERP", menu: "采购申请平衡利库" },
      object: `${CC.项目}｜需求月份 ${CC.月份}`, current: "待上传设计物资清单", deadline: "10月20日", remain: "剩余5天",
      risk: "逾期未提报的需求不能纳入11月采购批次", impact: "影响观音桥片区配网改造按期开工", advice: "上传设计物资清单，逐行确认可利库物资后提交，通过后直传 ERP", reason: "提报待办｜截止临近" },
    { id: "W6B", who: "D", cat: "不利库原因补填", title: "补填不利库原因", status: "pending", entry: { sys: "ERP", menu: "采购申请平衡利库" },
      object: `采购申请 ${CC.erp直提.采购申请}｜行 ${CC.erp直提.行}｜${CC.erp直提.项目}`, current: "ERP 审批已挂起，待补原因", deadline: "补填后放行", remain: "审批挂起中",
      risk: "本单位有可利库物资，计划未经资源池匹配", impact: "不补原因，采购申请停在审批环节", advice: "采纳利库，或选不利库原因并说明", reason: "补填待办｜审批挂起" },
    { id: "W7", who: "D", cat: "仓储数据填报", title: "借用物资与11月消纳计划填报", status: "pending",
      object: "借用单 3 张｜消纳物资 2 项", current: "待运检部填报", deadline: "10月17日", remain: "剩余2天",
      risk: "未用完的借用物资不进资源池，别的部门看不到", impact: "影响资源池完整性和消纳计划跟踪", advice: "填写借用物资已用数量，填写拟用项目、使用时间和责任人", reason: "填报待办｜仓储专责发起" },
    { id: "W1V", who: "D", cat: "资源池", title: "本单位可利库资源池", status: "running",
      object: `${num(CC.pool.total, 0)} 条｜仓储专责共享`, current: "本周已更新", deadline: "每周一08:00", remain: "下次更新10月19日",
      risk: "—", impact: "提报需求计划前可先查本单位库存", advice: "按物料、段长、库存地点查看可利库物资", reason: "资源池｜仓储专责共享" },
    /* C 仓储专责 */
    { id: "W3", who: "C", cat: "不利库原因审核", title: "不利库原因审核", status: "pending", dynamic: true,
      object: `运检部｜采购申请 ${CC.采购申请}｜行 30`, current: "提报人选「库存有损坏」，待专责审核", deadline: "今日17:00", remain: "剩余6小时",
      risk: "不利库原因没有可核验的数据", impact: "审核后报物资部主任审批", advice: "核对提报人说明和退役试验记录，认定不利库或驳回", reason: "审核待办｜转专责" },
    { id: "W1", who: "C", cat: "资源池", title: "本单位可利库资源池", status: "running",
      object: `${num(CC.pool.total, 0)} 条｜实体库、代保管库、借用库、专业仓`, current: "本周已更新", deadline: "每周一08:00", remain: "下次更新10月19日",
      risk: `专业仓已超期 ${num(CC.超期.find((o) => o.来源 === "专业仓").已超期, 0)} 条`, impact: "资源池是提报匹配、应急备查和消纳计划的底数", advice: "查看资源池和应急备查看板，按部门共享", reason: "资源池｜每周更新" },
    { id: "W5", who: "C", cat: "消纳计划", title: "消纳计划跟踪", status: "running",
      object: `${CC.消纳.部门.length} 个部门｜${CC.消纳.总} 项`, current: "江北中心 8 项未填拟用项目", deadline: "10月17日", remain: "剩余2天",
      risk: `${CC.消纳.超期} 项已超过库龄规定期限`, impact: "超期未消纳的物资计入长库龄物资考核", advice: "催办江北中心补填或归还，跟踪已超期物资", reason: "跟踪｜提前量不足" },
    /* E 物资部主任 */
    { id: "W4", who: "E", cat: "不利库审批", title: "不利库审批（10月）", status: "pending",
      object: "本月待审批 14 条", current: "待主任审批", deadline: "10月16日", remain: "剩余1天",
      risk: "不利库原因随意选择难以追究", impact: "审批结果回写 ERP", advice: "数据核验通过的整组审批，专责认定的逐条看", reason: "审批待办｜分组" },
    { id: "W6", who: "E", cat: "ERP直接提报", title: "ERP 直接提报未经匹配", status: "pending", entry: { sys: "ERP", menu: "采购申请审批" },
      object: `运检部｜采购申请 ${CC.erp直提.采购申请}｜${CC.erp直提.项目}`, current: "ERP 审批已挂起，待提报人补原因", deadline: "补原因后放行", remain: "挂起中",
      risk: "本单位库存有 3×400 电缆可以大代小，计划绕开了工作台匹配", impact: "未补原因前不放行", advice: "等提报人补原因后判定放行或驳回", reason: "管控｜审批挂起" },
    /* F 市区履约专责 */
    { id: "L2", who: "F", cat: "问询答复", title: "10月问询答复分级", status: "pending", entry: { sys: "e物资", menu: "问询回复" },
      object: `${LY.分级.订单} 张订单｜${LY.问询.供应商} 家供应商`, current: `答复已收回，提级管控及以上 ${LY.分级.提级管控 + LY.分级.三级履约协调 + LY.分级.违约处理} 张待确认`, deadline: "今日", remain: "今日收回",
      risk: `三级履约协调 ${LY.分级.三级履约协调} 张、违约处理 ${LY.分级.违约处理} 张`, impact: "超期订单影响工程施工", advice: "只处理提级管控及以上的订单：确认是否提级、确认处置方式", reason: "风险｜答复收回" },
    { id: "L4", who: "F", cat: "延期处置", title: `订单 ${LY.孟邦.订单} 超期处置`, status: "pending", entry: { sys: "ECP", menu: "合同履约管理" },
      object: `${supName(LY.孟邦)}｜防火堵料 6 行`, current: "处置材料已起草，待确认处置方式", deadline: "今日", remain: "已超期3—7天",
      risk: "问询和电话催货均未给出交货日期", impact: "6 个业扩配套项目缺防火封堵材料", advice: "确认约谈与考核方式，下发约谈通知", reason: "风险｜违约处理" },
    { id: "L3", who: "F", cat: "催货与开票", title: "今日催货与开票提醒", status: "running", entry: { sys: "e物资", menu: "催货、开票提醒" },
      object: `待交货 ${LY.催货.订单} 张订单｜${LY.催货.供应商} 家供应商`, current: "今日催货已发送", deadline: "每日08:00", remain: "自动执行",
      risk: `已超期 ${LY.催货.超期订单} 张订单`, impact: "交货后 30 天未开票影响结算", advice: "查看今日催货和开票提醒发送情况", reason: "自动｜每日" },
    { id: "L1", who: "F", cat: "问询清单", title: "10月问询清单", status: "done", entry: { sys: "e物资", menu: "问询发布" },
      object: `${LY.问询.订单} 张订单｜${LY.问询.供应商} 家供应商`, current: "10月10日已发出，15日收回", deadline: "10月15日", remain: "已完成",
      risk: "—", impact: "问询结果用于分级管控", advice: "回看问询清单和确认过程", reason: "已完成｜10月10日" },
    /* G 市区项目管理人员 */
    { id: "L6", who: "G", cat: "项目物资进度", title: "百士特 10kV 业扩配套工程物资进度", status: "pending", entry: { sys: "ECP", menu: "供应计划查询" },
      object: `${LY.项目.订单} 张订单｜${LY.项目.行} 行`, current: `待交货 ${LY.项目.状态.待交货} 张已超期，11月16日交货 ${LY.项目.状态.已确认} 张待确认收货`, deadline: "10月17日", remain: "剩余2天",
      risk: "防火堵料供应商未答复，已转违约处理", impact: "影响 10kV 业扩送电时间", advice: "确认 11 月 16 日到货订单的收货安排，反馈防火堵料对工期的影响", reason: "进度｜收货确认" },
    /* A 物资公司管理人员 */
    { id: "L5", who: "A", cat: "三级履约协调", title: "市区供电分公司申请三级履约协调", status: "pending", dynamic: true, entry: { sys: "ECP", menu: "合同履约管理" },
      object: `${supName(LY.万马)}｜订单 ${LY.万马.订单}｜${wan(LY.万马.金额)}`, current: "待物资公司受理", deadline: "今日17:00", remain: "剩余6小时",
      risk: "已超确定交货期 5 天，用于重点用户业扩配套工程", impact: "影响芯联微电子 220kV 业扩送电", advice: "查看全省在途订单，受理并约谈供应商", reason: "风险｜三级协调" },
  ];

  /* ---------- 首页重点事项摘要 ---------- */

  const pjName = () => "百士特 10kV 业扩配套工程";

  function lines(arr) {
    return `<ol class="fouranalysis-focus-lines">${arr.map((x, i) => `<li><b>${i + 1}. ${h(x[0])}：</b>${h(x[1])}</li>`).join("")}</ol>`;
  }
  function summary(who) {
    let arr = null;
    if (who === "D")
      arr = [
        [G.w2 ? "11月需求计划已提交" : "11月需求计划待提报", G.w2 ? `采购申请 ${CC.采购申请} 已传 ERP ${G.w2Pass} 行，行 30 由仓储专责审核` : `${CC.项目}，10月20日截止；上传设计物资清单后逐行确认可利库物资`],
        [G.w6b ? "采购申请 3806513044 已放行" : `采购申请 ${CC.erp直提.采购申请} 审批已挂起`, G.w6b ? "已补填原因并回写 ERP" : "09:12 在 ERP 直接提报，本单位库存有 3×400 电缆可以大代小；补原因或采纳利库后放行"],
        ["借用物资和消纳计划待填报", "借用单 3 张填已用数量，2 项物资填拟用项目和使用时间，10月17日截止"],
      ];
    if (who === "C")
      arr = [
        G.w2 ? (G.w3 ? ["不利库原因审核已完成", "运检部行 30 已报主任审批"] : ["运检部 1 行不利库原因待审核", "采购申请 3806512870 行 30 变压器选「库存有损坏」，退役试验记录已调出"]) : ["本单位资源池本周已更新", `${num(CC.pool.total, 0)} 条，需求部门已填借用物资 ${CC.pool.借用填报} 条`],
        [`消纳计划 ${CC.消纳.总} 项已超过规定期限`, "江北中心 8 项借用物资超过 12 个月，未填拟用项目"],
        [`本周应急备查看板已生成`, `应急库 ${CC.应急.count} 条，按物资类别汇总，可保存图片转发应急抢修群`],
      ];
    if (who === "E")
      arr = [
        [G.w4 ? "10月不利库审批已完成" : "本月不利库待审批 14 条", G.w4 ? "审批结果已回写 ERP" : "数据核验通过 9 条可整组审批；专责认定 4 条逐条看"],
        [G.w6 === "release" ? "ERP 直接提报已放行" : "ERP 直接提报未经匹配 1 条", G.w6 === "release" ? "提报人已补原因" : `运检部采购申请 ${CC.erp直提.采购申请} 审批已挂起，等提报人补原因`],
      ];
    if (who === "F") {
      const up = LY.分级.提级管控 + LY.分级.三级履约协调 + LY.分级.违约处理;
      arr = [
        ["10月问询答复已收回", `${LY.分级.订单} 张订单：三级履约协调 ${LY.分级.三级履约协调} 张、违约处理 ${LY.分级.违约处理} 张、提级管控 ${LY.分级.提级管控} 张，共 ${up} 张待确认；${LY.分级.未回复供应商} 家未回复`],
        [`订单 ${LY.孟邦.订单} 超期 3—7 天`, `${supName(LY.孟邦)}防火堵料 6 行未交货，约谈提纲等 5 份处置材料已起草`],
        ["今日催货、开票提醒已发送", `确定交货期 10月25日的订单已催货；${LY.催货.超期订单} 张订单已超期`],
      ];
    }
    if (who === "G") {
      const P = LY.项目;
      arr = [
        [`${pjName()}物资进度`, `${P.订单} 张订单：已验收 ${P.状态.已验收} 张，待交货 ${P.状态.待交货} 张已超确定交货期，11月16日交货 ${P.状态.已确认} 张`],
        [G.l6fb ? "防火堵料影响已反馈履约专责" : "防火堵料供应商未答复", G.l6fb ? "已写入订单 4500953501 约谈提纲" : `订单 ${LY.孟邦.订单} 已转违约处理，履约专责拟10月17日约谈；请反馈对工期的影响`],
        ["收货确认待回复", `${P.状态.已确认} 张订单 11月16日交货，10月17日前确认是否按原计划收货`],
      ];
    }
    if (who === "A" && G.l2up)
      return `<section class="homebrief-analysis fouranalysis-focus-analysis"><div class="homebrief-analysis-head"><strong>重点事项</strong><span>5项需优先关注</span></div><ol class="fouranalysis-focus-lines"><li><b>1. 市区供电分公司申请三级履约协调：</b>${h(supName(LY.万马))}订单 ${LY.万马.订单}（${h(wan(LY.万马.金额))}）已超期 5 天，用于芯联微电子 220kV 业扩配套；建议今日受理并约谈供应商。</li><li><b>2. 迎峰度夏重点工程采购批次2026-08流标：</b>距要求到货仅剩18天，按常规重新采购预计晚5天；建议今日16:00前确认加急采购方式或并入最近可执行批次。</li><li><b>3. 重庆北部500千伏输变电工程关键物资到货：</b>主变压器尚未确认发货，10千伏开关柜和电力电缆交期存在不确定性；建议今日确认主变发货时间并准备两类物资替代来源。</li><li><b>4. 南岸配网工程电力电缆抽检不合格：</b>质量抽检单Q-2026-071仍待确认复检与退换货方案；建议今日15:30前完成处置，避免影响8月20日施工备料。</li><li><b>5. 忠县石拔南线#22滑坡应急：</b>23项需求已完成多渠道寻源，OPGW光缆等3项方案差异等待确认；建议确认后立即生成寻源报告并启动调拨。</li></ol></section>`;
    if (!arr) return "";
    return `<section class="homebrief-analysis fouranalysis-focus-analysis"><div class="homebrief-analysis-head"><strong>重点事项</strong><span>${arr.length}项需优先关注</span></div>${lines(arr)}</section>`;
  }
  window.SCENE_SUMMARY = summary;

  /* ---------- 提报行的通用处理（W2、W6B 共用） ---------- */

  const REASON = Object.fromEntries(CC.reasons.map((r) => [r.k, r]));
  /* 3×400 电缆外径约 106 毫米（构造）；运输距离超过 30 公里可不利库（构造规则） */
  const OD = 106;
  const FAR = 30;

  function rowCell(T, r) {
    const s = T.rs[r.行];
    if (!r.匹配) return { act: '<span class="sc-dim">—</span>', st: '<span class="sc-dim">无可用库存，直接提报</span>' };
    const lock = T.done || T.busy || s.st === "ok" || s.st === "hand" || s.st === "lk" || T.sent;
    const opts = `<option value="">选择不利库原因</option>${CC.reasons.map((x) => `<option value="${x.k}" ${s.r === x.k ? "selected" : ""}>${h(x.name)}</option>`).join("")}`;
    const act = `<div class="sc-dec"><button class="sc-seg ${s.d === "yes" ? "on" : ""}" data-em-act="s-row-yes" data-row="${r.行}" ${lock ? "disabled" : ""}>采纳</button><button class="sc-seg ${s.d === "no" ? "on no" : ""}" data-em-act="s-row-no" data-row="${r.行}" ${lock ? "disabled" : ""}>不采纳</button>${s.d === "no" ? `<select class="sc-sel" data-row-r="${r.行}" ${lock ? "disabled" : ""}>${opts}</select>` : ""}</div>`;
    const ST = {
      lk: chip(`已利库·${T.proj}`, "ok"),
      ask: chip("待你在对话里说明", "warn"),
      ok: chip("核验通过", "ok"),
      fail: chip("核验不通过", "bad"),
      hand: chip("转仓储专责审核", "info"),
    };
    return { act, st: ST[s.st] || (s.d === "no" && !s.r ? chip("请选原因", "warn") : '<span class="sc-dim">待确认</span>') };
  }

  /* 物料简称：电缆写成「3×截面」，其余取描述前两段 */
  const spec = (d) => {
    const c = String(d).match(/YJV,(\d+),3,22/);
    return c ? `电力电缆 3×${c[1]}` : String(d).split(",").slice(0, 2).join(" ");
  };
  function matchHtml(m, unit) {
    if (!m) return '<span class="sc-dim">无可用库存</span>';
    const seg = m.段 ? `<small>段长 ${m.段.join(" / ")} 米</small>` : "";
    return `<div class="sc-match"><b>${h(m.类型)}</b> ${h(spec(m.物料描述))} · 可用 ${num(m.可用, 3)} ${h(unit)}<small>${mono(m.物料编码)} · ${h(m.库存地点)} · 库龄 ${h(m.库龄)}</small>${seg}${m.规则 ? `<small>${h(m.规则)}</small>` : ""}</div>`;
  }
  const rowTable = (T, rows) =>
    tbl(["行", "物料", "需求", "匹配库存", "处理"], rows.map((r) => {
      const c = rowCell(T, r);
      return [String(r.行).padStart(5, "0"), `${h(r.物料描述)}<small class="sc-code">${mono(r.物料编码)}</small>`, `${num(r.数量, 3)} ${h(r.单位)}`, matchHtml(r.匹配, r.单位), r.匹配 ? `${c.act}<div class="sc-st">${c.st}</div>` : c.st];
    }), "sc-t-plan");

  function rowAsk(T, n) {
    const s = T.rs[n];
    const R = REASON[s.r];
    T.ask = n;
    s.st = "ask";
    if (R.num) say(T, { k: "ai", html: `行 ${n} 选了「${h(R.name)}」。请填写<b>${h(R.num)}</b>，并说明原因。我按库存数据核验，核验通过的不用转人审核。` });
    else if (s.r === "broken") say(T, { k: "ai", html: `行 ${n} 选了「库存有损坏」，这一项没有可核验的数据。请说明损坏情况，有没有试验或检测记录。你的说明会留在这条对话里，随审核一起转给仓储专责。` });
    else say(T, { k: "ai", html: `行 ${n} 选了「${h(R.name)}」，这一项没有可核验的数据。请说明具体情况，你的说明会随审核一起转给仓储专责。` });
  }

  function rowReply(T, v) {
    const n = T.ask;
    if (n == null) return false;
    const s = T.rs[n];
    const R = REASON[s.r];
    const row = T.rows.find((x) => x.行 === n);
    const m = row.匹配;
    s.txt = v;
    s.at = EM.now();
    if (R.num) {
      const hit = String(v).match(/(\d+(?:\.\d+)?)/);
      if (!hit) {
        say(T, { k: "ai", html: `没有读到数字。请填写${h(R.num)}。` });
        return true;
      }
      const x = Number(hit[1]);
      s.val = x;
      if (T.id === "W2" && s.r === "seg") G.w2Seg = x;
      let rows;
      let ok;
      if (s.r === "seg") {
        const mx = Math.max(...(m.段 || [0]));
        ok = x > mx;
        rows = [
          { a: "查数据", t: `库存批次 ${m.批次} 描述扩展「${m.扩展 || ""}」，最长单段 ${mx} 米`, from: "ERP 批次描述扩展", cap: "查询" },
          { a: "按规则", t: `施工需要单段 ${x} 米，${ok ? "大于" : "不大于"}库存最长单段 ${mx} 米`, from: "规则库 · 盘长/段长不匹配须填单段长度" , cap: "分析" },
          { a: "得结论", t: ok ? "「盘长/段长不匹配」成立，记录核验数据，不转人审核" : `库存有 ${mx} 米单段，能满足 ${x} 米，原因不成立` },
        ];
      } else if (s.r === "install") {
        ok = x < OD;
        rows = [
          { a: "查数据", t: `库存 ${m.物料编码} 电缆外径约 ${OD} 毫米`, from: "物料主数据 · 技术参数", cap: "查询" },
          { a: "按规则", t: `管孔或桥架允许最大外径 ${x} 毫米，${ok ? "小于" : "不小于"}库存电缆外径`, from: "规则库 · 安装不匹配须填允许外径", cap: "分析" },
          { a: "得结论", t: ok ? "「安装不匹配」成立，记录核验数据，不转人审核" : "库存电缆能装进去，原因不成立" },
        ];
      } else {
        ok = x > FAR;
        rows = [
          { a: "查数据", t: `库存地点 ${m.库存地点}`, from: "资源池 · 库存地点", cap: "查询" },
          { a: "按规则", t: `施工现场距库存地点 ${x} 公里，${ok ? "超过" : "未超过"}本单位规定的 ${FAR} 公里`, from: "规则库 · 利库运输距离", cap: "分析" },
          { a: "得结论", t: ok ? "「利库运输距离远」成立，记录核验数据，不转人审核" : "运输距离在规定范围内，原因不成立" },
        ];
      }
      T.ask = null;
      stream(T, `行 ${n} 核验`, rows, () => {
        s.st = ok ? "ok" : "fail";
        if (!ok) {
          say(T, { k: "ai", html: `行 ${n} 原因不成立。请改为「采纳」，或换一个不利库原因。` });
          s.d = "";
          s.r = "";
          s.st = "";
        } else say(T, { k: "ai", html: `行 ${n} 核验通过，核验数据和你的说明随计划一起传 ERP。` });
        right(T);
      });
      return true;
    }
    T.ask = null;
    if (T.id === "W2") G.w2Txt = v;
    stream(T, `行 ${n} 转审核`, [
      { a: "查数据", t: `记录你的说明（${s.at}）：“${v}”`, from: "本对话", cap: "查询" },
      { a: "按规则", t: `「${R.name}」没有可核验的数据，按规则转仓储专责审核`, from: "规则库 · 不利库原因分类", cap: "分析" },
      { a: "交给人", t: s.r === "broken" ? "说明原文和这台变压器的退役试验记录一起转给仓储专责" : "说明原文转给仓储专责", warn: false },
    ], () => {
      s.st = "hand";
      say(T, { k: "ai", html: `行 ${n} 已转仓储专责审核。其余行不受影响，可以先提交。` });
      right(T);
    });
    return true;
  }

  function rowAct(T, a, el) {
    const n = Number(el.dataset.row);
    const s = T.rs[n];
    if (!s || T.busy) return;
    if (a === "s-row-yes") {
      s.d = "yes";
      s.r = "";
      s.st = "lk";
      if (T.ask === n) T.ask = null;
      say(T, { k: "me", text: `行 ${n} 采纳利库` });
      say(T, { k: "ai", html: `行 ${n} 采纳。这一行不进采购申请，对应库存标为「已利库·${h(T.proj)}」，资源池不再推荐给其他计划，出库后退出。` });
    } else if (a === "s-row-no") {
      s.d = "no";
      s.st = "";
    }
    draw(T);
  }

  function rowInput(T, t) {
    if (!t.dataset.rowR) return;
    const n = Number(t.dataset.rowR);
    const s = T.rs[n];
    s.r = t.value;
    if (!s.r) return right(T);
    say(T, { k: "me", text: `行 ${n} 不采纳：${REASON[s.r].name}` });
    rowAsk(T, n);
    right(T);
  }

  /* ---------- W2 需求计划提报（D） ---------- */

  const W2 = {
    pane: "画布",
    tabs: ["需求计划匹配"],
    init(T) {
      T.proj = CC.项目;
      T.rows = CC.plan;
      T.rs = {};
      T.rows.forEach((r) => (T.rs[r.行] = { d: "", r: "", st: "" }));
      T.up = false;
      T.only = true;
      T.ask = null;
      T.sent = false;
    },
    bg: () => [["需求计划", `${CC.项目}｜${CC.月份}`], ["截止", "10月20日｜剩余5天"], ["提报后", "通过后直传 ERP 采购申请"]],
    intro(T) {
      say(T, { k: "ai", html: `11 月需求计划 10 月 20 日截止。请上传这个项目的设计物资清单，我逐行到本单位资源池里找可以用的库存：同物料号、相似物料、以大代小。`, btns: [["上传设计物资清单", "s-w2-up", "p"]] });
    },
    used: (T, a) => (a === "s-w2-up" ? T.up : false),
    act(T, a, el) {
      if (a === "s-w2-up") {
        if (T.up) return;
        T.up = true;
        say(T, { k: "me", files: [CC.清单] });
        const stock = T.rows.filter((r) => r.匹配).length;
        stream(T, "匹配本单位资源池", [
          { a: "查数据", t: `读取设计物资清单：${T.rows.length} 行，项目 ${CC.项目}，需求月份 ${CC.月份}`, from: CC.清单, cap: "查询" },
          { a: "查数据", t: `同物料号匹配资源池 ${num(CC.pool.total, 0)} 条：行 20 借用库有 3×400，行 30 代保管库有 400kVA 变压器`, from: "资源池（实体库、代保管库、借用超量、专业仓）", cap: "查询" },
          { a: "按规则", t: `相似物料、以大代小：行 10 电缆 3×300，代保管库有 3×400 可用 ${num(CC.plan[0].匹配.可用, 3)} 千米`, from: `本单位以大代小规则「${CC.rules[1]}」`, cap: "分析" },
          { a: "按规则", t: `应急库 ${CC.pool.应急} 条为抢修储备不参与匹配；已利库未出库的不再推荐`, from: "资源池标记", cap: "分析" },
          { a: "得结论", t: `${T.rows.length} 行中 ${stock} 行本单位有库存，${T.rows.length - stock} 行无库存直接提报` },
        ], () => {
          say(T, { k: "ai", html: `请在右侧逐行确认这 ${stock} 行：采纳利库，或选不利库原因。选「盘长/段长不匹配」「安装不匹配」「利库运输距离远」的，要填数据，由我核验；其余原因请你说明，我转仓储专责审核。` });
        });
        return draw(T);
      }
      if (a === "s-w2-only") {
        T.only = !T.only;
        return right(T);
      }
      if (a === "s-row-yes" || a === "s-row-no") return rowAct(T, a, el);
      if (a === "s-w2-submit") return w2Submit(T);
    },
    input: (T, t) => rowInput(T, t),
    reply: (T, v) => rowReply(T, v),
    right(T) {
      if (!T.up) return page("需求计划匹配", `${CC.项目} · ${CC.月份}`, empty("上传设计物资清单后，在这里逐行显示匹配结果"));
      const rows = T.only ? T.rows.filter((r) => r.匹配) : T.rows;
      const stock = T.rows.filter((r) => r.匹配);
      const doneN = stock.filter((r) => ["lk", "ok", "hand"].includes(T.rs[r.行].st)).length;
      const body = rowTable(T, rows);
      const ready = doneN === stock.length && T.ask == null && !T.busy;
      const foot = T.sent
        ? `<div class="sc-foot ok"><span>已提交 · 采购申请 ${mono(CC.采购申请)} 已传 ERP ${G.w2Pass} 行</span></div>`
        : `<div class="sc-foot"><span>无库存 ${T.rows.length - stock.length} 行直接提报；有库存 ${stock.length} 行已处理 ${doneN}/${stock.length}</span>${btn("提交并传 ERP", "s-w2-submit", "w", !ready || T.done)}</div>`;
      return page("需求计划匹配", `${h(CC.工厂名称)} · 运检部 · ${h(CC.项目)} · ${CC.月份} · ${T.rows.length} 行 · 本单位有库存 ${stock.length} 行`,
        body + foot, `<button class="sc-tog ${T.only ? "on" : ""}" data-em-act="s-w2-only">${T.only ? `只看有库存（${stock.length}）` : `全部 ${T.rows.length} 行`}</button>`);
    },
  };

  function w2Submit(T) {
    if (EM.pending(T) || T.sent) return;
    const stock = T.rows.filter((r) => r.匹配);
    const pass = T.rows.length - stock.length + stock.filter((r) => T.rs[r.行].st === "ok").length;
    const lk = stock.filter((r) => T.rs[r.行].st === "lk").map((r) => `行 ${r.行}`);
    const hand = stock.filter((r) => T.rs[r.行].st === "hand").map((r) => `行 ${r.行}`);
    confirm(T, {
      title: "传 ERP",
      action: `生成采购申请并传 ERP：${pass} 行`,
      note: `${lk.length ? `${lk.join("、")} 已利库，不进采购申请；` : ""}${hand.length ? `${hand.join("、")} 待仓储专责审核，审核通过后补传。` : ""}`,
      warn: "传 ERP 后进入审批流程。",
      ok: "确认传 ERP",
      onOk: () => {
        T.sent = true;
        stream(T, "写入 ERP", [
          { a: "办理", t: `调用 ERP 接口创建采购申请 ${CC.采购申请}（工厂 ${CC.工厂}），${pass} 行`, from: "ERP 采购申请接口", cap: "写入" },
          { a: "办理", t: "不利库原因和核验数据写入对应行，与 ERP「不利库原因」一致", from: "ERP 采购申请平衡利库", cap: "写入" },
          { a: "办理", t: `${lk.join("、") || "—"} 库存标记「已利库·${CC.项目}」`, from: "资源池", cap: "写入" },
        ], () => {
          G.w2 = true;
          G.w2At = EM.now();
          G.w2Pass = pass;
          T.done = true;
          say(T, { k: "result", title: "已提交", lines: [`采购申请 ${CC.采购申请} 已传 ERP，${pass} 行`, ...(hand.length ? [`${hand.join("、")} 已转仓储专责审核`] : [])] });
          finish(T.id, { status: "done", current: hand.length ? `已提交，${hand.join("、")} 待专责审核` : "已提交", remain: "已完成", log: `提报 11 月需求计划，传 ERP ${pass} 行`, next: hand.length ? "仓储专责审核不利库原因" : "" });
          if (hand.length) show("W3");
        }, 600);
      },
      onCancel: () => (T.sent = false),
    });
  }

  /* ---------- W6B 补填不利库原因（D） ---------- */

  const W6B = {
    pane: "画布",
    tabs: ["采购申请 3806513044"],
    init(T) {
      const e = CC.erp直提;
      T.proj = e.项目;
      const avail = Math.round((CC.plan[0].匹配.可用 - (G.w2 ? 0.6 : 0)) * 1000) / 1000;
      T.rows = [{ 行: 10, 物料编码: e.物料编码, 物料描述: e.物料描述, 数量: e.数量, 单位: e.单位, 匹配: { 类型: "以大代小", 物料编码: "500108195", 物料描述: CC.plan[0].匹配.物料描述, 库存地点: CC.plan[0].匹配.库存地点, 批次: CC.plan[0].匹配.批次, 可用: avail, 库龄: CC.plan[0].匹配.库龄, 规则: `本单位以大代小规则「${CC.rules[1]}」` } }];
      T.rs = { 10: { d: "", r: "", st: "" } };
      T.ask = null;
      T.sent = false;
    },
    bg: () => [["采购申请", `${CC.erp直提.采购申请}｜行 ${CC.erp直提.行}`], ["ERP 提报时间", `今天 ${CC.erp直提.提报}`], ["状态", "ERP 审批已挂起"]],
    intro(T) {
      const e = CC.erp直提;
      say(T, { k: "ai", html: `你今天 ${e.提报} 在 ERP 提报的采购申请 ${mono(e.采购申请)} 行 ${e.行}（${spec(e.物料描述)}，${num(e.数量, 3)} 千米），本单位库存有 3×400 电缆可以以大代小，这条计划没有经过工作台匹配，ERP 审批已挂起。<br>请在右侧选择：采纳利库，或选不利库原因并说明。补完后放行。` });
    },
    act(T, a, el) {
      if (a === "s-row-yes" || a === "s-row-no") return rowAct(T, a, el);
      if (a === "s-w6b-submit") {
        const s = T.rs[10];
        confirm(T, {
          title: "回写 ERP",
          action: s.st === "lk" ? `采购申请 ${CC.erp直提.采购申请} 行 10 改为利库` : `把不利库原因「${REASON[s.r].name}」和说明写入采购申请 ${CC.erp直提.采购申请} 行 10`,
          note: s.st === "hand" ? "原因转仓储专责审核，审核通过后放行。" : "写入后 ERP 审批放行。",
          ok: "确认回写",
          onOk: () => {
            T.sent = true;
            T.done = true;
            G.w6b = s.st;
            say(T, { k: "result", title: "已回写 ERP", lines: [s.st === "hand" ? "已转仓储专责审核" : "ERP 审批已放行"] });
            finish(T.id, { status: "done", current: s.st === "hand" ? "已补原因，待专责审核" : "已补原因，审批放行", remain: "已完成", log: "补填不利库原因并回写 ERP" });
            EM.refreshHome();
          },
          onCancel: () => {},
        });
      }
    },
    input: (T, t) => rowInput(T, t),
    reply: (T, v) => rowReply(T, v),
    right(T) {
      const s = T.rs[10];
      const ready = ["lk", "ok", "hand"].includes(s.st) && !T.busy && T.ask == null;
      return page(`采购申请 ${CC.erp直提.采购申请}`, `${h(CC.工厂名称)} · 运检部 · ${h(CC.erp直提.项目)} · ERP 审批已挂起`,
        rowTable(T, T.rows) +
          `<div class="sc-foot">${T.sent ? `<span>已回写 ERP</span>` : `<span>补完后回写 ERP</span>${btn("回写 ERP", "s-w6b-submit", "w", !ready)}`}</div>`);
    },
  };

  /* ---------- W3 不利库原因审核（C） ---------- */

  const TXT30 = "这台变压器去年7月退役进的代保管库，试验时绕组绝缘电阻偏低，油色谱也超标，直接用在新工程上不放心。";
  const W3 = {
    pane: "画布",
    tabs: ["不利库原因审核"],
    init() {},
    bg: () => [["提报", `运检部｜采购申请 ${CC.采购申请}｜行 30`], ["原因", "库存有损坏"], ["时限", "今日17:00"]],
    intro(T) {
      const r = CC.plan[2];
      const t = G.w2Txt || TXT30;
      const x = CC.试验记录;
      stream(T, "审核前核对", [
        { a: "查数据", t: `运检部 ${CC.项目} 行 30：${r.物料描述.split(",").slice(0, 2).join(" ")} 1 台，可用库存 ${r.匹配.库存地点} 批次 ${r.匹配.批次}（退役再利用），提报人选「库存有损坏」`, from: "工作台提报记录", cap: "查询" },
        { a: "查数据", t: `提报人说明（今天 ${G.w2At || "09:41"}，对话原文）：“${t}”`, from: "提报对话留痕", cap: "查询" },
        { a: "查数据", t: `${x.名称}（${x.日期}）：${x.结论}；${x.建议}`, from: "设备退役试验记录", cap: "查询" },
        { a: "得结论", t: "试验记录与提报人说明一致" },
        { a: "交给人", t: "是否认定不利库，由你审核" },
      ], () => say(T, { k: "ai", html: "核对材料在右侧。认定不利库的报物资部主任审批；驳回的退回提报人改为利库或补充说明。" }), 500);
    },
    act(T, a) {
      if (a === "s-w3-ok" || a === "s-w3-no") {
        const ok = a === "s-w3-ok";
        confirm(T, {
          title: ok ? "认定不利库" : "驳回",
          action: ok ? "认定行 30「库存有损坏」成立，报物资部主任审批" : "驳回行 30，退回提报人改为利库或补充说明",
          note: "审核意见和对话原文一起留痕。",
          ok: ok ? "确认报主任" : "确认驳回",
          onOk: () => {
            T.done = true;
            G.w3 = ok ? "ok" : "no";
            say(T, { k: "result", title: ok ? "已报主任审批" : "已驳回", lines: [ok ? "物资部主任在「不利库审批」中查看" : "提报人已收到待办"] });
            finish(T.id, { status: "done", current: ok ? "已认定不利库，报主任审批" : "已驳回提报人", remain: "已完成", log: ok ? "认定不利库，报主任" : "驳回提报人" });
          },
          onCancel: () => {},
        });
      }
    },
    right(T) {
      const r = CC.plan[2];
      const x = CC.试验记录;
      return page("不利库原因审核", `运检部 · 采购申请 ${mono(CC.采购申请)} · 行 30`,
        sec("提报行", kv([["物料", `${mono(r.物料编码)} ${h(r.物料描述)}`], ["需求数量", "1 台"], ["可用库存", `${h(r.匹配.库存地点)} · 批次 ${mono(r.匹配.批次)} · 库龄 ${h(r.匹配.库龄)} · 退役再利用`], ["不利库原因", chip("库存有损坏", "warn")]])) +
          sec("提报人说明", `<blockquote class="sc-quote">${h(G.w2Txt || TXT30)}<cite>对话原文 · 今天 ${h(G.w2At || "09:41")}</cite></blockquote>`) +
          sec("退役试验记录", kv([["记录", h(x.名称)], ["试验日期", h(x.日期)], ["结论", h(x.结论)], ["处理意见", h(x.建议)]]) + `<p class="sc-ok-line">与提报人说明一致</p>`) +
          `<div class="sc-foot">${T.done ? `<span>${G.w3 === "ok" ? "已认定不利库，报主任审批" : "已驳回"}</span>` : `<span>认定后报物资部主任审批</span><div>${btn("驳回，要求利库", "s-w3-no")}${btn("认定不利库，报主任", "s-w3-ok", "p")}</div>`}</div>`);
    },
  };

  /* ---------- W4 不利库审批（E） ---------- */

  const W4ROWS = [
    ["3806511027", "00020", "营销部", "低压电力电缆,YJY,铜,50/25,4+1芯", "盘长/段长不匹配", "单段 260 米；库存最长单段 180 米"],
    ["3806511027", "00040", "营销部", "电缆保护管,CPVC,φ150", "利库运输距离远", "现场距库存地点 46 公里"],
    ["3806511390", "00010", "运检部", "电力电缆,AC10kV,YJV,240,3,22", "安装不匹配", "管孔允许外径 95 毫米；库存 3×400 外径约 106 毫米"],
    ["3806511390", "00030", "运检部", "架空绝缘导线,AC10kV,JKLGYJ,120/20", "盘长/段长不匹配", "单段 1,150 米；库存最长单段 800 米"],
    ["3806511702", "00010", "江北中心", "电力电缆,AC10kV,YJV,400,3,22", "盘长/段长不匹配", "单段 520 米；库存最长单段 340 米"],
    ["3806511702", "00050", "江北中心", "10kV电缆中间接头,3×300,直通接头", "利库运输距离远", "现场距库存地点 52 公里"],
    ["3806512016", "00020", "渝北中心", "低压电力电缆,YJY,铜,70/35,4+1芯", "盘长/段长不匹配", "单段 210 米；库存最长单段 150 米"],
    ["3806512233", "00010", "营销部", "电缆保护管,CPVC,φ100", "安装不匹配", "排管允许外径 90 毫米；库存规格 φ100"],
    ["3806512540", "00030", "运检部", "电力电缆,AC10kV,YJV,70,3,22", "盘长/段长不匹配", "单段 380 米；库存最长单段 300 米"],
  ];
  const W4MAN = [
    ["3806511390", "00060", "运检部", "柱上断路器,AC10kV,630A", "参数不匹配", "库存为 20kA，设计要求 25kA，与设计图纸核对一致", "设计要求开断电流 25kA，库存 20kA 不满足"],
    ["3806511702", "00020", "江北中心", "环网柜,AC10kV,630A,断路器柜", "规格不匹配", "库存为负荷开关柜，项目需断路器柜", "项目图纸为断路器柜，库存负荷开关柜不能替代"],
    ["3806512016", "00010", "渝北中心", "电能计量箱,三相,1,PC+ABS,250A", "业扩定额物资，暂不能使用", "库存为业扩定额储备，营销部确认本季度有业扩用量", "营销部回复本季度需保留 40 只"],
  ];
  const W4 = {
    pane: "画布",
    tabs: ["不利库审批"],
    init(T) {
      T.g1 = "";
      T.man = {};
    },
    bg: () => [["范围", "市北供电分公司 10 月"], ["条数", "14 条"], ["审批后", "回写 ERP"]],
    intro(T) {
      stream(T, "审批前分组", [
        { a: "查数据", t: "本月提报至主任的不利库共 14 条", from: "工作台不利库记录、ERP 采购申请", cap: "查询" },
        { a: "按规则", t: "按数据核验的 9 条：盘长/段长、安装、运输距离三类，提报人填了数据并已核验通过", from: "规则库 · 不利库原因分类", cap: "分析" },
        { a: "按规则", t: "无数据可核的 4 条：仓储专责已逐条审核认定，附对话原文", from: "专责审核记录", cap: "分析" },
        { a: "查数据", t: `另有 1 条在 ERP 直接提报、未经工作台匹配：采购申请 ${CC.erp直提.采购申请}，ERP 审批已挂起`, from: "ERP 当日同步", cap: "查询" },
        { a: "交给人", t: "核验通过的可整组审批，专责认定的建议逐条看" },
      ], null, 450);
    },
    act(T, a, el) {
      if (a === "s-w4-g1") {
        return confirm(T, {
          title: "整组审批",
          action: "数据核验通过的 9 条，审批通过并回写 ERP",
          note: "每条的填报数据和核验结论随审批记录留存。",
          ok: "确认通过 9 条",
          onOk: () => {
            T.g1 = "ok";
            say(T, { k: "result", title: "9 条已通过", lines: ["已回写 ERP"] });
            w4Check(T);
          },
          onCancel: () => {},
        });
      }
      if (a === "s-w4-ok" || a === "s-w4-no") {
        const i = el.dataset.i;
        T.man[i] = a === "s-w4-ok" ? "ok" : "no";
        say(T, { k: "me", text: `${a === "s-w4-ok" ? "通过" : "驳回"}：采购申请 ${i}` });
        w4Check(T);
        return draw(T);
      }
      if (a === "s-w4-w6") return EM.openThread("W6");
    },
    right(T) {
      const pass = G.w2 ? [[CC.采购申请, "00020", "运检部", "电力电缆,AC10kV,YJV,400,3,22", "盘长/段长不匹配", `单段 ${G.w2Seg || 450} 米；库存最长单段 340 米`], ...W4ROWS.slice(0, 8)] : W4ROWS;
      const man = W4MAN.slice();
      if (G.w3 === "ok") man.push([CC.采购申请, "00030", "运检部", "10kV变压器,400kVA,油浸", "库存有损坏", "退役试验绕组绝缘电阻偏低，油色谱乙炔超注意值，需返厂检修", "试验记录与提报人说明一致"]);
      const g1 = sec(`按数据核验通过 · ${pass.length} 条`, tbl(["采购申请", "行", "部门", "物料", "原因", "填报数据", "核验"], pass.map((r) => [mono(r[0]), r[1], h(r[2]), h(r[3]), h(r[4]), h(r[5]), chip("通过", "ok")])) +
        `<div class="sc-foot">${T.g1 ? "<span>已整组通过，已回写 ERP</span>" : `<span>9 条均有填报数据和核验结论</span>${btn("通过这 9 条", "s-w4-g1", "w")}`}</div>`);
      const g2 = sec(`专责认定不利库 · ${man.length} 条${G.w3 === "ok" ? "" : "（另有 1 条专责审核中）"}`, tbl(["采购申请", "行", "部门", "物料", "原因", "提报人说明", "专责意见", "审批"], man.map((r) => {
        const k = `${r[0]}-${r[1]}`;
        const st = T.man[k];
        return [mono(r[0]), r[1], h(r[2]), h(r[3]), h(r[4]), h(r[5]), h(r[6]), st ? chip(st === "ok" ? "已通过" : "已驳回", st === "ok" ? "ok" : "bad") : `<div class="sc-dec"><button class="sc-seg" data-em-act="s-w4-ok" data-i="${k}">通过</button><button class="sc-seg" data-em-act="s-w4-no" data-i="${k}">驳回</button></div>`];
      })));
      const e = CC.erp直提;
      const st6 = G.w6 === "release" ? chip("已放行", "ok") : G.w6 === "reject" ? chip("已驳回", "bad") : G.w6b ? chip("已补原因，待判定", "info") : chip("ERP 审批已挂起", "bad");
      const g3 = sec("ERP 直接提报、未经匹配 · 1 条", tbl(["采购申请", "行", "部门", "物料", "数量", "可利库", "状态", ""], [[mono(e.采购申请), e.行, h(e.部门), h(e.物料描述), `${num(e.数量, 3)} 千米`, "3×400 以大代小", st6, btn("查看", "s-w4-w6")]]));
      return page("不利库审批", `${h(CC.工厂名称)} · 2026 年 10 月 · 14 条`, kpis([{ k: "数据核验通过", v: pass.length, tone: "ok" }, { k: "专责认定", v: man.length + (G.w3 === "ok" ? 0 : 1) }, { k: "ERP 直接提报", v: 1, tone: "bad" }]) + g1 + g2 + g3);
    },
  };
  function w4Check(T) {
    const n = W4MAN.length + (G.w3 === "ok" ? 1 : 0);
    if (T.g1 && Object.keys(T.man).length >= n && !T.done) {
      T.done = true;
      G.w4 = true;
      finish(T.id, { status: "done", current: "已审批，已回写 ERP", remain: "已完成", log: "不利库审批完成" });
    }
  }

  /* ---------- W6 ERP 直接提报（E） ---------- */

  const W6 = {
    pane: "画布",
    tabs: ["ERP 直接提报"],
    init() {},
    bg: () => [["采购申请", `${CC.erp直提.采购申请}｜行 ${CC.erp直提.行}`], ["部门", "运检部"], ["状态", "ERP 审批已挂起"]],
    intro(T) {
      const e = CC.erp直提;
      past(T, "经过", [
        { a: "查数据", t: `09:12　运检部在 ERP 提报采购申请 ${e.采购申请} 行 ${e.行}：${spec(e.物料描述)} ${num(e.数量, 3)} 千米，${e.项目}`, from: "ERP", cap: "查询" },
        { a: "按规则", t: "09:13　工作台当日同步到这条计划；本单位库存有 3×400 电缆可以以大代小，这条计划没有经过工作台匹配", from: `资源池 · 以大代小规则「${CC.rules[0]}」`, cap: "分析" },
        { a: "办理", t: "09:13　ERP 审批挂起；推待办给提报人和仓储专责，要求采纳利库或补不利库原因", from: "ERP 审批管控", cap: "写入" },
        { a: "交给人", t: "补完原因前不放行；补完后由你判定放行或驳回" },
      ]);
      say(T, { k: "ai", html: G.w6b ? `提报人已补：${G.w6b === "lk" ? "改为利库" : "已填不利库原因"}。请判定放行或驳回。` : "提报人还没有补。可以等提报人补原因，也可以直接驳回。" });
    },
    act(T, a) {
      if (a === "s-w6-wait") {
        say(T, { k: "me", text: "等补原因" });
        say(T, { k: "ai", html: "好的，继续挂起。提报人补完后会推送给你。" });
        return draw(T);
      }
      if (a === "s-w6-reject" || a === "s-w6-release") {
        const rel = a === "s-w6-release";
        confirm(T, {
          title: rel ? "放行" : "驳回",
          action: rel ? `ERP 采购申请 ${CC.erp直提.采购申请} 解除挂起，进入审批` : `驳回 ERP 采购申请 ${CC.erp直提.采购申请}，退回运检部`,
          note: "处理结果回写 ERP 并通知提报人。",
          ok: rel ? "确认放行" : "确认驳回",
          onOk: () => {
            T.done = true;
            G.w6 = rel ? "release" : "reject";
            say(T, { k: "result", title: rel ? "已放行" : "已驳回", lines: ["已回写 ERP，已通知提报人"] });
            finish(T.id, { status: "done", current: rel ? "已放行" : "已驳回", remain: "已完成", log: rel ? "ERP 直接提报放行" : "ERP 直接提报驳回" });
          },
          onCancel: () => {},
        });
      }
    },
    right(T) {
      const e = CC.erp直提;
      const st = G.w6 ? (G.w6 === "release" ? chip("已放行", "ok") : chip("已驳回", "bad")) : G.w6b ? chip("提报人已补原因", "info") : chip("ERP 审批已挂起 · 待提报人补原因", "bad");
      const acts = T.done ? "" : G.w6b ? `${btn("驳回", "s-w6-reject")}${btn("放行", "s-w6-release", "p")}` : `${btn("驳回", "s-w6-reject")}${btn("等补原因", "s-w6-wait", "p")}`;
      return page("ERP 直接提报未经匹配", `采购申请 ${mono(e.采购申请)} · ${st}`,
        sec("ERP 计划", kv([["工厂", `${CC.工厂} ${h(CC.工厂名称)}`], ["行", e.行], ["物料", `${mono(e.物料编码)} ${h(e.物料描述)}`], ["数量", `${num(e.数量, 3)} 千米`], ["项目", h(e.项目)], ["提报时间", `今天 ${e.提报}`]])) +
          sec("可利库库存", kv([["匹配方式", "以大代小"], ["库存", `${mono("500108195")} ${h(CC.plan[0].匹配.物料描述)}`], ["库存地点", `${h(CC.plan[0].匹配.库存地点)} · 批次 ${CC.plan[0].匹配.批次}`], ["可用", `${num(CC.plan[0].匹配.可用 - (G.w2 ? 0.6 : 0), 3)} 千米`], ["依据", h(`本单位以大代小规则「${CC.rules[1]}」`)]])) +
          sec("提报人补充", G.w6b ? `<p>${G.w6b === "lk" ? "改为利库" : "已填不利库原因并说明"}</p>` : empty("提报人尚未补充")) +
          (acts ? `<div class="sc-foot"><span>补完原因前不放行</span><div>${acts}</div></div>` : ""));
    },
  };

  /* ---------- W1 资源池与应急备查看板（C） ---------- */

  const PL = CC.pool;
  const W1 = {
    pane: "画布",
    tabs: ["资源池", "应急备查看板"],
    init() {},
    bg: () => [["范围", "市北供电分公司（本单位内部消纳）"], ["更新", "10月15日 08:00"], ["下次", "10月19日 08:00"]],
    intro(T) {
      past(T, "本周更新（10月15日 08:00）", [
        { a: "查数据", t: `ERP 实体库可利库 ${PL.利库} 条、应急库 ${PL.应急} 条、代保管库 ${PL.代保管} 条`, from: "ERP 库存（当日同步）", cap: "查询" },
        { a: "查数据", t: `专业仓 ${num(PL.专业仓全部, 0)} 条，取备品备件、工程待用、工程拆旧 ${num(PL.专业仓, 0)} 条；工器具、办公劳保、仪器仪表 ${PL.专业仓剔除} 条不进资源池`, from: "专业仓管理系统", cap: "查询" },
        { a: "查数据", t: `借用库借出 ${PL.借用记录} 条，需求部门已填未用完数量 ${PL.借用填报} 条，其中 ${PL.借用超量} 条有剩余`, from: "借用库、需求部门填报", cap: "查询" },
        { a: "按规则", t: "线缆从批次描述扩展识别段长；正式退库的按项目和物料编码去重", from: "去重与段长识别", cap: "分析" },
        { a: "按规则", t: `应急库 ${PL.应急} 条是抢修储备，只进应急备查看板，不参与提报匹配`, from: "仓储专责标记", cap: "分析" },
        { a: "得结论", t: `本单位可利库资源池 ${num(PL.total, 0)} 条` },
      ]);
    },
    act(T, a) {
      const M = {
        "s-w1-exp": "已导出《市北可利库资源池_20261015.xlsx》，线缆注明段长，可发设计单位",
        "s-w1-share": `已共享给${CC.消纳.部门.join("、")}，登录工作台即可查看`,
        "s-w1-img": "已保存图片《市北应急备查看板_第42周.png》",
        "s-w1-link": "已复制内网链接",
      };
      if (M[a]) toast(M[a]);
    },
    right(T) {
      if (T.tab === 1) {
        const E = CC.应急;
        return page("市北应急备查看板 · 第42周", `10月13日—10月19日 · 应急库 ${E.count} 条 · 每周一更新`,
          `<div class="sc-board">${E.groups.map((g) => `<div class="sc-bd"><b>${g[1]}</b><span>${h(g[0])}</span></div>`).join("")}</div>` +
            sec("应急库物资（节选）", tbl(["物资", "可用", "库存地点"], E.rows.map((r) => r.map(h)))),
          `${btn("保存图片", "s-w1-img")}${btn("复制链接", "s-w1-link", "p")}`);
      }
      return poolPage("市北可利库资源池", `${h(CC.工厂名称)} · 10月15日 08:00 更新 · ${num(PL.total, 0)} 条`, `${btn("导出给设计单位", "s-w1-exp")}${btn("按部门共享", "s-w1-share", "p")}`);
    },
  };

  /* 资源池的拟用项目：行 0 在提报人采纳利库后写入，其余与消纳计划的部门填报一致（构造） */
  const POOL_USE = { 5: ["10kV线路综合检修（第四季度）", "2026-11-10", "运检部 计划提报人"], 6: ["10kV王陡线改造", "2026-11-05", "渝北中心 物资专责"], 9: ["2026年四季度表计轮换", "2026-11-20", "营销部 计量专责"] };
  function poolPage(title, sub, acts = "") {
    const use = (i) => {
      const u = i === 0 && G.w2 ? [CC.项目, "2026-11", "运检部 计划提报人"] : POOL_USE[i];
      return u ? `${h(u[0])}<br><span class="sc-dim">${h(u[1])} · ${h(u[2])}</span>` : '<span class="sc-dim">未安排</span>';
    };
    return page(title, sub,
      kpis([{ k: "实体库（可利库）", v: PL.利库, s: "ERP" }, { k: "代保管库", v: PL.代保管, s: "ERP" }, { k: "借用超量", v: PL.借用超量, s: `需求部门已填 ${PL.借用填报} 条` }, { k: "专业仓", v: num(PL.专业仓, 0), s: "备品备件、工程待用、工程拆旧" }, { k: "应急库", v: PL.应急, s: "抢修储备，不参与匹配", tone: "dim" }]) +
        tbl(["来源", "物料", "库存地点", "可用", "库龄", "拟用项目 / 使用时间 / 联系人"], PL.rows.map((r, i) => [chip(r[0]), `${h(r[3])}<br>${mono(r[2])}${r[6] ? ` <span class="sc-mark">${h(r[6])}</span>` : ""}`, h(r[1]), h(r[4]), h(r[5]), use(i)]), "sc-t-pool") + `<p class="sc-note">显示 ${PL.rows.length} 条，共 ${num(PL.total, 0)} 条</p>`,
      acts);
  }

  /* ---------- W1V 资源池（D，需求部门查看） ---------- */

  const W1V = {
    pane: "画布",
    tabs: ["资源池"],
    init() {},
    bg: () => [["共享", "市北供电分公司仓储专责"], ["更新", "10月15日 08:00"], ["下次", "10月19日 08:00"]],
    intro(T) {
      say(T, { k: "ai", html: `仓储专责共享的本单位可利库资源池，${num(PL.total, 0)} 条，每周一更新。线缆看描述里的段长，存放位置看库存地点；别的部门已经安排的，写了拟用项目、使用时间和联系人。你提报需求计划时，我按这份资源池逐行匹配。` });
    },
    right() {
      return poolPage("本单位可利库资源池", `${h(CC.工厂名称)} · 仓储专责共享 · 10月15日 08:00 更新 · ${num(PL.total, 0)} 条`);
    },
  };

  /* ---------- W5 消纳计划（C） ---------- */

  const XN = CC.消纳;
  const xnCats = () => {
    const m = {};
    XN.rows.forEach((r) => (m[`${r.类别}（${r.规定}）`] = (m[`${r.类别}（${r.规定}）`] || 0) + 1));
    return Object.entries(m).map(([k, v]) => `${k} ${v} 项`).join("、");
  };
  /* 拟用项目：江北中心未填，其余部门已填（构造） */
  const PLAN_USE = { 营销部: ["2026年四季度表计轮换", "2026-11-20"], 运检部: ["10kV线路综合检修（第四季度）", "2026-11-10"], 渝北中心: ["10kV王陡线改造", "2026-11-05"] };
  const W5 = {
    pane: "画布",
    tabs: ["消纳计划"],
    init(T) {
      T.urged = false;
    },
    bg: () => [["表样", "市北消纳计划表：按库存类别分页，每类注明期限"], ["库龄规定", CC.库龄规定], ["部门", XN.部门.join("、")]],
    intro(T) {
      past(T, "核验消纳计划", [
        { a: "查数据", t: `${XN.部门.length} 个部门的消纳计划 ${XN.总} 项：${xnCats()}`, from: "市北消纳计划表", cap: "查询" },
        { a: "按规则", t: "按入库日期和各类期限算出到期日，对照今天核验", from: CC.库龄出处, cap: "分析" },
        { a: "得结论", t: `${XN.超期} 项已超过规定期限；江北中心的 8 项借用物资还没填拟用项目` },
      ]);
    },
    act(T, a) {
      if (a === "s-w5-urge" && !T.urged) {
        T.urged = true;
        say(T, { k: "me", text: "催办江北中心" });
        say(T, { k: "ai", html: "已推送待办给江北中心：8 项借用物资已超过借用库 12 个月期限，请 10 月 17 日前填拟用项目和使用时间，或办理归还。江北中心在工作台回复后留痕。" });
        draw(T);
      }
    },
    right(T) {
      const rows = XN.rows.slice().sort((a, b) => b.金额 - a.金额);
      const use = (r) => (PLAN_USE[r.部门] ? `${h(PLAN_USE[r.部门][0])}<br><span class="sc-dim">${h(PLAN_USE[r.部门][1])}</span>` : T.urged ? chip("已催办", "info") : chip("未填", "warn"));
      return page("消纳计划", `市北供电分公司 · ${XN.部门.length} 个部门 · ${XN.总} 项`,
        kpis([{ k: "消纳计划", v: XN.总 }, { k: "已超过规定期限", v: XN.超期, tone: "bad" }, { k: "未填拟用项目", v: XN.rows.filter((r) => !PLAN_USE[r.部门]).length, tone: "warn" }]) +
          sec("填报进度", `<div class="sc-prog">${XN.部门.map((d) => `<span class="${PLAN_USE[d] ? "ok" : "warn"}">${PLAN_USE[d] ? "✓" : "△"} ${h(d)}</span>`).join("")}${T.urged ? "" : btn("催办江北中心", "s-w5-urge", "p")}</div>`) +
          sec("按金额排列", tbl(["部门", "类别（期限）", "物料", "数量", "金额（元）", "入库日期", "到期日", "超期", "拟用项目 / 使用时间"], rows.map((r) => [h(r.部门), h(`${r.类别}（${r.规定}）`), h(r.物料), h(r.数量), num(r.金额, 2), h(r.入库), h(r.到期), r.超期 > 0 ? `<b class="sc-red">${r.超期} 天</b>` : "—", use(r)]), "sc-t-dense")));
    },
  };

  /* ---------- W7 需求部门填报（D） ---------- */

  const W7 = {
    pane: "画布",
    tabs: ["借用物资", "消纳计划"],
    init(T) {
      T.f = {};
      T.sent = false;
    },
    bg: () => [["发起", "市北供电分公司仓储专责"], ["截止", "10月17日"], ["用途", "借用未用完的进资源池；消纳计划用于跟踪库龄"]],
    intro(T) {
      say(T, { k: "ai", html: "仓储专责请运检部填两项：借用物资还剩多少（未用完的进资源池，别的部门提计划时能看到）；已超期物资的拟用项目、使用时间和责任人。右侧两个页签分别填写，填完点「提交」。" });
    },
    act(T, a) {
      if (a !== "s-w7-submit" || T.sent) return;
      T.sent = true;
      stream(T, "核验填报", [
        { a: "查数据", t: `借用物资 ${CC.借用填报.length} 条已填剩余数量，有剩余的转入资源池「借用超量」`, from: "本次填报", cap: "查询" },
        { a: "按规则", t: "对照库龄规定核验使用时间；已超期的标出，推送仓储专责跟踪", from: CC.库龄出处, cap: "分析" },
      ], () => {
        T.done = true;
        say(T, { k: "result", title: "已提交", lines: ["仓储专责在资源池和消纳计划中可见"] });
        finish(T.id, { status: "done", current: "已提交", remain: "已完成", log: "填报借用物资和消纳计划" });
      });
      draw(T);
    },
    input(T, t) {
      if (t.dataset.f) T.f[t.dataset.f] = t.value;
    },
    right(T) {
      const inp = (k, ph, type = "text") => `<input class="sc-in" data-f="${k}" type="${type}" value="${h(T.f[k] || "")}" placeholder="${h(ph)}" ${T.sent ? "disabled" : ""} />`;
      const foot = `<div class="sc-foot">${T.sent ? "<span>已提交</span>" : `<span>两个页签填完后提交</span>${btn("提交", "s-w7-submit", "p")}`}</div>`;
      if (T.tab === 1) {
        const mine = XN.rows.filter((r) => r.部门 === "运检部").slice(0, 3);
        return page("消纳计划 · 运检部", "已超过库龄期限的物资，请填拟用项目、使用时间和责任人",
          tbl(["物料", "类别（期限）", "数量", "到期日", "拟用项目", "使用时间", "责任人"], mine.map((r, i) => [h(r.物料), h(`${r.类别}（${r.规定}）`), h(r.数量), `${h(r.到期)}<br><b class="sc-red">已超 ${r.超期} 天</b>`, inp(`c${i}-proj`, "拟用项目"), inp(`c${i}-date`, "", "date"), inp(`c${i}-man`, "岗位或班组")])) + foot);
      }
      return page("借用物资 · 运检部", "借出未用完的数量会进入本单位资源池",
        tbl(["批次", "物料", "借出数量", "剩余数量"], CC.借用填报.map((r, i) => [mono(r.批次), h(r.物料), num(r.借出, 3), inp(`b${i}`, "剩余", "number")])) + foot);
    },
  };

  /* ---------- L1 问询清单（F，回看） ---------- */

  const Q = LY.问询;
  const L1 = {
    pane: "画布",
    tabs: ["10月问询清单"],
    init() {},
    bg: () => [["范围", "确定交货期在当月、次月，状态为已确认的供应计划"], ["发出", "10月10日 经 e物资"], ["收回", "10月15日"]],
    intro(T) {
      past(T, "10月10日 09:00 生成问询清单", [
        { a: "查数据", t: `筛出确定交货期在 10 月、11 月、状态为已确认的供应计划 ${num(Q.行, 0)} 行，${Q.订单} 张订单，${Q.供应商} 家供应商，交货期都在 11 月；10 月到期的已是待交货，走到期前催货`, from: "ECP 供应计划", cap: "查询" },
        { a: "按规则", t: "同一供应商的订单合并为一条问询；按订单问排产、图纸、预计到货时间", from: "规则库 · 每月 10 日问询", cap: "分析" },
        { a: "查数据", t: "标注以往延期：长缆今年收货 126 行中晚到 44 行", from: "ERP 收货记录", cap: "查询" },
        { a: "查数据", t: `同时向 ${Q.项目} 个项目的项目部门问是否按原计划收货，不回复视为按原计划`, from: "ERP 项目信息", cap: "查询" },
      ]);
      say(T, { k: "confirm", state: "ok", cid: 0, at: "10-10 10:26", title: "发出问询", action: `经 e物资向 ${Q.供应商 - 1} 家供应商发出问询，15 日收回`, note: "已剔除 1 家：10 月 9 日已电话沟通。", ok: "确认发出" });
      say(T, { k: "result", title: "已发出", lines: [`10-10 10:27 经 e物资向 ${Q.供应商 - 1} 家供应商发出问询`, `向 ${Q.项目} 个项目的项目部门发出收货确认`] });
    },
    right() {
      const rows = Q.rows.map((r) => [r.剔除 ? "☐" : "☑", h(LY.实名 ? r.供应商 : LY.供应商对照[r.供应商]), String(r.订单), String(r.行), num(r.金额, 2), h(r.最早交货期), r.以往 ? `<span class="sc-mark">${h(r.以往)}</span>` : r.剔除 ? `<span class="sc-dim">${h(r.剔除)}</span>` : ""]);
      return page("10月问询清单", `10月10日 09:00 生成 · 已确认的供应计划，确定交货期在 11 月 · ${Q.订单} 张订单 · ${Q.供应商} 家供应商 · 10 月到期的已转待交货，走催货`,
        `<div class="sc-ask"><p><b>问供应商</b>是否排产、图纸是否确认、预计到货时间</p><p><b>问项目部门</b>是否按原计划收货（不回复视为按原计划）</p></div>` +
          tbl(["", "供应商", "订单", "行", "金额（万元）", "最早交货期", "备注"], rows, "sc-t-dense") +
          `<div class="sc-foot ok"><span>10月10日 10:27 已经 e物资发出 ${Q.供应商 - 1} 家 · 10月15日收回</span></div>`);
    },
  };

  /* ---------- L2 答复分级（F） ---------- */

  const FJ = LY.分级;
  const LVS = ["三级履约协调", "违约处理", "提级管控"];
  const L2 = {
    pane: "画布",
    tabs: ["答复分级"],
    init(T) {
      T.open = { 三级履约协调: true, 违约处理: true, 提级管控: false, 正常跟进: false };
      T.cf = {};
    },
    bg: () => [["范围", `问询答复 ${Q.订单} 张＋待交货催货答复 ${LY.催货.订单} 张，共 ${FJ.订单} 张订单`], ["收回", "10月15日"], ["要你做的", "只处理提级管控及以上"]],
    intro(T) {
      stream(T, "解析答复并分级", [
        { a: "查数据", t: `e物资收回答复：${Q.供应商} 家中 ${Q.供应商 - FJ.未回复供应商} 家已回复，${FJ.未回复供应商} 家未回复（${FJ.未回复订单} 张订单）`, from: "e物资", cap: "查询" },
        { a: "查数据", t: `并入待交货订单 ${LY.催货.订单} 张的催货答复；其中已超确定交货期 ${LY.催货.超期订单} 张`, from: "ECP 供应计划、e物资", cap: "查询" },
        { a: "按规则", t: "逐条解析答复原文：排产、图纸、预计到货日期、延期原因；与上次答复对比", from: "答复解析", cap: "分析" },
        { a: "按规则", t: "分四级：正常跟进；提级管控（答复含糊、承诺未兑现、以往延期）；三级履约协调；违约处理", from: "规则库 · 履约分级", cap: "分析" },
        { a: "得结论", t: `三级履约协调 ${FJ.三级履约协调} 张、违约处理 ${FJ.违约处理} 张、提级管控 ${FJ.提级管控} 张、正常跟进 ${FJ.正常跟进} 张` },
        { a: "交给人", t: `提级管控及以上 ${FJ.三级履约协调 + FJ.违约处理 + FJ.提级管控} 张请你确认` },
      ], () => say(T, { k: "ai", html: `未回复的 ${FJ.未回复供应商} 家明天自动再推一次，10 月 18 日仍未回复的转提级管控。` }), 500);
    },
    act(T, a, el) {
      if (a === "s-l2-tg") {
        const k = el.dataset.k;
        T.open[k] = !T.open[k];
        return right(T);
      }
      if (a === "s-l2-up") {
        const o = el.dataset.o;
        const r = FJ.rows.三级履约协调.find((x) => x.订单 === o);
        return confirm(T, {
          title: "提级",
          action: `订单 ${o} 申请物资公司三级履约协调`,
          note: `${supName(r)} · ${wan(r.金额)} · 已超期 ${r.超期} 天。协调申请表随申请一起提交。`,
          ok: "确认提级",
          onOk: () => {
            T.cf[o] = "up";
            say(T, { k: "result", title: "已提交物资公司", lines: [`订单 ${o} 三级履约协调申请已提交`] });
            if (o === LY.万马.订单) {
              G.l2up = true;
              show("L5");
            }
            right(T);
          },
          onCancel: () => {},
        });
      }
      if (a === "s-l2-l4") {
        const o = el.dataset.o;
        if (o === LY.孟邦.订单) return EM.openThread("L4");
        T.cf[o] = "draft";
        toast(`订单 ${o} 处置材料已起草`);
        return right(T);
      }
      if (a === "s-l2-ok") {
        const o = el.dataset.o;
        T.cf[o] = "ok";
        return right(T);
      }
    },
    input(T, t) {
      if (t.dataset.lv) {
        T.cf[t.dataset.lv] = `lv:${t.value}`;
        say(T, { k: "me", text: `订单 ${t.dataset.lv} 改为「${t.value}」` });
        draw(T);
      }
    },
    right(T) {
      const card = (o, lv) => {
        const st = T.cf[o.订单];
        const lvSel = `<select class="sc-sel" data-lv="${o.订单}">${["改级", "正常跟进", "提级管控", "三级履约协调", "违约处理"].map((x) => `<option ${st === `lv:${x}` ? "selected" : ""}>${x}</option>`).join("")}</select>`;
        const acts = st === "up" ? chip("已提交物资公司", "ok") : st === "draft" ? chip("处置材料已起草", "info") : st && st.startsWith("lv:") ? chip(`已改为${st.slice(3)}`, "info") :
          lv === "三级履约协调" ? `${btn("确认提级", `s-l2-up" data-o="${o.订单}`, "p")}${lvSel}` : `${btn(o.订单 === LY.孟邦.订单 ? "查看处置材料" : "生成处置材料", `s-l2-l4" data-o="${o.订单}`, "p")}${lvSel}`;
        return `<article class="sc-ord ${lv === "违约处理" ? "bad" : "warn"}"><header><b>${h(supName(o))}</b>${mono(o.订单)}<span>${h(o.描述)} · ${o.行} 行 · ${h(wan(o.金额))}</span></header>
          <div class="sc-ord-g"><div><dt>确定交货期</dt><dd>${h(o.交货期)}${o.超期 ? ` · <b class="sc-red">已超 ${o.超期} 天</b>` : ""}</dd></div><div><dt>项目</dt><dd>${h(o.项目)}</dd></div></div>
          <p class="sc-reply"><i>答复原文</i>${o.答复 ? `“${h(o.答复)}”` : '<span class="sc-dim">未给出交货日期</span>'}</p>
          <p class="sc-parse">${(o.解析 || []).map((x) => `<span>${h(x)}</span>`).join("")}</p>
          <p class="sc-why"><i>判级</i>${h(o.理由)}</p><p class="sc-why"><i>建议</i>${h(o.建议)}</p><footer>${acts}</footer></article>`;
      };
      const head = (k, n, tone) => `<button class="sc-lvh ${tone}" data-em-act="s-l2-tg" data-k="${k}"><b>${h(k)}</b><em>${n}</em><i>${T.open[k] ? "▾" : "▸"}</i></button>`;
      let body = kpis([{ k: "正常跟进", v: FJ.正常跟进 }, { k: "提级管控", v: FJ.提级管控, tone: "warn" }, { k: "三级履约协调", v: FJ.三级履约协调, tone: "bad" }, { k: "违约处理", v: FJ.违约处理, tone: "bad" }]);
      body += `<p class="sc-norep">另有 ${FJ.未回复供应商} 家供应商未回复（${FJ.未回复订单} 张订单）：明天自动再推，10 月 18 日仍未回复的转提级管控。<span>${(LY.实名 ? FJ.未回复 : FJ.未回复名).map(h).join("、")}</span></p>`;
      body += head("三级履约协调", FJ.三级履约协调, "bad") + (T.open.三级履约协调 ? FJ.rows.三级履约协调.map((o) => card(o, "三级履约协调")).join("") : "");
      body += head("违约处理", FJ.违约处理, "bad") + (T.open.违约处理 ? FJ.rows.违约处理.map((o) => card(o, "违约处理")).join("") : "");
      body += head("提级管控", FJ.提级管控, "warn") + (T.open.提级管控 ? tbl(["订单", "供应商", "物料", "行", "金额（万元）", "确定交货期", "答复原文", "判级理由", ""], FJ.rows.提级管控.map((o) => [mono(o.订单), h(supName(o)), h(o.物料), String(o.行), num(o.金额 / 10000, 2), `${h(o.交货期)}${o.超期 ? `<br><b class="sc-red">超 ${o.超期} 天</b>` : ""}`, h(o.答复), h(o.理由), T.cf[o.订单] === "ok" ? chip("已确认", "ok") : `<button class="sc-seg" data-em-act="s-l2-ok" data-o="${o.订单}">确认</button>`]), "sc-t-dense") : "");
      body += head("正常跟进", FJ.正常跟进, "") + (T.open.正常跟进 ? tbl(["订单", "供应商", "物料", "确定交货期", "答复原文"], LY.分级.正常样例.map((o) => [mono(o.订单), h(supName(o)), h(o.物料), h(o.交货期), h(o.答复 || "")]), "sc-t-dense") + `<p class="sc-note">显示前 40 张，共 ${FJ.正常跟进} 张</p>` : "");
      return page("10月问询答复分级", `${h(LY.工厂名称)} · 10月15日收回 · ${FJ.订单} 张订单`, body);
    },
  };

  /* ---------- L3 催货与开票提醒（F） ---------- */

  const CH = LY.催货;
  const L3 = {
    pane: "画布",
    tabs: ["催货", "开票提醒"],
    init() {},
    bg: () => [["催货", "待交货的供应计划，距确定交货期 10 天催一次；同一供应商合并；未回复自动再推"], ["开票提醒", "交货完成次日一次，20 天后再一次，30 天截止"]],
    intro(T) {
      past(T, "今日 08:00 自动执行", [
        { a: "查数据", t: `待交货供应计划 ${num(CH.行, 0)} 行、${CH.订单} 张订单；已验收的退出`, from: "ECP 供应计划", cap: "查询" },
        { a: "按规则", t: `确定交货期 ${CH.触发日} 的订单今日催货：${CH.今日.length} 家供应商`, from: "规则库 · 到期前 10 天催货", cap: "分析" },
        { a: "办理", t: "经 e物资发出催货；上次催货未回复的自动再推", from: "e物资", cap: "写入" },
        { a: "办理", t: "交货完成次日、交货后 20 天的订单，经 e物资提醒开票，附订单号、入库数量和备注格式", from: "ERP 入库数据、e物资", cap: "写入" },
      ]);
    },
    right(T) {
      if (T.tab === 1)
        return page("开票提醒", "交货完成次日第 1 次 · 交货后 20 天第 2 次 · 30 天截止 · 近期发送记录",
          tbl(["采购订单", "供应商", "入库凭证", "交货日期", "行", "金额（元）", "提醒", "状态"], LY.开票.map((r) => [mono(r.订单), h(LY.实名 ? r.供应商 : r.供应商名), mono(r.入库凭证), h(r.交货日期), String(r.行), num(r.金额, 2), h(r.提醒), r.状态 === "已开票" ? chip("已开票", "ok") : chip(r.状态, "warn")]), "sc-t-dense") +
            `<p class="sc-note">提醒附办理指引：开票通知编号、采购订单号、入库数量、开票总金额，发票备注填写“耗用清单编号；采购订单编号”。</p>`);
      return page("催货", `待交货 ${CH.订单} 张订单 · ${CH.供应商} 家供应商 · 已超期 ${CH.超期订单} 张（${CH.超期供应商} 家）`,
        sec(`今日催货 · 确定交货期 ${CH.触发日}`, tbl(["供应商", "订单", "行", "物料", "回复"], CH.今日.map((r) => [h(supName(r)), String(r.订单), String(r.行), h(r.物料), chip(r.回复, "info")]))) +
          sec("前两日催货的回复", tbl(["供应商", "订单", "行", "确定交货期", "物料", "回复"], CH.前次.map((r) => [h(supName(r)), String(r.订单), String(r.行), h(r.交货期), h(r.物料), /未回复/.test(r.回复) ? chip(r.回复, "warn") : /晚/.test(r.回复) ? chip(r.回复, "bad") : chip(r.回复, "ok")]), "sc-t-dense")) +
          `<p class="sc-note">已超期的 ${CH.超期订单} 张订单在「10月问询答复分级」中处理。</p>`);
    },
  };

  /* ---------- L4 超期处置材料（F） ---------- */

  const MB = LY.孟邦;
  const MBN = supName(MB);
  const docs = () => {
    const rows = MB.rows;
    const maxD = Math.max(...rows.map((r) => r.超期));
    const minD = Math.min(...rows.map((r) => r.超期));
    return {
      约谈提纲: [
        ["约谈事由", `采购订单 ${MB.订单}（合同 ${MB.合同号}，ECP ${MB.ECP合同号}）防火堵料共 ${rows.length} 行，确定交货期 2026 年 10 月 8 日至 12 日，截至 10 月 15 日未交货，已超期 ${minD}—${maxD} 天。到期前 10 天经 e物资催货未回复，10 月 13 日电话催货仍未给出交货日期。同一供应商另有 ${MB.其他超期订单.length} 张订单超期（${MB.其他超期订单.join("、")}）。`],
        ["约谈时间地点", "2026 年 10 月 17 日 10:00，市区供电分公司物资部会议室（供应商可线上参加）"],
        ["参加人员", "市区供电分公司物资部、项目部门；供应商法定代表人或携带法定代表人授权委托书的人员"],
        ...(G.l6fb ? [["对工程的影响（项目部门反馈）", G.l6fb]] : []),
        ["需供应商说明的事项", "未交货的原因；能否分批交货，首批数量和时间；全部交货的最晚日期；后续订单的保供措施。"],
        ["合同依据", "专用合同条款第 14.2.5 条：卖方违反合同约定迟延交货的，买方有权按迟交货物金额的 1‰/天向卖方主张迟延交货违约金，迟延交货违约金总额不超过供货单金额的 10%。第 14.2.17 条：卖方存在迟延交货等不良履约行为的，每出现一次买方有权核减合同总量的 10%。"],
        ["管理依据", "《国家电网有限公司供应商关系管理办法》（国网（物资/2）128-2023）第六十二条：原则上应通过约谈供应商认定不良行为；下级单位提报的不良行为由下级单位约谈；约谈前应向供应商发出书面通知，告知具体约谈内容。"],
        ["拟提出的要求", "3 个工作日内书面提交交货计划并加盖公章；按迟延天数计迟延交货违约金；建议物资公司按第 14.2.17 条核减合同总量 10%。"],
      ],
      协调申请表: [
        ["申请单位", "国网重庆市电力公司市区供电分公司"],
        ["供应商", MBN],
        ["合同", `${MB.合同名称}（${MB.合同号}）`],
        ["涉及订单", `${MB.订单}，另有 ${MB.其他超期订单.join("、")}`],
        ["问题", `防火堵料 ${rows.length} 行超期 ${minD}—${maxD} 天，供应商未给出交货日期`],
        ["已采取措施", "到期前 10 天经 e物资催货；10 月 13 日电话催货；10 月 17 日约谈"],
        ["申请协调事项", "约谈后 3 个工作日内仍无书面交货计划的，请物资公司协调供应商高层，并按合同核减"],
      ],
      确认书: [
        ["确认事项", `${MBN}确认：采购订单 ${MB.订单} 共 ${rows.length} 行于确定交货期未交货，迟延天数以实际到货日期为准计算。`],
        ["交货承诺", "供应商承诺于____年__月__日前全部交货，首批____于____年__月__日前交货。"],
        ["违约责任", "供应商确认按专用合同条款第 14.2.5 条承担迟延交货违约金。"],
        ["签字盖章", "供应商（盖章）：　　　　　　法定代表人或授权委托人（签字）：　　　　　　日期："],
      ],
      考核依据: [
        ["违约金计算", `按专用合同条款第 14.2.5 条，迟交货物金额 × 1‰ × 迟延天数，截至 10 月 15 日合计 ${yuan(MB.违约金)}，按实际到货日期结算。`],
        ["上限", `不超过供货单金额的 10%（供货单金额 ${yuan(MB.金额)}）`],
        ["核减建议", `按第 14.2.17 条，每出现一次不良履约行为可核减合同总量的 10%。合同含税价 ${yuan(MB.合同价)}，核减 10% 对应 ${yuan(MB.合同价 * 0.1)}。由物资公司决定。`],
        ["不良行为", "按管理办法第六十二条走约谈认定、告知确认（5 个工作日异议受理期）、审批发布。"],
      ],
      归档报告: [
        ["事件经过", `9 月 28 日至 10 月 2 日到期前催货未回复；10 月 8 日至 12 日 ${rows.length} 行到期未交货；10 月 13 日电话催货未给出日期；10 月 15 日分级为违约处理。`],
        ["处置结果", "约谈、交货承诺、违约金和核减建议，待约谈后补录"],
        ["归档材料", "问询与催货记录、答复原文、约谈通知与记录、确认书、违约金计算表、协调申请表"],
        ["归档位置", "工作台履约档案 · 订单 4500953501"],
      ],
    };
  };
  const L4 = {
    pane: "画布",
    tabs: ["订单与依据", "约谈提纲", "协调申请表", "确认书", "考核依据", "归档报告"],
    init(T) {
      T.ok = false;
    },
    bg: () => [["订单", `${MB.订单}｜${MBN}`], ["合同", `${MB.合同号}（ECP ${MB.ECP合同号}）`], ["级别", "违约处理"]],
    intro(T) {
      stream(T, "起草处置材料", [
        { a: "查数据", t: `订单 ${MB.订单} 共 ${MB.rows.length} 行，确定交货期 10-08 至 10-12，均为待交货`, from: "ECP 供应计划", cap: "查询" },
        { a: "查数据", t: `调出合同 ${MB.合同号}：专用合同条款第 14.2.5 条（迟延交货 1‰/天，上限 10%）、第 14.2.17 条（不良履约核减合同总量 10%）`, from: "ECP 合同文本 · 专用合同条款", cap: "查询" },
        { a: "查数据", t: "调出《供应商关系管理办法》第六十二条：约谈认定、书面通知、授权委托人参加", from: "国网（物资/2）128-2023", cap: "查询" },
        { a: "按规则", t: `按行计算迟延交货违约金，截至今日 ${yuan(MB.违约金)}`, from: "专用合同条款第 14.2.5 条", cap: "分析" },
        { a: "写作", t: "起草约谈提纲、协调申请表、确认书、考核依据、归档报告 5 份", from: "约谈记录表、协调申请表模板", cap: "写作" },
        { a: "交给人", t: "处置方式和归档内容由你确认" },
      ], () => say(T, { k: "ai", html: "5 份材料在右侧页签。确认处置方式后，我经 e物资向供应商发出约谈通知。", btns: [["确认处置方式", "s-l4-ok", "p"]] }), 500);
    },
    used: (T, a) => (a === "s-l4-ok" ? T.ok : false),
    act(T, a) {
      if (a === "s-l4-dl") return toast(`已下载《${T.tabs[T.tab]}_${MB.订单}.docx》`);
      if (a === "s-l4-ok" && !T.ok) {
        confirm(T, {
          title: "确认处置方式",
          action: "约谈供应商（10 月 17 日 10:00），计迟延交货违约金，建议物资公司核减合同总量 10%",
          note: "约谈通知经 e物资发出；协调申请表、考核依据随约谈结果报物资公司。",
          ok: "确认并发出约谈通知",
          onOk: () => {
            T.ok = true;
            T.done = true;
            G.l4 = true;
            say(T, { k: "result", title: "约谈通知已发出", lines: ["10-15 经 e物资发给供应商", "约谈后补录处置结果并归档"] });
            finish(T.id, { status: "external", current: "约谈通知已发出，待 10 月 17 日约谈", remain: "待约谈", log: "确认处置方式，发出约谈通知" });
          },
          onCancel: () => {},
        });
      }
    },
    right(T) {
      if (T.tab === 0)
        return page(`订单 ${MB.订单}`, `${h(MBN)} · ${h(MB.合同名称)}`,
          tbl(["行", "物料编码", "物料", "数量", "金额（元）", "确定交货期", "超期", "违约金（元）", "项目"], MB.rows.map((r) => [r.行, mono(r.物料编码), h(r.物料), num(r.数量, 3), num(r.金额, 2), h(r.确定交货期), `<b class="sc-red">${r.超期} 天</b>`, num(r.违约金, 2), h(r.项目)]), "sc-t-dense") +
            sec("合同", kv([["合同编号（买方）", mono(MB.合同号)], ["ECP 合同编号", mono(MB.ECP合同号)], ["合同价（含税）", yuan(MB.合同价)], ["买方", "国网重庆市电力公司物资分公司"]])) +
            sec("引用条款", `<blockquote class="sc-quote">14.2.5 卖方违反合同约定迟延交货的，买方有权按迟交货物金额的1‰/天向卖方主张迟延交货违约金。迟延交货违约金总额不超过供货单金额的10%。<cite>专用合同条款</cite></blockquote><blockquote class="sc-quote">14.2.17 卖方存在货物质量不合格、迟延交货、售后服务不到位等不良履约行为的，每出现一次买方有权核减合同总量的10%……<cite>专用合同条款</cite></blockquote><blockquote class="sc-quote">原则上应通过约谈供应商，认定供应商不良行为。下级单位提报的不良行为，由下级单位约谈……在约谈前应向供应商发出书面通知，告知供应商具体约谈内容。<cite>《国家电网有限公司供应商关系管理办法》第六十二条</cite></blockquote>`));
      const name = T.tabs[T.tab];
      const d = docs()[name];
      return `<div class="sc-doc"><div class="sc-doc-h"><h3>${h(name)}</h3><p>订单 ${h(MB.订单)} · ${h(MBN)}</p>${btn("下载 docx", "s-l4-dl")}</div>${d.map((r) => `<section><h5>${h(r[0])}</h5><p>${h(r[1])}</p></section>`).join("")}</div>`;
    },
  };

  /* ---------- L5 三级履约协调（A） ---------- */

  const WM = LY.万马;
  const WMN = supName(WM);
  const CROSS = [
    ["市区供电分公司", WM.订单, "220kV电缆终端等 8 行", wan(WM.金额), WM.交货期, "已超 5 天"],
    ["市北供电分公司", "4500946215", "电力电缆 AC10kV YJV 3×400", "386.40 万元", "2026-10-12", "已超 3 天"],
    ["市北供电分公司", "4500951137", "10kV电缆中间接头 3×400", "42.18 万元", "2026-10-28", "—"],
    ["市北供电分公司", "4500953560", "1kV电缆终端 4×185", "8.65 万元", "2026-11-06", "—"],
    ["物资公司直管", "4500949902", "110kV电缆终端", "612.00 万元", "2026-10-09", "已超 6 天"],
    ["物资公司直管", "4500955018", "电力电缆 AC110kV 1×800", "1,286.50 万元", "2026-11-20", "—"],
  ];
  const L5 = {
    pane: "画布",
    tabs: ["三级履约协调申请"],
    init() {},
    bg: () => [["申请单位", "市区供电分公司"], ["订单", `${WM.订单}｜${wan(WM.金额)}`], ["时限", "今日17:00"]],
    intro(T) {
      stream(T, "受理前核对", [
        { a: "查数据", t: `市区供电分公司申请：${WMN}订单 ${WM.订单}，${WM.rows.length} 行，${wan(WM.金额)}，确定交货期 ${WM.交货期}，已超 5 天`, from: "工作台三级履约协调申请", cap: "查询" },
        { a: "查数据", t: "供应商答复：220kV 电缆终端附件（应力锥）到厂延误，预计 10 月 30 日发货", from: "e物资答复原文", cap: "查询" },
        { a: "查数据", t: "同一供应商全省在途订单 6 张，其中超期 3 张（市区 1、市北 1、物资公司直管 1）", from: "ECP 供应计划（各单位）", cap: "查询" },
        { a: "得结论", t: "多家单位同时超期，属于供应商整体履约问题，适合物资公司统一约谈" },
        { a: "交给人", t: "受理或退回由你决定" },
      ], null, 500);
    },
    act(T, a) {
      if (a === "s-l5-ok" || a === "s-l5-back") {
        const ok = a === "s-l5-ok";
        confirm(T, {
          title: ok ? "受理" : "退回",
          action: ok ? "受理三级履约协调：约谈供应商（10 月 17 日 14:00，物资公司），全省 3 张超期订单一并督办" : "退回市区供电分公司先行约谈",
          note: ok ? "约谈通知经 e物资发出，并抄送市区、市北供电分公司。" : "退回意见推送给市区履约专责。",
          ok: ok ? "确认受理" : "确认退回",
          onOk: () => {
            T.done = true;
            G.l5 = ok ? "ok" : "back";
            say(T, { k: "result", title: ok ? "已受理" : "已退回", lines: ok ? ["约谈通知已经 e物资发出", "3 张超期订单列入督办"] : ["市区履约专责已收到退回意见"] });
            finish(T.id, { status: ok ? "external" : "done", current: ok ? "已受理，待 10 月 17 日约谈" : "已退回市区", remain: ok ? "待约谈" : "已完成", log: ok ? "受理三级履约协调" : "退回市区" });
          },
          onCancel: () => {},
        });
      }
    },
    right(T) {
      return page("三级履约协调申请", `市区供电分公司 · ${h(WMN)} · 订单 ${mono(WM.订单)}`,
        sec("申请内容", kv([["订单", `${mono(WM.订单)} · ${WM.rows.length} 行 · ${h(wan(WM.金额))} · ${h(WM.方式)}`], ["项目", h(WM.项目)], ["确定交货期", `${h(WM.交货期)} · <b class="sc-red">已超 5 天</b>`], ["供应商答复", "“220kV 电缆终端附件（应力锥）到厂延误，预计 10 月 30 日发货，11 月 2 日到货。”"], ["市区意见", "要求 10 月 30 日前发货并书面承诺；用于重点用户业扩送电，申请物资公司协调"], ["合同依据", "合同迟延交货违约条款"]])) +
          sec("同一供应商全省在途订单 · 6 张", tbl(["单位", "订单", "物料", "金额", "确定交货期", "超期"], CROSS.map((r) => [h(r[0]), mono(r[1]), h(r[2]), h(r[3]), h(r[4]), r[5] === "—" ? "—" : `<b class="sc-red">${h(r[5])}</b>`]))) +
          sec("订单明细", tbl(["行", "物料编码", "物料", "数量", "金额（元）"], WM.rows.map((r) => [r.行, mono(r.物料编码), h(r.物料), num(r.数量, 3), num(r.金额, 2)]), "sc-t-dense")) +
          `<div class="sc-foot">${T.done ? `<span>${G.l5 === "ok" ? "已受理，约谈通知已发出" : "已退回"}</span>` : `<span>附：协调申请表.docx</span><div>${btn("退回市区先行处理", "s-l5-back")}${btn("受理并约谈供应商", "s-l5-ok", "p")}</div>`}</div>`);
    },
  };

  /* ---------- 对话中发起：对话组装场景（C） ---------- */

  const AGE = CC.库龄;
  const OV = CC.超期;
  const CZ = {
    pane: "画布",
    tabs: ["场景草稿"],
    init(T) {
      T.st = 0;
      T.soon = false;
    },
    bg: () => [],
    intro(T) {
      say(T, { k: "ai", html: `库龄规定各库不同：${h(CC.库龄规定)}（${h(CC.库龄出处)}）。<br>按各自的规定算，还是统一按 1 年？` });
    },
    reply(T, v) {
      if (T.st === 0) {
        T.unified = /统一|都按|一年|1年/.test(v) && !/各自|规定/.test(v);
        T.soon = /30|三十|快|即将|就要/.test(v);
        T.st = 1;
        later(T, 300, () => czDraft(T));
        return true;
      }
      if (T.st === 1 && /30|三十|快|即将|就要/.test(v)) {
        T.soon = true;
        later(T, 300, () => czDraft(T));
        return true;
      }
      return false;
    },
    used: () => !!G.cz,
    act(T, a) {
      if (a === "s-cz-save") {
        G.cz = "me";
        T.done = true;
        say(T, { k: "result", title: "已保存为个人场景", lines: ["「库龄超期物资周报」每周一 08:00 运行，结果推送到今日简报", "在左侧「定时任务」里可以查看、修改或停用"] });
        finish(T.id, { status: "done", current: "已保存为个人场景", remain: "每周一08:00", log: "保存个人场景" });
      }
      if (a === "s-cz-apply") {
        G.cz = "all";
        T.done = true;
        say(T, { k: "result", title: "已申请为省公司通用场景", lines: ["管理员审批后，全省仓储专责可选用", "审批前先按个人场景运行"] });
        finish(T.id, { status: "done", current: "已申请省公司通用场景", remain: "待审批", log: "申请省公司通用场景" });
      }
    },
    right(T) {
      if (T.st === 0) return page("场景草稿", "", empty("回答上面的问题后生成草稿"));
      const r = czCount(T);
      return page("本周试运行结果", `按${T.unified ? "统一 1 年" : "各库规定"}筛选 · 不写入任何系统`,
        kpis([{ k: "已超期", v: num(r.over, 0), tone: "bad" }, ...(T.soon ? [{ k: "30 天内超期", v: r.soon, tone: "warn" }] : [])]) +
          tbl(["来源", "规定", "已超期", ...(T.soon ? ["30 天内超期"] : [])], r.rows.map((x) => [h(x[0]), h(x[1]), num(x[2], 0), ...(T.soon ? [String(x[3])] : [])])) +
          sec("已超期 · 节选", tbl(["来源", "物料", "数量", "库龄"], CC.超期样例.map((x) => x.map(h)))));
    },
  };
  function czCount(T) {
    const rows = OV.map((o) => (T.unified ? [o.来源, "1 年", o.按一年已超期, o.按一年三十天内] : [o.来源, o.规定, o.已超期, o.三十天内]));
    return { rows, over: rows.reduce((a, x) => a + x[2], 0), soon: rows.reduce((a, x) => a + x[3], 0) };
  }
  function czDraft(T) {
    const r = czCount(T);
    say(T, {
      k: "card",
      title: "场景草稿：库龄超期物资周报",
      html: `<ol class="sc-steps"><li><b>何时</b>每周一 08:00</li><li><b>取数</b>本单位实体库、应急库、代保管库、借用库、专业仓</li><li><b>筛选</b>${T.unified ? "库龄统一按 1 年" : h(CC.库龄规定)}，已超期${T.soon ? "＋30 天内超期" : ""}</li><li><b>整理</b>按来源分组，列物料、数量、库龄、库存地点</li><li><b>推送</b>今日简报</li></ol><p class="sc-sub2">用到：资源池查询、规则库（库龄规定）、分组汇总、推送提醒。只读，不写入任何系统。</p><p class="sc-sub2">本周试运行：已超期 ${num(r.over, 0)} 条${T.soon ? `，30 天内超期 ${r.soon} 条` : ""}，结果在右侧。</p>`,
      btns: [["保存为个人场景", "s-cz-save", "p"], ["申请为省公司通用场景", "s-cz-apply"]],
    });
    if (!T.soon) say(T, { k: "ai", html: "还要加什么条件，可以直接说，例如再加上快到期的。" });
    draw(T);
  }

  /* ---------- 对话中发起：看库龄数据（C） ---------- */

  const CQ = {
    pane: "画布",
    tabs: ["库龄分布"],
    init() {},
    bg: () => [],
    intro(T) {
      const sp = AGE.rows.find((r) => r.来源 === "专业仓");
      const dbg = AGE.rows.find((r) => r.来源 === "代保管库");
      stream(T, "查询", [
        { a: "查数据", t: "本单位实体库、应急库、代保管库、借用超量、专业仓的库存，按最近入库日期计算库龄", from: "ERP 库存、专业仓管理系统、借用物资收集表", cap: "查询" },
        { a: "按规则", t: "分 1 年以内、1—2 年、2—3 年、3 年以上", from: "资源池 · 入库日期", cap: "分析" },
      ], () => say(T, { k: "ai", html: `专业仓 3 年以上 ${num(sp.值[3], 0)} 条，代保管库超过 1 年 ${dbg.值[1] + dbg.值[2] + dbg.值[3]} 条，结果在右侧。` }), 450);
    },
    right() {
      const mx = Math.max(...AGE.rows.flatMap((r) => r.值));
      const bars = AGE.rows.map((g) => `<div class="sc-bar-row"><span>${h(g.来源)}</span><div>${g.值.map((v, j) => `<i class="b${j}" style="width:${(v / mx) * 88}%"><em>${v}</em></i>`).join("")}</div></div>`).join("");
      const miss = AGE.rows.filter((r) => r.无日期).map((r) => `${r.来源} ${r.无日期} 条没有入库日期，未计入`).join("；");
      return page("库存库龄分布", "市北供电分公司 · 10月15日 · 条数",
        `<div class="sc-legend">${AGE.段.map((s, j) => `<span><i class="b${j}"></i>${h(s)}</span>`).join("")}</div><div class="sc-bars">${bars}</div>` +
          tbl(["来源", ...AGE.段, "合计"], AGE.rows.map((g) => [h(g.来源), ...g.值.map((v) => num(v, 0)), num(g.值.reduce((a, b) => a + b, 0), 0)])) + (miss ? `<p class="sc-note">${h(miss)}</p>` : ""));
    },
  };

  /* ---------- 对话中发起：写材料（C 仓储、F 履约） ---------- */

  function docPage(title, sub, secs) {
    return `<div class="sc-doc"><div class="sc-doc-h"><h3>${h(title)}</h3><p>${h(sub)}</p>${btn("下载 docx", "s-doc-dl")}</div>${secs.map((s) => `<section><h5>${h(s[0])}</h5><p>${h(s[1])}</p>${s[2] ? `<small>数据来源：${h(s[2])}</small>` : ""}</section>`).join("")}</div>`;
  }
  const CW = {
    pane: "画布",
    tabs: ["10月库存消纳情况"],
    init() {},
    bg: () => [],
    intro(T) {
      stream(T, "起草", [
        { a: "查数据", t: "资源池、库龄、需求计划匹配记录、不利库审批记录、消纳计划", from: "工作台", cap: "查询" },
        { a: "写作", t: "按「总体情况、库龄、提报匹配、不利库、消纳计划、下一步」起草", cap: "写作" },
      ], () => say(T, { k: "ai", html: "初稿在右侧，每段注明了数据来源。要改哪段直接说。" }), 450);
    },
    act(T, a) {
      if (a === "s-doc-dl") toast("已下载《市北供电分公司10月库存消纳情况.docx》");
    },
    right() {
      const ov = (k) => OV.find((o) => o.来源 === k) || { 已超期: 0 };
      return docPage("市北供电分公司10月库存消纳情况", "仓储专责 · 2026年10月15日", [
        ["总体情况", `本单位可利库资源池 ${num(PL.total, 0)} 条：实体库 ${PL.利库} 条、代保管库 ${PL.代保管} 条、借用超量 ${PL.借用超量} 条、专业仓 ${num(PL.专业仓, 0)} 条；应急库 ${PL.应急} 条为抢修储备，不参与匹配。`, "资源池（10月15日 08:00）"],
        ["库龄", `按${CC.库龄规定}核对：专业仓已超期 ${num(ov("专业仓").已超期, 0)} 条，代保管库已超期 ${ov("代保管库").已超期} 条，实体库 30 天内到期 ${ov("实体库").三十天内} 条。`, "ERP 库存、专业仓管理系统"],
        ["提报匹配", "10 月以来需求部门在工作台提报需求计划 6 份 214 行，本单位有库存 23 行，采纳利库 14 行，不利库 9 行。", "工作台提报记录"],
        ["不利库情况", "本月报主任审批 14 条：数据核验通过 9 条（盘长/段长不匹配 5 条、安装不匹配 2 条、利库运输距离远 2 条），专责认定 4 条；另有 ERP 直接提报未经匹配 1 条，已挂起审批。", "不利库审批记录"],
        ["消纳计划", `${XN.部门.length} 个部门消纳计划 ${XN.总} 项，${XN.超期} 项已超过规定期限（${xnCats()}）；江北中心 8 项借用物资未填拟用项目。`, "市北消纳计划表"],
        ["下一步", "催办江北中心 10 月 17 日前补填或归还；资源池清单导出发设计单位；库龄超期物资每周一推送。", ""],
      ]);
    },
  };
  const LW = {
    pane: "画布",
    tabs: ["10月订单问询与催货情况"],
    init() {},
    bg: () => [],
    intro(T) {
      stream(T, "起草", [
        { a: "查数据", t: "问询清单、答复分级、催货与开票提醒记录", from: "工作台、e物资", cap: "查询" },
        { a: "写作", t: "按「问询、答复分级、超期订单、催货与开票、下一步」起草", cap: "写作" },
      ], () => say(T, { k: "ai", html: "初稿在右侧，数字都来自本月问询和分级结果。要改哪段直接说。" }), 450);
    },
    act(T, a) {
      if (a === "s-doc-dl") toast("已下载《市区供电分公司10月订单问询与催货情况.docx》");
    },
    right() {
      return docPage("市区供电分公司10月订单问询与催货情况", "履约专责 · 2026年10月15日", [
        ["问询", `10 月 10 日对确定交货期在 10 月、11 月的已确认供应计划发起问询（交货期均在 11 月），${Q.订单} 张订单、${Q.供应商} 家供应商，经 e物资发出 ${Q.供应商 - 1} 家（1 家已电话沟通），15 日收回。`, "ECP 供应计划、e物资"],
        ["答复分级", `并入待交货订单的催货答复，共 ${FJ.订单} 张订单：正常跟进 ${FJ.正常跟进} 张，提级管控 ${FJ.提级管控} 张，三级履约协调 ${FJ.三级履约协调} 张，违约处理 ${FJ.违约处理} 张；${FJ.未回复供应商} 家供应商未回复（${FJ.未回复订单} 张订单），明日再推。`, "e物资答复、分级结果"],
        ["超期订单", `待交货 ${CH.订单} 张订单中已超期 ${CH.超期订单} 张，涉及 ${CH.超期供应商} 家供应商。金额最大的为订单 ${WM.订单}（${wan(WM.金额)}），已申请物资公司三级履约协调；订单 ${MB.订单} 超期 3—7 天且未给出交货日期，拟 10 月 17 日约谈。`, "ECP 供应计划"],
        ["催货与开票", `每日对距确定交货期 10 天的订单催货，今日 ${CH.今日.length} 家；近期开票提醒 ${LY.开票.length} 笔。`, "e物资"],
        ["下一步", "10 月 17 日约谈；10 月 18 日对仍未回复的供应商转提级管控；11 月 10 日发起下月问询。", ""],
      ]);
    },
  };

  /* ---------- L6 项目物资进度（G 项目管理人员） ---------- */

  const PJ = LY.项目;
  const pjShort = pjName();
  const pjOver = PJ.rows.filter((r) => r.超期 > 0);
  const pjRisk = PJ.rows.filter((r) => r.级别 === "提级管控" || r.级别 === "违约处理" || r.级别 === "三级履约协调");
  const pjRecv = PJ.rows.filter((r) => r.状态 === "已确认");
  const mbRow = MB.rows.find((r) => r.项目 === PJ.名称) || MB.rows[0];
  const STC = { 已验收: "ok", 待交货: "warn", 已确认: "info" };
  const LVC = { 正常跟进: "ok", 提级管控: "warn", 三级履约协调: "bad", 违约处理: "bad" };
  const pjCount = (lv, over) => PJ.rows.filter((r) => r.级别 === lv && (!over || r.超期 > 0)).length;
  const deal = (r) =>
    r.订单 === MB.订单 ? (G.l4 ? "约谈通知已发出，10月17日约谈，计迟延交货违约金" : "履约专责已起草约谈材料，拟10月17日约谈") : r.级别 === "提级管控" ? "履约专责每周跟进，要求书面给出排产计划和发货日期" : "";
  function pjProgress() {
    const A = PJ.状态;
    return page(`${PJ.名称}`, `项目 ${mono(PJ.编号)} · ${PJ.订单} 张订单 · ${PJ.行} 行 · ${wan(PJ.金额)}`,
      kpis([{ k: "已验收", v: A.已验收 || 0, s: "已到货验收" }, { k: "待交货", v: A.待交货 || 0, s: `已超确定交货期 ${pjOver.length} 张`, tone: "bad" }, { k: "已确认", v: A.已确认 || 0, s: "11月16日交货" }, { k: "需关注", v: pjRisk.length, s: "提级管控、违约处理", tone: "warn" }]) +
        tbl(["订单", "供应商", "物料", "行", "金额（元）", "确定交货期", "状态", "供应商答复 / 管控级别"], PJ.rows.map((r) => {
          const tr = [mono(r.订单), h(supName(r)), h(r.物料), String(r.行), num(r.金额, 2), `${h(r.交货期)}${r.超期 ? `<br><b class="sc-red">已超 ${r.超期} 天</b>` : ""}`, chip(r.状态, STC[r.状态]),
            r.状态 === "已验收" ? `<span class="sc-dim">${h(r.到货)} 到货</span>` : `${r.答复 ? h(r.答复) : '<span class="sc-dim">未答复</span>'}${r.级别 ? `<br>${chip(r.级别, LVC[r.级别])}` : ""}`];
          if (pjRisk.includes(r)) tr.cls = "sc-hl";
          return tr;
        }), "sc-t-dense sc-t-pj") + `<p class="sc-note">数据来自 ECP 供应计划、ERP 项目信息和 e物资答复，每日 08:00 更新。</p>`);
  }
  const L6 = {
    pane: "画布",
    tabs: ["物资进度", "收货确认", "供货异常"],
    init(T) {
      T.f = {};
      T.recv = false;
      T.fb = false;
    },
    bg: () => [["项目", `${PJ.名称}（${PJ.编号}）`], ["履约专责", "市区供电分公司物资部"], ["确认截止", "10月17日"]],
    intro(T) {
      past(T, "汇总项目物资进度（10月15日 08:00）", [
        { a: "查数据", t: `项目 ${PJ.编号} 的采购订单 ${PJ.订单} 张、${PJ.行} 行`, from: "ERP 项目信息、ECP 供应计划", cap: "查询" },
        { a: "查数据", t: "并入供应商 10 月问询和催货答复、履约专责的管控级别", from: "e物资、工作台履约分级", cap: "查询" },
        { a: "按规则", t: `对照确定交货期：待交货 ${PJ.状态.待交货} 张已全部超期`, from: "ECP 供应计划", cap: "分析" },
      ]);
      say(T, { k: "ai", html: `${h(pjShort)}共 ${PJ.订单} 张订单：已验收 ${PJ.状态.已验收} 张；待交货 ${PJ.状态.待交货} 张，都已超过确定交货期，其中 ${pjCount("正常跟进", true)} 张供应商答复已到货或在途，${pjCount("提级管控", true)} 张没给发货日期、已提级管控；防火堵料 1 张供应商未答复，转违约处理。<br>需要你做两件事：确认 11 月 16 日交货的 ${pjRecv.length} 张订单是否按原计划收货；说明防火堵料晚到对工期的影响，我转给履约专责写进约谈材料。` });
    },
    act(T, a) {
      if (a === "s-l6-recv" && !T.recv) {
        T.recv = true;
        const later_ = pjRecv.filter((r, i) => (T.f[`r${i}`] || "按原计划收货") !== "按原计划收货").length;
        say(T, { k: "result", title: "收货确认已回传", lines: [`${pjRecv.length - later_} 张按原计划收货${later_ ? `，${later_} 张调整收货时间` : ""}`, "履约专责在问询答复中可见，供应商按确认结果备货"] });
        L6.end(T);
        draw(T);
      }
      if (a === "s-l6-fb" && !T.fb) {
        const d = T.f.fbDate || "10月20日";
        const w = T.f.fbWhy || "电缆沟封堵完成后才能送电";
        T.fb = true;
        stream(T, "转交履约专责", [
          { a: "查数据", t: `订单 ${MB.订单} 行 ${mbRow.行}：防火堵料 ${num(mbRow.数量, 0)}，确定交货期 ${mbRow.确定交货期}，已超期 ${mbRow.超期} 天`, from: "ECP 供应计划", cap: "查询" },
          { a: "写作", t: `写入约谈提纲「对工程的影响」：最晚 ${d} 到货；${w}`, from: "项目部门反馈", cap: "写作" },
        ], () => {
          G.l6fb = `${PJ.名称}：最晚 ${d} 到货；${w}`;
          say(T, { k: "result", title: "已转履约专责", lines: ["写入订单 4500953501 约谈提纲和归档材料", "约谈结果出来后推送给你"] });
          L6.end(T);
        }, 500);
        draw(T);
      }
    },
    end(T) {
      if (T.recv && T.fb) {
        T.done = true;
        finish(T.id, { status: "done", current: "收货确认和异常反馈已回传", remain: "已完成", log: "确认收货安排，反馈防火堵料对工期的影响" });
      }
    },
    input(T, t) {
      if (t.dataset.f) T.f[t.dataset.f] = t.value;
    },
    right(T) {
      if (T.tab === 1) {
        const sel = (i) => `<select class="sc-sel" data-f="r${i}" ${T.recv ? "disabled" : ""}>${["按原计划收货", "推迟到11月30日", "提前到11月5日"].map((x) => `<option ${(T.f[`r${i}`] || "按原计划收货") === x ? "selected" : ""}>${x}</option>`).join("")}</select>`;
        return page("收货确认", `11月16日交货 · ${pjRecv.length} 张订单 · 10月17日前确认，不确认视为按原计划`,
          tbl(["订单", "供应商", "物料", "行", "确定交货期", "供应商答复", "现场收货安排"], pjRecv.map((r, i) => [mono(r.订单), h(supName(r)), h(r.物料), String(r.行), h(r.交货期), h(r.答复 || "—"), sel(i)]), "sc-t-dense sc-t-pj") +
            `<div class="sc-foot">${T.recv ? "<span>已回传履约专责</span>" : `<span>确认后回传履约专责</span>${btn("提交收货确认", "s-l6-recv", "p")}`}</div>`);
      }
      if (T.tab === 2) {
        const inp = (k, ph) => `<input class="sc-in" data-f="${k}" value="${h(T.f[k] || "")}" placeholder="${h(ph)}" ${T.fb ? "disabled" : ""} />`;
        return page("供货异常", `需关注 ${pjRisk.length} 张订单 · 履约专责处置中`,
          tbl(["订单", "供应商", "物料", "确定交货期", "供应商答复", "级别", "处置进展"], pjRisk.map((r) => [mono(r.订单), h(supName(r)), h(r.物料), `${h(r.交货期)}${r.超期 ? `<br><b class="sc-red">已超 ${r.超期} 天</b>` : ""}`, r.答复 ? h(r.答复) : '<span class="sc-dim">未答复</span>', chip(r.级别, LVC[r.级别]), h(deal(r))]), "sc-t-dense sc-t-pj") +
            sec(`防火堵料（订单 ${MB.订单}）对工期的影响`, `<div class="sc-form"><label>最晚到货日期${inp("fbDate", "如 10月20日")}</label><label>对工程的影响${inp("fbWhy", "如 电缆沟封堵完成后才能送电")}</label></div>`) +
            `<div class="sc-foot">${T.fb ? "<span>已转履约专责，写入约谈材料</span>" : `<span>转给履约专责，写进约谈提纲</span>${btn("反馈给履约专责", "s-l6-fb", "p")}`}</div>`);
      }
      return pjProgress();
    },
  };

  /* 对话中发起：项目管理人员查物资进度 */
  const LP = {
    pane: "画布",
    tabs: ["项目物资进度"],
    init() {},
    bg: () => [],
    intro(T) {
      stream(T, "查询", [
        { a: "查数据", t: `项目 ${PJ.编号} 的采购订单 ${PJ.订单} 张、${PJ.行} 行`, from: "ERP 项目信息、ECP 供应计划", cap: "查询" },
        { a: "查数据", t: "供应商问询和催货答复、履约管控级别", from: "e物资、工作台履约分级", cap: "查询" },
      ], () => say(T, { k: "ai", html: `${h(pjShort)}：已验收 ${PJ.状态.已验收} 张，待交货 ${PJ.状态.待交货} 张（都已超期），已确认 ${PJ.状态.已确认} 张 11 月 16 日交货。没给发货日期的 ${pjRisk.length} 张，履约专责在跟：${pjCount("提级管控")} 张提级管控，防火堵料 1 张 ${G.l4 ? "10 月 17 日约谈" : "拟 10 月 17 日约谈"}。明细在右侧。` }), 450);
    },
    right: () => pjProgress(),
  };

  /* ---------- 注册 ---------- */

  window.SCENES = { W1, W1V, W2, W3, W4, W5, W6, W6B, W7, L1, L2, L3, L4, L5, L6, CZ, CQ, CW, LW, LP };
  const focus = window.homeBriefFocusItems || [];
  ITEMS.forEach((it) => {
    const S = window.SCENES[it.id];
    EM.register(it.id, { mode: "scene", who: it.who, tabs: S.tabs, why: "" });
    if (!focus.some((x) => x.id === it.id)) focus.push(it);
  });
  const CHAT = {
    CZ: { who: "C", title: "库龄超期物资周报", object: "对话组装场景" },
    CQ: { who: "C", title: "资源池库龄分布", object: "查询" },
    CW: { who: "C", title: "10月库存消纳情况", object: "写材料" },
    LW: { who: "F", title: "10月订单问询与催货情况", object: "写材料" },
    LP: { who: "G", title: "项目物资进度", object: "查询" },
  };
  Object.entries(CHAT).forEach(([id, c]) => {
    EM.register(id, { mode: "chat", who: c.who, tabs: window.SCENES[id].tabs }, { id, title: c.title, object: c.object, current: "对话中", deadline: "—", remain: "—", risk: "—", status: "running" });
  });

  /* 对话中发起：按输入判断进入哪一段 */
  window.SCENE_ROUTE = (v, who) => {
    if (who === "C") {
      if (/(每周|每天|每月|定时|推给我|发给我|提醒我)/.test(v) && /(库龄|超期|消纳|积压)/.test(v)) return "CZ";
      if (/(写|起草|生成|整理)/.test(v) && /(月报|简报|报告|材料|情况)/.test(v)) return "CW";
      if (/库龄/.test(v)) return "CQ";
    }
    if (who === "F" && /(写|起草|生成|整理)/.test(v) && /(简报|报告|材料|月报|周报|情况)/.test(v)) return "LW";
    if (who === "G" && /(物资|到货|进度|到哪|订单|供货)/.test(v)) return "LP";
    return "";
  };

  /* 市北、市区账号不显示省公司应急提醒卡 */
  const mark = () => document.body.classList.toggle("sc-acct", /^[C-G]$/.test(window.execWho ? window.execWho() : "A"));
  document.addEventListener("click", (ev) => ev.target.closest && ev.target.closest("[data-em-who]") && setTimeout(mark, 0), true);
  mark();
  EM.refreshHome();
})();
