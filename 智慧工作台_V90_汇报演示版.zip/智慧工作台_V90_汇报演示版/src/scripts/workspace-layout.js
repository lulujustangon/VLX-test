/* Source runtime block 30 id="canvaslayoutRuntime" */
!(function () {
        const t = "供应链智慧工作台";
        document.title = t;
        function e() {
          const t = document.getElementById("view-chat") || document.body;
          let e = document.getElementById("processreviewRecapAnchor");
          (e ||
            ((e = document.createElement("div")),
            (e.id = "processreviewRecapAnchor"),
            (e.className = "processreview-recap-anchor"),
            t.appendChild(e)),
            "1" !== e.dataset.canvaslayout &&
              ((e.innerHTML =
                '<div class="processreview-recap-anchor-card"><div class="processreview-recap-anchor-icon">✓</div><div class="processreview-recap-anchor-copy"><strong>今日复盘已生成</strong><span>今天完成12项工作，3项明日继续跟踪。辛苦啦。</span></div><button data-processreview-open-recap>查看总结</button></div>'),
              (e.dataset.canvaslayout = "1")));
          let n = document.getElementById("processreviewRecapOverlay");
          (n ||
            ((n = document.createElement("div")),
            (n.id = "processreviewRecapOverlay"),
            (n.className = "processreview-recap-overlay"),
            document.body.appendChild(n)),
            "1" !== n.dataset.canvaslayout &&
              ((n.innerHTML =
                '<section class="processreview-recap-modal" role="dialog" aria-modal="true" aria-label="今日复盘"><div class="processreview-recap-top"><span>17:00 · 今日复盘</span><h2>今天完成了这些工作</h2><p>重点工作、日常办理和协同进展已经汇总。</p></div><div class="processreview-recap-body"><div class="processreview-recap-metrics"><div class="processreview-recap-metric"><b>12</b><span>今日完成事项</span></div><div class="processreview-recap-metric"><b>2</b><span>重点事项闭环</span></div><div class="processreview-recap-metric"><b>3</b><span>协同事项推进</span></div></div><div class="processreview-recap-list"><div class="processreview-recap-item"><i>✓</i><div><strong>重点工作已完成</strong><p>迎峰度夏采购流标加急方式已确认，主变压器订单超期事项已发起升级督办。</p></div></div><div class="processreview-recap-item"><i>✓</i><div><strong>日常事项已推进</strong><p>完成6项业务办理、3项跨单位协同和1项应急保障方案确认。</p></div></div><div class="processreview-recap-item"><i>→</i><div><strong>明日继续关注</strong><p>1项供应商交期、1项采购审批和1项重点物资到货将继续跟踪。</p></div></div></div><div class="processreview-recap-cheer">今天的重点工作已经基本完成，辛苦啦。明天优先关注供应商交期确认和重点物资到货情况。</div><div class="processreview-recap-actions"><button data-processreview-recap-chat>进入复盘对话</button><button class="primary" data-processreview-close-recap>知道了</button></div></div></section>'),
              (n.dataset.canvaslayout = "1")),
            document.getElementById("briefnavRecapNudge")?.remove());
        }
        ((window.processreviewEnsureRecapUI = e), e());
        let n = 0;
        function a() {
          if (n) return n;
          try {
            return (
              Number(localStorage.getItem("canvaslayout-emergency-canvas-width")) || 0
            );
          } catch (t) {
            return 0;
          }
        }
        function s(t) {
          const e = Math.max(0, t.getBoundingClientRect().width),
            n = e < 1080 ? 280 : 320;
          return {
            total: e,
            minCanvas: 360,
            maxCanvas: Math.max(360, Math.min(0.82 * e, e - n - 16)),
          };
        }
        function c(t, e) {
          const n = s(t);
          return Math.max(n.minCanvas, Math.min(n.maxCanvas, e));
        }
        function i(t) {
          const e = s(t);
          return c(t, Math.round(0.52 * e.total));
        }
        function r(t, e, s = !1) {
          if (!t) return 0;
          const r = c(t, e || a() || i(t));
          return (
            t.style.setProperty("--canvaslayout-canvas-width", `${Math.round(r)}px`),
            t.classList.toggle("canvaslayout-canvas-compact", r < 470),
            s &&
              (function (t) {
                n = Math.round(t);
                try {
                  localStorage.setItem("canvaslayout-emergency-canvas-width", String(n));
                } catch (t) {}
              })(r),
            r
          );
        }
        let o = !1;
        function v() {
          o ||
            ((o = !0),
            requestAnimationFrame(() => {
              ((o = !1),
                (function () {
                  const t = document.getElementById("emergencyEmergencyWorkspace");
                  if (!t) return;
                  document
                    .querySelectorAll(".demohint-demo-note")
                    .forEach((t) => t.remove());
                  const e =
                      "undefined" != typeof state && state
                        ? state.emergencyThread
                        : null,
                    n = t.querySelector(".emergency-thread-title span"),
                    s =
                      ((c = e),
                      {
                        E001: window.__v91Sub || "23条物资 · 3项待确认", /* V91：随应急执行进度更新，见 v90.js syncMeta */
                        E002: "8条物资 · 1项待确认",
                        E003: "18条物资 · 寻源中",
                        E006: "需求解析中",
                      }[c] || "");
                  var c;
                  n && s && (n.textContent = s);
                  const o = t.querySelector(".emergency-center-welcome p");
                  o && (o.textContent = "选择左侧任务，查看进度并继续处理。");
                  const v = t.querySelector(":scope > .emergency-canvas-column"),
                    d = t.querySelector(":scope > .emergency-chat-column");
                  if (
                    !(
                      window.innerWidth > 820 &&
                      t.classList.contains("canvas-open") &&
                      !t.classList.contains("canvas-full") &&
                      v &&
                      d
                    )
                  )
                    return (
                      t.classList.remove("canvaslayout-resizable", "canvaslayout-resizing"),
                      void t
                        .querySelectorAll(":scope > .canvaslayout-canvas-splitter")
                        .forEach((t) => t.remove())
                    );
                  let l = t.querySelector(":scope > .canvaslayout-canvas-splitter");
                  l
                    ? l.nextElementSibling !== v && t.insertBefore(l, v)
                    : ((l = document.createElement("div")),
                      (l.className = "canvaslayout-canvas-splitter"),
                      (l.dataset.canvaslayoutSplitter = "1"),
                      (l.innerHTML =
                        '<div class="canvaslayout-splitter-knob"><span class="canvaslayout-splitter-dots"></span><span class="canvaslayout-splitter-text">拖动</span></div>'),
                      (l.title = "左右拖动调整宽度，双击恢复默认"),
                      l.setAttribute("role", "separator"),
                      l.setAttribute("aria-orientation", "vertical"),
                      l.setAttribute("aria-label", "调整对话与业务画布宽度"),
                      t.insertBefore(l, v));
                  if (
                    (t.classList.add("canvaslayout-resizable"),
                    !t.classList.contains("canvaslayout-resizing"))
                  ) {
                    const e =
                      parseFloat(
                        t.style.getPropertyValue("--canvaslayout-canvas-width"),
                      ) || 0;
                    r(t, e || a() || i(t), !1);
                  }
                })());
            }));
        }
        const d = window.emergencyRender;
        "function" == typeof d &&
          (window.emergencyRender = function () {
            const t = d.apply(this, arguments);
            return (v(), setTimeout(v, 40), t);
          });
        const l = document.getElementById("view-emergency");
        if (l) {
          (new MutationObserver(v).observe(l, {
            childList: !0,
            subtree: !0,
            attributes: !0,
            attributeFilter: ["class"],
          }),
            l.addEventListener("click", () => setTimeout(v, 0), !0));
        }
        let u = null;
        function p(t) {
          if (!u) return;
          t.cancelable && t.preventDefault();
          const e = u.startWidth - (t.clientX - u.startX);
          r(u.root, e, !1);
        }
        function m() {
          if (!u) return;
          const t =
            parseFloat(
              getComputedStyle(u.root).getPropertyValue("--canvaslayout-canvas-width"),
            ) || i(u.root);
          (r(u.root, t, !0),
            u.root.classList.remove("canvaslayout-resizing"),
            document.body.classList.remove("canvaslayout-resizing"),
            (u = null));
        }
        (document.addEventListener(
          "pointerdown",
          function (t) {
            const e = t.target.closest?.("[data-canvaslayout-splitter]");
            e &&
              (t.preventDefault(),
              t.stopPropagation(),
              (function (t, e) {
                const n = e.closest(".emergency-agentos");
                if (!n) return;
                const a = n.querySelector(":scope > .emergency-canvas-column");
                ((u = {
                  root: n,
                  startX: t.clientX,
                  startWidth: a?.getBoundingClientRect().width || i(n),
                }),
                  n.classList.add("canvaslayout-resizing"),
                  document.body.classList.add("canvaslayout-resizing"));
              })(t, e));
          },
          !0,
        ),
          document.addEventListener("pointermove", p, {
            capture: !0,
            passive: !1,
          }),
          document.addEventListener("mousemove", p, {
            capture: !0,
            passive: !1,
          }),
          document.addEventListener("pointerup", m, !0),
          document.addEventListener("mouseup", m, !0),
          window.addEventListener("blur", m),
          document.addEventListener(
            "dblclick",
            function (t) {
              const e = t.target.closest?.("[data-canvaslayout-splitter]");
              if (!e) return;
              (t.preventDefault(), t.stopPropagation());
              const n = e.closest(".emergency-agentos");
              r(n, i(n), !0);
            },
            !0,
          ),
          window.addEventListener(
            "resize",
            function () {
              const t = document.getElementById("emergencyEmergencyWorkspace");
              t?.classList.contains("canvaslayout-resizable") && r(t, a() || i(t), !1);
            },
            { passive: !0 },
          ),
          setTimeout(function () {
            ((document.title = t), e(), v());
          }, 80));
      })();

/* Source runtime block 31 id="currentstateRuntime" */
!(function () {
        document.title = "供应链智慧工作台";
        const t = document.getElementById("sidebar"),
          e = document.getElementById("collapseSidebar");
        function n() {
          if (!t || !e) return;
          const n = t.classList.contains("collapsed");
          ((e.title = n ? "展开侧栏" : "收起侧栏"),
            e.setAttribute("aria-label", n ? "展开侧栏" : "收起侧栏"),
            e.setAttribute("aria-expanded", n ? "false" : "true"));
        }
        (n(),
          t &&
            new MutationObserver(function () {
              (n(),
                requestAnimationFrame(function () {
                  window.dispatchEvent(new Event("resize"));
                }));
            }).observe(t, { attributes: !0, attributeFilter: ["class"] }),
          e?.addEventListener(
            "click",
            function () {
              requestAnimationFrame(n);
            },
            !0,
          ));
      })();
